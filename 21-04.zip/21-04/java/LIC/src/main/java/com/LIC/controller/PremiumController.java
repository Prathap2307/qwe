package com.LIC.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.ErrorDto;
import com.LIC.model.Premium;
import com.LIC.model.PremiumPaymentFrequency;
import com.LIC.model.PremiumType;
import com.LIC.service.ILoadingAndDiscountService;
import com.LIC.service.IPaymentFrequencyService;
import com.LIC.service.IPremiumPaymentFrequencyService;
import com.LIC.service.IPremiumService;
import com.LIC.service.PremiumDetailsMapService;

@RestController
@RequestMapping("/configuration")
public class PremiumController {
	
	@Autowired(required=true)
	ILoadingAndDiscountService loadingAndDiscountService;
	
	@Autowired(required=true)
	IPremiumService premiumService;
	
	@Autowired(required=true)
	IPremiumPaymentFrequencyService premiumPaymentFrequencyService;
	
	@Autowired(required=true)
	PremiumDetailsMapService premiumDetailsMapService;
	
	@Autowired(required=true)
	IPaymentFrequencyService paymentFrequencyService;
	
	@RequestMapping(value = "/premium-payment-frequency/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdatePremiumPaymentFrequency(@RequestBody PremiumPaymentFrequency premiumPaymentFrequency) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == premiumPaymentFrequency) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != premiumPaymentFrequency.getId()) {
			premiumPaymentFrequency.setModifiedOn(new Date());
			premiumPaymentFrequency.setModifiedBy(1);
			premiumPaymentFrequency.setIsActive(1);
		}else {
			premiumPaymentFrequency.setId(0); 
			premiumPaymentFrequency.setCreatedOn(new Date());
			premiumPaymentFrequency.setIsActive(1);
		}
		premiumPaymentFrequencyService.saveOrUpdate(premiumPaymentFrequency);
		response.put("status", 1);
		if(premiumPaymentFrequency != null && premiumPaymentFrequency.getId() > 0) {
			response.put("message","Premium Payment Frequency updated successfully");
		}else {
			response.put("message","Premium Payment Frequency created successfully");
		}
		
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/premium-payment-frequency/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deletePremmiumPaymentFrequency(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Premium Payment Frequency ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PremiumPaymentFrequency obj = premiumPaymentFrequencyService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Premium Payment Frequency ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		premiumPaymentFrequencyService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/premium-payment-frequency/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllPremmiumPaymentFrequency() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PremiumPaymentFrequency> premiumPaymentFrequencyList = premiumPaymentFrequencyService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("premiumPaymentFrequencyList",premiumPaymentFrequencyList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/premium-payment-frequency/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getPremmiumPaymentFrequency(@PathVariable Integer id) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Premium Payment Frequency ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PremiumPaymentFrequency premiumPaymentFrequencyObj = premiumPaymentFrequencyService.get(id);
		if(null == premiumPaymentFrequencyObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Premium Payment Frequency ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("premiumPaymentFrequencyObj", premiumPaymentFrequencyObj); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/premium-payment-frequency/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchPremmiumPaymentFrequency(@RequestBody PremiumPaymentFrequency filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PremiumPaymentFrequency> list = premiumPaymentFrequencyService.getAll(filterObj);
		List<PremiumPaymentFrequency> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(null != filterObj.getPlanID() ) {
	                		 if(null != filterObj.getPremPaymentFrequencyID()) {
	                			 if (p.getPlanID().equals(filterObj.getPlanID()) && p.getPremPaymentFrequencyID().equals(filterObj.getPremPaymentFrequencyID())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (p.getPlanID().equals(filterObj.getPlanID())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(null != filterObj.getPremPaymentFrequencyID()){
	                		 if (p.getPremPaymentFrequencyID().equals(filterObj.getPremPaymentFrequencyID())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/premium/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdatePremium(@RequestBody Premium premium) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == premium) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != premium.getId()) {
			premium.setIsActive(1);
		}else {
			premium.setProcessID(1);
			premium.setId(0);
			premium.setIsActive(1);
		}
		premium.setProcessID(0);
		premiumService.saveOrUpdate(premium);
		response.put("status", 1);
		response.put("message","Premium updated successfully.");
		return ResponseEntity.accepted().body(response);
	}
	 
	
	@RequestMapping(value = "/premium/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deletePremmium(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Premium ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Premium obj = premiumService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Premium ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		premiumService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/premium/get/{variantId}/{premiumTypeId}/{coverageId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllPremmium(@PathVariable Integer variantId, @PathVariable Integer premiumTypeId,@PathVariable Integer coverageId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("status", 1);
		response.put("message","Success");
		List<Premium> filteredList = premiumService.getAll(null);
		response.put("list", filteredList); 
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/premium/get", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> getAllPremmiumWithFilter(@RequestBody Premium filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("status", 1);
		response.put("message","Success");
		List<Premium> filteredList = premiumService.getAll(filterObj);
		response.put("list", filteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/premium/get/{premiumId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getPremmium(@PathVariable Integer premiumId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		Premium premium = premiumService.get(premiumId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", premium); 
		return ResponseEntity.accepted().body(response);
	}
	
	 
	@RequestMapping(value = "/product-premium-type/get/{variantId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllProductPremiumList(@PathVariable Integer variantId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PremiumType> variantList = premiumService.getPreimumTypeByBusinessId(1, variantId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("productTypeList", variantList); 
		return ResponseEntity.accepted().body(response);
	}
}

package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.AccountingProcessDAO;
import com.LIC.model.AccountingProcessModel;
import com.LIC.model.GetAllGSTTypeModel;

@RestController
public class AccountingProcessController {

	@Autowired

	private AccountingProcessDAO accountingProcessDAO;

	@PostMapping("/createAccount")
	public int createAccountProcessInfo(@RequestBody AccountingProcessModel model) {
		return accountingProcessDAO.createAccountProcessInfo(model);

	}

	@GetMapping("/CheckDuplicateAccountProcess")
	public String getDuplicateAccountingProcess(@RequestBody AccountingProcessModel model) {
		return accountingProcessDAO.getDuplicateAccountingProcess(model);
	}

	@GetMapping("/SearchAccountProcess/{accountProcessID}/{code}/{groupName}")
	public List<AccountingProcessModel> searchAccountingProcess(@PathVariable int accountProcessID,
			@PathVariable int code, @PathVariable int groupName) {
		return accountingProcessDAO.searchAccountingProcess(accountProcessID, code, groupName);
	}

	
	  @GetMapping("/GetAcccountProcess")
	  
	  public List<AccountingProcessModel> getAllAccountingProcess() { 
		  return accountingProcessDAO.getAllAccountingProcess(); }
	  
	  @GetMapping("/GetAllGSTType")
	  public List<GetAllGSTTypeModel> GetAllGSTType() { 
		  return accountingProcessDAO.GetAllGSTType(); }
	 
}

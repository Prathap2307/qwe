package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.AddressType;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class AddressTypeDAO implements IAddressTypeDAO {
	
	static final Logger LOGGER = LogManager.getLogger(AddressTypeDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(AddressType obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateAddressType(?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getAddressTypeID());
		  callableStatement.setString(2, obj.getDescription());
		  callableStatement.setInt(3, obj.getCreatedBy());
		  callableStatement.setString(4, obj.getRemarks());
		  callableStatement.registerOutParameter(5, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateAddressType executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateAddressType executed successfully.");
	}
	
	@Override
	public void delete(Integer addressTypeID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteAddressType(?,?,?); END;");
		  callableStatement.setInt(1, addressTypeID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteAddressType executed successfully.");
		  LOGGER.info("SP>spDeleteAddressType executed successfully.");
	} 
	
	@Override
	public List<AddressType> getAll(AddressType filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<AddressType> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllAddressType(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  AddressType obj = null;
			  list = new ArrayList<AddressType>();
		      while (rs.next()) {
		        obj = new AddressType();
		        obj.setAddressTypeID(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllAddressType executed successfully.");
			  LOGGER.info("SP>spGetAllAddressType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllAddressType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public AddressType get(Integer addressTypeID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  AddressType obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAddressType(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, addressTypeID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new AddressType();
		        obj.setAddressTypeID(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		      }
			  System.out.println("SP>spGetAddressType executed successfully.");
			  LOGGER.info("SP>spGetAddressType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAddressType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			   
		  }
		  return obj;
	} 
	 
}

package com.LIC.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ClaimsRegistrationModel;

@Repository
public class ClaimsRegistrationDao {

	@Autowired
	private EntityManager entityManager;

	public int getAllPendingClaims(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetAllPendingClaims")
				.registerStoredProcedureParameter("pLineOfBusinessID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pClaimNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pFirstName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pLastName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPolicyNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pContactID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pAgeing", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pStatusID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pAssessorID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pLineOfBusinessID", claimsRegistrationModel.getpLineOfBusinessID())
				.setParameter("pClaimNumber", claimsRegistrationModel.getpClaimNumber())
				.setParameter("pFirstName", claimsRegistrationModel.getpFirstName())
				.setParameter("pLastName", claimsRegistrationModel.getpLastName())
				.setParameter("pPolicyNumber", claimsRegistrationModel.getpPolicyNumber())
				.setParameter("pContactID", claimsRegistrationModel.getpContactID())
				.setParameter("pAgeing", claimsRegistrationModel.getpAgeing())
				.setParameter("pStatusID", claimsRegistrationModel.getpStatusID())
				.setParameter("pAssessorID", claimsRegistrationModel.getpAssessorID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int getAllCoveragesByClaimId(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spGetAllCoveragesByClaimID")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsRegistrationModel.getpClaimID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int getClaimDocumentsByClaimId(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spGetClaimDocumentsByClaimID")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsRegistrationModel.getpClaimID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}
	 
	public int getClaimDetailsByClaimId(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spGetClaimDetailsByClaimID")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsRegistrationModel.getpClaimID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}
		
	public int getClaimProductTransactionDetails(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spGetClaimProductTransactionDetails")
				.registerStoredProcedureParameter("pApplicationID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pProductID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pApplicationID", claimsRegistrationModel.getpApplicationID())
				.setParameter("pProductID", claimsRegistrationModel.getpProductID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}
	
	public int getClaimsDocument(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetClaimsDocument")
				.registerStoredProcedureParameter("pID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pID", claimsRegistrationModel.getpID());
		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}
	 
	public int getAssessmentHistory(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetAssessmentHistory")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsRegistrationModel.getpClaimID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}
	
	public int isClaimExistOrNot(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("IsClaimExsistOrNot")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPolicyNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfLoss", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vLineOfBusinessID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vExistCount", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCount", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", claimsRegistrationModel.getvClaimID())
				.setParameter("vPolicyNumber", claimsRegistrationModel.getvPolicyNumber())
				.setParameter("vDateOfLoss", claimsRegistrationModel.getvDateOfLoss())
				.setParameter("vLineOfBusinessID", claimsRegistrationModel.getvLineOfBusinessID())
				.setParameter("vExistCount", claimsRegistrationModel.getvExistCount())
				.setParameter("pCount", claimsRegistrationModel.getpCount());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int insertOrUpdateClaimsRegistration(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spInsertOrUpdateClaimRegistration")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfLoss", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTimeOfLoss", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPlaceOfLoss", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vParticularsOfDeath", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDoctorNameAndAddress", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPartialAdvanceClaimPayment", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsAdditionalDcoument", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vStatusID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAssessmentRemarks", String.class, ParameterMode.IN)
				/*
				 * .registerStoredProcedureParameter("pApplicationID", Integer.class,
				 * ParameterMode.IN) .registerStoredProcedureParameter("pID", Integer.class,
				 * ParameterMode.IN) .registerStoredProcedureParameter("pCount", Integer.class,
				 * ParameterMode.IN)
				 */
				//.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
				.registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("vClaimID", claimsRegistrationModel.getvClaimID())
				.setParameter("vDateOfLoss", claimsRegistrationModel.getvDateOfLoss())
				.setParameter("vTimeOfLoss", claimsRegistrationModel.getvTimeOfLoss())
				.setParameter("vPlaceOfLoss", claimsRegistrationModel.getvPlaceOfLoss())
				.setParameter("vParticularsOfDeath", claimsRegistrationModel.getvParticularsOfDeath())
				.setParameter("vDoctorNameAndAddress", claimsRegistrationModel.getvDoctorNameAndAddress())
				.setParameter("vPartialAdvanceClaimPayment", claimsRegistrationModel.getvPartialAdvanceClaimPayment())
				.setParameter("vCreatedBy", claimsRegistrationModel.getvCreatedBy())
				.setParameter("vCreatedOn", claimsRegistrationModel.getvCreatedOn())
				.setParameter("vIsActive", claimsRegistrationModel.getvIsActive())
				.setParameter("vIsAdditionalDcoument", claimsRegistrationModel.getvIsAdditionalDcoument())
				.setParameter("vStatusID", claimsRegistrationModel.getvStatusID())
				.setParameter("vAssessmentRemarks", claimsRegistrationModel.getvAssessmentRemarks());
				/*.setParameter("pApplicationID", claimsRegistrationModel.getpApplicationID())
				.setParameter("pID", claimsRegistrationModel.getpID())
				.setParameter("pCount", claimsRegistrationModel.getpCount());*/
				//.setParameter("vResult", claimsRegistrationModel.getvResult());

		storedProcedureQuery.execute();
		/* return (int) storedProcedureQuery.getOutputParameterValue("vResult"); */
		return 1;
	}

	public int deleteClaimCoverageMap(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spDeleteClaimCoverageMap")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsRegistrationModel.getpClaimID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public void deleteClaimDocuments(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spDeleteClaimsDocuments")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				// .registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", claimsRegistrationModel.getvClaimID());

		storedProcedureQuery.execute();
	}
	
	public int insertClaimsCoverageMap(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spInsertClaimCoverageMap")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCoverageID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", claimsRegistrationModel.getvClaimID())
				.setParameter("vCoverageID", claimsRegistrationModel.getvCoverageID())
				.setParameter("vTypeID", claimsRegistrationModel.getvTypeID())
				.setParameter("pID", claimsRegistrationModel.getpID())
				.setParameter("vResult", claimsRegistrationModel.getvResult());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int insertClaimsProofOfDocument(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spInsertClaimsProofOfDocument")

				.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vImageName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsAdditionDocument", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", claimsRegistrationModel.getvClaimID())
				.setParameter("vDocumentTypeID", claimsRegistrationModel.getvDocumentTypeID())
				.setParameter("vDocumentNumber", claimsRegistrationModel.getvDocumentNumber())
				.setParameter("vImageName", claimsRegistrationModel.getvImageName())
				.setParameter("vIsAdditionDocument", claimsRegistrationModel.getvIsAdditionDocument())
				.setParameter("vIsActive", claimsRegistrationModel.getvIsActive())
				.setParameter("pID", claimsRegistrationModel.getpID())
				.setParameter("vResult", claimsRegistrationModel.getvResult());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int insertClaimsMandatoryDocumentMap(ClaimsRegistrationModel claimsRegistrationModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spInsertClaimsMandatoryDocumentMap")
				.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vImageName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsAdditionDocument", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", claimsRegistrationModel.getvClaimID())
				.setParameter("vDocumentTypeID", claimsRegistrationModel.getvDocumentTypeID())
				.setParameter("vDocumentNumber", claimsRegistrationModel.getvDocumentNumber())
				.setParameter("vImageName", claimsRegistrationModel.getvImageName())
				.setParameter("vIsAdditionDocument", claimsRegistrationModel.getvIsAdditionDocument())
				.setParameter("vIsActive", claimsRegistrationModel.getvIsActive())
				.setParameter("pID", claimsRegistrationModel.getpID())
				.setParameter("vResult", claimsRegistrationModel.getvResult());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}
	
	

	public int InsertClaimsBeneficiaryDetails(List<ClaimsRegistrationModel> claimsRegistrationModel) {
		int MapID=0;
		for (ClaimsRegistrationModel obj : claimsRegistrationModel) {
			System.out.println("test getBeneficiaryId");
			System.out.println(obj.getBeneficiaryId());
			  StoredProcedureQuery storedProcedureQuery = entityManager
	                  .createStoredProcedureQuery("spInsertClaimsBeneficiaryDetails")
	                  .registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vbeneficiaryID", Integer.class, ParameterMode.IN)
	                  
	                  .registerStoredProcedureParameter("vBeneficiaryName", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vClaimAmountShare", Integer.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vShare", Integer.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vEmailID", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vContactNo", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vAccountNo", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vBankName", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vAccountTypeID", Integer.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vIFSCCode", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vRelationshipID", Integer.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vAccountHolderName", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vCreatedOn", String.class, ParameterMode.IN)
	                  .registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
	
                      .setParameter("vClaimID", obj.getClaimId())
                      .setParameter("vbeneficiaryID", obj.getBeneficiaryId())
                      .setParameter("vBeneficiaryName", obj.getBeneficiaryName())
                      .setParameter("vClaimAmountShare", obj.getClaimAmountShare())
                      .setParameter("vShare", obj.getShares())
                      .setParameter("vEmailID", obj.getEmailID())
                      .setParameter("vContactNo", obj.getContactNo())
                      .setParameter("vAccountNo", obj.getAccountNo())
                      .setParameter("vBankName", obj.getBankName())
                      .setParameter("vAccountTypeID", obj.getAccountTypeID())
                      .setParameter("vIFSCCode", obj.getIfscCode())
                      .setParameter("vRelationshipID", obj.getRelationshipID())
                      .setParameter("vAccountHolderName", obj.getAccountHolderName())
                      .setParameter("vCreatedBy", obj.getCreatedBy())
                      .setParameter("vCreatedOn", obj.getCreatedOn());

			  		storedProcedureQuery.execute();
	   
			  		MapID =  (int) storedProcedureQuery.getOutputParameterValue("vResult");    
			}
		
		
		  return MapID;    
	
	       }
	
	
	}
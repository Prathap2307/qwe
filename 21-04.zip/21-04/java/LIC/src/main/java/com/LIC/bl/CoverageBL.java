package com.LIC.bl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.LIC.constant.Constant;
import com.LIC.model.CoverageExclusionNewModal;
import com.LIC.model.CoverageModal;
import com.LIC.model.CoverageUINMapModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

public class CoverageBL {
	
	private static final Logger logger = Logger.getLogger(CoverageBL.class);
	
	@SuppressWarnings("unchecked")
	public CoverageModal createCoverageModalDto(ValueObject object, ValueObject outObject) throws Exception {
		
		ValueObject 				objectMapper 			= null;
		CoverageModal 				coverageinfo 			= null;
		CoverageUINMapModal		 	coverageUINMapInfo		= null;
		List<Object>				coverageUINObject		= null;
		List<CoverageUINMapModal> 	coverageUINMapModalList	= null;
		List<Object>				exclusionObjectList		= null;
		List<CoverageExclusionNewModal> coverageExclusionNewModalList = null;
		CoverageExclusionNewModal coverageExclusionNewModal 	= null;
		
		try {
			
			coverageinfo = new CoverageModal();
			
			coverageinfo.setCoverageID(object.getLong("coverageID",0));
			coverageinfo.setTypeofCoverID(object.getLong("typeofCoverId",0));
			coverageinfo.setCalculationID(object.getLong("calculationId",0));
			coverageinfo.setCalculationID(object.getLong("coverageId",0));
			if(object.getString("coverageName", "").equals("")) {
				outObject.put(Constant.ERROR, "Coverage Name Should not null !");
			}
			coverageinfo.setCoverageName(object.getString("coverageName", ""));
			coverageinfo.setCoverCode(object.getString("coverCode",""));
			coverageinfo.setCalculationName(object.getString("calculationName",""));
			coverageinfo.setDescription(object.getString("description",""));
			coverageinfo.setTypeOfCover(object.getString("typeOfCover",""));
			coverageinfo.setIsStampDutyApplicable(object.getShort("isStampDutyApplicable",(short)0));
			coverageinfo.setStamDutyType(object.getInt("stamdutyType",0));
			coverageinfo.setStampDutyRate(object.getDouble("stampDutyRate",0));
			coverageinfo.setProductId(object.getLong("productId",0));
			coverageinfo.setIsBaseCoverage(object.getShort("isBaseCoverage", (short)0));
			coverageinfo.setIsSelectable(object.getShort("isSelectable", (short)0));
			coverageinfo.setCoverageMaxSumAssured(object.getDouble("coverageMaxSumAssured",0));
			coverageinfo.setHouseHoldLimitPerYear(object.getDouble("houseHoldLimitPerYear",0));
			coverageinfo.setPackageID(object.getDouble("packageID",0));
			coverageinfo.setPackages(object.getString("packages",""));
			coverageinfo.setPackageRate(object.getDouble("packageRate",0));
			coverageinfo.setSectionID(object.getLong("sectionID",0));
			coverageinfo.setType(object.getInt("type",0));
			coverageinfo.setAmountPercentage(object.getDouble("AmountPercentage",0));
			coverageinfo.setProductTypeID(object.getLong("productTypeID",0));
			coverageinfo.setInsurerID(object.getLong("insurerID",0));
			coverageinfo.setInsurerName(object.getString("insurerName",""));
			coverageinfo.setLineOfBusinessID(object.getLong("lineOfBusinessID",0));
			coverageinfo.setCreatedBy(object.getLong("createdBy",0));
			coverageinfo.setIsActive(object.getShort("isActive",(short)1));
			
			if(object.get("effectiveTo") != null && !object.get("effectiveTo").equals("")) {
				coverageinfo.setEffectToDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("effectiveTo")));
			} else {
				coverageinfo.setEffectToDate(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("effectiveFrom") != null && !object.get("effectiveFrom").equals("")) {
				coverageinfo.setEffectFromDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("effectiveFrom")));
			} else {
				coverageinfo.setEffectFromDate(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("createdOn") != null && !object.get("createdOn").equals("")) {
				coverageinfo.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				coverageinfo.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			
			coverageUINObject		= (List<Object>) object.get("uinMapDetails",null);
			
			if(coverageUINObject != null) {
				
				coverageUINMapModalList	= new ArrayList<CoverageUINMapModal>();
				
				for(Object obj : coverageUINObject) {
					
					objectMapper	= new ValueObject((HashMap<Object, Object>) obj);
					if(objectMapper != null) {
						
						coverageUINMapInfo	= createCoverageUINMapModalDto((ValueObject) objectMapper, outObject);
						coverageUINMapModalList.add(coverageUINMapInfo);
					}
				}
			}
			
			coverageinfo.setCoverageUINMapModalList(coverageUINMapModalList);
			
			exclusionObjectList		= (List<Object>) object.get("exclusion",null);
			
			if(exclusionObjectList != null) {
				
				coverageExclusionNewModalList	= new ArrayList<CoverageExclusionNewModal>();
				objectMapper			= null;
				
				for(Object obj : exclusionObjectList) {
					coverageExclusionNewModal 	= null;
					objectMapper	= new ValueObject((HashMap<Object, Object>) obj);
					if(objectMapper != null) {
						coverageExclusionNewModal = createCoverageExclusionNewModal((ValueObject) objectMapper, outObject);
						coverageExclusionNewModalList.add(coverageExclusionNewModal);
					}
				}
				coverageinfo.setCoverageExclusionNewModalList(coverageExclusionNewModalList);	
			}		
		
			return coverageinfo;	
		} catch(Exception e) {
			e.printStackTrace();
			outObject.put(Constant.ERROR, e.getLocalizedMessage());
			logger.info("error :"+e.getLocalizedMessage());
		}
		
		return null;
	}
	
	public CoverageUINMapModal createCoverageUINMapModalDto(ValueObject object, ValueObject outObject)throws Exception {
		
		try {
			CoverageUINMapModal coverageUINMapInfo = new CoverageUINMapModal();
			
			coverageUINMapInfo.setUinID(object.getLong("uinID",0));
			coverageUINMapInfo.setCoverageID(object.getLong("coverageID",0));
			if(object.getString("uinNumber") == null || object.getString("uinNumber").equals("")) {
				outObject.put(Constant.ERROR, "UIN Number can not be null or empty !");
			}
			coverageUINMapInfo.setUinNumber(object.getString("uinNumber",""));
			coverageUINMapInfo.setVersionNo(object.getString("versionNo",""));
			coverageUINMapInfo.setDescription(object.getString("description",""));
			coverageUINMapInfo.setMaximumMaturityAge(object.getLong("maximumMaturityAge",0));
			coverageUINMapInfo.setMaximumMaturityAgeType(object.getInt("maximumMaturityAgeType",0));
			
			if(object.get("uinEffectiveFrom") != null && !object.get("uinEffectiveFrom").equals("")) {
				coverageUINMapInfo.setUinEffectiveFrom((Timestamp) DateTimeUtility.getTimeStamp(object.getString("uinEffectiveFrom")));
			} else {
				coverageUINMapInfo.setUinEffectiveFrom(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("uinEffectiveTo") != null  && !object.get("uinEffectiveTo").equals("")) {
				coverageUINMapInfo.setUinEffectiveTo((Timestamp) DateTimeUtility.getTimeStamp(object.getString("uinEffectiveTo")));
			} else {
				coverageUINMapInfo.setUinEffectiveTo(new Timestamp(System.currentTimeMillis()));
			}
			coverageUINMapInfo.setMinimumEntryAge(object.getLong("minimumEntryAge",0));
			coverageUINMapInfo.setMinimumEntryAgeType(object.getInt("minimumEntryAgeType",0));
			
			coverageUINMapInfo.setMaximumEntryAge(object.getLong("maximumEntryAge",0));
			coverageUINMapInfo.setMaximumEntryAgeType(object.getInt("maximumEntryAgeType",0));
			
			coverageUINMapInfo.setMinimumSumAssured(object.getDouble("minimumSumAssured",0));
			coverageUINMapInfo.setMinimumSumAssuredType(object.getInt("minimumSumAssuredType",0));
			
			coverageUINMapInfo.setMaximumSumAssured(object.getLong("maximumSumAssured",0));
			coverageUINMapInfo.setMaximumSumAssuredType(object.getInt("maximumSumAssuredType",0));
			
			coverageUINMapInfo.setMinimumFreeCoverLimit(object.getDouble("minimumFreeCoverLimit",0));
			coverageUINMapInfo.setMaximumFreeCoverLimit(object.getDouble("maximumFreeCoverLimit",0));
			
			coverageUINMapInfo.setIsActive(object.getShort("isActive", (short)1));
			
			/*if(object.get("createdOn") != null) {
				coverageUINMapInfo.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				coverageUINMapInfo.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}*/
			
			return coverageUINMapInfo;
		} catch(Exception e) {
			e.printStackTrace();
			outObject.put(Constant.ERROR, e.getLocalizedMessage());
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	
public CoverageExclusionNewModal createCoverageExclusionNewModal(ValueObject object, ValueObject outObject)throws Exception {
	CoverageExclusionNewModal coverageExclusionNewModal = null;
		try {
			coverageExclusionNewModal = new CoverageExclusionNewModal();
			
			coverageExclusionNewModal.setCoverageID(object.getLong("coverageID",0));
			/*if(object.getString("description") == null || object.getString("description").equals("")) {
				outObject.put(Constant.ERROR, "Exclusion can not be null or empty !");
			}*/
			
			coverageExclusionNewModal.setDescription(object.getString("description",""));
			coverageExclusionNewModal.setIsActive(object.getShort("isActive", (short)1));
			coverageExclusionNewModal.setCreatedBy(object.getLong("createdBy",0));
			coverageExclusionNewModal.setCoverageExclusionID(object.getLong("coverageExclusionID",0));
			
			if(object.get("createdOn") != null && !object.get("createdOn").equals("")) {
				coverageExclusionNewModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				coverageExclusionNewModal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			
			return coverageExclusionNewModal;
		} catch(Exception e) {
			e.printStackTrace();
			outObject.put(Constant.ERROR, e.getLocalizedMessage());
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
}

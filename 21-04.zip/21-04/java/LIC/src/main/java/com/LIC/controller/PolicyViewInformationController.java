package com.LIC.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.PolicyDetailsDAO;
import com.LIC.dao.PolicyViewInformationDAO;
import com.LIC.dao.PolicyViewInformationSearchModel;
import com.LIC.model.PolicyViewInformationModel;
import com.itextpdf.text.DocumentException;

@RestController
public class PolicyViewInformationController {
	
	@Autowired
	private PolicyViewInformationDAO pvi;
	@Autowired
	private PolicyDetailsDAO PDtl;
	
	@RequestMapping(path = "/Groupsearch", method = RequestMethod.POST)
	public List<PolicyViewInformationModel> AllGroupSearch(@RequestBody PolicyViewInformationModel model) {
		return	pvi.GetAllGroupDetailsSearch(model);
	}
	@RequestMapping(path = "/Membersearch", method = RequestMethod.POST)
	public List<PolicyViewInformationSearchModel> AllMemberSearch(@RequestBody PolicyViewInformationModel model) {
		return	pvi.GetAllMemberDetailsSearch(model);
	}

   @GetMapping(value="/PolicyCertificatesdownload/{applicationId}")
	public String PolicyCertificatedownload(@PathVariable Integer applicationId) throws IOException, DocumentException
	{
		return PDtl.PolicyCertificatedownload(applicationId);
	}

}

package com.LIC.controller;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.MemberDeletionDAO;
import com.LIC.model.MemberDeletionModel;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
public class MemberDeletionController {
	@Autowired
	private MemberDeletionDAO deletion;
	
	@PostMapping ("/MemberDeletionUpload")
	public void ExcelUpload(@RequestBody MemberDeletionModel model)
	{
		try {
			
			deletion.BulkInsert(model);
			
		} 
		catch (Exception e) {
	}
	
	
	}
	@PostMapping ("/deletionValidateExcelFile")
    public String ValidateExcelFile(@RequestBody MemberDeletionModel NBmodel){
           try {
                  return deletion.ValidateExcelFile(NBmodel);
           } 
           catch (Exception e) {return "";}
    }
	
	@PostMapping(value = "/SaveUploadedFileDeletion")
	public MemberDeletionModel SaveUploadedFile(@RequestParam("file") MultipartFile file) throws IOException {
	       return deletion.SaveUploadedFile(file);
	}

}

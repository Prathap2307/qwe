package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.AddressStructureModel;
import com.LIC.model.GetAddressStructure;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleTypes;


@Repository
public class AddressStructureDAO {
	@Autowired	JdbcTemplate jdbcTemplate;
	private static final Logger logger = Logger.getLogger(AddressStructureDAO.class);
	
	@Autowired private EntityManager em;
	
	public List<GetAddressStructure> getAllAddressInfo() {
	    
	    
	    StoredProcedureQuery query = em
	                 .createStoredProcedureQuery("spGetAllAddressStructure")
	                 
	                 .registerStoredProcedureParameter(
	                     1,
	                     
	                     Class.class,
	                     ParameterMode.REF_CURSOR
	                 );
	                
	  //  return query.execute() ? query.getResultList() : null;
	    
	    List<Object[]> list  =  (List<Object[]>)query.getResultList();
	    List<GetAddressStructure> AddressList = list.stream().map(
	            o -> new GetAddressStructure((Number) o[0], (String) o[1])).collect(Collectors.toList());
	    
	   return AddressList;
	}
	
	
	
	
	
	public void createAddressStructure(AddressStructureModel model) {

		StoredProcedureQuery addAddressStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateAddressStructure");
		addAddressStoredProcedure.setParameter("vStructureID", model.getStructureId());
		addAddressStoredProcedure.setParameter("vDescription", model.getDescription());
		addAddressStoredProcedure.setParameter("vCreatedBy", model.getCreatedBy());
		addAddressStoredProcedure.setParameter("vCreatedOn", model.getCreatedOn());
		addAddressStoredProcedure.setParameter("visActive", 1);
		addAddressStoredProcedure.execute();
}
	
	
	public void deleteAddress(AddressStructureModel model) {

		StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteAddress");
		query.setParameter("vStructureID",model.getStructureId());
		
		query.setParameter("vDeletedBy",model.getDeletedBy());
		query.setParameter("vDeletedOn",model.getDeletedOn());
		query.getParameter("RESULT1");
        query.execute();
	}
	
	public String updateAddressStructure(long structureId,String description) throws Exception {
	    CallableStatement		cstm				= null;
		Connection 				conn 				= null;
	    
	    try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call SPUPDATEADDRESSSTRUCTURE(?,?,?)");
			 cstm.setString(1, description);
			 cstm.setLong(2, structureId);
			 cstm.registerOutParameter(3, OracleTypes.CURSOR);
			 cstm.executeUpdate();
			 
			 return "Successfully Updated.";
	    } catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e); 
		} finally {
		    cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		 }
		 return "Error";
	 }
	
	
}


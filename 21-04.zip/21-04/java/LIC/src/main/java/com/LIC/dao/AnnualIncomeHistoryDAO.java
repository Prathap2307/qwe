package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.AnnualIncomeHistory;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class AnnualIncomeHistoryDAO implements IAnnualIncomeHistoryDAO {

	static final Logger LOGGER = LogManager.getLogger(AnnualIncomeHistoryDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	 
	@Override
	public List<AnnualIncomeHistory> getAll(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<AnnualIncomeHistory> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllAnnualIncomeHistory(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  AnnualIncomeHistory obj = null;
			  list = new ArrayList<AnnualIncomeHistory>();
		      while (rs.next()) {
		        obj = new AnnualIncomeHistory();
		        obj.setHistoryId(rs.getInt("HISTORYID"));
		        obj.setAnnualIncomeID(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		         
		        obj.setCreatedBy(rs.getInt("CREATEDBY"));
		        if(null != rs.getString("CREATEDON") && !rs.getString("CREATEDON").isEmpty()) {
		        	obj.setCreatedOnStr(rs.getString("CREATEDON"));
		        }
		        
		        obj.setModifiedBy(rs.getInt("MODIFIEDBY"));
		        if(null != rs.getString("MODIFIEDON") && !rs.getString("MODIFIEDON").isEmpty()) {
		        	obj.setModifiedOnStr(rs.getString("MODIFIEDON"));
		        }
		        
		        obj.setDeletedBy(rs.getInt("DELETEDBY"));
		        if(null != rs.getString("DELETEDON") && !rs.getString("DELETEDON").isEmpty()) {
		        	obj.setDeletedOnStr(rs.getString("DELETEDON"));
		        }
		        obj.setIsActive(rs.getInt("ISACTIVE"));
		        obj.setRemarks(rs.getString("REMARKS"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllAnnualIncomeHistory executed successfully.");
			  LOGGER.info("SP>spGetAllAnnualIncomeHistory executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllAnnualIncomeHistory exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	}
	
}

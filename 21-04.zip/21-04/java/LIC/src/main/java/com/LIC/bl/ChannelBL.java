package com.LIC.bl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.LIC.constant.Constant;
import com.LIC.model.BranchModal;
import com.LIC.model.ChannelModal;
import com.LIC.model.SubChannelModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

public class ChannelBL  {
	
	private static final Logger logger = Logger.getLogger(ChannelBL.class);
	
	public ChannelModal createChannelInfoDto(ValueObject object) {
		
		try {
			
			ChannelModal		 channelModal	= new ChannelModal();
			 	
			channelModal.setChannelID(object.getLong("ChannelID",0));
			channelModal.setShortDescription(object.getString("shortDescription",""));
			channelModal.setDescription(object.getString("Description",""));
			channelModal.setChannelName(object.getString("ChannelName",""));
			channelModal.setChannelCode(object.getString("ChannelCode",""));
			channelModal.setCreatedBy(object.getLong("CreatedBy",0));
			channelModal.setDeletedBy(object.getLong("DeletedBy",0));
			channelModal.setIsActive(object.getShort("IsActive",(short)0));
			channelModal.setCategroyID(object.getLong("CategroyID",0));
			
			if(channelModal.getChannelName().equals("")) {
				channelModal.setChannelName(object.getString("Description",""));
			}
			if(channelModal.getChannelCode().equals("")) {
				channelModal.setChannelCode(object.getString("shortDescription",""));
			}
			
			if(object.get("DeletedOn") != null && !object.get("DeletedOn").equals("")) {
				channelModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("DeletedOn")));
			} 
			
			if(object.get("CreatedOn") != null && !object.get("CreatedOn").equals("")) {
				channelModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("CreatedOn")));
			} else {
				channelModal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
				
			 return channelModal;
		} catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public SubChannelModal createSubChannelInfoDto(ValueObject object, ValueObject valueOutObject) throws Exception {
		
		List<Object> 		branchIDs			= null;
		ValueObject			objectMapper		= null;
		SubChannelModal	 	channelModal 		= null;
		BranchModal	 		branchModal 		= null;
		List<BranchModal>	branchModalList		= null;
		try {
			
			channelModal	= new SubChannelModal();
			channelModal.setSubChannelID(object.getLong("SubChannelID",0));
			channelModal.setMainChannelID(object.getLong("MainChannelID",0));
			channelModal.setChannelName(object.getString("ChannelName",""));
			channelModal.setChannelCode(object.getString("ChannelCode",""));
			channelModal.setCreatedBy(object.getLong("CreatedBy",0));
			channelModal.setIsActive(object.getShort("IsActive",(short)0));
			channelModal.setBranchID(object.getLong("BranchID",0));
			System.out.println("object "+object);
			System.out.println("valueOutObject "+valueOutObject);
			System.out.println("channelModal.getBranchID() "+channelModal.getBranchID());
			if(channelModal.getBranchID() == 0 ) {
				branchIDs	=  (List<Object>) object.get("BranchID",null);
				System.out.println("branchIDs >>>>> "+branchIDs);
				if(branchIDs != null  && !branchIDs.isEmpty()) {
					branchModalList	= new ArrayList<BranchModal>();
					for(Object obj : branchIDs) {
						
						objectMapper = new ValueObject((HashMap<Object, Object>) obj);
						if(objectMapper != null && objectMapper.getLong("branchId",0) > 0) {
							branchModal 	= new BranchModal();
							branchModal.setBranchId(objectMapper.getLong("branchId"));
							
							if(objectMapper.get("createdOn") != null && !objectMapper.getString("createdOn").isEmpty() && objectMapper.containsKey("createdOn")) {
								branchModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(objectMapper.getString("CreatedOn")));
							} else {
								branchModal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
							}
							branchModalList.add(branchModal);
						}
						if(channelModal.getBranchID() == 0 && branchIDs != null && branchIDs.size() > 0) {
							channelModal.setBranchID(objectMapper.getLong("branchId",0));
						}
					}
				}
			}
			
			channelModal.setBranchModalList(branchModalList);
			channelModal.setIsCDAccount(object.getShort("IsCDAccount",(short)0));
			channelModal.setMobileNo(object.getString("MobileNo",""));
			channelModal.setEmail(object.getString("Email",""));
			channelModal.setTriggerLimit(object.getDouble("TriggerLimit",0));
			channelModal.setPolicyHolderCode(object.getString("PolicyHolderCode",""));
			channelModal.setIsPhysicalEntry(object.getShort("IsPhysicalEntry",(short)0));
			channelModal.setIsBlanket(object.getShort("IsBlanket",(short)0));
			channelModal.setIsChildrenAccess(object.getShort("IsChildrenAccess",(short)0));
			channelModal.setDeletedBy(object.getLong("DeletedBy",0));
			channelModal.setCategroyID(object.getLong("CategroyID",0));
			
			if(object.get("DeletedOn") != null && !object.get("DeletedOn").equals("")) {
				channelModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("DeletedOn")));
			} 
			
			if(object.get("CreatedOn") != null && !object.getString("CreatedOn").isEmpty() && object.containsKey("CreatedOn")) {
				channelModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("CreatedOn")));
			} else {
				channelModal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			
			return channelModal;
		} catch (Exception e) {
			e.printStackTrace();
			valueOutObject.put(Constant.ERROR, e.getLocalizedMessage());
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	

}



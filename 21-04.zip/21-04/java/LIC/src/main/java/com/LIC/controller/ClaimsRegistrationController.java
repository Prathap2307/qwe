package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsRegistrationDao;
import com.LIC.model.ClaimsRegistrationModel;

@RestController
@RequestMapping("/claimRegis")
public class ClaimsRegistrationController {

	@Autowired
	private ClaimsRegistrationDao claimsRegistrationDao;

	@RequestMapping(value = "/getAllPendingClaims", method = RequestMethod.GET)
	public int getAllPendingClaims(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.getAllPendingClaims(claimsRegistrationModel);
	}

	@RequestMapping(value = "/getAllCoveragesByClaimId", method = RequestMethod.GET)
	public int getAllCoveragesByClaimID(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.getAllCoveragesByClaimId(claimsRegistrationModel);
	}

	@RequestMapping(value = "/getClaimDocumentsByClaimId", method = RequestMethod.GET)
	public int getClaimDocumentsByClaimId(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.getClaimDocumentsByClaimId(claimsRegistrationModel);
	}
	
	@RequestMapping(value = "/getClaimDetailsByClaimId", method = RequestMethod.GET)
	public int getClaimDetailsByClaimId(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.getClaimDetailsByClaimId(claimsRegistrationModel);
	}

	@RequestMapping(value = "/getClaimProductTransactionDetails", method = RequestMethod.GET)
	public int getClaimProductTransactionDetails(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.getClaimProductTransactionDetails(claimsRegistrationModel);
	}

	@RequestMapping(value = "/getClaimsDocument", method = RequestMethod.GET)
	public int getClaimsDocument(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.getClaimsDocument(claimsRegistrationModel);
	}

	@RequestMapping(value = "/getAssessmentHistory", method = RequestMethod.GET)
	public int getAssessmentHistory(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.getAssessmentHistory(claimsRegistrationModel);
	}

	@RequestMapping(value = "/isClaimExistOrNot", method = RequestMethod.GET)
	public int isClaimExistOrNot(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.isClaimExistOrNot(claimsRegistrationModel);
	}

	@RequestMapping(value = "/insertOrUpdateClaimsRegistration", method = RequestMethod.POST)
	public int insertOrUpdateClaimsRegistration(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.insertOrUpdateClaimsRegistration(claimsRegistrationModel);
	}

	@RequestMapping(value = "/deleteClaimCoverageMap", method = RequestMethod.DELETE)
	public int deleteClaimCoverageMap(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.deleteClaimCoverageMap(claimsRegistrationModel);
	}

	@RequestMapping(value = "/deleteClaimDocuments", method = RequestMethod.DELETE)
	public void deleteClaimDocuments(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		claimsRegistrationDao.deleteClaimDocuments(claimsRegistrationModel);
	}

	@RequestMapping(value = "/insertClaimsCoverageMap", method = RequestMethod.POST)
	public int insertClaimsCoverageMap(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.insertClaimsCoverageMap(claimsRegistrationModel);
	}

	@RequestMapping(value = "/insertClaimsProofOfDocument", method = RequestMethod.POST)
	public int insertClaimsProofOfDocument(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.insertClaimsProofOfDocument(claimsRegistrationModel);
	}

	@RequestMapping(value = "/insertClaimsMandatoryDocumentMap", method = RequestMethod.POST)
	public int insertClaimsMandatoryDocumentMap(@RequestBody ClaimsRegistrationModel claimsRegistrationModel) {
		return claimsRegistrationDao.insertClaimsMandatoryDocumentMap(claimsRegistrationModel);
	}
	
	
    @RequestMapping(value = "/insertClaimsBeneficiary", method = RequestMethod.POST)
    public int spInsertClaimsBeneficiaryDetails(@RequestBody List<ClaimsRegistrationModel>  claimsRegistrationModel) {
           return claimsRegistrationDao.InsertClaimsBeneficiaryDetails(claimsRegistrationModel);
    }


}
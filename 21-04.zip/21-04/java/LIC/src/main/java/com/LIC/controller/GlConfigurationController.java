package com.LIC.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.GlConfigurationDAO;
import com.LIC.model.GetAccountGroupModel;
import com.LIC.model.GetGlConfigurationModel;
import com.LIC.model.GetOrganisationModel;
import com.LIC.model.GlConfigurationModel;

@RestController
public class GlConfigurationController {
	
	@Autowired
	private GlConfigurationDAO glConfig;
	
	
	
	
	@PostMapping("/createGlConfig")
	public void postGlConfig(@RequestBody GlConfigurationModel model) {
		System.out.println(" control check");
		System.out.println(model.getGlconfigurationId());
		System.out.println(model.getPaymentMode());
		glConfig.createGlConfigurationInfo(model);

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/process")
    public List<GetGlConfigurationModel> AllProcessInfo() {
                return	glConfig.GetAllProcess();
      }
	
	@RequestMapping(method = RequestMethod.GET, value = "/payment")
    public List<GetGlConfigurationModel> AllPaymentInfo() {
                return	glConfig.GetAllPaymentInfo();
      }
	
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/varient/{lob}")
    public List<GetGlConfigurationModel> getAllvarientdetails(@PathVariable Integer lob) {
                return	glConfig.GetAllVariantInfo(lob);
      }
	
	@RequestMapping(method = RequestMethod.GET, value = "/all/{processId}/{productId}/{paymentMode}")
    public List<GetGlConfigurationModel> getAllDetails(@PathVariable Integer processId,@PathVariable Integer productId,@PathVariable Integer paymentMode) {
                return	glConfig.GetAll(processId,productId,paymentMode);
      }
	
	@RequestMapping(method = RequestMethod.GET, value = "/debitcredit/{id}")
    public List<GetGlConfigurationModel> getAllCreditDebitGlConfig(@PathVariable Integer id) {
                return	glConfig.GetAllDebirCreditGlcode(id);
      }
	
	  @GetMapping( value="/gcountries")
      public List<GetGlConfigurationModel> GetAllCountries() {
                          return	glConfig.GetAllCountryNames();
}

	
	  @GetMapping( value="/gstate/{countryId}")
      public List<GetGlConfigurationModel> GetAllStateName(@PathVariable Long countryId) {
                          return	glConfig.GetAllStateNames(countryId);
}
	

}

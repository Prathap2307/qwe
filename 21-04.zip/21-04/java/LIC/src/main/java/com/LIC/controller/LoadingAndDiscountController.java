package com.LIC.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.ErrorDto;
import com.LIC.model.LoadingAndDiscount;
import com.LIC.model.VariantBenefitRider;
import com.LIC.service.IBenefitRidersService;
import com.LIC.service.ILoadingAndDiscountService;
import com.LIC.utils.TextUtil;

@RestController
@RequestMapping("/configuration")
public class LoadingAndDiscountController {
	
	@Autowired(required=true)
	ILoadingAndDiscountService loadingAndDiscountService;
	
	@Autowired(required=true)
	IBenefitRidersService benefitRidersService;
	 
	@RequestMapping(value = "/loading-discounting/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateLoadingAndDiscounting(@RequestBody LoadingAndDiscount loadingAndDiscount) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == loadingAndDiscount) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != loadingAndDiscount.getId()) {
			loadingAndDiscount.setIsActive(1);
		}else {
			loadingAndDiscount.setId(0);
			loadingAndDiscount.setCreatedOn(new Date());
			loadingAndDiscount.setIsActive(1);
		}
		loadingAndDiscountService.saveOrUpdate(loadingAndDiscount);
		response.put("status", 1);
		if(loadingAndDiscount != null && loadingAndDiscount.getId() > 0) {
			response.put("message","Loading and Discount updated successfully.");
		}else {
			response.put("message","Loading and discount  created successfully");
		}
		
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/loading-discounting/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteLoadingAndDiscounting(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Loading and Discount ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		LoadingAndDiscount obj = loadingAndDiscountService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Loading and Discount ID ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		loadingAndDiscountService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/loading-discounting/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllLoadingDiscounting() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<LoadingAndDiscount> list = loadingAndDiscountService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/loading-discounting/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getLoadingDiscounting(@PathVariable Integer id) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Loading and Discount ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		LoadingAndDiscount obj = loadingAndDiscountService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Loading and Discount ID ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/loading-discounting/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchBankCity(@RequestBody LoadingAndDiscount filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<LoadingAndDiscount> list = loadingAndDiscountService.getAll(filterObj);
		List<LoadingAndDiscount> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(null != filterObj.getCategoryValueId()) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 p.getCategoryValueId().equals(filterObj.getCategoryValueId())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(null != filterObj.getCategoryValueId()){
	                		 if (p.getCategoryValueId().equals(filterObj.getCategoryValueId())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/product-benefit-riders/get/{variantId}/{typeId}/{lineofBusinessId}/{isSelectable}/{isBaseCoverage}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllProductBenefitRidersList(@PathVariable Integer variantId, @PathVariable Integer typeId,@PathVariable Integer lineofBusinessId,@PathVariable Integer isSelectable,@PathVariable Integer isBaseCoverage) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		System.out.println("variantId >>> "+variantId);
		System.out.println("typeId >>> "+typeId);
		List<VariantBenefitRider> variantList =  benefitRidersService.getCoverageByProductID(lineofBusinessId, variantId, isSelectable, isBaseCoverage);
		response.put("status", 1);
		response.put("message","Success");
		
		response.put("productBenefitRiders", variantList); 
		return ResponseEntity.accepted().body(response);
	}
}

package com.LIC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.AccountingClassificationDAO;
import com.LIC.model.AccountingClassificationModel;
import com.LIC.model.GetAccountingClassificationModel;

import java.util.*;

@RestController
public class AccountingClassificationController {
	@Autowired
	private AccountingClassificationDAO accClass;
	
	@GetMapping ("/CheckDuplicateClassification")
	public String GetDuplicateAccountingClassification(@RequestBody AccountingClassificationModel Accmodel)
	{
		return accClass.GetDuplicateAccountingClassification(Accmodel);
	}
	
	@PostMapping("/CreateClassifications")
	public int postClassifications(@RequestBody AccountingClassificationModel Accmodel) {
		return accClass.CreateAccountingClassification(Accmodel);

	}
	
	@RequestMapping(value = "/GetAllClassifications", method = RequestMethod.GET)
	@ResponseBody
	public List<GetAccountingClassificationModel> getAllAccountingClassification()
	{
		return accClass.GetAllAccountingClassifications();
	}
	
	@RequestMapping(path = "/SearchAccountingClassification/{AccountClassificationID}/{Code}/{Description}", method = RequestMethod.GET)
	public List<GetAccountingClassificationModel> SearchAccountingClassification(@PathVariable int AccountClassificationID,@PathVariable int Code,@PathVariable int  Description)
	{
		return accClass.SearchAccountingClassification(AccountClassificationID,Code,Description);
	}
	
}

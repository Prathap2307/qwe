package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.AccountingHeadDAO;
import com.LIC.model.AccountTypeModel;
import com.LIC.model.AccountingGroupInfoModel;
import com.LIC.model.AccountingHeadModel;
import com.LIC.model.GetAccountingClassificationModel;

@RestController
public class AccountingHeadController {
	@Autowired
	private AccountingHeadDAO accClass;
	
	
	//Accounting Classification
	@GetMapping ("/GetAllAccountingClassification")
	public List<GetAccountingClassificationModel> SearchAccountingClassification()
	{
		return accClass.GetBindAccountingClassification();
	}
	
	
	//Accounting Group
	@GetMapping ("/GetAllAccountingGroup")
	public List<AccountingGroupInfoModel> GetAllAccountingGroup()
	{
		return accClass.GetAllAccountingGroup();
	}
	
	//Account Type
		@GetMapping ("/GetAllAccountType")
		public List<AccountTypeModel> GetAllAccountType()
		{
			return accClass.GetAllAccountType();
		}
	
	//Accounting Head Details
	@RequestMapping(path = "/GetAllAccountDetails/{AccountClassificationID}/{AccountGroupID}", method = RequestMethod.GET)
	public List<AccountingHeadModel> GetAccountDetails(@PathVariable int AccountClassificationID,@PathVariable int AccountGroupID)
	{
		return accClass.GetAccountDetails(AccountClassificationID, AccountGroupID);
	}

	
	//Accounting Head Details
	@RequestMapping(path = "/GetDuplicateAccountingHead/{Code}/{accountname}/{AccountHeadID}", method = RequestMethod.GET)
	public String  GetDuplicateAccountingHead(@PathVariable String Code,@PathVariable String accountname,@PathVariable int AccountHeadID)
	{
		return accClass.GetDuplicateAccountingHead(Code,accountname,AccountHeadID);
	}

	@PostMapping("/CreateAccountingHead")
	public int CreateAccountingHead(@RequestBody AccountingHeadModel AccountHeadID) {
		return accClass.CreateAccountingHead(AccountHeadID);

	}
	
	//Accounting Head Details
	@RequestMapping(path = "/SearchAccountHeadDetails/{AccountHeadID}/{AccountClassificationID}/{AccountGroupID}/{AccountType}/{AccountHeadCode}/{AccountHeadName}", method = RequestMethod.GET)
	public List<AccountingHeadModel> SearchAccountHeadDetails(@PathVariable int AccountHeadID,@PathVariable int AccountClassificationID,@PathVariable int AccountGroupID,
			@PathVariable int AccountType,@PathVariable int AccountHeadCode,@PathVariable int AccountHeadName)
	{
		return accClass.SearchAccountHeadDetails(AccountHeadID,AccountClassificationID,AccountGroupID,AccountType,AccountHeadCode,AccountHeadName);
	}
	
	
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcesstaxmappingComponent } from './processtaxmapping.component';

describe('ProcesstaxmappingComponent', () => {
  let component: ProcesstaxmappingComponent;
  let fixture: ComponentFixture<ProcesstaxmappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcesstaxmappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcesstaxmappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

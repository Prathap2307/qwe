import { Component, OnInit, ViewChild } from '@angular/core';
import { TooltipPosition } from '@angular/material';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';

import { MatPaginator } from '@angular/material/paginator';
import { AccountinggroupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountinggroup.service';
import { AccountingGroup } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountinggroup';
import { MatTableDataSource } from '@angular/material/table';
@Component({
  selector: 'app-accountinggroup',
  templateUrl: './accountinggroup.component.html',
  styleUrls: ['./accountinggroup.component.css']
})
export class AccountinggroupComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  accountingGroupColumns: string[] = ['View', 'Edit', 'code', 'description'];

  AccountingGroupForm: FormGroup;
  item: any;

  get AccountingGroupFormAction() {
    return this.AccountingGroupForm.get('AccountingGroupFormAction') as FormGroup;
  }
  constructor(private accountingGroupService: AccountinggroupService, private fb: FormBuilder) { }
  accountGroupGridObj: AccountingGroup[];
  accountGroupDDObj: AccountingGroup[];
  accountGridFilterObj: AccountingGroup[];
  fieldDisable: Boolean;
  textSaveBtn: any;

  createBtn: boolean;
  saveBtnMode: boolean;
  actionHeading: string;
  dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngOnInit() {
    this.dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
    this.actionHeading = 'Add New - Accounting Group ';
    this.saveBtnMode = true;
    this.createBtn = true;
    this.textSaveBtn = 'Save';
    this.getAccountingGroupGridDetails();
    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: ['', Validators.required],
        searchGroupName: ['', Validators.required],
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: [''],
        code: ['', Validators.required],
        groupName: ['', Validators.required]
      })
    });

  }

  //  removeExtraControls(){
  //   this.AccountingGroupFormAction.removeControl('createdBy');
  //   this.AccountingGroupFormAction.removeControl('createdOn');
  //   this.AccountingGroupFormAction.removeControl('isActive');
  //   this.AccountingGroupFormAction.removeControl('reMarks');
  //   this.AccountingGroupFormAction.removeControl('statusId');
  //   this.AccountingGroupFormAction.removeControl('WorkFlowId');
  //  }

  saveMethod(){
    let a = this.AccountingGroupForm.get('AccountingGroupFormAction').value;
    //console.log(a)
    this.accountingGroupService.createAccountingGroup(a).subscribe(a => {

      this.getAccountingGroupGridDetails();
    });

    this.onBtnClearAction();
  }
  alreadygroupNameExist: any;
  alreadycodeExist: any;
	alreadyDescriptionExist: any;


  alreadycodeEditExist: any;
  alreadyDescriptionEditExist: any;
  onBtnSaveAccountGroup() {

    this.textSaveBtn = 'Save';

    this.AccountingGroupForm.get('AccountingGroupFormAction').markAllAsTouched();

    if (this.AccountingGroupForm.get('AccountingGroupFormAction').valid) {

      let des = this.AccountingGroupFormAction.get('groupName').value;
      let co = this.AccountingGroupFormAction.get('code').value;

      if (this.createBtn) {
        this.AccountingGroupForm.get('AccountingGroupFormAction').patchValue({
          accountHeadId: '0'
        });

        this.AccountingGroupFormAction.addControl('createdBy', new FormControl('1'));
        this.AccountingGroupFormAction.addControl('createdOn', new FormControl(new Date()));
        this.AccountingGroupFormAction.addControl('isActive', new FormControl('1'));
        this.AccountingGroupFormAction.addControl('reMarks', new FormControl(''));
        this.AccountingGroupFormAction.addControl('statusId', new FormControl('1'));
        this.AccountingGroupFormAction.addControl('WorkFlowId', new FormControl('1'));

       
        this.alreadycodeExist = 0;
        this.alreadyDescriptionExist = 0;
        this.accountGroupGridObj.forEach((fe) => {
          if (fe.groupName.toUpperCase().trim() == des.toUpperCase().trim()) {
            this.alreadyDescriptionExist = 1;
          }
  
          if (fe.code.toUpperCase().trim() == co.toUpperCase().trim()) {
            this.alreadycodeExist = 1;
          }
  
  
        });
        
  
  
        
        if (this.alreadyDescriptionExist == 0 && this.alreadycodeExist == 0) {
          this.saveMethod();
        } else {
  
          if (this.alreadyDescriptionExist == 1) {
            window.alert('Description already exists');
  
            return false;
          }
  
          if (this.alreadycodeExist == 1) {
            window.alert('Code already exists');
            return false;
          }
  
          
        }



      }else{


        console.log("else");
        let id = this.AccountingGroupFormAction.get('accountingGroupId').value;
		
      this.alreadycodeEditExist = 0;
			this.alreadyDescriptionEditExist = 0;
			this.accountGroupGridObj.forEach((fe) => {
				if (fe.accountingGroupId != id) {
					if (fe.groupName.toUpperCase().trim() == des.toUpperCase().trim()) {
            console.log("else inside");
						this.alreadyDescriptionEditExist = 1;
					}

					if (fe.code.toUpperCase().trim() == co.toUpperCase().trim()) {
						this.alreadycodeEditExist = 1;
					}

				}

			});

			if (this.alreadyDescriptionEditExist == 0 && this.alreadycodeEditExist == 0) {
				this.saveMethod();
			} else {
				if (this.alreadyDescriptionEditExist == 1) {
					window.alert('Description already exists');

					return false;
				}

				if (this.alreadycodeEditExist == 1) {
					window.alert('Code already exists');
					return false;
				}
      }
      }

    
   
    }
  }


  getAccountingGroupGridDetails(): void {
    this.accountingGroupService.getAccountingGroupGridDetails('ALL').subscribe(a => {
      this.accountGroupGridObj = a;
      this.accountGroupDDObj = a;

      this.dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
      this.dataSource.data = this.accountGroupGridObj = a;
      this.dataSource.paginator = this.paginator;
    });

  }

  btngvView_Click(a) {
    this.actionHeading = 'View - Accounting Group ';
    this.saveBtnMode = false;
    this.fieldDisable = true;
    this.accountGridFilterObj = this.accountGroupGridObj.filter((unit) => unit.accountingGroupId == a);

    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: this.accountGridFilterObj[0].accountingGroupId,
        code: this.accountGridFilterObj[0].code,
        groupName: this.accountGridFilterObj[0].groupName,

      })
    });
  }


  btngvEdit_Click(a) {
    this.actionHeading = 'Edit - Accounting Group ';
    this.saveBtnMode = true;

    this.createBtn = false;
    this.textSaveBtn = 'Update';
    this.fieldDisable = false;
    this.accountGridFilterObj = this.accountGroupGridObj.filter((unit) => unit.accountingGroupId == a);

    this.AccountingGroupFormAction.addControl('createdBy', new FormControl('1'));
    this.AccountingGroupFormAction.addControl('createdOn', new FormControl(''));
    this.AccountingGroupFormAction.addControl('isActive', new FormControl(''));
    this.AccountingGroupFormAction.addControl('reMarks', new FormControl(''));
    this.AccountingGroupFormAction.addControl('statusId', new FormControl(''));
    this.AccountingGroupFormAction.addControl('WorkFlowId', new FormControl(''));



    this.AccountingGroupForm = this.fb.group({

      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: this.accountGridFilterObj[0].accountingGroupId,
        code: this.accountGridFilterObj[0].code,
        groupName: this.accountGridFilterObj[0].groupName,
        createdBy: '1',
        createdOn: new Date(),
        isActive: '1',
        reMarks: '1',
        statusId: '1',
        WorkFlowId: '1',
      })
    });
  }

  onBtnClearAction() {
    this.createBtn = true;
    this.textSaveBtn = 'Save';
    this.actionHeading = 'Add New - Accounting Group ';
    this.fieldDisable = false;
    this.saveBtnMode = true;

    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: '',
        code: '',
        groupName: ''
      })
    });

  }

  getAccountingGroupBySearch() {
    this.AccountingGroupForm.get('AccountingGroupFormSearch').markAllAsTouched();
    if (this.AccountingGroupForm.get('AccountingGroupFormSearch').valid) {

      let a = this.AccountingGroupForm.get('AccountingGroupFormSearch.searchCode').value;
      let b = 0;
      let c = 0;
      //let d = this.AccountingGroupForm.get('AccountingGroupFormAction.searchGroupName').value;
      let r = this.accountGroupGridObj.filter((unit) => unit.accountingGroupId == a);
      console.log(r.length);
      let d;
      if(r.length){
         d = r[0].groupName;
      }else{
         d = 0;
      }
     // let d = r[0].groupName;
     
      if (a == "") {
        a = 0;
      }



      this.accountingGroupService.getAGGridDetailsBySearch(a, b, c, d).subscribe(s => {

      this.accountGroupGridObj = s;

      this.dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
      this.dataSource.data = this.accountGroupGridObj = s;
      this.dataSource.paginator = this.paginator;

      });
    }

  }
  clearSearchAccountHead() {
    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: '',
        code: '',
        groupName: ''
      })
    });
    this.getAccountingGroupGridDetails();
  }
  createItem() {
    return this.fb.group({
      name: ['Jon'],
      surname: ['Doe']
    })
  }


  cfn(a) {
    console.log(a);
  }


}

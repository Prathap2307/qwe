import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
import { MemberadditionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberaddition.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
@Component({
  selector: 'app-maendorsement',
  templateUrl: './maendorsement.component.html',
  styleUrls: ['./maendorsement.component.css']
})
export class MAEndorsementComponent implements OnInit {
  dummyObj: string;


  // myControl = new FormControl();
  //options: string[] = ['One', 'Two', 'Three', 'One', 'Two', 'Three', 'One', 'Two', 'Three', 'One', 'Two', 'Three', 'One', 'Two', 'Three', 'One', 'Two', 'Three'];



  filteredOptions: Observable<any[]>;

  constructor(private fb: FormBuilder, private memberupload: MemberuploadService, private memberadditionService: MemberadditionService) { }

  memberAdditionForm: FormGroup;
  get memberAdditionAction() {
    return this.memberAdditionForm.get('memberAdditionAction') as FormGroup;
  }
  groupNameObj: any[] = [];
  groupNameFilterObj: any[] = [];
  mpnObj: MemberUpload[];
  authorizedSignatoryObj: MemberUpload[];
  uploadFileurl: any;
  uploadFiledata: any;
  uploadFileName: any;
  formData = new FormData();
  successObj: any;
  divsuccessMessage: Boolean;

  ngOnInit() {
   

    this.memberAdditionForm = this.fb.group({
      memberAdditionAction: this.fb.group({

        groupID: ['', [Validators.required]],
        masterPolicyNumber: ['', [Validators.required]],
        agreementNumber: ['', [Validators.required]],
        browseBtn: ['']

      })

    });

    this.getGroupDetails();
    // this.filteredOptions = this.myControl.valueChanges
    //   .pipe(
    //     startWith(''),
    //     map((value) => this._filter(value))
    //   );


  }


  private _filter(value): any[] {
    const filterValue = value;

    let r = this.groupNameObj.filter((unit) => unit.groupName == filterValue);

    return this.groupNameObj.filter(option => option.groupName.includes(filterValue));


  }

  filterListCareUnit(val) {
    this.groupNameObj = this.groupNameFilterObj.filter((unit) => unit.groupName.indexOf(val) > -1);
  }


  getGroupDetails() {



    this.memberAdditionAction.addControl('groupName', new FormControl(''));
    this.memberAdditionAction.addControl('contactFirstName', new FormControl(''));
    this.memberAdditionAction.addControl('contactLastName', new FormControl(''));
    this.memberAdditionAction.addControl('customerGroupID', new FormControl(''));
    this.memberAdditionAction.addControl('branchID', new FormControl(0));
    this.memberAdditionAction.addControl('userID', new FormControl(0));

    let a = this.memberAdditionAction.value;

    this.memberupload.getGroupDetails(a).subscribe(a => {
      this.groupNameObj = a;
      this.groupNameFilterObj = a;
    });

  }


  getmasterPolicyDetails() {

    let groupID = this.memberAdditionAction.get('groupID').value;

    this.memberupload.getmasterPolicyDetails(groupID).subscribe(a => {
      this.mpnObj = a;
    });

    this.memberupload.getAllAuthorisedSignatories(groupID).subscribe(a => {
      this.authorizedSignatoryObj = a;
    });

  }
  selectedFile: any;
  handleFileInput(event: any) {

    this.selectedFile = event.target.files[0];
    console.log(this.selectedFile.name);
    this.uploadFileName = this.selectedFile.name
    this.formData.append("file", this.selectedFile);


  }

  validationMessage: any;

  fileSaveFn() {

    this.memberadditionService.saveFile(this.formData).subscribe(a => {


      this.uploadFileurl = a;
      console.log(this.uploadFileurl);

      console.log(this.uploadFileurl.filePath);


      this.uploadFiledata = { 'filePath': this.uploadFileurl.filePath, 'fileName': this.uploadFileName };

      this.memberadditionService.memberAdditionValidateExcelFile(this.uploadFiledata).subscribe(data => {
        this.validationMessage = data;

        if (this.validationMessage == "") {

          console.log('valid test');
          this.memberadditionService.postFile(this.uploadFiledata).subscribe(data => {
            // do something, if upload success
            this.migrationGNBDataUpload();
            this.onBtnClearAction();
          });  }

      });

    
    });


  }

  migrationGNBDataUpload() {

    let obj: Object = {

      "fileName": this.uploadFileName,
      "groupId": this.memberAdditionAction.get('groupID').value,
      "masterPolicyId": this.memberAdditionAction.get('masterPolicyNumber').value,
      "createdBy": 1,
      "createdOn": "2020-03-30",
      "type": "A",
      "authorisedSignatoryId": 0

    };




    this.memberadditionService.migrationGNB(obj).subscribe(data => {
      this.successObj = data;
     
      this.divsuccessMessage = true;

     
    });
  }

  uploadFileToActivity() {
    this.memberAdditionAction.markAllAsTouched();

    if (this.memberAdditionAction.valid) {

      this.fileSaveFn();
    }









  }

  onBtnClearAction() {
    this.memberAdditionAction.reset({
      masterPolicyNumber: '',
      agreementNumber: '',
      browseBtn: ''

    });

    this.validationMessage = '';

    this.validationMessage = '';
    setTimeout( ()=>{  
      this.divsuccessMessage = false;
 }, 5000);


  }
  getData(a) {
    console.log(a);
  }
  cfn(a) {
    console.log(a);
  }
  getPosts(a) {
    //console.log(a);
  }

}



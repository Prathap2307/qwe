import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nmendorsement',
  templateUrl: './nmendorsement.component.html',
  styleUrls: ['./nmendorsement.component.css']
})
export class NmendorsementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { DefectDataUpload, SuccessMessage, UploadFileurl } from 'src/app/mcore-product/mcore-shared/mcore-entity/defectdataupload';
import { DefectdatauploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/defectdataupload.service';
import { MatTableDataSource, MatPaginator } from '@angular/material'
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';


@Component({
  selector: 'app-defectdata',
  templateUrl: './defectdata.component.html',
  styleUrls: ['./defectdata.component.css']
})
export class DefectdataComponent implements OnInit {
  dummyObj: string;
  divDisplay: Boolean;
  groupNameObj: MemberUpload[];
  defectDataForm: FormGroup;
  //defectDataFormAction: FormGroup;
  ddObj: any;
  defectDataColumns: string[] = ['fileName', 'uploadDate', 'totalRecords', 'successRecords', 'failedRecords', 'status'];
  defectdataSource = new MatTableDataSource<DefectDataUpload>(this.ddObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  public ngAfterViewInit() {
    this.defectdataSource.paginator = this.paginator;
  }
  get defectDataFormAction() {
    return this.defectDataForm.get('defectDataFormAction') as FormGroup;
  }

  constructor(private fb: FormBuilder, private defectdataupload: DefectdatauploadService, private memberupload: MemberuploadService ) { }

  ngOnInit() {
    this.divDisplay = false;
    this.Validation();
    this.getGroupDetails();
  }
  Validation() {
    this.defectDataForm = this.fb.group({
      defectDataFormAction: this.fb.group({
        groupID: ['', [Validators.required]],
        masterPolicyNumber: ['', [Validators.required]],
        agreementNumber: ['', [Validators.required]],
        fromDate: [''],
        toDate: [''],
        fileName: [''],
        uploadDate: [''],
        totalRecords: [''],
        successRecords: [''],
        failedRecords: [''],
        status: [''],
      })
    });
  }

  getGroupDetails() {
    let a = this.defectDataFormAction.value;
    this.memberupload.getGroupDetails(a).subscribe(a => {
      this.groupNameObj = a;
    });
  }

  getmasterPolicyDetails() {
    let groupID = this.defectDataFormAction.get('groupID').value;
    this.memberupload.getmasterPolicyDetails(groupID).subscribe(a => {
      this.ddObj = a;
    });
  }

  SearchDefectDataUpload() {
    this.defectDataForm.controls.defectDataFormAction.markAllAsTouched();
    if (this.defectDataForm.get('defectDataFormAction').valid) {
      console.log('valid');
      let a = this.defectDataForm.controls.defectDataFormAction.value;
      this.divDisplay = true;
      console.log(a);
      this.ClearDefectDataDetails();
    }
  }
  getDefectDataDetails() {
    this.defectdataupload.getAllDefectDataUploadDetails().subscribe(
      defectDataObj => {
        this.defectdataSource = new MatTableDataSource<DefectDataUpload>(this.ddObj);
        this.defectdataSource.data = this.ddObj = defectDataObj;
        this.defectdataSource.paginator = this.paginator;
      })
  }

  SearchClearDefectDataUpload() {
    this.ClearDefectDataDetails();
  }

  ClearDefectDataDetails() {
    this.defectDataForm.controls.defectDataFormAction.reset();
    this.divDisplay = false;
    this.defectDataForm = this.fb.group({
      defectDataFormAction: this.fb.group({
        groupID: [''],
        masterPolicyNumber: [''],
        agreementNumber: [''],
        fromDate: [''],
        toDate: [''],
      })
    });
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FemailSmsComponent } from './femail-sms.component';

describe('FemailSmsComponent', () => {
  let component: FemailSmsComponent;
  let fixture: ComponentFixture<FemailSmsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FemailSmsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FemailSmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

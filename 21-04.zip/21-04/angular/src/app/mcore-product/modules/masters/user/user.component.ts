import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';

import { MustMatch } from 'src/app/mcore-product/mcore-shared/mcore-helpers/must-matchvalidator';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import { DesignationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/designation.service';
import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';
import { MatTableDataSource } from '@angular/material';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';
import { GradeService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/grade.service';
import { Grade } from 'src/app/mcore-product/mcore-shared/mcore-entity/grade';
import { AuthorizedsignatoryService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/authorizedsignatory.service';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
class ImageSnippet {
  constructor(public src: string, public file: File) { }
}

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],

  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class UserComponent implements OnInit {
  Searchuser: FormGroup;
  Adduser: FormGroup;
  UnderWriter: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  submitted3: boolean;
  saveBtnMode: boolean = true;
  view: boolean = false;
  Under_Writers: boolean = false;
  userheading: string = 'Add - New User'
  display: string = 'none';
  Addunderwriter: any = [];
  textSaveBtn: string = 'Save';

  dummyObj =
    [{ Id: '1', Name: 'abc' },
    { Id: '2', Name: 'abcd' },
    { Id: '3', Name: 'abc34' },
    { Id: '4', Name: 'abc4' }
    ]

  userType = [
    { Id: 1, Name: 'Organisational User' },
    { Id: 3, Name: 'Client Organisation User' },
    { Id: 4, Name: 'Agent User' },
    { Id: 5, Name: 'General User' }
  ]

  branchFilteredObj: any;
  allbranch: any;
  LOB: any[] = [{ "id": 5, "value": "Group Insurance" }];
  all: boolean;
  exist: boolean;
  success: boolean;
  transaction: string;
  pwdexist: boolean;
  fail: boolean;
  msg: any;
  alluser: any;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  designationDDObj: Designation[];
  departmentObj: DepartmentType[];
  uwIndex: any;
  UnderWriterheading: string = 'Add- UnderWriter';
  uwobj: any;
  textSaveBtn1: string = 'Add';
  view1: boolean;
  saveBtnMode1: boolean = true;
  gradeObj: Grade[];
  salutation: any;
  lob: any;
  module: any;
  files: File;
  gender: any;
  reporting: any;
  organisationID: string;
  Selectuser: FormGroup;
  level: any;
  admin: boolean=true;
  userID: string;


  constructor(private fb: FormBuilder,private fchannelService: FchannelService, public AuthoriseService: AuthorizedsignatoryService, private gradeService: GradeService, private designationService: DesignationService, private departmentService: DepartmentService, private BranchService: BranchService, private _adapter: DateAdapter<any>, private user: UserService) {
    this._adapter.setLocale('en-gb');
  }

  ngOnInit() {
    this.getlevel()
    this.GetAllReportingTo()
  this.getmodule()   
   this.Selectuser = this.fb.group({
      userType: [1,Validators.required],
    })
    console.log(localStorage.getItem('organisationID'))
    this.organisationID=localStorage.getItem('organisationID')
    this.userID = localStorage.getItem('userID')
    this.getAllGender()
    this.getallbranches()
    this.GetLineOfBusiness()
    this.getalluser()
    this.getDesignationDetails()
    this.getDepartmentDetails()
    this.Searchuser = this.fb.group({
      firstName: [],
      lastName: [],
      userName: [],
      ReportingTo: [],
    })
    this.UnderwriterForm()
    this.UserForm()
    this.getGradeDetails()
    this.GetAllSalutation()
  }
  UserForm() {
    this.Adduser = this.fb.group({
      firstName: [],
      salutationID: [''],
      lastName: [],
      initial: [],
      gender: [],
      branchID: [],
      departmentID: [],
      designationID: [],
      gradeID: [],
      select_All_Branch: [0],
      selectAllBranch: [0],
      reportingTo: [],
      branchcheck: ['',],
      branchToWhichAttached: this.fb.array([]),
      address: [],
      mobileNo: ['', [Validators.required, Validators.pattern("[0-9 -()+]+$")]],
      conferenceNo: ['', [Validators.pattern('[0-9]{11,12}')]],
      employeeNo: [],
      email: ['', [Validators.required,Validators.email,Validators.pattern('^[a-z0-9,A-Z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      isUnderWriter: [''],
      photos: ['', Validators.required],
      userID: [0],
      userName: [],
      isAdmin: [],
      isSuperUser: 0,
      password: ['', [Validators.required, Validators.pattern('(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[a-z])(?=.*[a-z]).*$')]],
      Confirm_Password: [],
      underWriter: this.fb.array([
      ]),
      lineOfBusiness: this.fb.array([
      ]),

    },
      {
        validator: MustMatch('password', 'Confirm_Password')
      })
  }



  UnderwriterForm() {

    this.UnderWriter = this.fb.group({
      Level: ['', [Validators.required]],
      Module: ['', [Validators.required]],
      LOB: ['', [Validators.required]],
      Plan: ['', [Validators.required]],
      Level_Name: ['', [Validators.required]],

    })
  }

  onSelectAllChange(event: any) {
    console.log(event)
    console.log(event.checked)
    if (event.checked === true) {
      this.Adduser.value['selectAllBranch'] = 1
      this.all = true
      // const formArray: FormArray = this.Adduser.get('branchToWhichAttached') as FormArray;
      // for(let i=0;i<this.allbranch.length;i++){
      //   formArray.push(new FormControl(this.allbranch[i]))
      // }
      this.Adduser.value['branchToWhichAttached'] = this.allbranch
    }
    else if (event.checked === false) {
      this.Adduser.value['selectAllBranch'] = 0
      this.all = false
      this.Adduser.value['branchToWhichAttached'] = []
    }

  }
  getmodule() {

    this.AuthoriseService.GetAllModules()
      .subscribe(result => {
        console.log(result)
        this.module = result.data
      });
  }
  isAdminChange(event: any) {
    console.log(event)
    console.log(event.checked)
    if (event.checked === true) {
      this.Adduser.value['isAdmin'] = 1
    }
    else if (event.checked === false) {
      this.Adduser.value['isAdmin'] = 0
    }
  }
  isunderWriterChange(event: any) {
    console.log(event)
    console.log(event.checked)
    if (event.checked === true) {
      this.Adduser.value['isUnderWriter'] = 1
      this.Under_Writers = true
    }
    else if (event.checked === false) {
      this.Adduser.value['isUnderWriter'] = 0
      this.Under_Writers = false
    }

  }


  onCheckChange(event: any) {
    console.log(event)
    console.log(event.source.value)
    if (event.checked) {
      for (let i = 0; i < this.allbranch.length; i++) {
        if (event.source.value.branchId === this.allbranch[i].branchId) {
          this.allbranch[i]["checked"] = true
        }
      }
    }
    else {
      for (let i = 0; i < this.allbranch.length; i++) {
        if (event.source.value.branchId === this.allbranch[i].branchId) {
          this.allbranch[i]["checked"] = false
        }
      }
    }
    console.log(this.allbranch)
    // const formArray: FormArray = this.Adduser.get('branchToWhichAttached') as FormArray;
    // if (event.checked) {
    //   formArray.push(new FormControl(event.source.value));
    //   console.log(formArray)
    // }
    // else {
    //   let i: number = 0;
    //   formArray.controls.forEach((ctrl: FormControl) => {
    //     if (ctrl.value == event.source.value) {
    //       formArray.removeAt(i);
    //       return;
    //     }

    //     i++;
    //   });
    // }
  }
  GetAllSalutation() {
    this.user.GetAllSalutation()
      .subscribe(result => {
        console.log(result)
        this.salutation = result.salutationList
      })
  }
  GetLineOfBusiness() {
    this.user.GetLineOfBusiness()
      .subscribe(result => {
        console.log(result)
        this.lob = result.data
      })
  }
  getalluser() {
    let data = {
      "organisationID":   this.organisationID,
      "parentBranchID": 0,
      "firstName": "",
      "lastName": "",
      "loginName": "",
      "employeeNo": "",
      "departmentID": 0,
      "designationID": 0,
      "branchID": 0,
      "reportingTo": 0,
      "userID": 0,
      "userType": this.Selectuser.value["userType"]
    }
    this.user.GetAllUserBySearch(data)
      .subscribe(result => {
        console.log(result)
        this.alluser = result.data.GetUserEmployeeModel
        if (this.alluser) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.alluser.length
          }
        }


      })  
  }
  getlevel() {
    console.log("result")
    this.user.getAllLevel()
      .subscribe(result => {
        console.log(result)
        this.level = result.data
      })
  }
  GetAllReportingTo() {
    console.log("result")
    this.fchannelService.GetAllReportingTo()
      .subscribe(result => {
        console.log(result)
        this.reporting = result.data
      })
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  searchUser() {
    this.submitted = true;
    let data = {
      "organisationID": this.organisationID,
      "parentBranchID": 0,
      "firstName": this.Searchuser.value["firstName"],
      "lastName": this.Searchuser.value["lastName"],
      "loginName": this.Searchuser.value["userName"],
      "employeeNo": "",
      "departmentID": 0,
      "designationID": 0,
      "branchID": 0,
      "reportingTo": 0,
      "userType": this.Selectuser.value["userType"],
      "userID":this.userID
    }
    
    this.user.GetSearchUser(data)
      .subscribe(result => {
        console.log(result)
        this.alluser = result.data.GetUserEmployeeModel
        console.log(this.alluser)
        if (this.alluser) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.alluser.length
          }
        }
      })
  }
  onchangetype(event:any){
    console.log(event.target.value)
    this.getalluser() 
    this.onchangeisAdmin(event.target.value)

  }
  onchangeisAdmin(selected: any) {

    console.log(selected);
    const isAdmin = this.Adduser.get('isAdmin')
    
    if (this.Selectuser.value["userType"] === 1) {
      this.admin = true;
      console.log(true)
    }else{
      this.admin=false
    }
  }
  getallbranches() {
    let branch = {
      "OrganisationID":   this.organisationID,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data

      })
  }
  viewUnderwriter(i: any) {
    console.log(i)
    this.uwIndex = i
    this.UnderWriterheading = 'View - UnderWriter';
    this.saveBtnMode1 = false;
    this.view1 = false;
    this.getuw()
  }

  editUnderwriter(i: any) {
    this.uwIndex = i
    this.UnderWriterheading = 'Edit - UnderWriter';
    this.saveBtnMode1 = true;
    this.view1 = false;
    this.textSaveBtn1 = 'Update'
    this.getuw()
  }
  getuw() {
    this.uwobj = this.Addunderwriter[this.uwIndex];
    console.log(this.Addunderwriter)
    console.log(this.uwobj)
    this.UnderWriter = this.fb.group({
      Level: [{ value: this.uwobj.Level, disabled: false }, [Validators.required]],
      Module: [{ value: this.uwobj.Module, disabled: false }, [Validators.required]],
      LOB: [{ value: this.uwobj.LOB, disabled: false }, [Validators.required]],
      Plan: [{ value: this.uwobj.Plan, disabled: false }, [Validators.required]],
      Level_Name: [{ value: this.uwobj.Level_Name, disabled: false }, [Validators.required]],
    })
  }

  cancelUnderWriters() {
    this.saveBtnMode1 = true;
    this.textSaveBtn1 = 'Add'
    this.UnderWriterheading = 'Add - UnderWriter';
    this.UnderWriter.reset();
    this.UnderwriterForm()
    this.submitted3 = false;
  }

  AddUnderWriters() {
    this.submitted3 = true;
    console.log(this.UnderWriter.value)

    if (this.UnderWriter.valid) {
      if (this.textSaveBtn1 === 'Update') {
        this.Addunderwriter[this.uwIndex] = this.UnderWriter.value;

        this.UnderWriter.reset();
        this.submitted3 = false;
        console.log(this.UnderWriter.value)
        console.log(this.Addunderwriter)
      }
      else {
        this.Addunderwriter.push(this.UnderWriter.value);
        this.UnderWriter.reset();
        this.submitted3 = false;
        console.log(this.UnderWriter.value)
        console.log(this.Addunderwriter)
      }

    }
  }

  getUserById(id) {
    this.user.GetUserModulesFeatureByUserID(id)
      .subscribe(result => {
        console.log(result)
        this.branchFilteredObj = result.data
        console.log(this.branchFilteredObj)
        if (this.branchFilteredObj) {
          // console.log(this.Adduser.value)
          this.Adduser = this.fb.group({
            firstName: [{ value: this.branchFilteredObj.firstName, disabled: false }],
            salutationID: [{ value: this.branchFilteredObj.salutationID, disabled: false }],
            lastName: [{ value: this.branchFilteredObj.lastName, disabled: false }],
            employeeID: [{ value: this.branchFilteredObj.employeeID, disabled: false }],
            groupID: [{ value: this.branchFilteredObj.groupID, disabled: false }],
            initial: [{ value: this.branchFilteredObj.initial, disabled: false }],
            gender: [{ value: this.branchFilteredObj.gender, disabled: false }],
            branchID: [{ value: this.branchFilteredObj.branchID, disabled: false }],
            departmentID: [{ value: this.branchFilteredObj.departmentID, disabled: false }],
            designationID: [{ value: this.branchFilteredObj.designationID, disabled: false }],
            gradeID: [{ value: this.branchFilteredObj.gradeID, disabled: false }],
            selectAllBranch: [{ value: this.branchFilteredObj.selectAllBranch, disabled: false }],
            reportingTo: [{ value: 1, disabled: false }],
            address: [{ value: this.branchFilteredObj.address, disabled: false }],
            mobileNo: [{ value: this.branchFilteredObj.mobileNo, disabled: false }, [Validators.pattern('\\d{10}')]],
            conferenceNo: [{ value: this.branchFilteredObj.conferenceNo, disabled: false }, [Validators.pattern('[0-9]{11,12}')]],
            employeeNo: [{ value: this.branchFilteredObj.employeeNo, disabled: false }],
            email: [{ value: this.branchFilteredObj.email, disabled: false }, [Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")]],
            isUnderWriter: [{ value: this.branchFilteredObj.isUnderWriter, disabled: false }],
            photos: [{ value: '', disabled: false }, [Validators.required]],
            userID: [{ value: this.branchFilteredObj.userModal.userID, disabled: false }],
            userName: [{ value: this.branchFilteredObj.userModal.userName, disabled: false }],
            isAdmin: [{ value: this.branchFilteredObj.userModal.isAdmin, disabled: false }],
            isSuperUser: { value: this.branchFilteredObj.userModal.isSuperUser, disabled: false },
            password: [{ value: this.branchFilteredObj.userModal.password, disabled: false }, [Validators.required, Validators.pattern('(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$')]],
            Confirm_Password: [{ value: this.branchFilteredObj.userModal.password, disabled: false }],
            branchToWhichAttached: this.fb.array(this.branchFilteredObj.branchModalList),
            branchcheck: [{ value: 0, disabled: false }],
          })
          if (this.branchFilteredObj.branchModalList) {
            for (let i = 0; i < this.branchFilteredObj.branchModalList.length; i++) {
              for (let k = 0; k < this.allbranch.length; k++) {
                if (this.branchFilteredObj.branchModalList[i]['branchId'] === this.allbranch[k]["branchId"]) {
                  console.log(this.allbranch[k])
                  console.log(true)
                  this.allbranch[k].checked = true

                }
              }
            }
          }
        }
      })
  }

  get a() { return this.Searchuser.controls; }

  getDesignationDetails(): void {

    this.designationService.getDesignationDetails(0, null)
      .subscribe(a => {
        console.log(a)
        this.designationDDObj = a;
      });

  }

  getDepartmentDetails(): void {
    this.departmentService.getDepartmentDetails()
      .subscribe(a => {
        console.log(a)
        this.departmentObj = a
        console.log(this.departmentObj)
      }
      )
  }


  clearsearch() {
    this.Searchuser.reset()
    this.getalluser()
  }

  get au() { return this.UnderWriter.controls; }
  get am() { return this.Adduser.controls; }

  Addusers() {
    this.submitted1 = true;
    console.log(this.Adduser.value)
    this.Adduser.value.underWriter = this.Addunderwriter
    this.Adduser.value.lineOfBusiness = this.LOB
    console.log(this.Adduser.controls)
    if (this.Adduser.valid) {
      this.Adduser.value['branchToWhichAttached'] = []
      for (let i = 0; i < this.allbranch.length; i++) {
        if (this.allbranch[i]["checked"] === true) {
          console.log(this.allbranch[i])
          this.Adduser.value['branchToWhichAttached'].push(this.allbranch[i]);
        }
      }
      console.log(this.Adduser.value['branchToWhichAttached'])
      if (this.textSaveBtn === 'Save') {
        this.Adduser.value["employeeID"] = 0
        this.Adduser.value["userID"] = null
      }
      console.log(this.Selectuser.value["userType"])
      this.Adduser.value["organisationID"] =   this.organisationID
      this.Adduser.value["userType"] = this.Selectuser.value["userType"]
      this.Adduser.value["createdBy"] = 1
      this.Adduser.value["createdOn"] = null
      if (this.textSaveBtn === 'Update') {
        this.IsPasswordExists(this.Adduser.value)
      } else {
        this.IsUserEmployeeExist(this.Adduser.value)
      }
    }

  }
  getAllGender() {
    this.user.getAllGender()
      .subscribe(result => {
        console.log(result)
        this.gender=result.data
      })}

  IsPasswordExists(data: any) {
    this.user.IsPasswordExists(data)
      .subscribe(result => {
        console.log(result)
        if (result.data.message === "NOTEXIST") {
          this.IsUserEmployeeExist(data)
        }
        else {
          this.pwdexist = true
          //  this.present=result.data
          this.openModalDialog1(result.data.message)
        }

      });
  }
  selectedFile: ImageSnippet;

  processFile(e: any) {
    console.log(e)
    console.log(e.target.files[0])
    const file: File = e.target.files[0];
    this.files=file

  }
  uploadfile(){
    const reader = new FileReader();
    reader.addEventListener('load', (event: any) => {

      this.selectedFile = new ImageSnippet(event.target.result,  this.files);
      console.log(this.selectedFile)
      this.user.UploadEmployeePoto(this.selectedFile.file).subscribe(
        (res) => {
          console.log("ddd>", res);
        },
        (err) => {
          console.log("err>", err);
        })
    });

    reader.readAsDataURL( this.files);
  }
  IsUserEmployeeExist(data: any) {
    this.user.IsUserEmployeeExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data.message === "NOTEXIST") {
          console.log(this.Adduser.value)
          this.user.InsertUserAndEmployeeDetails(data)
            .subscribe(result => {
              console.log(result)
              if (result.data.EmployeeAttachedBranchStatus === "Success") {
                this.success = true
                if (this.textSaveBtn === 'Save') {
                  this.transaction = "Created"
                } else {
                  this.transaction = "Updated"
                }

                this.openModalDialog()
                this.CancelAddUser()
                this.getalluser()
              }
              else {
                this.fail = true

                this.openModalDialog()
              }
              // this.getalltaxstructure()
              // this.clearTaxStructure()
            });
        }
        else {
          this.exist = true
          this.openModalDialog1(result.data.message)
          //  this.present=result.data
          this.openModalDialog()
        }

      });
  }
  getGradeDetails(): void {

    let obj = {
      "organisationId" :this.organisationID,
      "description": ''
    }

    this.gradeService.getGradeDetails(obj)
      .subscribe(a => {
        console.log(a)
        this.gradeObj = a;
      });

  }
  CancelAddUser() {
    this.UserForm()
    this.getallbranches()
    this.Addunderwriter = []
    // console.log(this.submitted)
    this.submitted1 = false
    this.userheading = 'Add - New User';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    this.all = false
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  mobValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }

  textValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (charCode === 32 || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)
        event.preventDefault();

      }

    }
  }

  pwdValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (charCode === 32) {
        console.log(l)
        event.preventDefault();
      }
    }
  }
  btngEdit_Click(data) {
    console.log(data)
    this.userheading = 'Edit - User';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.getUserById(data.employeeID)
  }
  btngView_Click(data) {
    this.userheading = 'View - User';
    this.view = true
    this.Under_Writers = false
    console.log(this.view)
    this.saveBtnMode = false;
    this.getUserById(data.employeeID)
  }
  
  faxNphoneValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 11) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }

  get MobNoError() {

    if (this.Adduser.controls['mobileNo'].hasError('required')) {
      return 'Mobile Number is required';
    } else if (this.Adduser.controls['mobileNo'].hasError('pattern')) {
      return 'Please enter valid Mobile Number';
    } else if (this.Adduser.controls['mobileNo'].hasError('minlength')) {
      return 'Please enter valid 10 digits Mobile Number';
    }
  }

  get ConferenceNoError() {
    if (this.Adduser.controls['conferenceNo'].hasError('pattern')) {
      return 'Conference Number Should be 11 Digit or 12 Digit';
    }
  }

  get EmailError() {
    if (this.Adduser.controls['email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }

  get passwordError() {

    if (this.Adduser.controls['password'].hasError('required')) {
      return 'Please enter the Password';
    }
    else if (this.Adduser.controls['password'].hasError('pattern')) {
      return 'Password must contain Minimum 8 Characters,Minimum 1 Alphabet,Minimum 1 Numeric,Minimum 1 Special Character and No Spaces';
    }
  }

  get confirmpasswordError() {

    if (this.Adduser.controls['Confirm_Password'].hasError('required')) {
      return 'Please confirm  the Password';
    }
    else if (this.Adduser.controls['Confirm_Password'].hasError('mustMatch')) {
      return ' confirm password must match password';
    }
  }




  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted1 = false
    this.Adduser.reset()
  }
  openModalDialog1(msg) {
    this.display = 'block'; //Set block css
    this.submitted1 = false
    this.msg = msg
  }
  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.pwdexist = false
    this.exist = false
    this.success = false
  }



}



// error on password field if entered wrong=====

// error msg

//  Password must contain Minimum 8 Characters,Minimum 1 Alphabet,
// Minimum 1 Numeric,Minimum 1 Special Character and No Spaces


// confirm password copy paste not allowed

// visually increase length of password

// on submit msg User Created Successfully


// mobile number only numbers allowed error  Mobile Number Should be 10 Digit

//   Landline Number Should be 11 Digit or 12 Digit.(number only numbers)

//   Please provide a valid email address


//   on click of Under Writer  UnderWriter form
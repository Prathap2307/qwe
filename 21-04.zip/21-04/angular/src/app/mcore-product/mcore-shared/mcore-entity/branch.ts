export class Branch {
    branchName: string;
    branchCode: string;
	parentBranchName: string;
	workingDate: string;
    zone: string;
	division: string;
	addressOne: number;
	addressTwo: number;
	addressThree: number;
	zipCode: number;
	country: string;
	state: string;
	district: string;
	postOffice: string;
	emailId: string;
	phoneNumber: number;
	mobileNumber: number;
}
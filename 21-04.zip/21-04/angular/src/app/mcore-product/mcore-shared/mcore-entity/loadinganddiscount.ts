export class LoadingAndDiscount {
	loadingAndDiscount: string;
	categoryValue: string;
	variant: string;
	questions: string;
    employeeRangeFrom: number;
    employeeRangeTo: number;
    valueSpecified: number;
}	


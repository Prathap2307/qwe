import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {
  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }


  departmentUrl = this.baseUrl + '/department';

  /* GET Department */
  getDepartmentDetails(): Observable<DepartmentType[]> {
   console.log(this.departmentUrl);
    return this.http.get<DepartmentType[]>(this.departmentUrl)
      .pipe();
  }


  /* GET Department by ID */
  getDepartmentInfoByDescription(departmentId: number, description: string): Observable<DepartmentType[]> {

    const departmentByIDUrl = this.baseUrl + `/department/${departmentId}/${description}`;

    console.log(departmentByIDUrl);
    return this.http.get<DepartmentType[]>(departmentByIDUrl)
      .pipe();
  }

  /** PUT: update the hero on the server */

  updateDepartment(departmentRow: DepartmentType): Observable<DepartmentType> {
   console.log(departmentRow);
   const departmentUpdateUrl = this.baseUrl + `/createDepartment`;
   console.log(departmentUpdateUrl);
   return this.http.post<DepartmentType>(this.departmentUrl, departmentRow).pipe(
     catchError(this.handleError)
   );

  }

  handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput<any> {
    throw new Error("Method not implemented.");
  }
  consoleLogFn(val) {
    console.log(val);
  }

  createdepartmentUrl = this.baseUrl + `/createDepartment`;
  addDepartment(departmentRow: DepartmentType): Observable<DepartmentType> {
    // console.log(this.createdepartmentUrl);
    // console.log(departmentRow);
    return this.http.post<DepartmentType>(this.createdepartmentUrl, departmentRow);
  }


  // log(arg0: string): void {
  //   throw new Error("Method not implemented.");
  // }

    /** DELETE: delete the hero from the server */
    deleteDepartment (departmentRow: DepartmentType): Observable<DepartmentType> {
      
      const deleteDepartmentUrl = this.baseUrl + `/deleteDepartment`;
     return this.http.put<DepartmentType>(deleteDepartmentUrl, departmentRow)
     .pipe();

    }



}

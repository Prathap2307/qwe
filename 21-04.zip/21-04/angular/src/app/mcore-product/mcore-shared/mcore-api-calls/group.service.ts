import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class GroupService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }


  

  GetAllEmployeesByGroupID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetAllEmployeesByGroupID' + id).pipe(tap((response) => response));
    }

 
  

    GetGroupDetailsSearch(name:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetGroupDetailsSearch' + name).pipe(tap((response) => response));
    }

    GetPopupSearchGroupDetails(data:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetPopupSearchGroupDetails' + data).pipe(tap((response) => response));
    }

    GetGroupDetailsByGroupID(data:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetGroupDetailsByGroupID' + data).pipe(tap((response) => response));
    }

    GetSearchGroupDetailsByGroupName(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetSearchGroupDetailsByGroupName' + id).pipe(tap((response) => response));
    }

    GetAllUsersGroupByOrganisationID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetAllUsersGroupByOrganisationID?OrganisationID=' + id).pipe(tap((response) => response));
    }
    GetAllGroupsByOrg(data: any): Observable<any> {
      console.log("data", data)
      return this.http.get(this.baseUrl + '/GetAllGroupsByOrg?OrganisationID='+data.OrganisationID+'&Description='+data.Description).pipe(tap((response) => response));
    }

    InsertBranchIDBySalesHierarchyID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/InsertBranchIDBySalesHierarchyID' + id).pipe(tap((response) => response));
    }
    IsExistsGroupByLevelID(name:any): Observable<any>{
      return this.http.get(this.baseUrl + '/IsExistsGroupByLevelID' + name).pipe(tap((response) => response));
    }

    InsertOrUpdateGroup(data:any): Observable<any>{
      console.log(data)
      return this.http.post(this.baseUrl + '/InsertOrUpdateGroup' , data).pipe(tap((response) => response));
    }

    DeleteGroup(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/DeleteGroup?GroupID=' + id+'&DeletedBy='+1).pipe(tap((response) => response));
    }
    GetGroupByGroupID(data:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetGroupByGroupID?GroupID=' + data.groupID+'&OrganisationID=' + data.organisationID+'&Mode=0').pipe(tap((response) => response));
    }


   


    
}

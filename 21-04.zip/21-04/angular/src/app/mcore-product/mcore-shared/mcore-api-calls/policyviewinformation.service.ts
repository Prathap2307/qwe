import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
import { PolicyViewInformation } from 'src/app/mcore-product/mcore-shared/mcore-entity/policyviewinformation';

@Injectable({
  providedIn: 'root'
})
export class PolicyViewInformationService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

 
  getMembersearch(a: any): Observable<any> {
    
    const url = this.baseUrl + `/Membersearch`;
    console.log(a);
    console.log(url);
    return this.http.post<any>(url, a);
  }

  
  getPolicyCertificatesdownload(applicationId: number): Observable<any> {
    const requestOptions: Object = {
			/* other options here */
			responseType: 'text'
		  }

    const url = this.baseUrl + `/PolicyCertificatesdownload/${applicationId}`;
    return this.http.get<any>(url, requestOptions)
      .pipe();
  }
 


}

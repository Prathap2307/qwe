import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FchannelService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addHierarchy(a: any): Observable<any> {
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    // console.log(departmentRow);
    return this.http.post<any>(this.baseUrl+"/", a, { headers: headers });
  }
  addfchannel(a: any): Observable<any> {
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    console.log(a);
    return this.http.post<any>(this.baseUrl+"/InsertOrUpdateChannel", a, { headers: headers });
  }
  GetAllMainChannel(): Observable<any>{
 
    return this.http.get(this.baseUrl + '/GetAllMainChannel').pipe(tap((response) => response));
  }
  GetChannel(objinfo): Observable<any>{
 
    return this.http.post(this.baseUrl + '/GetAllChannel',objinfo).pipe(tap((response) => response));
  }
  GetAllBranchesbyorgID(id): Observable<any>{
    console.log(id)
    return this.http.get(this.baseUrl + '/GetAllBranchesByOrganisionId?OrganisationID='+ id).pipe(tap((response) => response));
  }

  IsChannelExist(objInfo): Observable<any>{
    console.log(objInfo)
    return this.http.post(this.baseUrl + '/IsChannelExist', objInfo).pipe(tap((response) => response));
  }
  DeleteChannel(objInfo): Observable<any>{
    console.log(objInfo)
    return this.http.post(this.baseUrl + '/DeleteChannel', objInfo).pipe(tap((response) => response));
  }
  addfsubchannel(a: any): Observable<any> {
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    // console.log(departmentRow);
    return this.http.post<any>(this.baseUrl+"/InsertSubChannel", a, { headers: headers });
  }
  IsSubChannelExist(objInfo): Observable<any>{
    console.log(objInfo)
    return this.http.post(this.baseUrl + '/IsSubChannelExist', objInfo).pipe(tap((response) => response));
  }
  GetSubChannelById(id): Observable<any>{
    console.log(id)
    return this.http.get(this.baseUrl + '/GetSubChannelDetailsbySubChannelID?SubChannelID='+id).pipe(tap((response) => response));
  }
  GetAllSubChannel(objInfo): Observable<any>{
 
    return this.http.post(this.baseUrl + '/GetSubChannel',objInfo).pipe(tap((response) => response));
  }
  GetChannelById(id): Observable<any>{
    console.log(id)
    return this.http.get(this.baseUrl + '/GetChannelById?ChannelID='+ id).pipe(tap((response) => response));
  }
  DeleteSubChannel(id): Observable<any>{
    console.log(id)
    return this.http.get(this.baseUrl + '/DeleteSubChannel?SubChannelID='+id).pipe(tap((response) => response));
  }
  
  //saleshierarchy
  InsertOrUpdateSalesHierarchy(a: any): Observable<any> {
  

    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    console.log(a);
    return this.http.post<any>(this.baseUrl+"/InsertOrUpdateSalesHierarchy", a, { headers: headers });
  }
  GetAllSalesHierarchyBySearch(): Observable<any>{
    return this.http.get(this.baseUrl + '/GetAllSalesHierarchyBySearch?LineOfBusinessID=5').pipe(tap((response) => response));
  }
  getaddresstype(): Observable<any>{
    return this.http.get(this.baseUrl + '/lookup/address-type/get').pipe(tap((response) => response));
  }
  GetSalesHierarchyByID(id): Observable<any>{
    console.log(id)
    return this.http.get(this.baseUrl + '/GetSalesHierarchyByID?SalesHierarchyID='+id+'&LineOfBusinessID=5').pipe(tap((response) => response));
  }
  GetAllReportingTo(): Observable<any>{

    return this.http.get(this.baseUrl + '/getAllReportingTo').pipe(tap((response) => response));
  }

}

package com.LIC.bl;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;

import com.LIC.constant.Constant;
import com.LIC.model.SalesHierarchyModal;
import com.LIC.model.SalesHierarchyAddressModal;
import com.LIC.model.SalesHierarchyAddressMapModal;

import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;
public class SalesHierarchyBL {
	private static final Logger logger = Logger.getLogger(SalesHierarchyBL.class);
	
	public SalesHierarchyModal createSalesHierarchyModalDto(ValueObject object) {
		try {
			SalesHierarchyModal objSalesHierarchyModal = new SalesHierarchyModal();
			objSalesHierarchyModal.setSalesHierarchyID(object.getLong("salesHierarchyID",0));
			objSalesHierarchyModal.setLineOfBusinessID(object.getLong("lineOfBusinessID",0));
			objSalesHierarchyModal.setSalutationID(object.getLong("salutationID",0));
			objSalesHierarchyModal.setFirstName(object.getString("firstName",""));
			objSalesHierarchyModal.setLastName(object.getString("lastName",""));
			objSalesHierarchyModal.setCode(object.getString("code",""));
			objSalesHierarchyModal.setFireTypeID(object.getLong("fireTypeID",0));
			objSalesHierarchyModal.setDesignationID(object.getLong("designationID",0));
			objSalesHierarchyModal.setParentHierarchyID(object.getLong("parentHierarchyID",0));
			objSalesHierarchyModal.setBranchID(object.getLong("branchID",0));
			objSalesHierarchyModal.setAccountBranchID(object.getLong("accountBranchID",0));
			objSalesHierarchyModal.setTriggerLimit(object.getDouble("triggerLimit",0));
			objSalesHierarchyModal.setSalesTypeID(object.getLong("salesTypeID",0));
			objSalesHierarchyModal.setType(object.getString("type",""));
			objSalesHierarchyModal.setIsEmployee(object.getShort("isEmployee",(short)0));
		    objSalesHierarchyModal.setIsAdvanceDeposit(object.getShort("isAdvanceDeposit", (short)0));
		    objSalesHierarchyModal.setCreatedBy(object.getLong("createdBy",0));
		    if(object.get("createdOn") != null && !object.get("createdOn").equals("")) {
		    	objSalesHierarchyModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} 
		    objSalesHierarchyModal.setModifiedBy(object.getLong("modifiedBy",0));
		    if(object.get("modifiedOn") != null && !object.get("modifiedOn").equals("")) {
		    	objSalesHierarchyModal.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("modifiedOn")));
			}
		    objSalesHierarchyModal.setIsActive(object.getShort("isActive",(short)0));
		    objSalesHierarchyModal.setDeletedBy(object.getLong("deletedBy"));
		    if(object.get("deletedOn") != null && !object.get("deletedOn").equals("")) {
		    	objSalesHierarchyModal.setDeletedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("deletedOn")));
			}
		    objSalesHierarchyModal.setSalesType(object.getLong("salesType",0));
		    objSalesHierarchyModal.setChannelID(object.getLong("channelID",0));
		    objSalesHierarchyModal.setSubChannelID(object.getLong("subChannelID",0));
		    objSalesHierarchyModal.setPolicyHolderID(object.getLong("policyHolderID",0));
		    objSalesHierarchyModal.setMobileNumber(object.getString("mobileNumber",""));
		    objSalesHierarchyModal.setLandLineNumber(object.getString("landLineNumber",""));
		    objSalesHierarchyModal.setPanCard(object.getString("panCard",""));
		    objSalesHierarchyModal.setAadharNumber(object.getString("aadharNumber",""));
		    objSalesHierarchyModal.setOrganisationName(object.getString("organisationName"));
		    objSalesHierarchyModal.setDepartmentID(object.getLong("departmentID",0));
		    objSalesHierarchyModal.setIsPayableFeature(object.getLong("IsPayableFeature",0));
		    if(object.get("applicationDate") != null && !object.get("applicationDate").equals("")) {
		    	objSalesHierarchyModal.setApplicationDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("applicationDate")));
			}
		    if(object.get("DateofJoining") != null && !object.get("DateofJoining").equals("")) {
		    	objSalesHierarchyModal.setDateofJoining((Timestamp) DateTimeUtility.getTimeStamp(object.getString("DateofJoining")));
			}
		    objSalesHierarchyModal.setGender(object.getLong("Gender",0));
		    if(object.get("DOB") != null && !object.get("DOB").equals("")) {
		    	objSalesHierarchyModal.setDOB((Timestamp) DateTimeUtility.getTimeStamp(object.getString("DOB")));
			}
		    objSalesHierarchyModal.setAge(object.getLong("Age",0));
		    objSalesHierarchyModal.setMonth(object.getLong("Month",0));
		    objSalesHierarchyModal.setPanNumber(object.getString("PanNumber",""));
		    objSalesHierarchyModal.setRegistredunder(object.getString("Registredunder",""));
		    if(object.get("MIAagreementdate") != null && !object.get("MIAagreementdate").equals("")) {
		    	objSalesHierarchyModal.setMIAagreementdate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("MIAagreementdate")));
			}
		    if(object.get("CodeIssuancedate") != null && !object.get("CodeIssuancedate").equals("")) {
		    	objSalesHierarchyModal.setCodeIssuancedate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("CodeIssuancedate")));
			}
		    if(object.get("Renewaldate") != null && !object.get("Renewaldate").equals("")) {
		    	objSalesHierarchyModal.setRenewaldate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("Renewaldate")));
			}
		    if(object.get("CodeExpiredate") != null && !object.get("CodeExpiredate").equals("")) {
		    	objSalesHierarchyModal.setCodeExpiredate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("CodeExpiredate")));
			}
		    if(object.get("Effectivedate") != null && !object.get("Effectivedate").equals("")) {
		    	objSalesHierarchyModal.setEffectivedate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("Effectivedate")));
			}
		    if(object.get("Expiredate") != null && !object.get("Expiredate").equals("")) {
		    	objSalesHierarchyModal.setExpiredate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("Expiredate")));
			}
		    if(object.get("RemarksDate") != null && !object.get("RemarksDate").equals("")) {
		    	objSalesHierarchyModal.setRemarksDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("RemarksDate")));
			}
		    if(object.get("Registrationdate") != null && !object.get("Registrationdate").equals("")) {
		    	objSalesHierarchyModal.setRegistrationdate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("Registrationdate")));
			}
		    objSalesHierarchyModal.setBankName(object.getString("BankName",""));
		    objSalesHierarchyModal.setBranchName(object.getString("BranchName",""));
		    objSalesHierarchyModal.setAccountHolderName(object.getString("AccountHolderName",""));
		    objSalesHierarchyModal.setAccountNO(object.getString("AccountNO",""));
		    objSalesHierarchyModal.setAccountType(object.getString("AccountType",""));
		    objSalesHierarchyModal.setIFSCcode(object.getString("IFSCcode",""));
		    objSalesHierarchyModal.setMicrcode(object.getString("Micrcode",""));
		    objSalesHierarchyModal.setAgentLocation(object.getString("AgentLocation",""));
		    objSalesHierarchyModal.setRemarks(object.getString("Remarks",""));
		    objSalesHierarchyModal.setAddressID(object.getLong("addressID",0));
		    objSalesHierarchyModal.setPayableFeature(object.getShort("payableFeature",(short)0));
		    return objSalesHierarchyModal;
		}
		catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	
	public SalesHierarchyAddressModal createSalesHierarchyAddressModalDto(ValueObject object) {
		
		try
		{
			SalesHierarchyAddressModal salesHierarchyAddressModal = new SalesHierarchyAddressModal();
			salesHierarchyAddressModal.setAddressID(object.getLong("addressID"));
			salesHierarchyAddressModal.setAddress1(object.getString("address1"));
			salesHierarchyAddressModal.setAddress2(object.getString("address2"));
			salesHierarchyAddressModal.setAddress3(object.getString("address3"));
			salesHierarchyAddressModal.setAddress4(object.getString("address4"));
			salesHierarchyAddressModal.setAddress5(object.getString("address5"));
			salesHierarchyAddressModal.setCountryID(object.getLong("countryID"));
			salesHierarchyAddressModal.setStateID(object.getLong("stateID"));
			salesHierarchyAddressModal.setTehsil(object.getString("tehsil"));
			salesHierarchyAddressModal.setDistrictID(object.getLong("districtID"));
			salesHierarchyAddressModal.setTalukID(object.getLong("talukID"));
			salesHierarchyAddressModal.setZipCode(object.getString("zipCode"));
			salesHierarchyAddressModal.setAddressTypeID(object.getLong("addressTypeID"));
			salesHierarchyAddressModal.setPhoneNo(object.getString("phoneNo"));
			salesHierarchyAddressModal.setMobileNo(object.getString("mobileNo"));
			salesHierarchyAddressModal.setConferenceNo(object.getString("conferenceNo"));
			salesHierarchyAddressModal.setFaxNo(object.getString("faxNo"));
			salesHierarchyAddressModal.setEmail(object.getString("email"));
			salesHierarchyAddressModal.setCreatedBy(object.getLong("createdBy"));
			if(object.get("createdOn") != null && !object.get("createdOn").equals("")) {
				salesHierarchyAddressModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} 
			salesHierarchyAddressModal.setModifiedBy(object.getLong("modifiedBy",0));
			salesHierarchyAddressModal.setModifiedBy(object.getLong("modifiedBy",0));
			    if(object.get("modifiedOn") != null && !object.get("modifiedOn").equals("")) {
			    	salesHierarchyAddressModal.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("modifiedOn")));
				}
			    salesHierarchyAddressModal.setDeletedBy(object.getLong("deletedBy"));
			    if(object.get("deletedOn") != null && !object.get("deletedOn").equals("")) {
			    	salesHierarchyAddressModal.setDeletedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("deletedOn")));
				} 

			    salesHierarchyAddressModal.setIsActive(object.getShort("isActive",(short)0));
			    salesHierarchyAddressModal.setVendorID(object.getString("vendorID"));
			    salesHierarchyAddressModal.setSalesHierArchyID(object.getLong("sSalesHierArchyID"));
			    salesHierarchyAddressModal.setVillageID(object.getLong("villageID"));
			    salesHierarchyAddressModal.setDeleted(object.getShort("deleted",(short)0));
			    salesHierarchyAddressModal.setAddressTypeTypeID(object.getLong("addressTypeTypeID"));
		}
		catch(Exception e)
		{
			logger.info("error :"+e.getLocalizedMessage());	
		}
		return null;
	}
	public SalesHierarchyAddressMapModal createSalesHierarchyAddressMapModalDto(ValueObject object) {
	 
		try
		{
			SalesHierarchyAddressMapModal salesHierarchyAddressMapModal = new SalesHierarchyAddressMapModal();
			salesHierarchyAddressMapModal.setId(object.getLong("id"));
			salesHierarchyAddressMapModal.setSalesHierarchyID(object.getLong("salesHierarchyID"));
			salesHierarchyAddressMapModal.setAddressID(object.getLong("AddressID"));
			salesHierarchyAddressMapModal.setCreaetedBy(object.getLong("creaetedBy"));
			if(object.get("createdOn") != null && !object.get("createdOn").equals("")) {
				salesHierarchyAddressMapModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			}
			salesHierarchyAddressMapModal.setIsActive(object.getShort("isActive",(short)0));
		}
		catch(Exception e)
		{
			logger.info("error :"+e.getLocalizedMessage());		
		}
		return null;
	}
}

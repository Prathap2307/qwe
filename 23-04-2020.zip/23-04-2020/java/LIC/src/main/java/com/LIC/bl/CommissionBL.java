package com.LIC.bl;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.LIC.model.CommissionModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

/**
 * @author Pradip/Rahul 
 *
 *2019
 */
public class CommissionBL  {
	
	private static final Logger logger = Logger.getLogger(CommissionBL.class);
	
	public  CommissionModal createCommisionInfoDto(ValueObject object) {
		
		try {
			
			CommissionModal		 commisionModal	= new CommissionModal();
			
			commisionModal.setPlanID(object.getLong("planID",0));
			commisionModal.setPolicyYearTypeID(object.getLong("policyYearTypeID",0));
			commisionModal.setMainChannelID(object.getLong("mainChannelID",0));
			commisionModal.setSubChannelID(object.getLong("subChannelID",0));
			
			if(object.get("fromDate") != null && !object.getString("fromDate").equals("")) {
				commisionModal.setFromDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("fromDate")));
			} 
			if(object.get("toDate") != null && !object.getString("toDate").equals("")) {
				commisionModal.setToDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("toDate")));
			} 
			commisionModal.setRangeFrom(object.getLong("rangeFrom",0));
			commisionModal.setRangeTo(object.getLong("rangeTo",0));
			commisionModal.setAmount(object.getDouble("amount",0));
			commisionModal.setCreatedBy(object.getLong("createdBy",0));
			commisionModal.setIsActive(object.getShort("isActive",(short)1));
			commisionModal.setPolicyTermID(object.getLong("policyTermID",0));
			commisionModal.setCommissionID(object.getLong("commissionID",0));
			commisionModal.setSalesHierarchyID(object.getLong("salesHierarchyID",0));
			
			 return commisionModal;
		} catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	
	
	public String getSearchDataForCommission(ValueObject object)  {
        
		String 					searchData 					= "";
		CommissionModal 		commissionModal 			= null;
			
		try {
			
			commissionModal 	= createCommisionInfoDto(object);
    
	        //if (txtSearchFromDate.Text.Trim() != "" & txtSearchToDate.Text.Trim() != "")
	        //{
	        //    DateTime SDate = Convert.ToDateTime(cmnObject.gfncFormatDate(txtSearchFromDate.Text));
	        //    DateTime EDate = Convert.ToDateTime(cmnObject.gfncFormatDate(txtSearchToDate.Text));
	        //    searchData += " AND Cm.FromDate >= '" + SDate.ToString("yyyy-MM-dd") + " 00:00:00.000' AND Cm.ToDate <= '" + EDate.ToString("yyyy-MM-dd") + " 00:00:00.000'";
	        //}
	        //if (txtSearchFromDate.Text.Trim() != "" & txtSearchToDate.Text.Trim() == "")
	        //{
	        //    DateTime SDate = Convert.ToDateTime(cmnObject.gfncFormatDate(txtSearchFromDate.Text));
	        //    searchData += " AND Cm.FromDate >= '" + SDate.ToString("yyyy-MM-dd") + " 00:00:00.000'";
	        //}
	        //if (txtSearchFromDate.Text.Trim() == "" & txtSearchToDate.Text.Trim() != "")
	        //{
	        //    DateTime EDate = Convert.ToDateTime(cmnObject.gfncFormatDate(txtSearchToDate.Text));
	        //    searchData += " AND Cm.ToDate <= '" + EDate.ToString("yyyy-MM-dd") + " 00:00:00.000'";
	        //}
	        if (commissionModal.getFromDate().toString().trim() != "" && commissionModal.getToDate().toString().trim()  != "")
	        {
	            
	            searchData += " AND Cm.FromDate >= '" + commissionModal.getFromDate() + "' AND Cm.FromDate <= '" + commissionModal.getToDate() + "' ";
	        }
	        if (commissionModal.getPlanID() > 0)
	        {
	        	searchData = searchData + " and Master_Product.ProductID  = " + commissionModal.getPlanID() + "";
	        }
	        if (commissionModal.getMainChannelID() > 0)
	        {
	            searchData = searchData + " and Master_Channel.ChannelID = " + commissionModal.getMainChannelID() + "";
	        }
	        return searchData;
		} catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}
		return searchData;
    }

}



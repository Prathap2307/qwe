package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.GradeDAO;
import com.LIC.model.GetGradeModel;
import com.LIC.model.GradeModel;

@RestController
public class GradeController {
	
@Autowired
	
	private GradeDAO grade;
@PostMapping("/createGrade")
public void postGrade(@RequestBody GradeModel model) {
	grade.postGrade(model);

}
	
@RequestMapping(method = RequestMethod.PUT, value = "/deleteGrade")
public void deleteGrade(@RequestBody GradeModel model) {

	grade.deleteGrade(model);
}


@PostMapping( value="/grade")
public List<GetGradeModel> GetGrades(@RequestBody GetGradeModel g) {
                        
                        return  grade.GetAllGrades(g);
                
                
                
        }



}




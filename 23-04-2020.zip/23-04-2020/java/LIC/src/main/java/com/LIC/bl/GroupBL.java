package com.LIC.bl;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.LIC.constant.Constant;
import com.LIC.model.GroupModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

public class GroupBL  {
	
	private static final Logger logger = Logger.getLogger(GroupBL.class);
	
	public GroupModal createGroupModel (ValueObject object,ValueObject outObject)throws Exception {
		
		GroupModal 	groupModel	= null;
		
		try {
			groupModel	= new GroupModal();
			
			groupModel.setOrganisationID(object.getLong("organisationID",0));
			groupModel.setGroupID(object.getLong("groupID",0));
			groupModel.setUserID(object.getLong("userID",0));
			groupModel.setGroupName(object.getString("groupName",""));
			
			if(object.getString("groupName","").equals("")) {
				outObject.put(Constant.ERROR, "Group Name should not empty !");
			}
			groupModel.setCreatedBy(object.getLong("createdBy",0));
			groupModel.setModifiedBy(object.getLong("modifiedBy",0));
			groupModel.setDeletedBy(object.getLong("deletedBy",0));
			groupModel.setIsActive(object.getShort("isActive",(short)1));
			
			if(object.get("createdOn") != null && !object.get("createdOn").equals("")) {
				groupModel.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				groupModel.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("modifiedOn") != null && !object.get("modifiedOn").equals("")) {
				groupModel.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("modifiedOn")));
			} else {
				groupModel.setModifiedOn(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("deletedOn") != null && !object.get("deletedOn").equals("")) {
				groupModel.setDeletedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("deletedOn")));
			} else {
				groupModel.setDeletedOn(new Timestamp(System.currentTimeMillis()));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			outObject.put(Constant.ERROR, e.getLocalizedMessage());
			logger.info("error :"+e.getLocalizedMessage());
		}
		return groupModel;
	}
}

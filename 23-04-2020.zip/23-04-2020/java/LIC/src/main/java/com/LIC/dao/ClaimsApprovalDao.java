package com.LIC.dao;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.SaveClaimsApprovalModel;

/*
 * @Author = "671621"
 */
@Repository
public class ClaimsApprovalDao {

	@Autowired
	private EntityManager entityManager; 
	
	public boolean updateClaimsPayableDetails(SaveClaimsApprovalModel saveClaimsApprovalModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spUpdateClaimsPayableDetails")
				
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsDeductible", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDeductibleAmount", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAccountBalance", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAmountDeducted", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAmountAdded", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTotalApprovedAmount", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTotalAmountPayable", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPreviousBalanceAmount", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vProfessionalCharges", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vProfessionalServiceTax", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTotalProfessionalCharges", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vSurveyorIncidentalCharges", Float.class, ParameterMode.IN)
				
				.setParameter("vClaimID", saveClaimsApprovalModel.getvClaimID())
				.setParameter("vIsDeductible", saveClaimsApprovalModel.getvIsDeductible())
				.setParameter("vDeductibleAmount", saveClaimsApprovalModel.getvDeductibleAmount())
				.setParameter("vAccountBalance", saveClaimsApprovalModel.getvAccountBalance())
				.setParameter("vAmountDeducted", saveClaimsApprovalModel.getvAmountDeducted())
				.setParameter("vAmountAdded", saveClaimsApprovalModel.getvAmountAdded())
				.setParameter("vTotalApprovedAmount", saveClaimsApprovalModel.getvTotalApprovedAmount())
				.setParameter("vTotalAmountPayable", saveClaimsApprovalModel.getvTotalAmountPayable())
				.setParameter("vPreviousBalanceAmount", saveClaimsApprovalModel.getvPreviousBalanceAmount())
				.setParameter("vProfessionalCharges", saveClaimsApprovalModel.getvProfessionalCharges())
				.setParameter("vProfessionalServiceTax", saveClaimsApprovalModel.getvProfessionalServiceTax())
				.setParameter("vTotalProfessionalCharges", saveClaimsApprovalModel.getvTotalProfessionalCharges())
				.setParameter("vSurveyorIncidentalCharges", saveClaimsApprovalModel.getvSurveyorIncidentalCharges());

		storedProcedureQuery.execute();
		return true;
	}

	public int insertClaimCoverageBenefitDetails(SaveClaimsApprovalModel saveClaimsApprovalModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spInsertClaimCoverageBenefitDetails")
				
				.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCoveargeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vBenefitID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vEligibleAmount", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vLimitType", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vActualExpenses", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vApprovedAmount", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTotApprovedAmmount", Float.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				
				
				
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
				
				.setParameter("vClaimID", saveClaimsApprovalModel.getvClaimID())
				.setParameter("vCoveargeID", saveClaimsApprovalModel.getvCoveargeID())
				.setParameter("vBenefitID", saveClaimsApprovalModel.getvBenefitID())
				.setParameter("vEligibleAmount", saveClaimsApprovalModel.getvEligibleAmount())
				.setParameter("vLimitType", saveClaimsApprovalModel.getvLimitType())
				.setParameter("vActualExpenses", saveClaimsApprovalModel.getvActualExpenses())
				.setParameter("vApprovedAmount", saveClaimsApprovalModel.getvApprovedAmount())
				.setParameter("vTotApprovedAmmount", saveClaimsApprovalModel.getvTotApprovedAmmount())
				.setParameter("vCreatedBy", saveClaimsApprovalModel.getvCreatedBy())
				.setParameter("vCreatedOn", saveClaimsApprovalModel.getvCreatedOn())
				.setParameter("vIsActive", saveClaimsApprovalModel.getvIsActive());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

}

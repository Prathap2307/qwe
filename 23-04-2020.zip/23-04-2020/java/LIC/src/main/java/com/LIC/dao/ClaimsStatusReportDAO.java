/*package com.lic.claim.claimsstatusreport.dao;*/

package com.LIC.dao;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ClaimsStatusReportModel;

@Repository
public class ClaimsStatusReportDAO {
	@Autowired
	private EntityManager entityManager;

	public int getSearchClaimsView(ClaimsStatusReportModel claimsStatusReportModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetSearchClaimsView")

				.registerStoredProcedureParameter("pLineOfBusinessID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPageTYpeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pClaimNumber", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pFirstName", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pLastName", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPolicyNumber", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pContactID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pStatusID", Integer.class, ParameterMode.IN)

				.setParameter("pLineOfBusinessID", claimsStatusReportModel.getpLineOfBusinessID())
				.setParameter("pPageTYpeID", claimsStatusReportModel.getpPageTYpeID())
				.setParameter("pClaimNumber", claimsStatusReportModel.getpClaimNumber())
				.setParameter("pFirstName", claimsStatusReportModel.getpFirstName())
				.setParameter("pLastName", claimsStatusReportModel.getpLastName())
				.setParameter("pPolicyNumber", claimsStatusReportModel.getpPolicyNumber())
				.setParameter("pContactID", claimsStatusReportModel.getpContactID())
				.setParameter("pStatusID", claimsStatusReportModel.getpStatusID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int getClaimDetailsByClaimID(ClaimsStatusReportModel claimsStatusReportModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createNamedStoredProcedureQuery("spGetClaimDetailsByClaimID")

				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oCur1", Class.class, ParameterMode.REF_CURSOR)
				.registerStoredProcedureParameter("oCur2", Class.class, ParameterMode.REF_CURSOR)
				.registerStoredProcedureParameter("oCur3", Class.class, ParameterMode.REF_CURSOR)
				.registerStoredProcedureParameter("oCur4", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pClaimID", claimsStatusReportModel.getpClaimID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int getClaimProductTransactionDetails(ClaimsStatusReportModel claimsStatusReportModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spGetClaimProductTransactionDetails")

				.registerStoredProcedureParameter("pApplicationID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pProductID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pApplicationID", claimsStatusReportModel.getpApplicationID())
				.setParameter("pProductID", claimsStatusReportModel.getpProductID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");

	}

	public int getClaimsDocument(ClaimsStatusReportModel claimsStatusReportModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetClaimsDocument")

				.registerStoredProcedureParameter("pID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oCUR", Class.class, ParameterMode.REF_CURSOR)
				.registerStoredProcedureParameter("oCUR1", Class.class, ParameterMode.REF_CURSOR)
				.registerStoredProcedureParameter("oCUR2", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pID", claimsStatusReportModel.getpID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int getAssessmentHistory(ClaimsStatusReportModel claimsStatusReportModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetAssessmentHistory")

				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oBANK", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pClaimID", claimsStatusReportModel.getpClaimID());

		storedProcedureQuery.execute();

		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

}

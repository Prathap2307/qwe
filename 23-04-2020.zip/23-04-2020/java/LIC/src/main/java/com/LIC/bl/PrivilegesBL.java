package com.LIC.bl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.LIC.model.PrivilegesModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

public class PrivilegesBL 
{
	
	private static final Logger logger = Logger.getLogger(MessageTemplateBL.class);
	
	public PrivilegesModal createPrivilegesModal (ValueObject object) throws Exception {
		
		try {
			PrivilegesModal privilegesmodal = new PrivilegesModal();
			privilegesmodal.setUserID(object.getLong("userID",0));
			privilegesmodal.setGroupID(object.getLong("groupID",0));
			privilegesmodal.setModuleID(object.getLong("moduleID",0));
			privilegesmodal.setFeatureID(object.getLong("featureID",0));
			privilegesmodal.setUserRoleID(object.getLong("userRoleID",0));
			privilegesmodal.setGroupRoleID(object.getLong("groupRoleID",0));
			privilegesmodal.setDepartmentID(object.getLong("departmentID",0));
			privilegesmodal.setDesignationID(object.getLong("designationID",0));
			privilegesmodal.setPrivilegesID(object.getLong("privilegesID",0));
			privilegesmodal.setUserRoles(object.getString("userRoles",""));
			privilegesmodal.setGroupRoles(object.getString("groupRoles",""));
			privilegesmodal.setType(object.getLong("type",0));
			privilegesmodal.setCreatedBy(object.getLong("createdBy",0));
			
			if(object.get("createdOn") != null && !object.get("createdOn").equals("")) {
				privilegesmodal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				privilegesmodal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			return privilegesmodal;
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<PrivilegesModal> createPrivilegesModalList(ValueObject object) throws Exception {
		PrivilegesModal 		privilegesmodal			= null;
		List<PrivilegesModal> 	privilegesmodalList		= null;
		List<Object> 			privilegesmodalDetails	= null;
		ValueObject				objectMapper			= null;
		
		try {
			privilegesmodalDetails	= (List<Object>) object.get("privilegesmodalDetails",null);
			System.out.println("privilegesmodalDetails >"+privilegesmodalDetails);
			if(privilegesmodalDetails != null) {
				
				privilegesmodalList	= new ArrayList<PrivilegesModal>();
				
				for(Object obj : privilegesmodalDetails) {
					
					System.out.println("obj >"+obj);
					objectMapper 	= new ValueObject((HashMap<Object, Object>) obj);
					privilegesmodal = new PrivilegesModal();
					privilegesmodal.setUserID(objectMapper.getLong("userID",0));
					privilegesmodal.setGroupID(objectMapper.getLong("groupID",0));
					privilegesmodal.setModuleID(objectMapper.getLong("moduleID",0));
					privilegesmodal.setFeatureID(objectMapper.getLong("featureID",0));
					privilegesmodal.setUserRoleID(objectMapper.getLong("userRoleID",0));
					privilegesmodal.setGroupRoleID(objectMapper.getLong("groupRoleID",0));
					privilegesmodal.setDepartmentID(objectMapper.getLong("departmentID",0));
					privilegesmodal.setDesignationID(objectMapper.getLong("designationID",0));
					privilegesmodal.setPrivilegesID(objectMapper.getLong("privilegesID",0));
					privilegesmodal.setUserRoles(objectMapper.getString("userRoles",""));
					privilegesmodal.setGroupRoles(objectMapper.getString("groupRoles",""));
					privilegesmodal.setType(objectMapper.getLong("type",0));
					privilegesmodal.setCreatedBy(objectMapper.getLong("createdBy",0));
					privilegesmodal.setLineOfBusinessID(objectMapper.getLong("lineOfBusinessID",0));
					
					if(objectMapper.get("createdOn") != null && !objectMapper.get("createdOn").equals("")) {
						privilegesmodal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(objectMapper.getString("createdOn")));
					} else {
						privilegesmodal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
					}
					privilegesmodalList.add(privilegesmodal);
				}
			}
			
			return privilegesmodalList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}

}

package com.LIC.bl;

import java.sql.Timestamp;
import org.apache.log4j.Logger;

import com.LIC.model.DataUploadModal;
import com.LIC.model.SearchModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;
public class DataUploadBL {

	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryBL.class);
	
	public DataUploadBL  createdatauploadmodalInfoDto(ValueObject object) throws Exception
	{
		try
		{
			DataUploadModal dataupload = new DataUploadModal();
			SearchModal search = new SearchModal();
			dataupload.setPageName(object.getString("pageName",""));
			dataupload.setPileName(object.getString("pileName",""));
			dataupload.setFileName(object.getString("fileName",""));
			dataupload.setTypeID(object.getLong("typeID",0));
			dataupload.setCreatedBy(object.getLong("createdBy",0));
			if(object.get("createdOn") != null) {
				dataupload.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				dataupload.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			dataupload.setGroupID(object.getLong("groupID",0));
			dataupload.setProductID(object.getLong("productID",0));
			dataupload.setQuotationID(object.getLong("quotationID",0));
			dataupload.setMasterPolicyID(object.getLong("masterPolicyID",0));
			if(object.get("fromDate") != null) {
				dataupload.setFromDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("fromDate")));
			} else {
				dataupload.setFromDate(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("toDate") != null) {
				dataupload.setToDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("toDate")));
			} else {
				dataupload.setToDate(new Timestamp(System.currentTimeMillis()));
			}
			dataupload.setMasterPolicyAgreementID(object.getLong("masterPolicyAgreementID",0));
			dataupload.setStatusID(object.getLong("statusID",0));
			dataupload.setHeaderID(object.getLong("headerID",0));
			dataupload.setStatus(object.getString("status",""));
			dataupload.setIsPolicyIssuance(object.getShort("isPolicyIssuance",(short)0));
			dataupload.setProcessID(object.getLong("processID",0));
			
		}
		catch(Exception e)
		{
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
}

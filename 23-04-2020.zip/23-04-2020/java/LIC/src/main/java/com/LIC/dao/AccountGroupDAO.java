package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.AccountGroupModel;
import com.LIC.model.GetAccountGroupModel;
import com.LIC.model.GetOrganisationModel;

@Repository
public class AccountGroupDAO {
	
	
	@Autowired
	private EntityManager em;
	
	public void createAccountGroupInfo(AccountGroupModel model) {

		StoredProcedureQuery addQuestionStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateAccountGroup");
		addQuestionStoredProcedure.setParameter("pAccountGroupID", model.getAccountingGroupId());
		addQuestionStoredProcedure.setParameter("pCode", model.getCode());
		addQuestionStoredProcedure.setParameter("pDescription", model.getGroupName());
		addQuestionStoredProcedure.setParameter("pCreatedBy", model.getCreatedBy());
		addQuestionStoredProcedure.setParameter("pCreatedOn", model.getCreatedOn());
		addQuestionStoredProcedure.setParameter("pIsactive", model.getIsActive());
		addQuestionStoredProcedure.getParameter("pRESULT");
		addQuestionStoredProcedure.execute();
		
		
		
		

	

}
	
	
	
	public List<GetAccountGroupModel>GetAllAccountGroupByCodeAndDescription(String Type) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllAccountGroupByTypID")
               .registerStoredProcedureParameter("vTypeid",String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oBANK", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vTypeid",Type);

        
         // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetAccountGroupModel> accList = list.stream().map(
        		  o -> new GetAccountGroupModel((Number) o[0],(String) o[1],(String) o[2])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	public List<GetAccountGroupModel>GetAllSearch(Number accountGroupId,Number code,Number groupName,String name) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("GetSearchAccountingGroup")
               .registerStoredProcedureParameter("vid",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vCode",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vGroupName",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vPara",String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oBANK", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vid",accountGroupId)
                         .setParameter("vCode",code)
                         .setParameter("vGroupName",groupName)
                         .setParameter("vPara",name);
        
        // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetAccountGroupModel> accList = list.stream().map(
        		  o -> new GetAccountGroupModel((Number) o[0],(String) o[1],(String) o[2],(Number) o[3],(Number) o[4],(String) o[5],(Number) o[6],(String) o[7])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	
	
	
	
	
	
	
	
	
	
	public String  CodeExistOrNot( String code,String group,Number dupid) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("GetDuplicateAccountingGroup")
               .registerStoredProcedureParameter("vCode",String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vGroupName",String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vdupid",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("RESULT1", String.class, ParameterMode.OUT)
        .setParameter("vCode",code)
        .setParameter("vGroupName",group)

        .setParameter("vdupid",dupid);

        
        return (String)query.getOutputParameterValue("RESULT1");
      
        
        
       
         
       }
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

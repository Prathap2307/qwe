package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.AccountingSubHeadDAO;
import com.LIC.model.AccountingSubHeadModel;

@RestController
public class AccountingSubHeadController {
	@Autowired
	private AccountingSubHeadDAO objSAH;
	
		//Get Account Head
		@GetMapping ("/GetAllAccountingHead")
		public List<AccountingSubHeadModel> GetAllAccountingHead()
		{
			return objSAH.GetAllAccountingHead();
		}
		
		//Get Sub Account Head
		@GetMapping ("/GetAllSubAccountHeadbyAccountHead/{AccountHeadID}")
		public List<AccountingSubHeadModel> GetAllSubAccountHead(@PathVariable int AccountHeadID)
		{
			return objSAH.GetAllSubAccountHeadbyAccountHead(AccountHeadID);
		}
		
		
		//Create Sub Account Head
		@PostMapping("/CreateSubAccountHead")
		public int CreateSubAccountHead(@RequestBody AccountingSubHeadModel SubAccmodel) {
			return objSAH.CreateSubAccountHead(SubAccmodel);

		}
		
		//Get Sub Account Head
		@GetMapping ("/GetAllSubAccountHeads/{Id}/{AccountHeadID}/{Code}/{Description}")
		public List<AccountingSubHeadModel> GetAllSubAccountHeads(@PathVariable int Id,@PathVariable int AccountHeadID,@PathVariable int Code,@PathVariable int Description)
		{
			return objSAH.GetAllSubAccountHeads(Id,AccountHeadID,Code,Description);
		}
		
}

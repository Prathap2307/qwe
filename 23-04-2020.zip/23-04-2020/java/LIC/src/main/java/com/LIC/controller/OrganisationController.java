package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.OrganisationDAO;
import com.LIC.model.GetOrganisationModel;
import com.LIC.model.OrganisationModel;

@RestController
public class OrganisationController {
	
	@Autowired
	private OrganisationDAO organisation;
	@PostMapping("/createOrganisation")
	public void postOrganisation(@RequestBody OrganisationModel model) {
		organisation.postOrganisation(model);

	}
	  @GetMapping( value="/organisations")
      public List<GetOrganisationModel> GetAllOrganisation() {
                          return	organisation.GetAllOrganisations();
}

	  
	  @GetMapping( value="/countries")
      public List<GetOrganisationModel> GetAllCountries() {
                          return	organisation.GetAllCountryNames();
}

	
	  @GetMapping( value="/state/{countryId}")
      public List<GetOrganisationModel> GetAllStateName(@PathVariable Long countryId) {
                          return	organisation.GetAllStateNames(countryId);
}

	  @GetMapping( value="/Districts/{stateId}")
      public List<GetOrganisationModel> GetAllDistrictsName(@PathVariable Long stateId) {
                          return	organisation.GetAllDistrictsNames(stateId);
}
	  @GetMapping( value="/PostOffice/{districtId}")
      public List<GetOrganisationModel> GetAllPostOfficeName(@PathVariable Long districtId) {
                          return	organisation.GetAllPostOfficeNames(districtId);
}
	  
	  
	  @GetMapping( value="/zipCode/{zipCode}")
      public List<GetOrganisationModel>DetailsBasedOnZipCode(@PathVariable String zipCode) {
                          return  organisation.GetAllDetailsBasedOnZipCode(zipCode);
}
         


}

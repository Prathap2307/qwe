package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsAssessmentDao;
import com.LIC.model.SaveClaimsAssessmentModel;
import com.LIC.model.SearchClaimsAssessmentModel;
import com.LIC.model.DropdownClaimsAssessmentModel;
import com.LIC.model.OnSelectionOfGridClaimsAssessmentModel;
import com.LIC.model.OnSelectionOfGridPIDClaimsAssessmentModel;

/*
 * @Author = "671621"
 */
@RestController
@RequestMapping("/ClaimsAssessment")
public class ClaimsAssessmentController {

	@Autowired
	private ClaimsAssessmentDao claimsAssessmentDao;
	
	
	@RequestMapping(path = "/getAllPendingClaims/{pLineOfBusinessID}/{pClaimNumber}/{pFirstName}/{pLastName}/{pPolicyNumber}/{pContactID}/{pAgeing}/{pStatusID}/{pAssessorID}", method = RequestMethod.GET)
	public List getAllPendingClaims(@PathVariable int pLineOfBusinessID,
			@PathVariable String pClaimNumber, @PathVariable String pFirstName, @PathVariable String pLastName,
			@PathVariable String pPolicyNumber, @PathVariable String pContactID, @PathVariable String pAgeing,
			@PathVariable int pStatusID, @PathVariable int pAssessorID)
	{
		return claimsAssessmentDao.getAllPendingClaims(pLineOfBusinessID, pClaimNumber, pFirstName, pLastName,
				pPolicyNumber, pContactID, pAgeing, pStatusID, pAssessorID);
		
	}

	/*
	 * @RequestMapping(value =
	 * "/getAllPendingClaims/{pLineOfBusinessID}/{pClaimNumber}/{pFirstName}/{pLastName}/{pPolicyNumber}/{pContactID}/{pAgeing}/{pStatusID}/{pAssessorID}",
	 * method = RequestMethod.GET) public List<SearchClaimsAssessmentModel>
	 * getAllPendingClaims(@PathVariable int pLineOfBusinessID,
	 * 
	 * @PathVariable String pClaimNumber, @PathVariable String
	 * pFirstName, @PathVariable String pLastName,
	 * 
	 * @PathVariable String pPolicyNumber, @PathVariable String
	 * pContactID, @PathVariable String pAgeing,
	 * 
	 * @PathVariable int pStatusID, @PathVariable int pAssessorID) { return
	 * claimsAssessmentDao.getAllPendingClaims(pLineOfBusinessID, pClaimNumber,
	 * pFirstName, pLastName, pPolicyNumber, pContactID, pAgeing, pStatusID,
	 * pAssessorID); }
	 */

	@RequestMapping(value = "/getAllCoveragesByClaimId/{pClaimID}", method = RequestMethod.GET)
	public List<DropdownClaimsAssessmentModel> getAllCoveragesByClaimID(@PathVariable int pClaimID) {
		return claimsAssessmentDao.getAllCoveragesByClaimId(pClaimID);
	}

	/*
	 * @RequestMapping(value = "/getClaimDocumentsByClaimId/{pClaimID}", method =
	 * RequestMethod.GET) public List<DropdownClaimsAssessmentModel>
	 * getClaimDocumentsByClaimId(@PathVariable int pClaimID) { return
	 * claimsAssessmentDao.getClaimDocumentsByClaimId(pClaimID); }
	 */
	
	@RequestMapping(value = "/getClaimDocumentsByClaimId/{pClaimID}", method = RequestMethod.GET)
	public List<DropdownClaimsAssessmentModel> getClaimDocumentsByClaimId(@PathVariable int pClaimID) {
		return claimsAssessmentDao.getClaimDocumentsByClaimId(pClaimID);
	}

	@RequestMapping(value = "/getClaimDetailsByClaimId/{pClaimID}", method = RequestMethod.GET)
	public List getClaimDetailsByClaimId(@PathVariable int pClaimID) {
		return claimsAssessmentDao.getClaimDetailsByClaimId(pClaimID);
	}

	@RequestMapping(value = "/getClaimProductTransactionDetails/{pApplicationID}/{pProductID}", method = RequestMethod.GET)
	public List<OnSelectionOfGridClaimsAssessmentModel> getClaimProductTransactionDetails(
			@PathVariable int pApplicationID, @PathVariable int pProductID) {
		return claimsAssessmentDao.getClaimProductTransactionDetails(pApplicationID, pProductID);
	}

	@RequestMapping(value = "/getClaimsDocument/{pID}", method = RequestMethod.GET)
	public List<OnSelectionOfGridPIDClaimsAssessmentModel> getClaimsDocument(@PathVariable int pID) {
		return claimsAssessmentDao.getClaimsDocument(pID);
	}

	@RequestMapping(value = "/getAssessmentHistory/{pClaimID}", method = RequestMethod.GET)
	public List<OnSelectionOfGridClaimsAssessmentModel> getAssessmentHistory(@PathVariable int pClaimID) {
		return claimsAssessmentDao.getAssessmentHistory(pClaimID);
	}

	@RequestMapping(value = "/isClaimExistOrNot", method = RequestMethod.POST)
	public int isClaimExistOrNot(SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		return claimsAssessmentDao.isClaimExistOrNot(saveClaimsAssessmentModel);
	}

	@RequestMapping(value = "/insertOrUpdateClaimsRegistration", method = RequestMethod.POST)
	public int insertOrUpdateClaimsRegistration(@RequestBody SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		return claimsAssessmentDao.insertOrUpdateClaimsRegistration(saveClaimsAssessmentModel);
	}

	@RequestMapping(value = "/deleteClaimCoverageMap/{pClaimID}", method = RequestMethod.DELETE)
	public void deleteClaimCoverageMap(@PathVariable int pClaimID) {
		claimsAssessmentDao.deleteClaimCoverageMap(pClaimID);
	}

	@RequestMapping(value = "/deleteClaimDocuments/{vClaimID}", method = RequestMethod.DELETE)
	public void deleteClaimDocuments(@PathVariable int vClaimID) {
		claimsAssessmentDao.deleteClaimDocuments(vClaimID);
	}

	@RequestMapping(value = "/insertClaimsCoverageMap", method = RequestMethod.POST)
	public int insertClaimsCoverageMap(@RequestBody SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		return claimsAssessmentDao.insertClaimsCoverageMap(saveClaimsAssessmentModel);
	}

	@RequestMapping(value = "/insertClaimsProofOfDocument", method = RequestMethod.POST)
	public int insertClaimsProofOfDocument(@RequestBody SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		return claimsAssessmentDao.insertClaimsProofOfDocument(saveClaimsAssessmentModel);
	}

	@RequestMapping(value = "/insertClaimsMandatoryDocumentMap", method = RequestMethod.POST)
	public int insertClaimsMandatoryDocumentMap(@RequestBody SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		return claimsAssessmentDao.insertClaimsMandatoryDocumentMap(saveClaimsAssessmentModel);
	}

}

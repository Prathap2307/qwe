package com.LIC.controller;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.Response;
import com.LIC.model.TransactionContext;
import com.LIC.service.PasswordPolicyService;
import com.LIC.utils.dataobject.ValueObject;

@RestController
public class PasswordPolicyController {
	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(PasswordPolicyController.class);
	@Autowired
	public PasswordPolicyController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	@Autowired 	PasswordPolicyService  passwordPolicy;
	
	@RequestMapping(value = "/InsertPasswordPolicy", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public ResponseEntity<Response> InsertPasswordPolicy(@RequestHeader HttpHeaders httpHeader,
				@RequestBody HashMap<Object, Object> allRequestParams ) {
	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParams);

			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, passwordPolicy.InsertPasswordPolicy(object), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetPasswordPolicy", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	 public ResponseEntity<Response> GetPasswordPolicy(@RequestHeader HttpHeaders httpHeader,@RequestParam("OrganisationID") long OrganisationID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, passwordPolicy.GetPasswordPolicy(OrganisationID), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
}

import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-underwritinglevel',
  templateUrl: './underwritinglevel.component.html',
  styleUrls: ['./underwritinglevel.component.css']
})
export class UnderwritinglevelComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  elements: string[];
  dataSource;
  underwritingLevelColumns: string[] = ['View', 'Edit', 'Delete', 'levelname', 'level', 'module', 'category', 'product'];
  constructor() { }

  ngOnInit() {
  }
  
}

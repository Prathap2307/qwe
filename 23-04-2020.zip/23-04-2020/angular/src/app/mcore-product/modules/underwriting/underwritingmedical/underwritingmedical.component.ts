import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-underwritingmedical',
  templateUrl: './underwritingmedical.component.html',
  styleUrls: ['./underwritingmedical.component.css']
})
export class UnderwritingmedicalComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  typesOfBrands: string;
  dataSource;
  underwritingMedicalColumns: string[] = ['View', 'Edit', 'Delete', 'AgeFrom', 'AgeTo', 'SumAssuredFrom', 'SumAssuredTo'];
  constructor() { }

  ngOnInit() {
  }

}

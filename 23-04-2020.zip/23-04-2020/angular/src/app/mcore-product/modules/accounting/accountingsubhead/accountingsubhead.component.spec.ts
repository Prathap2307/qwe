import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountingsubheadComponent } from './accountingsubhead.component';

describe('AccountingsubheadComponent', () => {
  let component: AccountingsubheadComponent;
  let fixture: ComponentFixture<AccountingsubheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountingsubheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountingsubheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

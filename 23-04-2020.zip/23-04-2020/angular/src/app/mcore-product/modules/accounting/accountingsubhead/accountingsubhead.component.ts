import { Component, OnInit, ViewChild } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Accountingsubhead, AccountHead } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingsubhead';
import { AccountingsubheadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingsubhead.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-accountingsubhead',
  templateUrl: './accountingsubhead.component.html',
  styleUrls: ['./accountingsubhead.component.css']
})
export class AccountingsubheadComponent implements OnInit {
  divIsStatus: Boolean;
  fieldDisable: Boolean;
  accountHeads: string;
  accountSubHeads: string;
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  elements: string;
  accountingSubHeadColumns: string[] = ['View', 'Edit', 'accountHeadName', 'subAccountHeadCode', 'subAccountHeadName'];
  accountSubHeadObj: Accountingsubhead[];
  accountSubHeadFilteredObj: Accountingsubhead[] = [];
  AccountHeadObj: AccountHead[];
  accountSubHeadForm: FormGroup;
  AccountSubHeadFormSearch: FormGroup;
  accountSubHeadFormAction: FormGroup;
  accountSubHeadHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  accountSubHeadSource = new MatTableDataSource<Accountingsubhead>(this.accountSubHeadObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.accountSubHeadSource.paginator = this.paginator;
  }
  createSubAccount: boolean;
  AlreadySubAccountHeadExist: number;
  AlreadySubAccountHeadCodeExist: number;
  AlreadyEditSubAccountHeadExist: number;
  AlreadyEditSubAccountHeadCodeExist: number;
  isactiveVal: number;
  constructor(
    private fb: FormBuilder, private accountSubHeadService: AccountingsubheadService,
  ) { }
  ngOnInit() {
    this.createSubAccount = true;
    this.divIsStatus = false;
    this.accountSubHeadHeading = 'Add New - Accounting Sub Head';
    this.btnSaveText = 'Save';
    this.getAllAccountingSubHeadDetails(0, 0, 0, 0);
    this.BindgetAllAccountHeadDetails();
    this.ValidateAccountSubHead();
  }
  disableEvent(e) {
    e.preventDefault();
    return false;
  }
  RestrictSplChar(event) {
    let k;
    k = event.charCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
  }
  // change_accountHead_fn() {
  //   let accountHeadId = this.accountSubHeadForm.get('AccountSubHeadFormSearch.SearchAccountHead').value;
  //   let code = this.accountSubHeadFilteredObj.filter((u) => u.accountHeadId == accountHeadId);
  //   let name = this.accountSubHeadFilteredObj.filter((u) => u.accountHeadId == accountHeadId);
  //   console.log(accountHeadId);
  // }
  BindgetAllAccountHeadDetails() {
    this.accountSubHeadService.getAccountHeadDetails().subscribe(
      accountHeadVal => {
        this.AccountHeadObj = accountHeadVal;
      });
  }
  ValidateAccountSubHead() {
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: ['', [Validators.required]],
        SearchAccountHeadCode: ['', [Validators.required]],
        SearchAccountHeadDescription: ['', [Validators.required]],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: [''],
        accountHeadId: ['', [Validators.required]],
        accountHeadName: [''],
        subAccountHeadName: ['', [Validators.required]],
        subAccountHeadCode: ['', [Validators.required]],
        createdBy: [1],
        createdOn: [new Date()],
        isactive: [1],
      })
    });
  }
  getAllAccountingSubHeadDetails(a, b, c, d) {
    this.accountSubHeadService.getAccountingSubHeadSearchDetails(a, b, c, d).subscribe(
      accountSubHeadObj => {
        this.accountSubHeadSource = new MatTableDataSource<Accountingsubhead>(this.accountSubHeadObj);
        this.accountSubHeadSource.data = this.accountSubHeadObj = accountSubHeadObj;
        this.accountSubHeadSource.paginator = this.paginator;
      })
  }
  // Grid View Button Events
  btngvView_Click(a) {
    this.accountSubHeadHeading = 'View - Accounting Sub Head';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.divIsStatus = true;
    this.accountSubHeadFilteredObj = this.accountSubHeadObj.filter((unit) => unit.subAccountHeadId == a);
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: [''],
        SearchAccountHeadCode: [''],
        SearchAccountHeadDescription: [''],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: this.accountSubHeadFilteredObj[0].subAccountHeadId,
        accountHeadId: this.accountSubHeadFilteredObj[0].accountHeadId,
        accountHeadName: this.accountSubHeadFilteredObj[0].accountHeadName,
        subAccountHeadCode: this.accountSubHeadFilteredObj[0].subAccountHeadCode,
        subAccountHeadName: this.accountSubHeadFilteredObj[0].subAccountHeadName,
        createdBy: this.accountSubHeadFilteredObj[0].createdBy,
        createdOn: this.accountSubHeadFilteredObj[0].createdOn,
        isactive: this.accountSubHeadFilteredObj[0].isactive,
      })
    });
  }
  // Grid Edit Button Events
  btngvEdit_Click(a) {
    this.createSubAccount = false;
    this.accountSubHeadHeading = 'Edit - Accounting Sub Head';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.divIsStatus = true;
    this.accountSubHeadFilteredObj = this.accountSubHeadObj.filter((unit) => unit.subAccountHeadId == a);
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: [''],
        SearchAccountHeadCode: [''],
        SearchAccountHeadDescription: [''],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: this.accountSubHeadFilteredObj[0].subAccountHeadId,
        accountHeadId: this.accountSubHeadFilteredObj[0].accountHeadId,
        accountHeadName: this.accountSubHeadFilteredObj[0].accountHeadName,
        subAccountHeadCode: this.accountSubHeadFilteredObj[0].subAccountHeadCode,
        subAccountHeadName: this.accountSubHeadFilteredObj[0].subAccountHeadName,
        createdBy: this.accountSubHeadFilteredObj[0].createdBy,
        createdOn: this.accountSubHeadFilteredObj[0].createdOn,
        isactive: this.accountSubHeadFilteredObj[0].isactive,
      })
    });
  }
  onBtnSearchAccountSubHead() {
    this.accountSubHeadForm.controls.AccountSubHeadFormSearch.markAllAsTouched();
    if (this.accountSubHeadForm.get('AccountSubHeadFormSearch').valid) {
      let a = 0;
      let b = this.accountSubHeadForm.get('AccountSubHeadFormSearch.SearchAccountHead').value;
      let c = this.accountSubHeadForm.get('AccountSubHeadFormSearch.SearchAccountHeadCode').value;
      let d = this.accountSubHeadForm.get('AccountSubHeadFormSearch.SearchAccountHeadDescription').value;
      if (b == "" || b == null) {
        b = 0;
      }
      if (c == "" || c == null) {
        c = 0;
      }
      if (d == "" || d == null) {
        d = 0;
      }
      console.log(a, b, c, d);
      this.getAllAccountingSubHeadDetails(a, b, c, d);
    }
  }
  onBtnClearSearchAccountSubHead() {
    this.accountSubHeadForm.reset();
    this.getAllAccountingSubHeadDetails(0, 0, 0, 0);
  }
  onBtnSaveAccountSubHeadClick() {
    if (this.createSubAccount) {
      this.accountSubHeadForm.get('accountSubHeadFormAction.subAccountHeadId').patchValue('');
      this.AlreadySubAccountHeadExist = 0;
      this.AlreadySubAccountHeadCodeExist = 0;
      let code = this.accountSubHeadForm.get('accountSubHeadFormAction.subAccountHeadCode').value;
      let desc = this.accountSubHeadForm.get('accountSubHeadFormAction.subAccountHeadName').value;
      this.accountSubHeadObj.forEach((fe) => {
        if (fe.subAccountHeadCode == code) {
          this.AlreadySubAccountHeadCodeExist = 1;
        }
        if (fe.subAccountHeadName == desc) {
          this.AlreadySubAccountHeadExist = 1;
        }
      });
      if (this.AlreadySubAccountHeadCodeExist == 0 && this.AlreadySubAccountHeadExist == 0) {
        this.SaveSubAccountHeadDetails();
      }
      else {
        console.log('else test');
        console.log(this.AlreadySubAccountHeadExist);
        console.log(this.AlreadySubAccountHeadCodeExist);
        if (this.AlreadySubAccountHeadCodeExist == 1) {
          window.alert('Code already exists');
          this.onBtnClearAccountSubHeadClick();
          return false;
        }
        if (this.AlreadySubAccountHeadExist == 1) {
          window.alert('Description already exists');
          this.onBtnClearAccountSubHeadClick();
          return false;
        }
      }
    }
    else {
      let id = this.accountSubHeadForm.get('accountSubHeadFormAction.subAccountHeadId').value;
      let codeEdit = this.accountSubHeadForm.get('accountSubHeadFormAction.subAccountHeadCode').value;
      let descEdit = this.accountSubHeadForm.get('accountSubHeadFormAction.subAccountHeadName').value;
      this.AlreadyEditSubAccountHeadExist = 0;
      this.AlreadyEditSubAccountHeadCodeExist = 0;
      this.accountSubHeadObj.forEach((fe) => {
        if (fe.subAccountHeadId != id) {
          if (fe.subAccountHeadCode == codeEdit) {
            this.AlreadyEditSubAccountHeadCodeExist = 1;
          }
          if (fe.subAccountHeadName == descEdit) {
            this.AlreadyEditSubAccountHeadExist = 1;
          }
        }
      });
      if (this.AlreadyEditSubAccountHeadCodeExist == 0 && this.AlreadyEditSubAccountHeadExist == 0) {
        this.SaveSubAccountHeadDetails();
      }
      else {
        console.log('else test');
        console.log(this.AlreadyEditSubAccountHeadCodeExist);
        console.log(this.AlreadyEditSubAccountHeadExist);
        if (this.AlreadyEditSubAccountHeadCodeExist == 1) {
          window.alert('Code already exists');
          this.onBtnClearAccountSubHeadClick();
          return false;
        }
        if (this.AlreadyEditSubAccountHeadExist == 1) {
          window.alert('Description already exists');
          this.onBtnClearAccountSubHeadClick();
          return false;
        }
      }
    }
  }
  SaveSubAccountHeadDetails() {
    this.accountSubHeadForm.controls.accountSubHeadFormAction.markAllAsTouched();
    if (this.accountSubHeadForm.get('accountSubHeadFormAction').valid) {
      console.log('valid');
      if (this.createSubAccount) {
        this.accountSubHeadForm.get('accountSubHeadFormAction').patchValue({
          subAccountHeadId: '0',
          createdBy: '1',
          createdOn: new Date(),
          isactive: '1',
        });
      }
      else {
        this.accountSubHeadForm.get('accountSubHeadFormAction').patchValue({
          createdBy: '1',
          createdOn: new Date(),
          //isStatusValue();
        });
      }
      let a = this.accountSubHeadForm.controls.accountSubHeadFormAction.value;
      console.log(a);
      this.accountSubHeadService.addAccountingSubHeadDetails(a).subscribe(result => { this.getAllAccountingSubHeadDetails(0, 0, 0, 0) });
      this.onBtnClearAccountSubHeadClick();
    }
  }
  isStatusValue(event) {
    if (event.checked) {
      this.accountSubHeadForm.get('accountSubHeadFormAction').patchValue({
        isactive: this.isactiveVal = 1
      });
    }
    else {
      this.accountSubHeadForm.get('accountSubHeadFormAction').patchValue({
        isactive: this.isactiveVal = 0
      });
    }
  }
  onBtnClearAccountSubHeadClick() {
    this.accountSubHeadForm.controls.accountSubHeadFormAction.reset();
    this.accountSubHeadHeading = 'Add New - Accounting Sub Head';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.divIsStatus = false;
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: [''],
        SearchAccountHeadCode: [''],
        SearchAccountHeadDescription: [''],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: { value: '', disabled: false },
        accountHeadId: { value: '', disabled: false },
        accountHeadName: { value: '', disabled: false },
        subAccountHeadCode: { value: '', disabled: false },
        subAccountHeadName: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
        isactive: { value: '', disabled: false },
      })
    });
    this.getAllAccountingSubHeadDetails(0, 0, 0, 0);
  }
}

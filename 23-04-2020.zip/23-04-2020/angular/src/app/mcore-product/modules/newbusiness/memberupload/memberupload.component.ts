import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MemberUpload, SuccessMessage, UploadFileurl } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { request } from 'http';
@Component({
  selector: 'app-memberupload',
  templateUrl: './memberupload.component.html',
  styleUrls: ['./memberupload.component.css']
})
export class MemberuploadComponent implements OnInit {

  constructor(private fb: FormBuilder, private memberupload: MemberuploadService, private _snackBar: MatSnackBar) { }

  fileToUpload: File = null;

  uploadFileurl: UploadFileurl[] = [];
  uploadFiledata: any;
  uploadFileName: any;
  browseErrorDiv: boolean;
  uploadFileValidatedata: any;
  validationMessage: any;
  successObj: SuccessMessage[] = [];
  divsuccessMessage: Boolean;


  selectedFile: any;
  formData = new FormData();
  handleFileInput(event: any) {


    this.selectedFile = event.target.files[0];
    console.log(this.selectedFile.name);
    this.uploadFileName = this.selectedFile.name
    this.formData.append("file", this.selectedFile);

  //   var reader = new FileReader();



  //   reader.onload = (event: ProgressEvent) => {
  //    this.uploadFileurl = (<FileReader>event.target).result;

   
  //   }
  //   console.log(this.uploadFileurl);
   
  //   reader.readAsDataURL(event.target.files[0]);

  
  //  this.uploadFileName = event.target.files[0];

  }

 
//   handleImages(event: any){  
   
//     console.log(this.selectedFile);
   

   
// }

  fileSaveFn(){
    this.memberupload.saveFile(this.formData).subscribe(a => {
      
      
      this.uploadFileurl = a;
    
      console.log(this.uploadFileurl[0].filePath);
      this.uploadFiledata = { 'filePath': this.uploadFileurl[0].filePath, 'fileName': this.uploadFileName };

      this.uploadFileValidatedata = { 'filePath': this.uploadFileurl[0].filePath };

     


  
      this.memberupload.validateExcelFile(this.uploadFileValidatedata).subscribe(data => {
       this.validationMessage = data;
 
         if (this.validationMessage == "") {
           console.log('valid test');
           this.memberupload.postFile(this.uploadFiledata).subscribe(data => {
            this.migrationGNBDataUpload();
            this.onBtnClearAction();
          }, error => {
            //console.log(error);
          });
         //  this.onBtnClearAction();
          // this.migrationGNBDataUpload();
         }
       }, error => {
        // console.log(error);
       });
    
    });
  }

  uploadFileToActivity() {

    //this.memberUploadAction.markAllAsTouched();

   //if(this.memberUploadAction.valid){

    this.fileSaveFn();

   // setTimeout(()=>{
   // },3000);

   // }
   



  }

 

  migrationGNBDataUpload() {

    let obj: Object = {

      "fileName": this.uploadFileName,
      "groupID": this.memberUploadAction.get('groupID').value,
      "masterPolicyID": this.memberUploadAction.get('masterPolicyNumber').value,
      "createdBy": 1,
      "createdOn": new Date(),
      "type": "A",
      "authorisedSignatoryID": this.memberUploadAction.get('authorizedSignatory').value

    };




    this.memberupload.migrationGNBDataUpload(obj).subscribe(data => {
      this.successObj = data;
     
      this.divsuccessMessage = true;

     
    });
  }





  url: any;
  readUrl(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.onload = (event: ProgressEvent) => {
        this.url = (<FileReader>event.target).result as string;
      
      }

      reader.readAsBinaryString(event.target.files[0]);
    }
  }

  groupNameObj: MemberUpload[];

  mpnObj: any;

  authorizedSignatoryObj: MemberUpload[];

  memberUploadForm: FormGroup;
  get memberUploadAction() {
    return this.memberUploadForm.get('memberUploadAction') as FormGroup;
  }

  ngOnInit() {
    this.browseErrorDiv = false;
    this.memberUploadForm = this.fb.group({
      memberUploadAction: this.fb.group({

        groupID: ['', [Validators.required]],
        masterPolicyNumber: ['', [Validators.required]],
        agreementNumber: ['', [Validators.required]],
        authorizedSignatory: [''],
        browseBtn: ['']

      })

    });
    this.getGroupDetails();
  }

  getGroupDetails() {

    this.memberUploadAction.addControl('groupName', new FormControl(''));
    this.memberUploadAction.addControl('contactFirstName', new FormControl(''));
    this.memberUploadAction.addControl('contactLastName', new FormControl(''));
    this.memberUploadAction.addControl('customerGroupID', new FormControl(''));
    this.memberUploadAction.addControl('branchID', new FormControl(0));
    this.memberUploadAction.addControl('userID', new FormControl(1));

    let a = this.memberUploadAction.value;
    this.memberupload.getGroupDetails(a).subscribe(a => {
      this.groupNameObj = a;
    });

  }

  getmasterPolicyDetails() {

    let groupID = this.memberUploadAction.get('groupID').value;
    console.log('groupID test', groupID);
    this.memberupload.getmasterPolicyDetails(groupID).subscribe(a => {
      this.mpnObj = a;
    });

    this.memberupload.getAllAuthorisedSignatories(groupID).subscribe(a => {
      this.authorizedSignatoryObj = a;
    });

  }

  onBtnClearAction() {
    this.memberUploadForm = this.fb.group({
      memberUploadAction: this.fb.group({

        groupID: '',
        masterPolicyNumber: '',
        agreementNumber: '',
        authorizedSignatory: '',
        browseBtn: ''

      })

    });
    this.validationMessage = '';
    setTimeout( ()=>{  
      this.divsuccessMessage = false;
 }, 5000);
    
  }

  cfn(a) {
    console.log(a);
  }

}

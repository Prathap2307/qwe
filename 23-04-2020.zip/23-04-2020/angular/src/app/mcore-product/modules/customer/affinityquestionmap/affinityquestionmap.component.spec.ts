import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AffinityquestionmapComponent } from './affinityquestionmap.component';

describe('AffinityquestionmapComponent', () => {
  let component: AffinityquestionmapComponent;
  let fixture: ComponentFixture<AffinityquestionmapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AffinityquestionmapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AffinityquestionmapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

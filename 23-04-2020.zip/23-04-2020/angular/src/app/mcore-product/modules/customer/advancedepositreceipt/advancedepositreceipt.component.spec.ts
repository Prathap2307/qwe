import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedepositreceiptComponent } from './advancedepositreceipt.component';

describe('AdvancedepositreceiptComponent', () => {
  let component: AdvancedepositreceiptComponent;
  let fixture: ComponentFixture<AdvancedepositreceiptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvancedepositreceiptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvancedepositreceiptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumpaymentfrequencyComponent } from './premiumpaymentfrequency.component';

describe('PremiumpaymentfrequencyComponent', () => {
  let component: PremiumpaymentfrequencyComponent;
  let fixture: ComponentFixture<PremiumpaymentfrequencyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumpaymentfrequencyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumpaymentfrequencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

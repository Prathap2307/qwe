import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { InsurerService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/insurer.service';
import { Insurer } from 'src/app/mcore-product/mcore-shared/mcore-entity/insurer';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as moment from "moment"
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
@Component({
  selector: 'app-insurer',
  templateUrl: './insurer.component.html',
  styleUrls: ['./insurer.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class InsurerComponent implements OnInit {
  @ViewChild('picker', { static: true }) picker;
  pinobj: any;
  fail: boolean;
  failed: string;
  lob: any;
  organisationID: string;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  userID: string;
  branchError: boolean;
  open() {
    this.picker.open();
  }
  submitted: boolean;
  SearchIForm: FormGroup;
  insurerHeading: string = 'Add New - Insurer';
  saveBtnMode: boolean = true;
  textSaveBtn: string = 'Save';
  country: any;
  state: any;
  District: any;
  Taluka: any;
  allinsurer: any;
  insurerObj: any;
  view: boolean = false;
  BRANCH = [
    { Id: 1, Name: 'Term Life' },
    { Id: 2, Name: 'Credit Shield' },

  ]
  display: string;
  exist: boolean;
  success: boolean;
  transaction: string;
  present: any;
  submit: boolean;
  id: any;
  deleteid: any;
  deleted: boolean;
  constructor(private insurerService: InsurerService, private user: UserService, private BranchService: BranchService, private fb: FormBuilder) { }
  dummyObj = ['swdsd', 'asdasd']
  InsurerForm: FormGroup;
  ngOnInit() {
    console.log(localStorage.getItem('organisationID'))
    this.userID = localStorage.getItem('userID')


    this.getAllInsurer()
    this.GetAllcountries()
    this.insurerHeading = 'Add New - Insurer'
    this.GetLineOfBusiness()
    this.searchform()
    this.forminit()
  }
  searchform() {
    this.SearchIForm = this.fb.group({
      insurerName: ['',],
      lineOfBusinessID: ['',],
    })
  }
  forminit() {
    this.InsurerForm = this.fb.group({
      createdBy: [1,],
      createdOn: [null,],
      OrganisationID: [this.organisationID,],
      isActive: [1,],
      insurerID: [],
      insurerName: ['', [Validators.required]],
      collectionGLCode: [],
      paymentGLCode: [],
      freshGLCode: [],
      apOnlineGLCode: [],
      licPremiumPaymentGLCode: [],
      revivalGLCode: [],
      medicalGLCode: [],
      claimGLCode: [],
      triggerLimitforStampDuty: [],
      intimationEmailaddressforStampDuty: [],
      intimationMobileNumberforStampDuty: [],
      lineOfBusinessID: ['',],
      dateOfCommencement: ['', Validators.required],
      geographicalPresence: ['', Validators.pattern('[A-Za-z0-9]\\d{3}')],
      distributionID: ['',],
      logo: ['',],
      address1: ['', Validators.required],
      address2: [''],
      address3: [''],
      countryID: ['', Validators.required],
      stateID: ['', Validators.required],
      districtID: ['', Validators.required],
      talukID: [''],
      zipCode: ['', Validators.required],
      phoneNo: ['',],
      faxNumber: ['',],
      conferenceNumber: ['',],
      mobileNo: ['', Validators.pattern("[0-9 -()+]+$")],
      email: ['', [Validators.email, Validators.pattern('^[a-z0-9,A-Z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      gstNo: ['', [Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
      panNo: ['', [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]],
      lineOfBusinessInsurerList: this.fb.array([]),
    });
  }
  addressObj: Insurer[];
  getAddressDetails(e) {
    // zipcode = 625203;
    console.log(e.target.value);
    this.insurerService.getAddressByIDzipCode(e.target.value)
      .subscribe(addressObj => {
        this.addressObj = addressObj;

      });

  }
  get f() { return this.InsurerForm.controls; }

  getAllInsurer() {
    this.insurerService.getAllInsurer()
      .subscribe(result => {
        console.log(result)
        this.allinsurer = result.data;
        console.log(this.allinsurer)
        if (this.allinsurer) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allinsurer.length
          }
        }
      });

  }

  pageChanged(event) {
    this.config.currentPage = event;
  }
  onCheckChange(event: any) {
    console.log(event)
    console.log(event.source.value)
    if (event.checked) {
      this.branchError = false
      for (let i = 0; i < this.lob.length; i++) {
        if (event.source.value.lobID === this.lob[i].lobID) {
          this.lob[i]["checked"] = true
        }
      }
    }
    else {
      for (let i = 0; i < this.lob.length; i++) {
        if (event.source.value.lobID === this.lob[i].lobID) {
          this.lob[i]["checked"] = false
        }
      }
    }
    console.log(this.lob)

  }
  GetLineOfBusiness() {
    this.user.GetLineOfBusiness()
      .subscribe(result => {
        console.log(result)
        this.lob = result.data
        if (this.lob) {
          console.log(this.lob)
          for (let k = 0; k < this.lob.length; k++) {
            this.lob[k]["checked"] = false

          }
        }
      })
  }
  IsInsurerExist(data: any) {
    this.insurerService.IsInsurerExist(data)
      .subscribe(result => {

        console.log(result)
        if (result.data && result.data === "NOTEXIST") {
          // this.submit = true
          // console.log(this.submit)
          this.insurerService.InsertOrUpdateInsurer(this.InsurerForm.value)
            .subscribe(result => {
              console.log(result)


              if (result.data.InsurerID > 0) {
                this.success = true
                this.transaction = "Created"
                this.openModalDialog()
                this.getAllInsurer()
                this.cancel()
              } else {
                this.failed = 'Addition'
                this.fail = true
                this.openModalDialog()
              }

              // this.InsurerForm.reset()
            });
        }
        else {
          this.exist = true
          this.present = result.data
          this.openModalDialog()
        }

      });
  }
  clear() {
    console.log('ss')
    this.searchform()
  }
  onSubmit() {
    event.preventDefault();
    console.log(this.id)
    this.submitted = true;
    console.log(this.InsurerForm.value)
    console.log(this.InsurerForm.controls)
    // console.log(this.ZoneForm.value["GSTNo"].slice(2, 12))

    if (this.id && this.textSaveBtn === 'Update') {
      console.log(this.id)
      this.InsurerForm.value["insurerID"] = this.id
      this.InsurerForm.value["modifiedBy"] = this.userID
      this.InsurerForm.value["isActive"] = 1
      this.InsurerForm.value['lineOfBusinessInsurerList'] = []
      for (let i = 0; i < this.lob.length; i++) {
        if (this.lob[i]["checked"] === true) {
          console.log(this.lob[i])
          this.InsurerForm.value['lineOfBusinessInsurerList'].push(this.lob[i]);
        }
      }
      if (this.InsurerForm.value['lineOfBusinessInsurerList'].length == 0) {
        this.branchError = true
      } else {
        if (this.InsurerForm.valid) {

          console.log(this.InsurerForm.value)
          this.InsurerForm.value["dateOfCommencement"] = moment(new Date(this.InsurerForm.value["dateOfCommencement"])).format('DD-MM-YYYY ')
          this.insurerService.InsertOrUpdateInsurer(this.InsurerForm.value)
            .subscribe(result => {
              console.log(result)

              this.transaction = "Updated"
              this.getAllInsurer()
              if (result.data.InsurerID > 0) {
                this.success = true
                this.openModalDialog()
                this.cancel()
              }
              else {
                this.fail = true
                this.failed = 'Updation'
                this.openModalDialog()
              }


            });
        }
      }
    }
    else {
      console.log(moment(new Date(this.InsurerForm.value["dateOfCommencement"])).format('DD-MM-YYYY '))
      if (this.InsurerForm.valid && this.textSaveBtn === 'Save') {
        this.InsurerForm.value['lineOfBusinessInsurerList'] = []
        console.log(this.lob)
        for (let i = 0; i < this.lob.length; i++) {
          if (this.lob[i]["checked"] === true) {
            console.log(this.lob[i])
            this.InsurerForm.value['lineOfBusinessInsurerList'].push(this.lob[i]);
          }
        }
        
        this.InsurerForm.value['insurerID'] = 0
        this.InsurerForm.value["createdBy"] = this.userID
        this.InsurerForm.value["createdOn"] = null
        this.InsurerForm.value["dateOfCommencement"] = moment(new Date(this.InsurerForm.value["dateOfCommencement"])).format('DD-MM-YYYY ')
        console.log(moment(new Date(this.InsurerForm.value["dateOfCommencement"])).format('DD-MM-YYYY '))
        // console.log(JSON.stringify(this.InsurerForm.value))
        if (this.InsurerForm.value['lineOfBusinessInsurerList'].length == 0) {
          this.branchError = true
        } 
        else{
          if(this.InsurerForm.valid){
            this.IsInsurerExist(this.InsurerForm.value)
          }
        
        }
      }

    }

  }

  btngEdit_Click(a) {
    this.id = a
    this.insurerHeading = 'Edit - Insurer';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update';
    this.GetInsurerByID(a)
  }

  GetInsurerByID(a) {
    this.insurerService.GetInsurerByID(a)
      .subscribe(result => {
        console.log(result)
        this.insurerObj = result.data
        console.log(this.insurerObj)
        if (this.insurerObj) {
          this.GetAllStates(this.insurerObj.countryID)
          this.GetAllDistricts(this.insurerObj.stateID)
          this.GetTaluk(this.insurerObj.districtID)
          this.InsurerForm = this.fb.group({
            insurerID: [{ value: this.insurerObj.insurerID, disabled: false },],
            insurerName: [{ value: this.insurerObj.insurerName, disabled: false }, Validators.required],
            collectionGLCode: [{ value: this.insurerObj.collectionGLCode, disabled: false }],
            paymentGLCode: [{ value: this.insurerObj.paymentGLCode, disabled: false }],
            freshGLCode: [{ value: this.insurerObj.freshGLCode, disabled: false }],
            apOnlineGLCode: [{ value: this.insurerObj.apOnlineGLCode, disabled: false }],
            licPremiumPaymentGLCode: [{ value: this.insurerObj.licPremiumPaymentGLCode, disabled: false }],
            revivalGLCode: [{ value: this.insurerObj.revivalGLCode, disabled: false }],
            medicalGLCode: [{ value: this.insurerObj.medicalGLCode, disabled: false }],
            claimGLCode: [{ value: this.insurerObj.claimGLCode, disabled: false }],
            triggerLimitforStampDuty: [{ value: this.insurerObj.triggerLimitforStampDuty, disabled: false }],
            intimationEmailaddressforStampDuty: [{ value: this.insurerObj.intimationEmailaddressforStampDuty, disabled: false }],
            intimationMobileNumberforStampDuty: [{ value: this.insurerObj.intimationMobileNumberforStampDuty, disabled: false }],
            lineOfBusinessID: [{ value: this.insurerObj.lineOfBusinessID, disabled: false }, Validators.required],
            dateOfCommencement: [{ value: new Date(this.insurerObj.dateOfCommencement), disabled: false }, Validators.required],
            geographicalPresence: [{ value: this.insurerObj.geographicalPresence, disabled: false },],
            // [Validators.pattern('[A-Za-z0-9]\\d{3}')]
            distributionID: [{ value: this.insurerObj.distributionID, disabled: false }, [Validators.required]],
            logo: [{ value: '', disabled: false },],
            // logo: [{ value: this.insurerObj.logo, disabled: false }, [Validators.required]],
            address1: [{ value: this.insurerObj.address1, disabled: false }, Validators.required],
            address2: [{ value: this.insurerObj.address2, disabled: false },],
            address3: [{ value: this.insurerObj.address3, disabled: false },],
            countryID: [{ value: this.insurerObj.countryID, disabled: false }, Validators.required],
            stateID: [{ value: this.insurerObj.stateID, disabled: false }, Validators.required],
            districtID: [{ value: this.insurerObj.districtID, disabled: false }, Validators.required],
            talukID: [{ value: this.insurerObj.talukID, disabled: false }],
            zipCode: [{ value: this.insurerObj.zipcode, disabled: false }, Validators.required],
            phoneNo: [{ value: this.insurerObj.phoneNumber, disabled: false },],
            faxNumber: [{ value: this.insurerObj.faxNumber, disabled: false },],
            conferenceNumber: [{ value: this.insurerObj.conferenceNumber, disabled: false },],
            mobileNo: [{ value: this.insurerObj.mobilNumber, disabled: false }, Validators.pattern("[0-9 -()+]+$")],
            email: [{ value: this.insurerObj.email, disabled: false }, [Validators.email, Validators.pattern('^[a-z0-9,A-Z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
            gstNo: [{ value: this.insurerObj.gstNo, disabled: false }, [Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
            panNo: [{ value: this.insurerObj.panNo, disabled: false }, [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]],
            createdBy: [{ value: this.insurerObj.createdBy, disabled: false },],
            createdOn: [{ value: this.insurerObj.createdOn, disabled: false },],
            isActive: [{ value: this.insurerObj.isActive, disabled: false },],
          });
          if (this.insurerObj.lineOfBusinessInsurerList) {
            for (let i = 0; i < this.insurerObj.lineOfBusinessInsurerList.length; i++) {
              for (let k = 0; k < this.lob.length; k++) {
                if (this.insurerObj.lineOfBusinessInsurerList[i]['lobID'] === this.lob[k]["lobID"]) {
                  console.log(this.lob[k])
                  console.log(true)
                  this.lob[k].checked = true

                }
              }
            }
          }

        }

      })
  }
  btngView_Click(a) {
    this.view = true
    this.insurerHeading = 'View - Insurer';
    this.saveBtnMode = false;

    this.GetInsurerByID(a)
  }
  setdelete(id) {
    this.deleteid = id
  }
  delete(id) {
    let data = {
      "insurerID": this.deleteid,
      "DeletedBy": 1
    }

    this.insurerService.DeleteInsurer(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === "DELETED") {
          this.deleted = true
        }
        else {
          this.deleted = false
        }
        this.getAllInsurer()
      });
  }
  cancel() {
    this.InsurerForm.reset()
    this.forminit()
    this.GetLineOfBusiness()
    console.log(this.submitted)
    this.submitted = false
    this.insurerHeading = 'Add New - Insurer';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  pinValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.exist = false
    this.success = false

  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();

        }
        console.log(event.keyCode)
        // event.target.value = event.target.value.slice(0, 5).replace(/[^a-zA-Z]/g, "");
      }
      else if (l >= 5 && l <= 8) {

        console.log(l)
        console.log(charCode)
        // console.log(event.target.value.slice(5,9))
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l >= 8 && l <= 9) {
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  mobValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  faxNphoneValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 11) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  dateValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (charCode === 32 || (charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)

        event.preventDefault();
      }


    }
  }
  GstnValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      // State code
      if (l <= 1) {
        console.log(l)

        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN alphabets
      else if (l >= 2 && l <= 6) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN numeric
      else if (l > 6 && l <= 10) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      } // PAN alphabet
      else if (l >= 11 && l < 12) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 12 && l < 13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // alphabet
      else if (l >= 13 && l < 14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 14 && l < 15) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 15) {

        event.preventDefault();

      }

    }
  }
  getdetailsbypin(a) {
    console.log(a)
    this.BranchService.GetAllDetailsByZipCode(a)
      .subscribe(result => {
        console.log(result)
        if (result.data.length > 0) {
          this.pinobj = result.data[0]
          this.GetAllStates(this.pinobj.countryID)
          this.GetAllDistricts(this.pinobj.stateID)
          this.GetTaluk(this.pinobj.districtID)
          let pin = {
            countryID: this.pinobj.countryID,
            stateID: this.pinobj.stateID,
            districtID: this.pinobj.districtID,
            talukID: this.pinobj.talukID,
          }
          this.InsurerForm.patchValue(pin);
        }
        else {
          let pin = {
            countryID: '',
            stateID: '',
            districtID: '',
            talukID: '',
          }

          this.InsurerForm.patchValue(pin);
        }

      });
  }

  detectpin(event: any) {
    console.log(event.target.value.length);
    if (event.target.value.length === 6) {
      this.getdetailsbypin(this.InsurerForm.value["zipCode"])
    }
  }
  Select_country(event: any) {
    console.log(event.target.value)
    let zip = {
      zipCode: '',
    }

    this.InsurerForm.patchValue(zip);
    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)
    let zip = {
      zipCode: '',
    }

    this.InsurerForm.patchValue(zip);
    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)
    let zip = {
      zipCode: '',
    }

    this.InsurerForm.patchValue(zip);
    this.GetTaluk(event.target.value);
  }


  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }


  get MobNoError() {
    if (this.InsurerForm.controls['MobileNo'].hasError('required')) {
      return 'Mobile Number is required';
    } else if (this.InsurerForm.controls['MobileNo'].hasError('pattern')) {
      return 'Please enter valid Mobile Number';
    } else if (this.InsurerForm.controls['MobileNo'].hasError('minlength')) {
      return 'Please enter valid 10 digits Mobile Number';
    }
  }

  get EmailError() {
    if (this.InsurerForm.controls['email'].hasError('required')) {
      return 'Please enter the E-Mail ID.';
    } else if (this.InsurerForm.controls['email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }
  get GstnError() {
    if (this.InsurerForm.controls['gstNo'].hasError('pattern')) {
      return 'GSTIN should be 15 digits Master.';
    }
    else if (this.InsurerForm.value["panNo"] && this.InsurerForm.value['gstNo'] && this.InsurerForm.value["panNo"].toUpperCase() != this.InsurerForm.value["gstNo"].slice(2, 12).toUpperCase()) {
      console.log(this.InsurerForm.value["panNo"])
      console.log(this.InsurerForm.value["gstNo"].slice(2, 12).toUpperCase())
      return 'PAN Mismatch in GSTIN.';
    }
  }

  get PanError() {
    // return this.email.hasError('required') ? 'You must enter a value' :
    //     this.email.hasError('email') ? 'Not a valid email' :
    //         '';
    if (this.InsurerForm.controls['panNo'].hasError('required')) {
      return 'PAN Number is required';
    } else if (this.InsurerForm.controls['panNo'].hasError('pattern')) {
      return 'Please enter valid PAN Number';
    } else if (this.InsurerForm.controls['panNo'].hasError('minlength')) {
      return 'Please Enter 10 digits of PAN Number.';
    }
  }


  consoleLogFn(val) {
    console.log(val);
  }

}

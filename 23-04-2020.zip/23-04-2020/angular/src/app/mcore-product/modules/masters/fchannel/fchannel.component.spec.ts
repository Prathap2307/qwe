import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FchannelComponent } from './fchannel.component';

describe('FchannelComponent', () => {
  let component: FchannelComponent;
  let fixture: ComponentFixture<FchannelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FchannelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FchannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, HostBinding } from '@angular/core';
declare var $: any;
import { OverlayContainer } from '@angular/cdk/overlay';
import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { McoreCommunicationService } from 'src/app/mcore-product/mcore-shared/mcore-communication/communicationService';
import { Subscription } from 'rxjs/internal/Subscription';
import * as moment from "moment"
@Component({
	selector: 'app-master-page',
	templateUrl: './master-page.component.html',
	styleUrls: ['./master-page.component.css']
})
@Injectable()
export class MasterPageComponent implements OnInit {

	parentMessage = "message from parent";
	tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
	tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
	display: string;
	fname: any;
	timezone: any;
	subscription: Subscription = new Subscription;
	description: {};
	lastLoginTime: any;
	arr: any[];
	now: string;


	constructor(@Inject(DOCUMENT) private document: Document, private mcom: McoreCommunicationService, private UserService: UserService, public overlayContainer: OverlayContainer) { }
	theme: string;
	@HostBinding('class') componentCssClass;


	ngOnInit() {
		this.now=moment(new Date()).format('DD/MM/YYYY HH:mm:ss')
		this.subscription = this.mcom._bottomHeadSource.subscribe(
			(data) => {
				console.log(data)
				if (Object.keys(data).length>0) {
					localStorage.setItem('timezone', JSON.stringify(data))
					this.timezone=JSON.parse(localStorage.getItem('timezone'))
					console.log(this.timezone)
				}
			})

		if (localStorage.getItem('timezone')) {
			console.log(JSON.parse(localStorage.getItem('timezone')));
			this.timezone=JSON.parse(localStorage.getItem('timezone'))
		}

		localStorage.getItem('fname');
		console.log(localStorage.getItem('timezone'))
		this.fname = localStorage.getItem('fname')
		this.lastLoginTime = moment(new Date(JSON.parse(localStorage.getItem('lastLoginTime')))).format('DD/MM/YYYY HH:mm:ss')

		//MENU ACCORDION
		var first_menu = $(".first-menu");
		if (first_menu.length) {
			$('.sub-menu .first-link').on('click', function () {
				var $this = $(this);

				$(".first-menu").slideUp();
				$(".second-menu").slideUp();
				if ($this.next().css("display") == "none") {
					$this.next().slideToggle();
				}
			});
		}

		var second_menu = $(".second-menu");
		if (second_menu.length) {
			$('.first-menu .second-link').on('click', function () {
				var $this = $(this);

				$(".second-menu").slideUp();
				if ($this.next().css("display") == "none") {
					$this.next().slideToggle();
				}
			});
		}


		// MENU ACCORDION

		$('[data-toggle="offcanvas"]').click(function () {
			$('#wrapper').toggleClass('toggled');
			$('.overlay').removeClass('overlay_add');
			if ($(window).width() <= 1199) {
				if ($('#wrapper').hasClass("toggled")) {
					$('.overlay').addClass('overlay_add');
				}
			}

		});


		function menu_toggled_fn() {

			if ($(window).width() <= 1199) {
				$('#wrapper').removeClass('toggled');

			} else {
				$('#wrapper').addClass('toggled');

			}
		}
		menu_toggled_fn();

		function menu_top_fn() {
			if ($(window).width() <= 1199) {

			} else {
				$('.overlay').removeClass('overlay_add');

			}
		}
		$(window).on('resize', function () {
			menu_toggled_fn();
			menu_top_fn();
		});

		if ($(window).width() <= 1199) {
			menu_top_fn();
		}

		$(".overlay").on('click', function () {
			$('#wrapper').removeClass('toggled');
			$('.overlay').removeClass('overlay_add');
		});


		$('.menu-close').on("click", function () {
			$('[data-toggle="offcanvas"]').trigger("click");
		});




		//TOOLTIP
		// var actionTooltip = $(".actionTooltip");
		// if(actionTooltip.length){
		// $(actionTooltip).tooltipster({
		// 	   animation: 'grow',
		// 	   theme: 'tooltipster-punk',
		// 	   trigger: 'hover',
		// 	   side:'top'
		// 	});
		// }


	}

	onSetTheme(theme: string) {


		this.theme = theme;
		//console.log(theme);
		if (theme == "blue-light-theme") {
			this.document.body.classList.remove("yellowTheme");
		} else if (this.theme == "yellow-light-theme") {
			this.document.body.classList.add("yellowTheme");
		}

		const overlayContainerClasses = this.overlayContainer.getContainerElement().classList;

		const themeClassesToRemove = Array.from(overlayContainerClasses).filter((item: string) => item.includes('-theme'));

		if (themeClassesToRemove.length) {
			overlayContainerClasses.remove(...themeClassesToRemove);
		}
		this.overlayContainer.getContainerElement().classList.add(theme);

		//this.document.body.classList.add(theme); 
		this.componentCssClass = theme;

	}

	openModalDialog() {
		this.display = 'block'; //Set block css


	}
	logout() {
		this.UserService.LoggedOut(1)
			.subscribe(result => {
				console.log(result)
				localStorage.clear()
			});
	}
	closeModalDialog() {
		this.display = 'none'; //set none css after close dialog
	}

}

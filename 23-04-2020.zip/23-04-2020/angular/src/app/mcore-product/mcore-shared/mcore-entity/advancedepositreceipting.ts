export class AdvanceDepositReceipting {
	clientName: string;
	clientId: number;
	contactpersonFirstName: string;
	contactpersonLastName: string;
	insurerServicingBranch: string;
	occupationTradeBusiness: string;
	triggerSmsEmail: string;
	contactNumber: number;
	riskCategory: string;
	turnOver: string;
	typeOfClient: string;
	gstType: string;
	panNumber: number;
	emailId: string;
	servicingBranch: string;
	selectParent: string;
	parentCompany: string;
	marketingOfficeLocation: string;
	agentName: string;
	masterPolicyNumber: string;
	agreementNumber: number;
	paymentMode: string;
	paymentDate: Date;
	paidAmount: string;	
}
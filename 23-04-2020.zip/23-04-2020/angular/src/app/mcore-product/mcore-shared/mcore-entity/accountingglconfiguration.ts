export interface Accountingglconfiguration {
    searchAccountProcess: number;
    searchAccountVariant: number;
    searchAccountPayment: number;  
    accountHeadId: number; 
    glConfigurationId: number;
    id: number;
    paymentModeId: number;
    description: string;
    paymentCode:number;
    paymentMode: string;
    productId: number;
    productName: string;
    processId: number;
    processName: string;
    creditGlcode: number;
    creditGlName: string;
    debitGlCode: number;
    debitGlName: string;
    creditAccountName: string;   
    debitAccountName: string;
    creditNarration: string;
    debitNarration: string;
    remark: string;
    isActive: number;
    createdBy: number;
    createdOn: Date;
    countryId: number;
    stateId: number;
}

export interface ProcessName {
    processId: number;
    processName: string;
}
export interface PaymentMode {
    paymentModeId: number;
    description: string;
}
export interface ProductVariant {
    productId: number;
    description: string;
}
export interface DebitName {
    id: number;
    description: string;
}
export interface CreditName {
    id: number;
    description: string;
}
export interface country {
    countryId: number;
    description: string;
}

export interface state {
    stateId: number;
    description: string;
}	

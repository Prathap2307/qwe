export interface Question {
	questionId: number;
	lobId: number;
	searchDescription: string;
	description: string;
	shortDescription: string;	
	orderId: number;
	weightage: number;
	createdBy: number;
	createdOn: Date;
	createdTime: Date;
	modifiedBy: number;
	modifiedOn: Date;
	deletedBy: number;
	deletedOn: Date;
	isActive: boolean;
}

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
// import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
@Injectable({
  providedIn: 'root'
})
export class QuotationService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

  getSalesHierarchyDetails(moCode: string): Observable<any> {
    const url = this.baseUrl + `/salesHierarchy/${moCode}`;
    return this.http.get<any>(url)
      .pipe();
  }

  getProduct(): Observable<any> {
    const url = this.baseUrl + `/salesHierarchy/getProduct`;
    return this.http.get<any>(url)
      .pipe();
  }

  getPremium(): Observable<any> {
    const url = this.baseUrl + `/salesHierarchy/getPremium`;
    return this.http.get<any>(url)
      .pipe();
  }

  getVariant(lineOfBusinessID: number): Observable<any> {
    const url = this.baseUrl + `/salesHierarchy/getVariant/${lineOfBusinessID}`;
    return this.http.get<any>(url)
      .pipe();
  }

  getPremiumDetails(productId: number): Observable<any> {
    const url = this.baseUrl + `/getPremiumDetailsByMasterPolicy/${productId}`;
    return this.http.get<any>(url)
      .pipe();
  }

  saveQuotation(a: any): Observable<any> {
    const url = this.baseUrl + `/saveQuotation`;
    return this.http.post<any>(url, a)
      .pipe();
  }

  insertPremiumValue(a: any): Observable<any> {
    const url = this.baseUrl + `/insertPremiumValue`;
    return this.http.post<any>(url, a)
      .pipe();
  }


  validateAnyExcelFile(a: any, quotationId: number): Observable<any> {
    const requestOptions: Object = {
      /* other options here */
      responseType: 'text'
    }
    const url = this.baseUrl + `/validateAnyExcelFile/MemberUpload/${quotationId}`;
     return this.http.post<any>(url, a, requestOptions)
       .pipe();
   }


   migrationDataUpload(a: any): Observable<any> {
    const url = this.baseUrl + '/migrationDataUpload';
      return this.http.post<any>(url, a);
    }

    getClientDetails(clientId: number, typeId: number): Observable<any> {
      const url = this.baseUrl + `/getClientDetails/${clientId}/${typeId}`;
      return this.http.get<any>(url)
        .pipe();
    }

    getSearchQuotation(a: any): Observable<any> {
      const url = this.baseUrl + `/getSearchQuotation`;
      return this.http.post<any>(url, a)
        .pipe();
    }
}

import { TestBed } from '@angular/core/testing';

import { AccountingglconfigurationService } from './accountingglconfiguration.service';

describe('AccountingglconfigurationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AccountingglconfigurationService = TestBed.get(AccountingglconfigurationService);
    expect(service).toBeTruthy();
  });
});

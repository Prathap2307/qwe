import { TestBed } from '@angular/core/testing';

import { ClaimssettlementService } from './claimssettlement.service';

describe('ClaimssettlementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClaimssettlementService = TestBed.get(ClaimssettlementService);
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Organization } from 'src/app/mcore-product/mcore-shared/mcore-entity/organization';
@Injectable({
  providedIn: 'root'
})
export class OrganizationService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

  getOrganizationGridDetails(): Observable<Organization[]> {
    const allGridUrl = this.baseUrl + `/organisations`;
     return this.http.get<Organization[]>(allGridUrl)
       .pipe();
   }

   createOrganizationUrl = this.baseUrl + '/createOrganisation';
  createOrganization(a: any): Observable<any> {
    return this.http.post<any>(this.createOrganizationUrl, a);
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { PaymentMode } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingglconfiguration';
import { Beneficiary, Claimssettlement } from 'src/app/mcore-product/mcore-shared/mcore-entity/claimssettlement';


@Injectable({
  providedIn: 'root'
})
export class ClaimssettlementService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  // GET PAYMENT MODE DDL DETAILS
  getPaymentModeDetails(): Observable<PaymentMode[]> {
    const PaymentModeByNameUrl = this.baseUrl + `/payment`;
    return this.http.get<PaymentMode[]>(PaymentModeByNameUrl).pipe();
  }

  // GET PRODUCT DDL DETAILS
  getBeneficiaryDetails(claimId: number): Observable<Beneficiary[]> {
    const BeneficiaryNameUrl = this.baseUrl + `/beneficiary/${claimId}`;
    return this.http.get<Beneficiary[]>(BeneficiaryNameUrl).pipe();
  }

  // GET SEARCH & GRID CLAIM SETTLEMENT
  getAllClaimSettlementDetails(claimId: string, policyNo: string, firstName: string, lastName: string, agentCode: string, serviceBranch: string): Observable<Claimssettlement[]> {
    const AllClaimSettlementSearchUrl = this.baseUrl + `/getAllClaimsForSettlement/${claimId}/${policyNo}/${firstName}/${lastName}/${agentCode}/${serviceBranch}`;
    return this.http.get<Claimssettlement[]>(AllClaimSettlementSearchUrl).pipe();
  }

}



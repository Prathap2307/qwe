﻿

if($( window ).width() <= 767){
	$(".dropdown-main").removeClass("dropdown-content");
	$(".admin_menu_common .dropdown-main").css("display", "none");
}

$(window).on('resize', function() {
	if($( window ).width() > 767){
		$(".dropdown-main").addClass("dropdown-content");
	}
});

$(document).on('click', ".admin_menu_common .dropbtn", function() {
	if($( window ).width() <= 767){
		var $this = $(this)
		$(".admin_menu_common .dropdown-main").slideUp();
		if ($this.next().css("display") == "none") {
			
			$this.next().slideToggle();
		}
	}
});

	var lookupValueload = $(".lookup-select option:selected").val();
	if(lookupValueload == "0"){
	}
	else{
		//alert(lookupValueload);
		$("."+lookupValueload).show();
	}
	
	
	$(document).on('change', ".lookup-select select", function () {

		 var currentValue = $(this).val();
		 $(".lookup-details").hide();
		 $("."+currentValue).show();
       
    });
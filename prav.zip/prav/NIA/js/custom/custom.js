﻿
/* 
function myFunction(x) {
    x.classList.toggle("change");
}


function showHideLogin1(x) {
	$(".tab-ul li").removeClass("currentIndex");
	$(x).addClass("currentIndex");
	ShowLogin();
}
function showHideLogin2(x) {
	$(".tab-ul li").removeClass("currentIndex");
	$(x).addClass("currentIndex");
	ShowLogin();
}
function showHideLogin3(x) {
	$(".tab-ul li").removeClass("currentIndex");
	$(x).addClass("currentIndex");
	ShowLogin();
}

function ShowLogin() {
	if ($('#tab_1').hasClass("currentIndex")) {
		document.getElementById('tab_1').className = 'active';
		document.getElementById('tab_2').className = '';
		document.getElementById('tab_3').className = '';
		
		
		document.getElementById('divTab1').style.display = "block";
		document.getElementById('divTab2').style.display = "none";
		document.getElementById('divTab3').style.display = "none";
	}
	else if ($('#tab_2').hasClass("currentIndex")) {
		document.getElementById('tab_1').className = '';
		document.getElementById('tab_2').className = 'active';
		document.getElementById('tab_3').className = '';
		
		
		document.getElementById('divTab1').style.display = "none";
		document.getElementById('divTab2').style.display = "block";
		document.getElementById('divTab3').style.display = "none";
	}
	else if ($('#tab_3').hasClass("currentIndex")) {
		document.getElementById('tab_1').className = '';
		document.getElementById('tab_2').className = '';
		document.getElementById('tab_3').className = 'active';
		
		
		document.getElementById('divTab1').style.display = "none";
		document.getElementById('divTab2').style.display = "none";
		document.getElementById('divTab3').style.display = "block";
	}
	
}
ShowLogin(); */


$(document).on('ready', function () {

    // "use strict"; //Start of Use Strict
	
	/* function sidebar_fn(para1) {
        var windowWidth = $(window).width();
        if (windowWidth >= 1150 && windowWidth >= 640) {
            var wh = $(window).height();
            var fh = $(".footer_common").height();
            var x = $(".after-signin-logo").offset().top
            var h = $(".after-signin-logo").outerHeight();
            var y = $(para1).scrollTop();
            th = x + h;
            wh = wh - fh - th;
            $(".sidebar_menu_common").css({ "height": wh + "px" });
            if (y > th) {
                $(".sidebar_menu_common").css({ "top": "0%", "position": "fixed" });
            }
            else {
                $(".sidebar_menu_common").css({ "top": th + "px", "position": "absolute" });
            }
        }
    } */
	
	
	 var coverageValueload = $(".coverage-select option:selected").val();
		if(coverageValueload == "0"){
		}
		else{
			$("."+coverageValueload).show();
		}
	
	
	$(document).on('change', ".coverage-select select", function () {

		 var currentValue = $(this).val();
		 $(".proposer_common .coverage-details").hide();
		 $("."+currentValue).show();
       
    }); 
	
	
	/* function sidebar_fn(para1) {
        var windowWidth = $(window).width();
        if (windowWidth >= 1150 && windowWidth >= 640) {
            var wh = $(window).height();
            var fh = $(".footer_common").height();
            var x = $(".after-signin-logo").offset().top
            var h = $(".after-signin-logo").outerHeight();
            var y = $(para1).scrollTop();
            th = x + h;
            wh = wh - fh;
			
			 
           $(".sidebar_menu_common").css({ "height": wh + "px" });
            if (y > th) {
                $(".sidebar_menu_common").css({ "top": "0%", "position": "fixed" });
            }
            else {
                $(".sidebar_menu_common").css({ "top": th + "px", "position": "absolute" });
            }
        }
    } */
 
    function sidebar_fn(para1) {
        var windowWidth = $(window).width();
        if (windowWidth >= 1150 && windowWidth >= 640) {
            var wh = $(window).height();
			
            var fh = $(".footer_common").height();
            var x = $(".after-signin-logo").offset().top
            var h = $(".after-signin-logo").outerHeight();
			
            var y = $(para1).scrollTop();
            th = x + h;
            //wh = wh - fh;
			wh = wh - fh;


            $(".sidebar_menu_common").css({ "height": wh + "px" });
            if (y > th) {
                $(".sidebar_menu_common").css({ "top": "0%", "position": "fixed" });
            }
            else {
                $(".sidebar_menu_common").css({ "top": th + "px", "position": "absolute" });
				wh = wh - fh - h;
				$(".sidebar_menu_common").css({ "height": wh + "px", "padding-bottom": fh + "px"  });
            }
        }
    }
	if ($(".sidebar_menu_common").length) {
        sidebar_fn(document);
    }
    

    $(document).on('scroll', function () {

        if ($(".sidebar_menu_common").length) {
            sidebar_fn(this);
        }
       
    });

    $(document).on('resize', function () {

        if ($(".sidebar_menu_common").length) {
            sidebar_fn(this);
        }
       
    });
	
	/* $(document).on('click', '.map-icon', function (event) {
        event.preventDefault();
		$(".map-modal").find("iframe").attr("src", "");
		var current_url = $(this).attr("href");
		 $(".map-modal").find("iframe").attr("src", current_url);
		// $('iframe').attr('src', $('iframe').attr('src'));

		// $('#iframe_id').contentWindow.location.reload(true);
		 
    });  */
	 
	
	var tog = 0;
	$('.res-menu-bar').on("click", function() { 
		var windowWidth = $(window).width();
		if(windowWidth < 1150 && windowWidth >= 640 ){
			//alert("hi");
		    if(tog == 0){
				$(".sidebar_menu_common").animate({
						"left": "0"
						
				}, 200);
				tog = 1;
			}
			else {
				$(".sidebar_menu_common").animate({
						
						"left": "-100%"
				}, 500);
				tog = 0;
			}
		}
	});
	
	$('.res-menu-bar').on("click", function() { 
		var windowWidth = $(window).width();
		if(windowWidth < 640 ){
			
			$(".sidebar_menu_common").slideToggle();
	
		}
	
	});
	
	
	var menu_icon_bar = $(".menu-bar-main-li");
	if(menu_icon_bar.length){
		function myFunction(x) {
			x.classList.toggle("change");
		}
	}
	
	

	
	/* function sidebar_fn(){
		var x = $(".logo_user_common").offset().top
		var h = $(".logo_user_common").outerHeight();
		var doch = $(document).height();
		x = x + h;
		doch = doch - x;
		var y = $(this).scrollTop();
		$(".sidebar_menu_common").css({ "top":  x + "px" });
		$(".sidebar_menu_common").css({ "height":  doch + "px" });
	}
	sidebar_fn();
	$(window).on('resize', function () {
		sidebar_fn();
	}); 
	var menu_icon_bar = $(".menu-bar-main-li");
	if(menu_icon_bar.length){
		function myFunction(x) {
			x.classList.toggle("change");
		}
	} */
	
	
	
	
	$(".toggle-password").click(function() {

	  $(this).toggleClass("fa-eye fa-eye-slash");
	  var input = $($(this).attr("toggle"));
	  if (input.attr("type") == "password") {
		input.attr("type", "text");
	  } else {
		input.attr("type", "password");
	  }
	});
	
	//MENU ACCORDION
	var acc_menu = $(".acc-menu");
	if(acc_menu.length){
		$('.sub-menu .first-menu').on('click', function() {
			var $this = $(this);
			/* if( $this.next().css("display") == "block" ){
				$(".acc-menu").slideUp();
			} */
			$( ".acc-menu" ).slideUp();
			$( ".product-menu" ).slideUp();
			if ( $this.next().css("display") == "none" ) {
				$this.next().slideToggle();
			}
		});
	}	
	
	var product_menu = $(".product-menu");
	if(product_menu.length){
	 $('.acc-menu .product-link').on('click', function() {
			var $this = $(this);
			/* if( $this.next().css("display") == "block" ){
				$(".acc-menu").slideUp();
			} */
			$( ".product-menu" ).slideUp();
			if ( $this.next().css("display") == "none" ) {
				$this.next().slideToggle();
			}
		});
	}
		
	/*  $('.acc-menu').on('click', function() {
		 if(){
			 $(this).css({ 'display': 'block' });
		 }
			
		 }); */


    function premium_bar() {
        var tot_len = $(".qa-tab .tab-pane").length;
        var current_len = $(".tab-pane.active").index();
        tot_len = tot_len - 1;
        var per = (current_len / tot_len) * 100;

        per = Math.round(per);
        $('.inner').animate({
            width: per + '%'
        }, 1000);

        $(".range").text(per + '%');
    }
    premium_bar();



    //SEARCH FOR PREMIUM CALCULATOR
    $(".inputString").keyup(function () {
        var filter = $(this).val();

        $(this).parents(".search-main").next().find(".ans-btns-main li").each(function () {

            if ($(this).text().search(new RegExp(filter, "i")) < 0) {
                $(this).hide();
            } else {
                $(this).show();
            }

        });

      /*   if ($(this).parents(".search-main").next().find(".ans-btns-main li:visible").length == "0") {
            $(this).parents(".search-main").next().find(".ans-btns-main").next(".no-result").text("No Results Found");
        } else {
            $(this).parents(".search-main").next().find(".ans-btns-main").next(".no-result").text("");
        } */
		
		if ($(this).parents(".search-main").next().find(".ans-btns-main li:visible").length == "0") {
            $(this).parents(".search-main").next().find(".no-result").text("No Results Found");
        } else {
            $(this).parents(".search-main").next().find(".no-result").text("");
        }

    });


    $(document).on("click", ".tab-ul > li", function () {

        var len = $(this).index();
        $(".tab-ul > li").removeClass('visited');
        $(".tab-ul > li").removeClass('active');

        $(this).addClass('active');
        $(".tab-ul > li").each(function (i) {
            if (i < len) {
                $(this).addClass('visited');
            }
        });
    });
	
	/*  $(".datepicker").datepicker('show').on('changeDate',function(ev){                 
     $('.datetimepicker').hide();
  }); */

    //Datepicker//
    var datepicker = $('.datepicker');
    if (datepicker.length) {
        $(".datepicker").datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true,
			todayBtn: true
        }).datepicker();
		
		$('.datepicker-dropdown').hide();
       
    } 

    //After Scroll Menu Created, Menu Bgcolor and Text Color
    var menu_bar = $('.logo_common');
    var top_nav = $('.contact_common');

    if (top_nav.length) {
        var x = top_nav.offset().top
        /* if (x > 0) {
            menu_bar.addClass( " navbar-fixed-top menu-bottom-shadow animated fadeInDown" );
            
        }
        else {
            menu_bar.removeClass( "navbar-fixed-top menu-bottom-shadow animated fadeInDown" );
        } */


        $(document).on('scroll', function () {
            var y = $(this).scrollTop();

            if ($('.header_common').hasClass("menu_fixed_top")) {
                if (y > x) {
                    menu_bar.addClass("navbar-fixed-top menu-bottom-shadow animated fadeInDown");
                }
                else {
                    menu_bar.removeClass("navbar-fixed-top menu-bottom-shadow animated fadeInDown");
                }
            }
        });
    }



    // WINDOW SCROLL TO TOP 
    var $pageTop = $('.scroll-top');
    if ($pageTop.length) {
        function prestige_showScrollToTop() {
            var topy = $(window).scrollTop();
            if (topy > 350) {
                $pageTop.fadeIn();
            }
            else {
                $pageTop.fadeOut();
            }
        }

        $pageTop.on('click', 'a', function (event) {
            $('html, body').animate({
                scrollTop: $($(this).attr('href')).offset().top
            }, 2000);
            return false;
        });

        $(document).on('scroll', function () {
            prestige_showScrollToTop(); //show/hide scroll to top button
        });
    }

    //FAQ
    var faq_common = $(".faq_common");
    if (faq_common.length) {
        $('.faq_common .faq-title').on('click', function () {
            var $this = $(this);
            $(".faq-ans").slideUp();
            $('.plus-arrow').removeClass("minus-arrow");
            if ($this.next().css("display") == "none") {
                $this.next().slideToggle();
                $this.find('.plus-arrow').toggleClass("minus-arrow");
            }
        });
    }


   



    // RANGE SLIDER
    var range_slider = $(".range-slider");
    if (range_slider.length) {
        $(document).foundation();
    }



    /* function product_loadpage_fn(index_value){
		if(index_value.toString().length){
			var liv = $(".products-main");
			liv.eq(index_value).addClass("act");
			var activeLi = $(".products-main.act");
			activeLi.find(".product-design").addClass("rad-curved");
			var productId = activeLi.find("a").attr("href");
			$(productId).show();
		}
		
	}
	product_loadpage_fn(0);
	
	$(document).on("click", ".products-main a", function(e) {
		e.preventDefault();
		var productId = this.hash;
		$(".product-design").removeClass("rad-curved");
		$(this).parents(".products-main").find(".product-design").addClass("rad-curved");
		$(".entry_main").hide();
		if($(productId).css('display') =='none'){
			$(productId).show();
			$(productId).addClass("animated zoomIn");
		}
	}); */


    //TOOLTIP
    var tooltip_title = $(".tooltip_msg");
    if (tooltip_title.length) {
        $('.tooltip_msg').tooltipster({
            animation: 'grow',
            theme: 'tooltipster-noir',
            trigger: 'hover',
            side: 'right',
            delay: 100,
        });
    }

    //TOOLTIP
    var tooltip_top = $(".tooltip_top");
    if (tooltip_top.length) {
        $('.tooltip_top').tooltipster({
            animation: 'grow',
            theme: 'tooltipster-noir',
            trigger: 'hover',
            side: 'top',
            delay: 100,
        });
    }


    //TOOLTIP
    var tooltip_title = $(".tooltip_claim");
    if (tooltip_title.length) {
        $('.tooltip_claim').tooltipster({
            animation: 'grow',
            theme: 'tooltipster-noir',
            trigger: 'hover',
            side: 'top',
            delay: 100,
        });
    }

    //DYNAMIC FORM VALIDATION
    function validate_result_fn(mtry_len) {
        $(".error-list, .sucess-msg").remove();
        //alert(mtry_len);
        if (mtry_len <= 0) {
            $(".validate-result").append('<div class="center sucess-msg">' + 'All mandatory fields Completed' + '</div>');
        } else if (mtry_len > 0) {
            $(".validate-result").append('<div class="center error-list">' + '<span>' + mtry_len + '</span>' + 'mandatory fields pending ' + '</div>');
        }

    }

    var required = $(".required");
    var mtry_len = $(".mtry").length;
    validate_result_fn(mtry_len);
    $('.required').val("");
    if (required.length) {

        $('.required').change(function () {
            if ($(this).val() != '') {
                $(this).removeClass("mtry");
            } else {
                $(this).addClass("mtry");
            }
            mtry_len = $(".mtry").length;
            validate_result_fn(mtry_len);

        });

        $(".required").on("keypress keypress keyup", function () {

            var $this = $(this);
            if ($this.val() != '') {
                $this.removeClass("mtry");
            } else {
                $this.addClass("mtry");
            }

            mtry_len = $(".mtry").length;
            validate_result_fn(mtry_len);
        });
    }



    //CUSTOMER REGISTRATION ACCORDION
    var acc_tax = $(".acc-main");
    if (acc_tax.length) {
        //alert("hi");
        var acc_content = $(".customer_reg_common .acc-content");
        var acc_heading = $(".customer_reg_common .acc-heading");


        acc_heading.on('click', function () {
            var $this = $(this);

            $this.next().slideToggle();
            $this.find('.plus-arrow').toggleClass("minus-arrow");

        });



        /* $('.customer_reg_common .next-btn').on('click', function() {
			var $this = $(this);
			acc_content.slideUp();
			if ($this.parents(".acc-main").next().find(".acc-content").css("display") == "none") {
				$this.parents(".acc-main").next().find(".acc-content").slideToggle();
			}
			
		}); */


    }


    /* $('.plus-arrow').removeClass("minus-arrow");
			if ($this.next().css("display") == "none") {
				$this.next().slideToggle();
				$this.find('.plus-arrow').toggleClass("minus-arrow");
			} */


    //$(this).parents(".products-main").find(".product-design").css({ "position": "absolute", "left": "0", "right": "0", "top": "50px", "width": "250px", "margin": "0 auto" });

    //$("p").css({"background-color": "yellow", "font-size": "200%"});

    /* $(document).on("click", ".product_list_common .product-design", function(e) {
		e.preventDefault();
		//alert($(this).attr("class"));
		$(".products-main").hide();
		$(this).parents(".products-main").show();
		$(this).parents(".products-main").addClass("full-width");
		
		$(this).parents(".products-main").find(".product-design").addClass("fix-width");
		$(this).next().show();
		
		$(this).find(".close-product").show();
		
		
	});	

	$(document).on("click", ".product_list_common .product-design .close-product", function(e) {
		e.preventDefault();
		//alert("hi");
		$(".products-main").show();
		
		//$(this).parents(".products-main").removeClass("full-width");
		
		//$(this).parents(".product-design").removeClass("fix-width");
		
		
		//$(this).hide();
		
		
	});		 */

   /*  function product_orgin_fn() {
        $(".product_list_common .products-main").css({ "left": "33%", "top": "80px", "margin": "0 auto" });
        $(".product_list_common .products-main").addClass("pointer-none");

    }
    product_orgin_fn();

    function product_fn() {
        $(".products-main-1").css({ 'left': '0%', 'top': '100px' });
        $(".products-main-2").css({ 'left': '50%', 'top': '100px' });
        $(".products-main-3").css({ 'left': '0%', 'top': '300px' });
        $(".products-main-4").css({ 'left': '50%', 'top': '300px' });
        $(".products-main-nia").css({ 'left': '25%', 'top': '200px' });
        $(".product_list_common .products-main").removeClass("pointer-none");
        $(".product_list_common .products-main-nia").addClass("pointer-none");
    }
    setTimeout(function () {
        product_fn();
    }, 1000);


    $(document).on("click", ".product_list_common .products-main", function (e) {
        e.preventDefault();
        product_orgin_fn();
        $(".product_list_common .products-main").removeClass("pointer-none");
        $(".product_list_common .products-main-nia").addClass("pointer-none");

        $(".product_list_common .products-main").hide();
        $(this).show();


        var $this = $(this);
        function btn_slide_fn() {
            setTimeout(function () {
                $this.find(".product-btns-main").slideDown();
                $(".product_list_common .close-product").show();
            }, 500);
        }
        btn_slide_fn();


        $(".overlay").addClass("slide_lay");

    });


    $(document).on("click", ".product_list_common .close-product", function () {
        $(this).hide();

        $(".overlay").removeClass("slide_lay slide_lay_2");
        $(".product-btns-main").hide();
        $(".product_list_common .products-main").show();
        setTimeout(function () {
            product_fn();
        }, 1000);

    });
	 */
	
	// PREMIUM CALCULATOR DESIGN
    var premium_tab = $(".premium_tab");
    var premium_list_Len = premium_tab.find('.premium_list').length;


    function premium_next_fn() {
        var currentIndex = premium_tab.find('.premium_list.active').index();

        var current = premium_tab.find('.premium_list.active');
        var next = premium_tab.find('.premium_list.active').next();

        current.removeClass('active in animated slideInRight');
        next.addClass('active in animated slideInRight');
    }

    function premium_prev_fn() {

        var currentIndex = premium_tab.find('.premium_list.active').index();
        var firstIndex = premium_tab.find('.premium_list.active').prev().index();

        var current = premium_tab.find('.premium_list.active');
        var prev = premium_tab.find('.premium_list.active').prev();

        current.removeClass('active in animated slideInLeft');
        prev.addClass('active in animated slideInLeft');
    }



    $(document).on('click', '.premiumcal_common .continue-btn', function (event) {
        event.preventDefault();
		var currentIndex = premium_tab.find('.premium_list.active').index();
		if( currentIndex == (premium_list_Len-1) ){
			$(this).attr('disabled', true);
			return false;
		} 
        premium_next_fn();
       
    });

 

    $(document).on('click', '.premiumcal_common .left-arrow a', function (event) {
        event.preventDefault();
		
        premium_prev_fn();
    });
	



    /* Q&A SLIDING */
    var qa_tab = $(".qa-tab");
    var qa_Len = qa_tab.find('.tab-pane').length;

	//$(".qa-tab .scroll-main li label").("")
	
	
	
    function qa_next_fn() {
        var currentIndex = qa_tab.find('.tab-pane.active').index();

        var current = qa_tab.find('.tab-pane.active');
        var next = qa_tab.find('.tab-pane.active').next();
		
		current.removeClass('active in animated zoomIn');
        next.addClass('active in animated zoomIn');
		
		
        //current.removeClass('active in animated slideInRight');
       // next.addClass('active in animated slideInRight');
    }

    function qa_prev_fn() {

        var currentIndex = qa_tab.find('.tab-pane.active').index();
        var firstIndex = qa_tab.find('.tab-pane.active').prev().index();

        var current = qa_tab.find('.tab-pane.active');
        var prev = qa_tab.find('.tab-pane.active').prev();

        current.removeClass('active in animated zoomIn');
        prev.addClass('active in animated zoomIn');
    }



    $(document).on('change', '.qa_radio', function (event) {

        event.preventDefault();
		
			
			//var isLastElement = index == data.length -1;
			
			var currentIndex = qa_tab.find('.tab-pane.active').index();
			
			if( currentIndex == qa_Len - 1 ){
				return false;
			}else{
				 $(".errorContainerInner").removeClass("show");
				qa_next_fn();
				premium_bar(); 
				
			}
      


    });

    $(document).on('click', '.continue-btn', function (event) {
        event.preventDefault();
        qa_next_fn();
        premium_bar();
    });

    $(document).on('click', '.right-arrow, .ui-state-active', function (event) {
        event.preventDefault();

        //if( $(this).parents(".tab-pane").find(".ui-state-active").length > 0 || $(this).parents(".tab-pane").find(".form-input").val() != "" ){
			
			
			var currentIndex = qa_tab.find('.tab-pane.active').index();
			
			if( currentIndex == qa_Len - 1 ){
				return false;
			}else{
				
				 if ($(this).parents(".tab-pane").find(".ui-state-active").length > 0) {
					qa_next_fn();
					premium_bar();

				} else {
					$(".errorContainerInner").addClass("show");
				}
				
			}

       

    });

    $(document).on('click', '.left-arrow', function (event) {
        event.preventDefault();
        qa_prev_fn();
        premium_bar();
    });

	//MENU BAR SMOOTH SCROLLING FUNCTION		
	var menu_list=$('.pagescroll');
	if(menu_list.length) {	
	$(document).on('click', '.pagescroll', function (event) {					
			event.preventDefault();	
			var hash_tag= $(this).attr('href');
			$('html, body').animate({
			scrollTop: $(hash_tag).offset().top - 0
			}, 1000);	
			return false;
		});			
	}	


    $(".caltr_common .question:last .right-arrow").addClass("hide");
    $(".caltr_common .question:first .left-arrow").addClass("hide");
	
/* 	var arr_li = []; 
	window.arr_fn = function(x){
		var li_width = x.width();
		arr_li.push(li_width);
	 } 
	 $(".qa-tab .vehicle-variant .scroll-main li").each( function(i){
		var largest= 0;
		arr_fn($(this));
		console.log($(this));
		for (i=0; i<=largest;i++){
			if (arr_li[i]>largest) {
				largest=arr_li[i];
			}
		}
			alert(largest);
		
	 }); */


    // ON SCROLL JS
    /* 	var $animation_elements = $('.animat');
        var $window = $(window);
    
        function check_if_in_view() {
          var window_height = $window.height();
          var window_top_position = $window.scrollTop();
    
          var window_bottom_position = (window_top_position + window_height - 0);
    
          $.each($animation_elements, function() {
            var $element = $(this);
            var element_height = $element.outerHeight();
    
            var element_top_position = $element.offset().top;
    
            var element_bottom_position = (element_top_position + element_height);
    
            if (element_top_position <= window_bottom_position) {
                
                
                setTimeout(function(){ 
                    $('.choose_common .section-heading-bottom').addClass('animated fadeInDown');
                }, 0);
                
                setTimeout(function(){ 
                    $('.choose_common .row_animat').addClass('animated fadeInDown');
                }, 300);
                
                setTimeout(function(){ 
                    $('.choose_common .cont_animat').addClass('animated fadeInDown');
                }, 300);
                
                setTimeout(function(){ 
                    $('.choose_common .btn_animat').addClass('animated fadeInDown');
                }, 300);
                
                //$('.choose_common .animat').addClass('animated fadeInDown');
                
                
                //$('.connect_common .animat').addClass('animated fadeInDown');
                
                // $('.service-section .slide-left').addClass('animated slideInLeft');
                //$('.service-section .slide-right').addClass('animated slideInRight');
                     
                //$('.main_timeline_common .slide-left').addClass('animated slideInLeft');
                //$('.main_timeline_common .slide-right').addClass('animated slideInRight');  
                
            } else {   
            }
          });
        }
    
        $window.on('scroll resize', check_if_in_view); 
        $window.trigger('scroll'); */




    /* $('.choose_common').each(function (){
		
		var $this = $(this);
		var myVal = $(this).data("value");

		$this.appear(function()
		{
			alert("hi");
			$('.choose_common .col-md-3').addClass('animated fadeInRight');
		});
		
	}); */

	
	  // RADIO-BTN	
    var qa_radio = $(".qa_radio");
    if (qa_radio.length) {
        $(".qa_radio").checkboxradio();
    }

    // RADIO-BTN	
    var qa_radio = $(".qa_radio");
    if (qa_radio.length) {
        $(".qa_radio").checkboxradio();
    }


    // SELECT DESIGN	
    var $range = $("#range1_id");
    if ($range.length) {

        var $input = $("#sum-input"),
			min = 4.5,
			max = 6.5, instance;

        $range.ionRangeSlider({
            type: "single",
            min: min,
            max: max,
            step: 0.2,
            grid: true,
            force_edges: true,
            prefix: "₹",
            force_edges: true,
            drag_interval: true,
            postfix: "Lakhs",
            from: 0,
            onStart: function (data) {
                $input.prop("value", data.from);
            },
            onChange: function (data) {
                $input.prop("value", data.from);
            }
        });

        instance = $range.data("ionRangeSlider");

        $input.on("change keyup", function () {
            var val = $(this).prop("value");
            // alert(val);
            // validate
            if (val < min) {
                val = min;
            } else if (val > max) {
                val = max;
            }

            instance.update({
                from: val
            });
        });
    }
	
	//FAQ
    var preview_acc = $(".preview-acc");
    if (preview_acc.length) {
		 $('.preview-acc').on('click', function() {
			var $this = $(this);
			
			 if($this.hasClass("minus-arrow")){
				
				$this.removeClass("minus-arrow");
				$this.addClass("plus-arrow");
				
			}else {
				$this.removeClass("plus-arrow");
				$this.addClass("minus-arrow");
				
			} 
			 $this.next(".preview-acc-content").slideToggle();
		});
    }

    // SELECT DESIGN	
    var select_box = $(".select-box");
    if (select_box.length) {
        $(".select-box").select2();
    }
	
	
	 // SELECT DESIGN	
        var select_box = $(".select-box");
        if (select_box.length) {
            $(".select-box").select2();
        }
	

	$(document).keydown(function (event) {
		if (event.keyCode == 123) { // Prevent F12
			return false;
		} else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
			return false;
		}
		else if (event.ctrlKey && event.keyCode == 85) { // Prevent Ctrl+U       
			return false;
		}
	});
	//https://css-tricks.com/snippets/javascript/javascript-keycodes/
	
	
	// THOUGHT OF THE DAY
		var thought_main = $('.thought_main');
		if (thought_main.length) {
			function thought_fn(dc) {
				var dh = $(dc).scrollTop();
				if (dh > 150) {
					thought_main.fadeOut("fast");
				}
				else {
					var fh = $(".footer_common").outerHeight();
					var fh = $(".footer_common").outerHeight();
					 $(".thought_main").css({ "bottom": fh + "px" });
					thought_main.fadeIn();
				}
			}

			$(document).on('scroll', function () {
				thought_fn(this); 
			});
			
			thought_fn(document);
			
			$(document).on('click', '.thought_main .close-icon', function (event) {
				event.preventDefault();
				//$(".thought_main").fadeOut("fast");
				$(".thought_main").remove();
			   
			});
			
		}

    $('.products_common .slide-left').addClass('animated slideInLeft');
    $('.products_common .slide-right').addClass('animated slideInRight');

    //AOS.init({
    //    duration: 1200,
    //})
    return false;

});
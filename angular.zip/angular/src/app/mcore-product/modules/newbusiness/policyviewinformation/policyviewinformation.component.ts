import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { PolicyViewInformationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/policyviewinformation.service';
import { TooltipPosition } from '@angular/material/tooltip';
import { PolicyViewInformation, PolicyTypeDropDown } from 'src/app/mcore-product/mcore-shared/mcore-entity/policyviewinformation';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
@Component({
	selector: 'app-policyviewinformation',
	templateUrl: './policyviewinformation.component.html',
	styleUrls: ['./policyviewinformation.component.css']
})
export class PolicyviewinformationComponent implements OnInit {

	policyViewForm: FormGroup;


	constructor(private fb: FormBuilder, private policyService: PolicyViewInformationService, private memberupload: MemberuploadService) { }



	mpnObj: any;
	policyViewGrigObj: any;
	get policyViewAction() {
		return this.policyViewForm.get('policyViewAction') as FormGroup;
	}
	filteredClients: Observable<any[]>;
	//tableColumns: string[] = ['ClientName', 'AgreementNumber', 'MasterPolicyNumber', 'UploadedDate', 'PDF', 'Document'];
	tableColumns: string[] = ['masterPolicyNumber', 'insurerMasterAgreementNo', 'policyNumber', 'policyHolderName', 'employeeId', 'contactId', 'PDF'];
	dataSource = new MatTableDataSource<any>(this.policyViewGrigObj);

	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	ngOnInit() {

		this.dataSource = new MatTableDataSource<any>(this.policyViewGrigObj);
		this.policyViewForm = this.fb.group({
			policyViewAction: this.fb.group({
				clientCtrl: [''],
				clientId: [''],
				masterpolicyId: [''],
				agreementId: [''],
				fromDate: [''],
				toDate: [''],
				policyHolderName: [''],
				employeeId: [''],
				certificateNumber: [''],
				contactId: [''],

			})

		});


		this.filteredClients = this.policyViewAction.get('clientCtrl').valueChanges
			.pipe(
				startWith(''),
				map(unit => unit ? this.filterclientFn(unit) : this.clientObj.slice())
			);

		this.getGroupDetails();

	}

	getGroupDetails() {

		let a: Object = {
			"groupName": "",
			"contactFirstName": "",
			"contactLastName": "",
			"customerGroupID": "",
			"branchID": 0,
			"userID": 1
		}

		this.memberupload.getGroupDetails(a).subscribe(a => {
			this.clientObj = a;
		});

	}


	clientObj: any = [];

	filterclientFn(groupName: string) {
		return this.clientObj.filter(unit =>
			unit.groupName.toLowerCase().indexOf(groupName.toLowerCase()) === 0);
	}

	onEnter(evt: any) {

		if (evt.source.selected) {
			// console.log(evt.source.value);
			let v = evt.source.value;

			let r;
			r = this.clientObj.filter((unit) => unit.groupName == v);
			console.log(r[0].groupID);
			this.policyViewAction.get('clientId').patchValue(r[0].groupID);

			this.getmasterPolicyDetails(r[0].groupID);

		}
	}
	getmasterPolicyDetails(groupID) {

		//let groupID = this.memberUploadAction.get('groupID').value;
		this.memberupload.getmasterPolicyDetails(groupID).subscribe(a => {
			this.mpnObj = a;
		});



	}

	onBtnSave() {
		this.policyViewAction.addControl('lobId', new FormControl(5));
		let a = this.policyViewAction.value;
console.log(a);
		// let o: Object = {

		// 	"lobId": 5,
		// 	"clientId": this.policyViewAction.get('clientId').value,
		// 	"masterpolicyId": this.policyViewAction.get('masterPolicyID').value,
		// 	"agreementId": this.policyViewAction.get('agreementID').value,
		// 	"fromDate": "",
		// 	"toDate": "",
		// 	"policyHolderName": "",
		// 	"employeeId": "",
		// 	"certificateNumber": "",
		// 	"contactId": ""

		// }

		console.log(a);
		this.policyService.getMembersearch(a)
			.subscribe(data => {

				this.policyViewGrigObj = data;
				this.dataSource = new MatTableDataSource<any>(this.policyViewGrigObj);
				this.dataSource.data = this.policyViewGrigObj = data;
				this.dataSource.paginator = this.paginator;
				console.log(this.policyViewGrigObj);
			});
	}



	onBtnClear() {
		this.policyViewAction.reset({

			clientCtrl: '',
			clientId: '',
			masterpolicyId: '',
			agreementId: '',
			fromDate: '',
			toDate: '',
			policyHolderName: '',
			employeeId: '',
			certificateNumber: '',
			contactId: ''

		});
	}
	pdfPath: any;
	btngvpdf_Click(id){
		console.log(id);
	


		this.policyService.getPolicyCertificatesdownload(id).subscribe(data => {
			this.pdfPath = data;
			window.open(this.pdfPath, '_blank');
		});

	

	}

	cfn(a) {
		console.log(a);
	}

}


import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claimssettlementnew',
  templateUrl: './claimssettlementnew.component.html',
  styleUrls: ['./claimssettlementnew.component.css']
})
export class ClaimssettlementnewComponent implements OnInit {
   
   dummyObj: string;
  tableColumns: string[] = ['Select', 'claimId', 'policyNumber', 'insuredName', 'claimApprovedDate' , 'approvedAmount', 'amountPayable', 'status'  ];
  
  constructor() { }

  ngOnInit() {
  }

}

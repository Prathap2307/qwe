import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClaimassessmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/claimassessment.service';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-claimsregistrationnew',
  templateUrl: './claimsregistrationnew.component.html',
  styleUrls: ['./claimsregistrationnew.component.css']
})
export class ClaimsregistrationnewComponent implements OnInit {

  dummyObj: string;
  tableColumns1: string[] = ['Select', 'CLAIMNUMBER', 'POLICYHOLDERNAME', 'POLICYNUMBER'];

  tableColumnsOne: string[] = ['edit', 'delete', 'documentType', 'image'];
  tableColumnsThree: string[] = ['claimNumber', 'assessor', 'assessorName', 'assessorBranch', 'assessorExpenses', 'assessmentRemarks'];
  constructor(private activatedRoute: ActivatedRoute, private claimAssessmentService: ClaimassessmentService, private fb: FormBuilder) { }

  divAssessorRemarksDetails: boolean;
  divAssessmentHistory: boolean;

  divCoverageDetails: boolean;
  divTotalPayable: boolean;
  divAssessorSelection: Boolean;
  divProcesses: Boolean;

  TypeClaim: string;
  ClaimForm: FormGroup;
  causeOfDeathObj: any;
  selectProcessObj: any = [{
    "id": 1,
    "description": "Approve"
  },
  {
    "id": 2,
    "description": "Return"
  },
  {
    "id": 3,
    "description": "Reject"
  }]
  claimDetailsObj: any;
  get ClaimDetailsGroup() {
    return this.ClaimForm.get('ClaimDetailsGroup') as FormGroup;
  }
  get TotalPayableGroup() {
    return this.ClaimForm.get('TotalPayableGroup') as FormGroup;
  }
  get expiryDetailsGroup() {
    return this.ClaimForm.get('expiryDetailsGroup') as FormGroup;
  }
  ngOnInit() {


    this.activatedRoute.queryParams.subscribe(params => {
      this.TypeClaim = params['Type'];
      this.claimsPageLoad();
    });

    this.ClaimForm = this.fb.group({
      ClaimDetailsGroup: this.fb.group({
        policyNumber: [''],
        claimID: [''],
        policyHolderName: [''],
        policyInceptionDate: [''],
        policyExpiryDate: [''],
        customerID: [''],
        plan: [''],
        profession: [''],
        sumInsured: [''],
        claimIntimationDate: [''],
        causeOfDeath: [''],
        DateOfEvent: [''],
      }),
      TotalPayableGroup: this.fb.group({
        amountPayable: ['']
      }),
      expiryDetailsGroup: this.fb.group({
        dateOfLoss: ['']
      })
    });

    this.getAllPendingClaims();
    this.getAllCauseOfDeath();

  }

  claimsPageLoad() {
    // if (this.TypeClaim.trim() == 'request') {
    //   this.divAssessorRemarksDetails = false;
    //   this.divAssessmentHistory = false;
    //   this.divCoverageDetails = true;
    //   this.divTotalPayable = true;
    //   this.divAssessorSelection = true;
    //   this.divProcesses = true;
    // }

    if (this.TypeClaim.trim() == 'Assessment') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = false;
      this.divProcesses = true;
    }

    if (this.TypeClaim.trim() == 'Approval') {
      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = false;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = true;
      this.divProcesses = true;
    }

    if (this.TypeClaim.trim() == 'View') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = false;
      this.divProcesses = false;
    }

    if (this.TypeClaim.trim() == 'Reopen') {

      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = true;
      this.divProcesses = true;
    }
  }
  pendingClaimsObj: any;
  pendingClaimFilteredObj: any;
  getAllPendingClaimsTestFn() {
    //  this.pendingClaimsObj = [];
    this.pendingClaimsObj = [{
      "CONTACTNUMBER": "9812345678",
      "SHORTNAME": null,
      "CONTACTLASTNAME": "DURAI",
      "CUSTOMERGROUPID": "2000000001",
      "AGREEMENTENDDATE": null,
      "COREBUSINESS": "IT",
      "CONTACTFIRSTNAME": "DEEPAN",
      "GROUPID": 1,
      "GROUPNAME": "DEEPAN D12345",
      "AGREEMENTSTARTDATE": null,
      "SALUTATIONID": 1,
      "CONTACTMIDDLENAME": "SING",
      "MASTERPOLICYAGREEMENT": 0,
      "TNAME": "GRP",
      "FULLNAME": "DEEPANDURAI",
      "BRANCHID": 301
    }];
  }

  getAllPendingClaims() {



    this.claimAssessmentService.getAllPendingClaims(2, "hi", "a", "b", "dd", "ee", "we", 18, 2)
      .subscribe(data => {

        this.pendingClaimsObj = data;

      });

    //  this.getAllPendingClaimsTestFn();
  }
  getAllCauseOfDeath() {



    this.claimAssessmentService.getAllCauseOfDeath()
      .subscribe(data => {

        this.causeOfDeathObj = data;

      });

    //  this.getAllPendingClaimsTestFn();
  }
  cfn(a) {
    console.log(a);
  }

  btngvEdit_Click(id) {

    this.pendingClaimFilteredObj = this.pendingClaimsObj.filter((unit) => unit.CLAIMID == id);

    this.ClaimDetailsGroup.patchValue({
      policyNumber: this.pendingClaimFilteredObj[0].POLICYNUMBER,
      claimID: this.pendingClaimFilteredObj[0].CLAIMNUMBER,
      policyHolderName: this.pendingClaimFilteredObj[0].POLICYHOLDERNAME,
      policyInceptionDate: [''],
      policyExpiryDate: ['']
    });
    this.ClaimDetailsGroup.disable();
    // this.ClaimDetailsGroup.get('policyNumber').disable();
    // this.ClaimDetailsGroup.get('claimID').disable();
    // this.ClaimDetailsGroup.get('policyHolderName').disable();

    this.getClaimDetailsByClaimId(id)
  }

  clearClaim() { 

    this.ClaimDetailsGroup.reset({
      policyNumber: '',
      claimID: '',
      policyHolderName: '',
      policyInceptionDate: '',
      policyExpiryDate: '',
      customerID: '',
      plan: '',
      profession: '',
      sumInsured: '',
      claimIntimationDate: '',
      causeOfDeath: '',
      DateOfEvent: ''
    });

    this.TotalPayableGroup.reset({
      amountPayable: ''
    });
    this.ClaimForm.enable();
  }

  // TotalPayableGroup: this.fb.group({
  //   amountPayable: ['']
  // })

  ClaimDetailsByClaimIdPatch() {
    console.log( this.claimDetailsObj[0].DATEOFLOSS);
    this.TotalPayableGroup.patchValue({
      amountPayable: this.claimDetailsObj[0].SUMINSURED
    });
    this.expiryDetailsGroup.patchValue({
      dateOfLoss: this.claimDetailsObj[0].DATEOFLOSS
    });
  }
  getClaimDetailsByClaimId(id) {



    this.claimAssessmentService.getClaimDetailsByClaimId(id)
      .subscribe(data => {

        this.claimDetailsObj = data;
        this.ClaimDetailsByClaimIdPatch();
      });


  }
}

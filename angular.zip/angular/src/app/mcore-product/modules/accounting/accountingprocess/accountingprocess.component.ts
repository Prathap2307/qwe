import { Component, OnInit, ViewChild, Directive, Input, ChangeDetectorRef, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AccountingProcessService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingprocess.service';
import { TooltipPosition } from '@angular/material/tooltip';
import { AccountingProcess, AccountTypeDropDown } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingprocess';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';




@Component({
	selector: 'app-accountingprocess',
	templateUrl: './accountingprocess.component.html',
	styleUrls: ['./accountingprocess.component.css']
})
export class AccountingprocessComponent implements OnInit {
	tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
	tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

	submitted = false;
	saveBtnMode: boolean;
	processForm: FormGroup;

	get processFormSearch() {
		return this.processForm.get('processFormSearch') as FormGroup;
	}
	get processFormAction() {
		return this.processForm.get('processFormAction') as FormGroup;
	}

	constructor(private fb: FormBuilder, private processService: AccountingProcessService, private changeDetector: ChangeDetectorRef) { }

	tableColumns: string[] = ['View', 'Edit', 'code', 'description'];
	processHeading: string = '';
	processObj: AccountingProcess[] = [];
	processGridObj: AccountingProcess[] = [];
	processFilteredObj: AccountingProcess[] = [];
	fieldDisable: Boolean;
	divIsGSTApplicable: Boolean;
	divGstTypeID: Boolean;


	AccountTypeObjDropDown: AccountTypeDropDown[] = [];

	isGSTApplicableV: number;
	isTaxApplicableV: number;
	createBtn: boolean;
	dataSource = new MatTableDataSource<AccountingProcess>(this.processGridObj);

	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild('refIsGSTApplicable', { static: false }) refIsGSTApplicable;

	textSaveBtn: any;

	ngOnInit() {
		this.textSaveBtn = 'Save';
		this.createBtn = true;

		this.dataSource = new MatTableDataSource<AccountingProcess>(this.processGridObj);
		this.divIsGSTApplicable = false;
		this.divGstTypeID = false;
		this.processHeading = 'Add New - Accounting Process';
		this.saveBtnMode = true;

		this.processForm = this.fb.group({

			processFormSearch: this.fb.group({
				searchCode: [''],
				searchDescription: ['']
			}),
			processFormAction: this.fb.group({
				processID: [''],
				code: ['', [Validators.required]],
				description: ['', [Validators.required]],

				isGSTApplicable: [this.isGSTApplicableV = 0],
				isTaxApplicable: [this.isTaxApplicableV = 0],
				gstTypeID: [0]
			})
		});
		this.getAccountingProcessDetails();
		this.getAllGSTType();
	}

	getAccountingProcessByClearSearch() {
		this.processFormSearch.reset({
			searchCode: '',
			searchDescription: ''
		});
		this.getAccountingProcessDetails();
	}


	getAccountingProcessBySearch() {
		let x = 0;
		let y = this.processFormSearch.get('searchCode').value;
		let z = this.processFormSearch.get('searchDescription').value;

		if (y == '') {
			y = 0;
		}

		if (z == '') {
			z = 0;
		}

		this.processService.getAccountingProcessSearchDetails(x, y, z).subscribe(a => {

			this.processGridObj = a;
			this.dataSource = new MatTableDataSource<AccountingProcess>(this.processGridObj);
			this.dataSource.data = this.processGridObj = a;
			this.dataSource.paginator = this.paginator;

		});
	}

	isTaxApplicableValue(event) {


		if (event.checked) {
			this.processForm.get('processFormAction').patchValue({
				isTaxApplicable: this.isTaxApplicableV = 1
			});

			this.divIsGSTApplicable = true;
			this.changeDetector.detectChanges();



			if (this.refIsGSTApplicable.checked) {
				this.divGstTypeID = true;
			} else {
				this.divGstTypeID = false;
			}

		} else {
			this.processForm.get('processFormAction').patchValue({
				isTaxApplicable: this.isTaxApplicableV = 0
			});

			this.divIsGSTApplicable = false;
			this.divGstTypeID = false;

		}



	}

	isGSTApplicableValue(event) {


		if (event.checked) {
			this.processForm.get('processFormAction').patchValue({
				isGSTApplicable: this.isGSTApplicableV = 1
			});
			this.divGstTypeID = true;
		} else {
			this.processForm.get('processFormAction').patchValue({
				isGSTApplicable: this.isGSTApplicableV = 0
			});
			this.divGstTypeID = false;
		}
	}




	getAccountingProcessDetails(): void {



		this.processService.getAccountingProcessDetails().subscribe(a => {
			this.processObj = a;
			this.processGridObj = a;
			this.dataSource = new MatTableDataSource<AccountingProcess>(this.processGridObj);
			this.dataSource.data = this.processGridObj = a;
			this.dataSource.paginator = this.paginator;

		});
	}

	getAllGSTType(): void {



		this.processService.getAllGSTType().subscribe(a => {
			this.AccountTypeObjDropDown = a;
		});
	}

	btngvView_Click(a) {
		this.saveBtnMode = false;
		this.fieldDisable = true;
		this.processFilteredObj = this.processObj.filter((unit) => unit.processID == a);

		this.processFormAction.patchValue({
			processID: this.processFilteredObj[0].processID,
			description: this.processFilteredObj[0].processName,
			code: this.processFilteredObj[0].code,
			isTaxApplicable: this.processFilteredObj[0].isTaxApplicable,
			isGSTApplicable: this.processFilteredObj[0].isGSTApplicable,

			gstTypeID: this.processFilteredObj[0].gstTypeID

		});

		if (this.processFilteredObj[0].isTaxApplicable == 1) {
			this.divIsGSTApplicable = true;
		}

		if (this.processFilteredObj[0].isGSTApplicable == 1) {
			this.divGstTypeID = true;
		}

		this.processHeading = 'View - Accounting Process';
	}

	btngvEdit_Click(a) {
		this.saveBtnMode = true;
		this.processFilteredObj = this.processObj.filter((unit) => unit.processID == a);
		this.fieldDisable = false;
		this.createBtn = false;
		this.textSaveBtn = 'Update';
		this.processFormAction.patchValue({
			processID: this.processFilteredObj[0].processID,
			description: this.processFilteredObj[0].processName,
			code: this.processFilteredObj[0].code,
			isTaxApplicable: this.processFilteredObj[0].isTaxApplicable,
			isGSTApplicable: this.processFilteredObj[0].isGSTApplicable,

			gstTypeID: this.processFilteredObj[0].gstTypeID

		});

		if (this.processFilteredObj[0].isTaxApplicable == 1) {
			this.divIsGSTApplicable = true;
		}

		if (this.processFilteredObj[0].isGSTApplicable == 1) {
			this.divGstTypeID = true;
		}

		this.processHeading = 'Edit - Accounting Process';

	}

	removeSaveFormControls() {
		this.processFormAction.removeControl('createdBy');
		this.processFormAction.removeControl('createdOn');
		this.processFormAction.removeControl('shortName');
		this.processFormAction.removeControl('isActive');
	}

	saveMethod() {
		if (this.divGstTypeID) {

			if (this.processFormAction.get('gstTypeID').value == 0) {
				this.processFormAction.get('gstTypeID').setErrors({ 'invalid': false });
			}
		}


		this.processFormAction.markAllAsTouched();

		if (this.processForm.controls.processFormAction.valid) {

			let c = this.processForm.controls.processFormAction.value;

			this.processService.addAccountingProcess(c)
				.subscribe(result => { this.getAccountingProcessDetails() });

			this.processHeading = 'Add New - Accounting Process';

			this.removeSaveFormControls();
			this.onBtnClearAccountingProcess();
			this.createBtn = true;
		}

	}
	alreadyProcessNameExist: any;
	alreadyProcessNameEditExist: any;

	alreadycodeExist: any;
	alreadycodeEditExist: any;
	onBtnSaveAccountingProcess() {

		this.textSaveBtn = 'Save';
		if (this.createBtn) {
			this.processFormAction.get('processID').patchValue(0);
			this.processFormAction.addControl('createdBy', new FormControl(1));
			this.processFormAction.addControl('createdOn', new FormControl(new Date()));
			this.processFormAction.addControl('isActive', new FormControl(1));
			let pn = this.processFormAction.get('description').value;
			let co = this.processFormAction.get('code').value;

			this.alreadycodeExist = 0;
			this.alreadyProcessNameExist = 0;
			this.processGridObj.forEach((fe) => {
				if (fe.processName.toUpperCase().trim() == pn.toUpperCase().trim()) {
					this.alreadyProcessNameExist = 1;
				}

				if (fe.code.toUpperCase().trim() == co.toUpperCase().trim()) {
					this.alreadycodeExist = 1;
				}


			});

			if (this.alreadyProcessNameExist == 0 && this.alreadycodeExist == 0) {
				this.saveMethod();
			} else {

				if (this.alreadyProcessNameExist == 1) {
					window.alert('Process Name already exists');

					return false;
				}

				if (this.alreadycodeExist == 1) {
					window.alert('Code already exists');
					return false;
				}

				
			}

		} else {

			this.processFormAction.addControl('createdBy', new FormControl(1));
			this.processFormAction.addControl('createdOn', new FormControl(new Date()));
			this.processFormAction.addControl('isActive', new FormControl(1));

			let id = this.processFormAction.get('processID').value;
			let pn = this.processFormAction.get('description').value;
			let co = this.processFormAction.get('code').value;
			this.alreadycodeEditExist = 0;
			this.alreadyProcessNameEditExist = 0;
			this.processGridObj.forEach((fe) => {
				if (fe.processID != id) {
					if (fe.processName.toUpperCase().trim() == pn.toUpperCase().trim()) {
						this.alreadyProcessNameEditExist = 1;
					}

					if (fe.code.toUpperCase().trim() == co.toUpperCase().trim()) {
						this.alreadycodeEditExist = 1;
					}

				}

			});

			if (this.alreadyProcessNameEditExist == 0 && this.alreadycodeEditExist == 0) {
				this.saveMethod();
			} else {
				if (this.alreadyProcessNameEditExist == 1) {
					window.alert('Process Name already exists');

					return false;
				}

				if (this.alreadycodeEditExist == 1) {
					window.alert('Code already exists');
					return false;
				}
			}

		}





	}


	onBtnClearAccountingProcess() {
		this.textSaveBtn = 'Save';
		this.processHeading = 'Add New - Accounting Process';
		this.fieldDisable = false;
		this.processFormAction.reset({
			processID: '',
			code: '',
			description: '',
			isGSTApplicable: this.isGSTApplicableV = 0,
			isTaxApplicable: this.isTaxApplicableV = 0,
			gstTypeID: 0,
		});

		this.divIsGSTApplicable = false;
		this.divGstTypeID = false;



		this.saveBtnMode = true;
	}

	cfn(val) {
		console.log(val);
	}

	omit_special_char(event) {
		var k;
		k = event.charCode;  //         k = event.keyCode;  (Both can be used)
		return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
	}

}
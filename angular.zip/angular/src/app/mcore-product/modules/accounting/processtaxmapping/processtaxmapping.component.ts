import { Component, OnInit, ViewChild } from '@angular/core';
import { TooltipPosition } from '@angular/material';
import { AccountingTaxMapping, AccountingTaxProcess, ModeObjDropDown, BasedOnObjDropDown, TaxStructure } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingtaxmapping';

import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { AccountingprocesstaxmappingService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingprocesstaxmapping.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-processtaxmapping',
  templateUrl: './processtaxmapping.component.html',
  styleUrls: ['./processtaxmapping.component.css']
})
export class ProcesstaxmappingComponent implements OnInit {

  dummyObj: string[];

  accountTaxProcessObj: AccountingTaxProcess[];
  AccountingTaxMappingForm: FormGroup;


  AccountingTaxStructureColumns: string[] = ['Edit', 'taxStructureName', 'description'];
  AccountingTaxMappingColumns: string[] = ['Edit', 'taxStructureDetailsName', 'parentTax', 'modeName', 'taxValue'];

  get AccountingTaxMappingAction() {
    return this.AccountingTaxMappingForm.get('AccountingTaxMappingAction') as FormGroup;
  }

  accountTaxMappingGridObj: AccountingTaxMapping[] = [];
  accountTaxMappingUpdateGridObj: AccountingTaxMapping[] = [];
  accountTaxMappingFilterGridObj: AccountingTaxMapping[] = [];
  taxStructureGridObj: TaxStructure[] = [];
  taxStructureFilterGridObj: TaxStructure[] = [];
  dataTaxMap = new MatTableDataSource<AccountingTaxMapping>(this.accountTaxMappingGridObj);

  dataTaxStructure = new MatTableDataSource<TaxStructure>(this.taxStructureGridObj);

  constructor(private fb: FormBuilder, private accountingProcessTaxmappingService: AccountingprocesstaxmappingService) { }


  basedOnObjDropDown: BasedOnObjDropDown[] = [];
  basedOnObjFilterDropDown: BasedOnObjDropDown[] = [];
  modeObjDropDown: ModeObjDropDown[] = [];

  fieldDisable: Boolean;

  createBtn: boolean;
 
  ngOnInit() {
    this.createBtn = true;

    this.dataTaxStructure = new MatTableDataSource<TaxStructure>(this.taxStructureGridObj);
    this.dataTaxMap = new MatTableDataSource<AccountingTaxMapping>(this.accountTaxMappingGridObj);

    this.AccountingTaxMappingForm = this.fb.group({
      AccountingTaxMappingSearch: this.fb.group({
        searchTaxStructure: [''],
      }),
      AccountingTaxMappingAction: this.fb.group({
        taxMappingID: [''],
        taxProcessID: ['', [Validators.required]],
        taxStructureDetailsName: ['', [Validators.required]],
        parentTax: [''],
        modes: ['', [Validators.required]],
        taxValue: ['', [Validators.required]],
      })
    });
    this.getAllTaxProcess();
    this.getAllTaxStructure();
    this.getAllAccountingTaxMapBasedOn();
    this.getAllAccountProcessTaxMapMode();
  }
  // Creates new user.
  createNewTaxMapping(id: number): AccountingTaxMapping {
    return {



      taxMappingID: 0,
      taxStructureID: 1,
      taxStructureDetailID: 1,
      taxProcessID: this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.taxProcessID').value,
      createdBy: 1,
      taxStructureDetailsName: this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.taxStructureDetailsName').value,
      taxStructureName: "",
      description: "",
      fromDate: new Date(),
      toDate: new Date(),
      exemptedInID: 1,
      parentsTaxStructure: 1,
      modes: 1,
      parentTax: this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.parentTax').value,
      modeName: "",
      hierarchyID: 1,
      taxValue: 1,
      isReferred: 1




    };
  }
  btngvEdit_Click(a) {


    this.taxStructureFilterGridObj = this.taxStructureGridObj.filter((unit) => unit.taxStructureID == a);
    let tid = this.taxStructureFilterGridObj[0].taxStructureID;
    this.accountingProcessTaxmappingService.getTaxProcessDetailsByID(tid).subscribe(o => {
      this.dataTaxMap.data = this.accountTaxMappingGridObj = o;

    });
  }


  btngvEditTaxMap_Click(a) {
    this.createBtn = false;
    this.accountTaxMappingFilterGridObj = this.accountTaxMappingGridObj.filter((unit) => unit.taxStructureDetailID == a);
   let basedOnText =  this.accountTaxMappingFilterGridObj[0].parentTax;
    this.basedOnObjFilterDropDown =  this.basedOnObjDropDown.filter( (unit) => unit.basedOn == basedOnText.toString() );
   //console.log(basedOnID);
    this.fieldDisable = true;
console.log(this.accountTaxMappingFilterGridObj[0]);
    this.AccountingTaxMappingForm = this.fb.group({
      AccountingTaxMappingSearch: this.fb.group({
        searchTaxStructure: [''],
      }),
      AccountingTaxMappingAction: this.fb.group({
        taxMappingID: this.accountTaxMappingFilterGridObj[0].taxMappingID,
        taxProcessID: this.accountTaxMappingFilterGridObj[0].taxProcessID,
        taxStructureDetailsName: this.accountTaxMappingFilterGridObj[0].taxStructureDetailsName,
        parentTax: this.basedOnObjFilterDropDown[0].basedOnID,
        modes: this.accountTaxMappingFilterGridObj[0].modes,
        taxValue: this.accountTaxMappingFilterGridObj[0].taxValue,
      })
    });

  }

  onBtnSaveProcessTaxMap() {
    this.AccountingTaxMappingForm.get('AccountingTaxMappingAction').markAllAsTouched();


    if (this.AccountingTaxMappingForm.get('AccountingTaxMappingAction').valid) {

   

      let id = this.AccountingTaxMappingAction.get('taxMappingID').value;


     this.accountTaxMappingFilterGridObj = this.accountTaxMappingGridObj.filter((unit) => unit.taxMappingID == id);
     this.basedOnObjFilterDropDown =  this.basedOnObjDropDown.filter( (unit) => unit.basedOnID == this.AccountingTaxMappingAction.get('parentTax').value );
      this.accountTaxMappingGridObj.forEach((fe) => {
        if (fe.taxMappingID == id) {
          //fe.taxValue = this.AccountingTaxMappingAction.get('taxValue').value;
         // fe.taxStructureDetailsName = this.AccountingTaxMappingAction.get('taxStructureDetailsName').value;
         // fe.parentTax = this.basedOnObjFilterDropDown[0].basedOnID;
       //  fe.parentTax = this.AccountingTaxMappingAction.get('parentTax').value;
        //  fe.modes = this.AccountingTaxMappingAction.get('modes').value;
        //  fe.taxValue = this.AccountingTaxMappingAction.get('taxValue').value;
          fe.taxProcessID = this.AccountingTaxMappingAction.get('taxProcessID').value;
        }

      });
      this.dataTaxMap.data = this.accountTaxMappingGridObj;


    }



    this.onBtnClearTaxMap();


  }

  onBtnSaveTaxStructure() {

    this.dataTaxMap.data.forEach((fe) => {

      fe.createdBy = 5

    });
    let a = this.dataTaxMap.data;
    console.log(a);
    this.accountingProcessTaxmappingService.createProcessTaxMap(a).subscribe(a => {
      this.dataTaxMap.data = this.accountTaxMappingGridObj;

    });


    this.onBtnClearTaxMap();


  }

  getAllTaxProcess() {
    this.accountingProcessTaxmappingService.getAllTaxProcess().subscribe(a => {
      this.accountTaxProcessObj = a;
    });

  }
  getAllAccountingTaxMapBasedOn() {
    this.accountingProcessTaxmappingService.getAllAccountingTaxMapBasedOn().subscribe(a => {
      this.basedOnObjDropDown = a;
    });

  }

  getAllAccountProcessTaxMapMode() {
    this.accountingProcessTaxmappingService.getAllAccountProcessTaxMapMode().subscribe(a => {
      this.modeObjDropDown = a;
    });

  }
  getAllTaxStructure() {
    this.AccountingTaxMappingAction.addControl("taxStructureName", new FormControl(''))
    //this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.taxStructureName').patchValue('');
    let a = this.AccountingTaxMappingForm.get('AccountingTaxMappingAction').value;

    this.accountingProcessTaxmappingService.getAllTaxStructure(a).subscribe(b => {
      //   this.dataTaxStructure = new MatTableDataSource<TaxStructure>(this.taxStructureGridObj);
      this.dataTaxStructure.data = this.taxStructureGridObj = b;
    });

  }


  onBtnClearTaxMap() {
    // this.AccountingTaxMappingForm = this.fb.group({
    //   AccountingTaxMappingSearch: this.fb.group({
    //     searchTaxStructure: [''],
    //   }),
    //   AccountingTaxMappingAction: this.fb.group({
    //     taxMappingID: '',
    //     taxProcessID: '',
    //     taxStructureDetailsName: '',
    //     parentTax: '',
    //     modes: '',
    //     taxValue: '',
    //   })
    // });

    this.AccountingTaxMappingAction.reset({
      taxMappingID: '',
      taxProcessID: '',
      taxStructureDetailsName: '',
      parentTax: '',
      modes: '',
      taxValue: ''
    });

    this.createBtn = true;
    this.fieldDisable = false;
  }

  onBtnClearTaxStructure() {
    this.dataTaxMap.data = [];
    this.onBtnClearTaxMap();
    this.createBtn = true;
  }

  cfn(a) {
    console.log(a);
  }
}

import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { TooltipPosition } from '@angular/material/tooltip';
import { MatPaginator } from '@angular/material/paginator';
import { AddressStructure } from 'src/app/mcore-product/mcore-shared/mcore-entity/addressstructure';
import { AddressstructureService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/addressstructure.service';

@Component({
  selector: 'app-addressstructure',
  templateUrl: './addressstructure.component.html',
  styleUrls: ['./addressstructure.component.css']
})
export class AddressstructureComponent implements OnInit {
  createAddressStructure: boolean;
  fieldDisable: Boolean;
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  addressStructureColumns: string[] = ['View', 'Edit', 'description'];
  addressStructureObj: AddressStructure[];
  addressStructureFilteredObj: AddressStructure[];
  AddressStructureFrom: FormGroup;
  addressStructureHeading: string = '';
  btnSavetext: string = '';
  btnModeSave: boolean = true;
  addressdataSource = new MatTableDataSource<AddressStructure>(this.addressStructureObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.addressdataSource.paginator = this.paginator;
    this.elr.nativeElement.focus();
  }
  AlreadyAddressExist: number;
  AlreadyEditAddressExist: number;
  constructor(
    private fb: FormBuilder,
    private addressStructureService: AddressstructureService,
    private elr: ElementRef
  ) { }
  ngOnInit() {
    this.addressStructureHeading = 'Add New - Address Structure';
    this.btnSavetext = 'Save';
    this.getAddressStructureDetails();
    this.ValidateAddressStructure();
    this.ngAfterViewInit();
    this.onChanges();
    // Focus on the first Form Element
    //this.elf.nativeElement.AddressStructureFrom('description').focus();
  }
  RestrictSplChar(event) {
    let k;
    k = event.charCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
  }
  // Drag & Drop Method
  disableEvent(e) {
    e.preventDefault();
    return false;
  }
  onBtnSaveAddressStructureClick() {
    //this.SaveAddressStructureDetails();
    if (this.createAddressStructure) {
      this.AddressStructureFrom.controls.structureId.patchValue('');
      this.AlreadyAddressExist = 0;
      let desc = this.AddressStructureFrom.controls.description.value;
      this.addressStructureObj.forEach((fe) => {
        if (fe.description == desc) {
          this.AlreadyAddressExist = 1;
        }
      });
      if (this.AlreadyAddressExist == 0) {
        this.SaveAddressStructureDetails();
      }
      else {
        console.log('else test');
        console.log(this.AlreadyAddressExist);
        if (this.AlreadyAddressExist == 1) {
          window.alert('Description already exists');
          this.ClearAddressStructureDetails();
          return false;
        }
      }
    }
    else {
      let id = this.AddressStructureFrom.controls.structureId.value;
      let descEdit = this.AddressStructureFrom.controls.description.value;
      this.AlreadyEditAddressExist = 0;
      this.addressStructureObj.forEach((fe) => {
        if (fe.structureId != id) {
          if (fe.description == descEdit) {
            this.AlreadyEditAddressExist = 1;
          }
        }
      });
      if (this.AlreadyEditAddressExist == 0) {
        this.SaveAddressStructureDetails();
      }
      else {
        window.alert('Description already exists');
        this.ClearAddressStructureDetails();
      }
    }
  }
  onBtnClearAddressStructureClick() {
    this.ClearAddressStructureDetails();
  }
  btngvView_Click(a) {
    this.fieldDisable = true;
    this.addressStructureFilteredObj = this.addressStructureObj.filter((unit) => unit.structureId == a);
    this.AddressStructureFrom = this.fb.group({
      structureId: this.addressStructureFilteredObj[0].structureId,
      description: this.addressStructureFilteredObj[0].description,
      createdBy: this.addressStructureFilteredObj[0].createdBy,
      createdOn: this.addressStructureFilteredObj[0].createdOn,
      isActive: this.addressStructureFilteredObj[0].isActive,
    })
    this.addressStructureHeading = 'View - Address Structure';
    this.btnModeSave = false;
    this.btnSavetext = '';
  }
  btngvEdit_Click(a) {
    this.fieldDisable = false;
    this.addressStructureFilteredObj = this.addressStructureObj.filter((unit) => unit.structureId == a);
    this.AddressStructureFrom = this.fb.group({
      structureId: this.addressStructureFilteredObj[0].structureId,
      description: this.addressStructureFilteredObj[0].description,
      createdBy: this.addressStructureFilteredObj[0].createdBy,
      createdOn: this.addressStructureFilteredObj[0].createdOn,
      isActive: this.addressStructureFilteredObj[0].isActive,
    })
    this.addressStructureHeading = 'Edit - Address Structure';
    this.btnSavetext = 'Update';
    this.btnModeSave = true;
  }
  btngvDelete_Click() {
    this.addressStructureService.deleteAddressStructureDetails().subscribe(result => { console.log(result); this.getAddressStructureDetails() });
  }
  onChanges() {
    this.AddressStructureFrom.valueChanges.subscribe(val => {
    });
  }
  ValidateAddressStructure() {
    this.AddressStructureFrom = this.fb.group({
      structureId: [''],
      description: ['', [Validators.required],],
      createdBy: [1],
      createdOn: [new Date()],
      modifiedBy: [1],
      modifiedOn: [new Date()],
      deletedBy: [1],
      deletedOn: [new Date()],
      isActive: [1]
    })
  }
  SaveAddressStructureDetails() {
    // this.AddressStructureFrom.patchValue({
    //   createdBy: '1',
    //   createdOn: new Date(),
    //   isActive: '1'
    // });
    // this.AddressStructureFrom.markAllAsTouched();
    // if (this.AddressStructureFrom.valid) {
    //   let val = this.AddressStructureFrom.value;
    //   this.addressStructureService.addAddressStructureDetails(val).subscribe(result => { console.log(result); this.getAddressStructureDetails() });
    //   this.ClearAddressStructureDetails();
    // }
    // this.AddressStructureFrom.patchValue({
    //   createdBy: '1',
    //   createdOn: new Date(),
    //   isActive: '1'
    // });
    // this.AddressStructureFrom.markAllAsTouched();
    // if (this.AddressStructureFrom.valid) {
    //   let val = this.AddressStructureFrom.value;
    //   this.addressStructureService.addAddressStructureDetails(val)
    //     .subscribe(result => { this.getAddressStructureDetails() });
    //   //this.ClearAddressStructureDetails();
    //   this.AddressStructureFrom.reset();
    //   this.addressStructureHeading = 'Add New - Address Structure';
    //   this.btnSavetext = 'Save';
    //   this.createAddressStructure = true;
    // }

    this.AddressStructureFrom.markAllAsTouched();
    if (this.AddressStructureFrom.valid) {
      console.log('valid');
      if (this.createAddressStructure) {
        this.AddressStructureFrom.patchValue({
          createdBy: '1',
          createdOn: new Date(),
          isActive: '1'
        });
      }
      else {
        this.AddressStructureFrom.patchValue({
          createdBy: '1',
          createdOn: new Date(),
        });
      }
      let val = this.AddressStructureFrom.value;
      console.log(val);
      this.addressStructureService.addAddressStructureDetails(val).subscribe(result => { this.getAddressStructureDetails() });
      this.ClearAddressStructureDetails();
    }
  }
  getAddressStructureDetails(): void {
    this.addressStructureService.getAddressStructureDetails().subscribe(
      addressStructureObj => {
        this.addressdataSource = new MatTableDataSource<AddressStructure>(this.addressStructureObj);
        this.addressdataSource.data = this.addressStructureObj = addressStructureObj;
        this.addressdataSource.paginator = this.paginator;
      });
  }
  ClearAddressStructureDetails() {
    this.addressStructureHeading = 'Add New - Address Structure';
    this.btnSavetext = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.AddressStructureFrom.reset();
    this.AddressStructureFrom = this.fb.group({
      structureId: { value: '', disabled: false },
      description: { value: '', disabled: false },
      createdBy: { value: '', disabled: false },
      createdOn: { value: '', disabled: false },
      isActive: { value: '', disabled: false },
    })
  }  
}

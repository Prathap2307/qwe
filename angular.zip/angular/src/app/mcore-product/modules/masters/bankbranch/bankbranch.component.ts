import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BankBranch, BankName, BankCity } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';
import { BankbranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/bankbranch.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { typeWithParameters } from '@angular/compiler/src/render3/util';

@Component({
  selector: 'app-bankbranch',
  templateUrl: './bankbranch.component.html',
  styleUrls: ['./bankbranch.component.css']
})
export class BankbranchComponent implements OnInit {
  createBankBranch: boolean;
  fieldDisable: Boolean;
  bankname: any;
  bankcity: any;
  BankBranchForm: FormGroup;
  BankBranchFormAction: FormGroup;
  bankBranchObj: BankBranch[];
  bankNameObj: BankName[];
  bankNameFilteredObj: BankName[] = [];
  BankCityObj: BankCity[];
  bankBranchFilteredObj: BankBranch[] = [];
  bankBranchHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  bankBranchColumns: string[] = ['View', 'Edit', 'Delete', 'bankName', 'bankCityName', 'description', 'ifscCode', 'micrCode'];
  bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.bankBranchdataSource.paginator = this.paginator;
  }
  AlreadyIFSCCodeExist: number;
  AlreadyMICRCodeExist: number;
  AlreadyEditIFSCCodeExist: number;
  AlreadyEditMICRCodeExist: number;
  constructor(
    private fb: FormBuilder,
    private bankBranchService: BankbranchService
  ) { }
  ngOnInit() {
    // setTimeout(() => this.bankBranchdataSource.paginator = this.paginator);
    // this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
    this.createBankBranch = true;
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.getBankBranchNameDetails();
    this.getBankBranchDetails();
    this.ValidateBankBranchForm();
  }
  // Drag & Drop Method
  disableEvent(e) {
    e.preventDefault();
    return false;
  }
  RestrictSplChar(event) {
    let k;
    k = event.charCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
  }
  allowNumberFn(event) {
    const keyCode = event.keyCode;
    //console.log(keyCode);
    const excludedKeys = [8, 37, 39, 46];
    if (!((keyCode >= 48 && keyCode <= 57) ||
      (keyCode >= 96 && keyCode <= 105) ||
      (excludedKeys.includes(keyCode)))) {
      event.preventDefault();
    }
  }

  ValidateBankBranchForm() {
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [
          ''
        ],
        searchbankCityId: [
          ''
        ],
        searchifscCode: [
          ''
        ],
        searchmicrCode: [
          ''
        ]
      }),
      BankBranchFormAction: this.fb.group({
        branchId: [''],
        bankId: ['', [Validators.required]],
        bankCityId: ['', [Validators.required]],
        bankName:
          [
            ''
          ],
        bankCityName:
          [
            ''
          ],
        description:
          [
            '', [Validators.required]
          ],
        ifscCode:
          [
            '', [Validators.required, Validators.pattern("^[A-Za-z]{4}[a-zA-Z0-9]{7}$"), Validators.maxLength(11), Validators.minLength(11)],
          ],
        micrCode:
          [
            '', [Validators.required]
          ],
        createdBy: [1],
        createdOn: [new Date()],
        isActive: 1,
      })
    });
  }
  onBtnSearchBankBranchDetails() {
    this.BankBranchForm.controls.BankBranchFormSearch.markAllAsTouched();
    if (this.BankBranchForm.get('BankBranchFormSearch').valid) {
      let search: any;
      search = {
        branchId: 0,
        bankId: this.BankBranchForm.get('BankBranchFormSearch.searchbankId').value,
        bankCityId: null,
        description: null,
        ifscCode: this.BankBranchForm.get('BankBranchFormSearch.searchifscCode').value,
        micrCode: null,
      }
      console.log(search);
      //if (this.BankBranchForm.controls.BankBranchFormSearch.valid) {
        this.bankBranchService.getSearchBankBranchdetails(search).subscribe(
          bankBranchObj => {
            this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
            this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
            this.bankBranchdataSource.paginator = this.paginator;
          });
     // }
    }
  }
  getSearchBankBranchDetails() {
  }
  onBtnSearchClearBankBranch() {
    this.BankBranchForm.reset();
    this.getBankBranchDetails();
  }
  onBtnSaveBankBranchClick() {
    //this.GetSaveBankBranchDetails();
    if (this.createBankBranch) {
   
      this.BankBranchForm.get('BankBranchFormAction.branchId').patchValue('');
      this.AlreadyIFSCCodeExist = 0;
      this.AlreadyMICRCodeExist = 0;
      let IFSCcode = this.BankBranchForm.get('BankBranchFormAction.ifscCode').value;
      let MICRcode = this.BankBranchForm.get('BankBranchFormAction.micrCode').value;
      this.bankBranchObj.forEach((fe) => {
        if (fe.ifscCode == IFSCcode) {
          this.AlreadyIFSCCodeExist = 1;
        }
        if (fe.micrCode == MICRcode) {
          this.AlreadyMICRCodeExist = 1;
        }
      });
      if (this.AlreadyIFSCCodeExist == 0 && this.AlreadyMICRCodeExist == 0) {
      
        this.GetSaveBankBranchDetails();
      }
      else {
       
        if (this.AlreadyIFSCCodeExist == 1) {
          window.alert('IFSCCode already exists');
          this.GetClearBankBranchDetails();
          return false;
        }
        if (this.AlreadyMICRCodeExist == 1) {
          window.alert('MICRCode already exists');
          this.GetClearBankBranchDetails();
          return false;
        }
      }
    }
    else {
      let id = this.BankBranchForm.get('BankBranchFormAction.branchId').value;
      let IFSCcodeEdit = this.BankBranchForm.get('BankBranchFormAction.ifscCode').value;
      let MICRcodeEdit = this.BankBranchForm.get('BankBranchFormAction.micrCode').value;
      this.AlreadyEditIFSCCodeExist = 0;
      this.AlreadyEditMICRCodeExist = 0;
      this.bankBranchObj.forEach((fe) => {
        if (fe.branchId != id) {
          if (fe.ifscCode == IFSCcodeEdit) {
            this.AlreadyEditIFSCCodeExist = 1;
          }
          if (fe.micrCode == MICRcodeEdit) {
            this.AlreadyEditMICRCodeExist = 1;
          }
        }
      });
      if (this.AlreadyEditIFSCCodeExist == 0 && this.AlreadyEditMICRCodeExist == 0) {
        this.GetSaveBankBranchDetails();
      }
      else {
        console.log('else test');
        console.log(this.AlreadyEditIFSCCodeExist);
        console.log(this.AlreadyEditMICRCodeExist);
        if (this.AlreadyEditIFSCCodeExist == 1) {
          window.alert('IFSCCode already exists');
          this.GetClearBankBranchDetails();
          return false;
        }
        if (this.AlreadyEditMICRCodeExist == 1) {
          window.alert('MICRCode already exists');
          this.GetClearBankBranchDetails();
          return false;
        }
      }
    }
  }
  GetSaveBankBranchDetails() {
 

    this.BankBranchForm.get('BankBranchFormAction').markAllAsTouched();

    console.log("bankId" , this.BankBranchForm.get('BankBranchFormAction.bankId').valid);
    console.log("bankCityId" , this.BankBranchForm.get('BankBranchFormAction.bankCityId').valid);
    console.log("description" , this.BankBranchForm.get('BankBranchFormAction.description').valid);
    console.log("ifscCode" , this.BankBranchForm.get('BankBranchFormAction.ifscCode').valid);
    console.log("micrCode" , this.BankBranchForm.get('BankBranchFormAction.micrCode').valid);
   


    
    if (this.BankBranchForm.get('BankBranchFormAction').valid) {
      console.log('valid for insert');
      if (this.createBankBranch) {
        this.BankBranchForm.get('BankBranchFormAction').patchValue({
          branchId: '0',
          createdBy: '1',
          createdOn: new Date(),
          isactive: '1',
        });
      }
      else {
        this.BankBranchForm.get('BankBranchFormAction').patchValue({
          createdBy: '1',
          createdOn: new Date(),
          isactive: '1',
        });
      }
      let a = this.BankBranchForm.controls.BankBranchFormAction.value;
      console.log(a);
      this.bankBranchService.insertbankBranch(a).subscribe(result => { this.getBankBranchDetails() });
      this.GetClearBankBranchDetails();
    }
  }
  onBtnClearBankBranchClick() {
    this.GetClearBankBranchDetails();
  }
  GetClearBankBranchDetails() {
    this.BankBranchForm.controls.BankBranchFormAction.reset();
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: { value: '', disabled: false },
        bankId: { value: '', disabled: false },
        bankName: { value: '', disabled: false },
        bankCityId: { value: '', disabled: false },
        bankCityName: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
      })
    });
    this.getBankBranchDetails();
  }
  getBankBranchDetails(): void {
    this.bankBranchService.getBankBranchdetails().subscribe(
      bankBranchObj => {
        this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
        this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
        this.bankBranchdataSource.paginator = this.paginator;
      });
  }
  // Grid View Button Events
  btngvView_Click(a) {
    this.bankBranchHeading = 'View - Bank Branch';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.branchId == a);
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: this.bankBranchFilteredObj[0].branchId,
        bankId: this.bankBranchFilteredObj[0].bankId,
        bankName: this.bankBranchFilteredObj[0].BankName,
        bankCityId: this.bankBranchFilteredObj[0].bankCityId,
        bankCityName: this.bankBranchFilteredObj[0].BankCityName,
        description: this.bankBranchFilteredObj[0].description,
        ifscCode: this.bankBranchFilteredObj[0].ifscCode,
        micrCode: this.bankBranchFilteredObj[0].micrCode,
        createdBy: this.bankBranchFilteredObj[0].createdBy,
        createdOn: this.bankBranchFilteredObj[0].createdOn,
      })
    });
    this.change_BranchCity_fn();
  }
  // Grid Edit Button Events
  btngvEdit_Click(a) {
    this.createBankBranch = false;
    this.bankBranchHeading = 'Edit - Bank Branch';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.branchId == a);
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: this.bankBranchFilteredObj[0].branchId,
        bankId: this.bankBranchFilteredObj[0].bankId,
        bankName: this.bankBranchFilteredObj[0].BankName,
        bankCityId: this.bankBranchFilteredObj[0].bankCityId,
        bankCityName: this.bankBranchFilteredObj[0].BankCityName,
        description: this.bankBranchFilteredObj[0].description,
        ifscCode: this.bankBranchFilteredObj[0].ifscCode,
        micrCode: this.bankBranchFilteredObj[0].micrCode,
        createdBy: this.bankBranchFilteredObj[0].createdBy,
        createdOn: this.bankBranchFilteredObj[0].createdOn,
      })
    });
    this.change_BranchCity_fn();
  }
  // Grid Delete Button Events
  btngvDelete_Click(a) {
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: { value: a, disabled: false },
        bankId: { value: '', disabled: false },
        bankName: { value: '', disabled: false },
        bankCityId: { value: '', disabled: false },
        bankCityName: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: 1,
        createdOn: new Date(),
        deletedBy: 1,
        deletedOn: new Date(),
        isActive: 0,
      })
    });
    let v = this.BankBranchForm.get('BankBranchFormAction').value;
    console.log(v);
    this.bankBranchService.deleteBankBranch(v).subscribe(result => { this.getBankBranchDetails(); });
  }
  getBankBranchNameDetails() {
    this.bankBranchService.getBankBranchNameDetails().subscribe(bankNameVal => { this.bankNameObj = bankNameVal });
  }
  Searchchange_BranchCity_fn() {
    let bankId = this.BankBranchForm.get('BankBranchFormSearch.searchbankId').value;
    this.getBankBranchCitydetails(bankId);
  }
  change_BranchCity_fn() {
    let bankId = this.BankBranchForm.get('BankBranchFormAction.bankId').value;
    this.getBankBranchCitydetails(bankId);
  }
  getBankBranchCitydetails(bankId) {
    this.bankBranchService.getBankBranchCityDetails(bankId).subscribe(bankCityNameVal => { this.BankCityObj = bankCityNameVal });
  }
}

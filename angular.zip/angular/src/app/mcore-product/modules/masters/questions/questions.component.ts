import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Question } from 'src/app/mcore-product/mcore-shared/mcore-entity/question';
import { QuestionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/question.service';
import { MatTableDataSource } from '@angular/material/table';
import { TooltipPosition } from '@angular/material/tooltip';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
  // Question Variables  
  createQuestion: Boolean;
  fieldDisable: Boolean;
  questiondataSourceEmpty: [];
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  questionObj: Question[];
  questionSearchObj: Question[];
  questionFilteredObj: Question[] = [];
  questionColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortDescription'];
  questionForm: FormGroup;
  questionFormAction: FormGroup;
  questionHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  questiondataSource = new MatTableDataSource<Question>(this.questionObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  public ngAfterViewInit() {
    this.questiondataSource.paginator = this.paginator;
  }
  AlreadyQuestionExist: number;
  AlreadyShortNameExist: number;
  AlreadyDescEditQuestionExist: number;
  AlreadyEditQuestionExist: number;
  AlreadyEditShortNameQuestionExist: number;
  constructor(
    private fb: FormBuilder,
    private questionService: QuestionService,
  ) { }

  disableEvent(e) {
    e.preventDefault();
    return false;
  }

  ngOnInit() {
    this.createQuestion = true;
    setTimeout(() => this.questiondataSource.paginator = this.paginator);
    this.questiondataSource = new MatTableDataSource<Question>(this.questionObj);
    this.questionHeading = 'Add New - Question';
    this.btnSaveText = 'Save';
    this.getQuestionDetails();
    this.ValidateQuestionForm();
    this.ngAfterViewInit();
  }
  ValidateQuestionForm() {
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: [''],
        lobId: [''],
        description:
          [
            '',
            [Validators.required]
          ],
        shortDescription:
          [
            '',
            [Validators.required]
          ],
        orderId: [''],
        weightage: [''],
        createdBy: 1,
        createdOn: new Date(),
        isActive: 1,
      })
    });
  }
  //Search 
  onBtnSearchQuestionClick() {
    this.getQuestionBySearch();
  }
  onBtnSearchClearQuestionClick() {
    //this.questionForm.reset();
    this.getQuestionDetails();
    this.ClearquestionDetails();
  }
  // Save
  onBtnSaveQuestionClick() {
    //this.SaveQuestionDetails();
    if (this.createQuestion) {
      this.questionForm.get('questionFormAction.questionId').patchValue('');
      this.AlreadyQuestionExist = 0;
      this.AlreadyShortNameExist = 0;
      let Desc = this.questionForm.get('questionFormAction.description').value;
      let Shortdesc = this.questionForm.get('questionFormAction.shortDescription').value;
      this.questionObj.forEach((fe) => {
        if (fe.description.toUpperCase().trim() == Desc.toUpperCase().trim()) {
          this.AlreadyQuestionExist = 1;
        }
        if (fe.shortDescription.toUpperCase().trim() == Shortdesc.toUpperCase().trim()) {
          this.AlreadyShortNameExist = 1;
        }
      });
      if ( this.AlreadyQuestionExist == 0 && this.AlreadyShortNameExist == 0) {
        this.SaveQuestionDetails();
      }
      else {
      
        if (this.AlreadyQuestionExist == 1) {
          window.alert('Description already exists');
        
      
          return false;
        }
        if (this.AlreadyShortNameExist == 1) {
          window.alert('Short Description already exists');
       
          return false;
        }
       
      }
    }
    else {
      let id = this.questionForm.get('questionFormAction.questionId').value;
      let Desc1 = this.questionForm.get('questionFormAction.description').value;
      let ShortdescEdit = this.questionForm.get('questionFormAction.shortDescription').value;
     
      this.AlreadyEditQuestionExist = 0;
      this.AlreadyEditShortNameQuestionExist = 0;
      this.questionObj.forEach((fe) => {
      
        if (fe.questionId != id) {

        
          if (fe.description.toUpperCase().trim() == Desc1.toUpperCase().trim()) {
            this.AlreadyEditQuestionExist = 1;
          }
          if (fe.shortDescription.toUpperCase().trim() == ShortdescEdit.toUpperCase().trim()) {
          //  console.log("shortDescription check in side" );
            this.AlreadyEditShortNameQuestionExist = 1;
          }
        }
      });
      if (this.AlreadyEditQuestionExist == 0 && this.AlreadyEditShortNameQuestionExist == 0) {
        this.SaveQuestionDetails();
      }
      else {
        console.log('else test new');
      
        if (this.AlreadyEditQuestionExist == 1) {
          window.alert('Description already exists');
       
          return false;
        }
        if (this.AlreadyEditShortNameQuestionExist == 1) {
          window.alert('Short Description already exists 1');
       
          return false;
        }
      }
    }
  }
  onBtnClearQuestionClick() {
    this.ClearquestionDetails();
  }
  ClearquestionDetails() {
    this.questionForm.controls.questionFormAction.reset();
    this.questionHeading = 'Add New - Question';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        shortDescription: { value: '', disabled: false },
        orderId: '',
        weightage: '',
        createdBy: 1,
        createdOn: new Date(),
        isActive: 1,
      })
    });
  }
  SaveQuestionDetails() {
    // this.questionForm.get('questionFormAction').patchValue({
    //   createdBy: '1',
    //   createdOn: new Date(),
    //   isActive: '1',
    // });
    // this.questionForm.controls.questionFormAction.markAllAsTouched();
    // if (this.questionForm.controls.questionFormAction.valid) {
    //   let a = this.questionForm.controls.questionFormAction.value;
    //   this.questionService.addQuestion(a).subscribe(result => { this.getQuestionDetails() });
    //   this.ClearquestionDetails();
    // }
    this.questionForm.controls.questionFormAction.markAllAsTouched();
    if (this.questionForm.get('questionFormAction').valid) {
      console.log('valid');
      if (this.createQuestion) {
        this.questionForm.get('questionFormAction').patchValue({
          questionId: '0',
          createdBy: '1',
          createdOn: new Date(),
          isactive: '1',
        });
      }
      else {
        this.questionForm.get('questionFormAction').patchValue({
          createdBy: '1',
          createdOn: new Date(),
        });
      }
      let a = this.questionForm.controls.questionFormAction.value;
      console.log(a);
      this.questionService.addQuestion(a).subscribe(result => { this.getQuestionDetails() });
      this.ClearquestionDetails();
    }
  }
  // Search Section
  getQuestionBySearch(): void {
    // let a = this.questionForm.get('searchDescription').value;
    // let r = this.questionObj.filter((unit) => unit.searchDescription == a);
    // let b = r[0].searchDescription;
    // this.questionService.getQuestionBySearch(a, b)
    // questionObj => {
    //   this.questiondataSource = new MatTableDataSource<Question>(this.questionObj);
    //   this.questiondataSource.data = this.questionObj = questionObj;
    //   this.questiondataSource.paginator = this.paginator;
    // };
    // if (this.questionForm.controls.searchDescription.valid) {
    // let searchValue = this.questionForm.controls.searchDescription.value;
    // this.questionService.getQuestionBySearch(0, searchValue).subscribe(
    //   questionObj => {
    //     this.questiondataSource = new MatTableDataSource<Question>(this.questionObj);
    //     this.questiondataSource.data = this.questionObj = questionObj;
    //     this.questiondataSource.paginator = this.paginator;
    //   });
    // // questionObj => this.questionObj = questionObj);
    // this.getQuestionDetails();
    // }
    // else {
    // }
    if (this.questionForm.controls.searchDescription.valid) {
      let searchValue = this.questionForm.get('searchDescription').value;
      // if (searchValue == '') {
      //   searchValue = '';
      // }
      // let obj = {
      //   "questionId": 1,
      //   "description": searchValue
      // }
      this.questionService.getQuestionBySearch(0, searchValue).subscribe(qustAns => {
        this.questiondataSource = new MatTableDataSource<Question>(this.questionObj);
        this.questiondataSource.data = this.questionObj = qustAns;
        this.questiondataSource.paginator = this.paginator;
        this.questionSearchObj = qustAns;
      });
    }
  }
  getQuestionDetails(): void {
    this.questionService.getQuestionDetails().subscribe(
      questionObj => {
        this.questiondataSource = new MatTableDataSource<Question>(this.questionObj);
        this.questiondataSource.data = this.questionObj = questionObj;
        this.questiondataSource.paginator = this.paginator;
      })
  }
  // Grid View Button Events
  btngvView_Click(a) {
    this.questionHeading = 'View - Question';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.questionFilteredObj = this.questionObj.filter((unit) => unit.questionId == a);
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: this.questionFilteredObj[0].questionId,
        description: this.questionFilteredObj[0].description,
        shortDescription: this.questionFilteredObj[0].shortDescription,
        createdBy: this.questionFilteredObj[0].createdBy,
        createdOn: this.questionFilteredObj[0].createdOn,
        isActive: this.questionFilteredObj[0].isActive,
      })
    });
  }
  // Grid Edit Button Events
  btngvEdit_Click(a) {
    this.createQuestion = false;
    this.questionHeading = 'Edit - Question';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.questionFilteredObj = this.questionObj.filter((unit) => unit.questionId == a);
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: this.questionFilteredObj[0].questionId,
        description: this.questionFilteredObj[0].description,
        shortDescription: this.questionFilteredObj[0].shortDescription,
        createdBy: this.questionFilteredObj[0].createdBy,
        createdOn: this.questionFilteredObj[0].createdOn,
        isActive: this.questionFilteredObj[0].isActive,
      })
    });
  }
  // Grid Delete Button Events
  btngvDelete_Click(a) {
    this.questionForm = this.fb.group({
      searchPlanName: [''],
      questionFormAction: this.fb.group({
        questionId: { value: a, disabled: false },
        description: { value: '', disabled: false },
        shortDescription: { value: '', disabled: false },
        createdBy: 1,
        createdOn: new Date(),
        deletedBy: 1,
        deletedOn: new Date(),
        isActive: 0,
      })
    });
    let v = this.questionForm.get('questionFormAction').value;
    console.log(v);
    this.questionService.deleteQuestion(v).subscribe(result => { this.getQuestionDetails() });
  }
}


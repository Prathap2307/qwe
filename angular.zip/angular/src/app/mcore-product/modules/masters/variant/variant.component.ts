import { Component, OnInit } from '@angular/core';
import { LookupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/lookup.service';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product1.service';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-variant',
  templateUrl: './variant.component.html',
  styleUrls: ['./variant.component.css']
})
export class VariantComponent implements OnInit {



  // New Business Level Proof of Document
  documentArr: any =
  [
  {documentTypeId:1,description:'Bankers Certificate with Photograph'},
  {documentTypeId:2,description:'PAN Card'},
  {documentTypeId:3,description:'Driving License'},
  {documentTypeId:4,description:'Electricity Bill'},
  {documentTypeId:5,description:'Telephone Bill'},
  {documentTypeId:6,description:'Rental Agreement'},
  {documentTypeId:7,description:'Degree Certificate'},
  {documentTypeId:8,description:'National Card'},
  {documentTypeId:9,description:'Passport'},
  {documentTypeId:10,description:'International Driving License'},
  {documentTypeId:11,description:'Contact Certificate'},
  {documentTypeId:12,description:'NOC'},
  {documentTypeId:13,description:'Ration Card'},
  {documentTypeId:14,description:'Aadhar Card'},
  {documentTypeId:15,description:'Employers Certificate with Photograph'},
  {documentTypeId:16,description:'Insurers Employee Certificate with photograph'},
  {documentTypeId:17,description:'Valid Debit Credit card with photograph'},
  {documentTypeId:18,description:'Employees ID Card with photograph'},
  {documentTypeId:19,description:'ESIC Card with Photograph'},
  {documentTypeId:20,description:'Armed Force ID Card with photograph'},
  {documentTypeId:21,description:'Post Office savings Acc Num PPF Acc Num'},
  {documentTypeId:22,description:'Bar Council ID for lawyers with photograph'},
  {documentTypeId:23,description:'PIO Card with Photograph'},
  {documentTypeId:24,description:'Job card issued by NREGA'},
  {documentTypeId:25,description:'Letter issued by UIDAI'},
  {documentTypeId:26,description:'SP Signature'},
  {documentTypeId:27,description:'VOTER ID'},
  {documentTypeId:28,description:'Death Certificate'},
  {documentTypeId:29,description:'Claimant Statement along with Discharge Receipt'},
  {documentTypeId:30,description:'Original Policy Document'},
  {documentTypeId:31,description:'Investigation Report by RRM'},
  {documentTypeId:32,description:'Death Confirmation Report'},
  {documentTypeId:33,description:'Relationship proof of claimant with insured'},
  {documentTypeId:34,description:'Photo ID proof of claimant'},
  {documentTypeId:35,description:'Bank Account Statement of Nominee'},
  {documentTypeId:36,description:'SP Signature'},
  {documentTypeId:37,description:'Accidental Claim FIR Copy and Post Mortem Report'},
  {documentTypeId:38,description:'Others'}


];


// Relationship  & Nominee Relationship
relationshipArr:any=
[
  {relationshipId:1,description:'Brother'},
  {relationshipId:2,description:'Charitable Institution'},
  {relationshipId:3,description:'Child'},
  {relationshipId:4,description:'Estate'},
  {relationshipId:5,description:'Other'},
  {relationshipId:6,description:'Other Family'},
  {relationshipId:7,description:'Parent'},
  {relationshipId:8,description:'Self'},
  {relationshipId:9,description:'Spouse'},
  {relationshipId:10,description:'Without Relationship'}



];


// Rider Factor
ridersFactorArr:any=
[
  {coefficientId:1,description:'Age'},
  {coefficientId:2,description:'Gender'},
  {coefficientId:3,description:'Sum Assured'},
  {coefficientId:4,description:'Policy Term'},
  {coefficientId:5,description:'Policy Type'},
 
 


];

// Product
// productArr:any = [
//   {lineOfBusinessId:1,description:'Group Protection Solution'},
//   {lineOfBusinessId:2,description:'ABSLI Group BIMA Yojna'},
//   {lineOfBusinessId:3,description:'Group BIMA Solution'},

// ];


// documentArr: any = [];
// relationshipArr:any = [];
// ridersFactorArr:any = [];
productArr:any = [];




  userId: any;
  token: any;
  typesOfBrands: string[] = [ 'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea' ,'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea' ,'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea'];

  insurerArr:any = [];
  benefitRidersArr:any = [];
  productTypeArr:any = [];
  questionArr:any = [];
  taxstructureArr:any = [];

  paymentFrequencyArr:any = [];
  ageArr:any = [];
  selectedOptionsArr:any = [];
  newBusinessLevelProofofDocumentObj:any = {};
  businessLvlPrfDocArr:any = [];
  docProofErrMsg: string;
  isReadonly = true;
  isVariantReadonly = true;
  buttonDisable = false;
  editdocProofId: any;
  deletedocProofID: any;
  updateBtn = false;
 
  stampDutyType :any;
  isStampDutyApplicable= 0;
  relationShipArr:any = [];
  relationShip:any = {};
  frequencyArr:any = [];
  nomineeRelationShipArr:any = [];
  coEfficientArr:any = [];
  variantTaxStructureArr:any = [];
  variantQuestionArr:any = [];
  productCoverageList:any = [];
  variantDataObj:any = {};
  minimumAgeTypeID = '1';
  temAgeProofDocumentArr:any = [];
  prductObj:any = {};
  prdctCvrAgeErrMsg: string;
  productCoverageListArr:any = [];
  docObj:any = {};
  productCoverageListObj:any = {};
  isBaseCoverage = 0;
  isSelectable= 0;
  autoIssuePolicyUpToFCLLimit= 0;
  variantArr:any = [];
  variantErrMsg: any;
  variantPage:any;
  deleteproductCoverageListID: any;
  editproductCoverageListId: any;
  variantObj:any = {};
  deleteVariantID: any;
  searchVariantObj:any = {};
  startDateDummy: any;
  viewRemarkInput = false;
  editRemarkInput = false;
  variantHistoryList:any = [];
  error: { isError: boolean; errorMessage: string; };
  ageTo: any;
  ageError: string;
  errorMsg: string;

  constructor(
    private _lookupService: LookupService,
    private _productService: ProductService,
    private datePipe : DatePipe,
    private spinner: NgxSpinnerService,
    private _snackBar: MatSnackBar
  ) {
    for (let i = 1; i <= this.variantArr.length; i++) {
      this.variantArr.push(`deal ${i}.0`);
    }
  }

  ngOnInit() {
    // this.variantForm
    this.userId = JSON.parse(localStorage.getItem('userID'));
    this.token = JSON.parse(localStorage.getItem('token'));
    this.spinner.show();
    this.getProduct();
    this.getInsurer();
    this.getBenefitRiders();
    // this.getProductType();
    this.getQuestion();
    this.getTaxStructure();
    this.getFrequency();
    this.getBusinessLvlPrfDoc();
    this.getProductCoverageList();
    this.getVariant();

    // =====in comment for temporary basis====

   // this.getRidersFactor();
    this.getProduct();
       // this.getDocument();
       // this.getRelationship();



    for (let i = 0; i < 76; i++) {
        let newName = {
          id:i,
          age:i
        };
        this.ageArr.push(newName);
    }
  }

  onNgModelChange($event){
    this.selectedOptionsArr=$event;
  }

  getDocument(){
    this._lookupService.getDocument().subscribe(res =>{
      this.documentArr = res.documentList;
    },err =>{
      console.log(err);
    })
  }

  getInsurer(){
    this._productService.getInsurer().subscribe(res =>{
      this.insurerArr = res.insurerList;
    },err =>{
      console.log(err);
    })
  }

  getBenefitRiders(){
    this._productService.getBenefitRiders().subscribe(res =>{
      this.benefitRidersArr = res.benefitRidersList;
    },err =>{
      console.log(err);
    })
  }

  getProductType(){
    this._productService.getProductType().subscribe(res =>{
      this.productTypeArr = res.productTypeList;
    },err =>{
      console.log(err);
    })
  }

  getQuestion(){

   
    this._productService.getquestion().subscribe(res =>{
      this.questionArr = res.questionList;
    },err =>{
      console.log(err);
    })
  }

  getTaxStructure(){
    this._productService.getTaxStructure().subscribe(res =>{
      this.taxstructureArr = res.taxstructureList;
    },err =>{
      console.log(err);
    })
  }

  getRelationship(){
    this._lookupService.getRelationship().subscribe(res =>{
      this.relationshipArr = res.relationshipList;
    },err =>{
      console.log(err);
    })
  }

  getFrequency(){
    this._lookupService.getFrequency().subscribe(res =>{
    this.paymentFrequencyArr = res.paymentFrequencyist;
    },err =>{
      console.log(err);
    })
  }

  getRidersFactor(){
    this._productService.getRidersFactor().subscribe(res =>{
      this.ridersFactorArr = res.coefficientList;
    },err =>{
      console.log(err);
    })
  }

  getProduct(){
    this._productService.getProduct().subscribe(res =>{
      this.productArr = res.getProductModelList
      console.log(this.productArr)
    },err =>{
      console.log(err);
    })
  }

  newBusinessLevelProofofDocumentForm = new FormGroup({
    ageFrom: new FormControl("", [Validators.required]),
    createdBy: new FormControl(""),
    ageTo: new FormControl("",[Validators.required]),
    documentTypeListId: new FormControl("", [Validators.required])
  });

  VarientDocProofData(){
    var localDocArr
    localDocArr = JSON.parse(localStorage.getItem('ageProofDocumentList'));
    for(let i = 0; i < localDocArr.length; i++){
        this.ageTo = localDocArr[i].ageTo;
    }

    if(this.ageTo >= this.ageProofDocumentArr.value[0].ageFrom || this.ageProofDocumentArr.value[0].ageFrom >= this.ageProofDocumentArr.value[0].ageTo){
      this.ageError = 'Your Age Is Not Valid';
      this._snackBar.open(this.ageError, 'Error', {
        duration: 2000,
      });
    }else{
      this.ageError = 'Valid';
    }
    if(this.ageProofDocumentArr.valid && this.ageError == 'Valid'){
      this.temAgeProofDocumentArr = this.ageProofDocumentArr.value;
        if (localStorage.getItem('ageProofDocumentList') === null) {
          localDocArr = [];
        }
         let reqId = Math.floor(100000 + Math.random() * 900000);
        for(let i = 0; i < this.temAgeProofDocumentArr.length; i++){
          this.temAgeProofDocumentArr[i].requestId = reqId;
          this.docObj = this.temAgeProofDocumentArr[i];
        }
        localDocArr.push(this.docObj);
        localStorage.setItem('ageProofDocumentList', JSON.stringify(localDocArr));
        this.getBusinessLvlPrfDoc();
    }
  }

  getBusinessLvlPrfDoc(){
    if(localStorage.getItem('ageProofDocumentList')){
      this.docProofErrMsg = '';
      this.newBusinessLevelProofofDocumentObj = {};
      this.buttonDisable = false;
      this.isReadonly = true;
      this.isVariantReadonly = true;
      this.updateBtn = false;
      this.ageProofDocumentArr.reset();
      this.businessLvlPrfDocArr = JSON.parse(localStorage.getItem('ageProofDocumentList'));
      if(this.businessLvlPrfDocArr == 0){
        this.docProofErrMsg = 'Not Found!'
      }
    }
  }

  removeVarientDocProof(){
    this.getBusinessLvlPrfDoc();
  }

  viewdocProof(id){
    if(this.buttonDisable == false){
      this.newBusinessLevelProofofDocumentObj = {};
      this.buttonDisable = false;
      this.isReadonly = true;
      this.isVariantReadonly = true;
      this.updateBtn = false;
      this.ageProofDocumentArr.reset();
      for(let i = 0; i < this.businessLvlPrfDocArr.length; i++){
        if(this.businessLvlPrfDocArr[i].requestId){
          if(this.businessLvlPrfDocArr[i].requestId == id){
            this.newBusinessLevelProofofDocumentObj = this.businessLvlPrfDocArr[i];
          }
        }else if(this.businessLvlPrfDocArr[i].id){
          if(this.businessLvlPrfDocArr[i].id == id){
            this.newBusinessLevelProofofDocumentObj = this.businessLvlPrfDocArr[i];
          }
        }
      }
      this.buttonDisable = true;
      this.isReadonly = false;
    }
    }

    editdocProof(editdocProofId){
      if(this.buttonDisable == false){
        this.newBusinessLevelProofofDocumentObj = {};
        this.buttonDisable = false;
        this.isReadonly = true;
        this.isVariantReadonly = true;
        this.updateBtn = false;
        this.editdocProofId = editdocProofId;
        this.ageProofDocumentArr.reset();
        for(let i = 0; i < this.businessLvlPrfDocArr.length; i++){
          if(this.businessLvlPrfDocArr[i].requestId){
            if(this.businessLvlPrfDocArr[i].requestId == this.editdocProofId){
              this.newBusinessLevelProofofDocumentObj = this.businessLvlPrfDocArr[i];
            }
          }else if(this.businessLvlPrfDocArr[i].id){
            if(this.businessLvlPrfDocArr[i].id == this.editdocProofId){
              this.newBusinessLevelProofofDocumentObj = this.businessLvlPrfDocArr[i];
            }
          }
        }
        this.buttonDisable = true;
        this.updateBtn = true;
        this.isReadonly = true;
        this.isVariantReadonly = true;
      }
    }

    deletedocProofId(deletedocProofId){
      if(this.buttonDisable == false){
        this.deletedocProofID = deletedocProofId;
        this.newBusinessLevelProofofDocumentObj = {};
        this.buttonDisable = false;
        this.updateBtn = false;
        this.isReadonly = true;
        this.isVariantReadonly = true;
        this.ageProofDocumentArr.reset();
      }
    }

    deletedocProof(){
      if(this.buttonDisable == false){
        for(let i = 0; i < this.businessLvlPrfDocArr.length; i++){
          if(this.businessLvlPrfDocArr[i].requestId){
          if(this.deletedocProofID == this.businessLvlPrfDocArr[i].requestId){
            this.businessLvlPrfDocArr.splice(i, 1);
            break;
          }
        } else  if(this.businessLvlPrfDocArr[i].id){
          if(this.deletedocProofID == this.businessLvlPrfDocArr[i].id){
            this.businessLvlPrfDocArr.splice(i, 1);
            break;
          }
        }
        }
        localStorage.setItem('ageProofDocumentList', JSON.stringify(this.businessLvlPrfDocArr));
        this.getBusinessLvlPrfDoc();
      }
    }

    updateVarientDocProofData(){
      this.businessLvlPrfDocArr = JSON.parse(localStorage.getItem('ageProofDocumentList'));
      for(let i = 0; i < this.businessLvlPrfDocArr.length; i++){
        if(this.businessLvlPrfDocArr[i].requestId){
          if(this.editdocProofId == this.businessLvlPrfDocArr[i].requestId){
            this.businessLvlPrfDocArr.splice(i, 1);
            break;
          }
        }else if(this.businessLvlPrfDocArr[i].id){
          if(this.editdocProofId == this.businessLvlPrfDocArr[i].id){
            this.businessLvlPrfDocArr.splice(i, 1);
            break;
          }
        }
      }
      localStorage.setItem('ageProofDocumentList', JSON.stringify(this.businessLvlPrfDocArr));
      this.VarientDocProofData();
    }

    OnChange($event){
      this.isStampDutyApplicable = $event.checked ? 1 : 0;
  }

  baseCoverage($event){
    this.isBaseCoverage = $event.checked ? 1 : 0;
}

  selectable($event){
    this.isSelectable = $event.checked ? 1 : 0;
  }

  AutoIssuePolicyUpToFCLLimit($event){
    this.autoIssuePolicyUpToFCLLimit = $event.checked ? 1 : 0;
  }

  addBenefits(){

    if(new Date(this.productCoverageArr.value[0].effectFromDate) >= new Date(this.productCoverageArr.value[0].effectToDate)){
      this.error={isError:false, errorMessage:'Effect To Date should be greater than Effect From Date'}
      this._snackBar.open(this.error.errorMessage, 'Error', {
        duration: 3000,
      });
  }else{
    this.error={isError:true, errorMessage:'Valid'}
  }
    if(this.productCoverageArr.valid && (this.error == undefined || this.error.isError != false)){
      var temProductCoverageArr = this.productCoverageArr.value;
      var localProArr;
      if (localStorage.getItem('productCoverageList') === null) {
        localProArr = [];
      } else {
           localProArr = JSON.parse(localStorage.getItem('productCoverageList'));
       }
        let reqId = Math.floor(100000 + Math.random() * 900000);
     
          for(let i = 0; i < temProductCoverageArr.length; i++){
            temProductCoverageArr[i].requestId = reqId;
            temProductCoverageArr[i].isStampDutyApplicable = this.isStampDutyApplicable;
            temProductCoverageArr[i].isBaseCoverage = this.isBaseCoverage;
            temProductCoverageArr[i].isSelectable = this.isSelectable;
            temProductCoverageArr[i].stampDutyType = 0;
            // temProductCoverageArr[i].effectFromDate = this.datePipe.transform(temProductCoverageArr[i].effectFromDate, 'dd/MM/yyyy');
            // temProductCoverageArr[i].effectToDate = this.datePipe.transform(temProductCoverageArr[i].effectToDate, 'dd/MM/yyyy');
            this.prductObj = temProductCoverageArr[i];
          }
        localProArr.push(this.prductObj);
        localStorage.setItem('productCoverageList', JSON.stringify(localProArr));
        this.getProductCoverageList();
    }
  }

  getProductCoverageList(){
    if(localStorage.getItem('productCoverageList')){
      this.prdctCvrAgeErrMsg = '';
      this.productCoverageListObj = {};
      this.isStampDutyApplicable = 0;
      this.buttonDisable = false;
      this.isReadonly = true;
      this.isVariantReadonly = true;
      this.updateBtn = false;
      this.productCoverageArr.reset();
      this.productCoverageListArr = JSON.parse(localStorage.getItem('productCoverageList'));
      if(this.productCoverageListArr == 0){
        this.prdctCvrAgeErrMsg = 'Not Found!'
      }
    }
  }

  viewproductCoverageList(id){
    if(this.buttonDisable == false){
      this.productCoverageListObj = {};
      this.buttonDisable = false;
      this.isReadonly = true;
      this.isVariantReadonly = true;
      this.updateBtn = false;
      this.productCoverageArr.reset();
      for(let i = 0; i < this.productCoverageListArr.length; i++){
        if(this.productCoverageListArr[i].requestId){
        if(this.productCoverageListArr[i].requestId == id){
          this.productCoverageListObj = this.productCoverageListArr[i];
        }
      }else if(this.productCoverageListArr[i].id){
        if(this.productCoverageListArr[i].id == id){
          this.productCoverageListObj = this.productCoverageListArr[i];
          // this.productCoverageListObj.effectFromDate = new Date(this.productCoverageListArr[i].effectFromDate);
          // this.productCoverageListObj.effectToDate = new Date(this.productCoverageListArr[i].effectToDate);
        }
      }
      }
      this.buttonDisable = true;
      this.isReadonly = false;
    }
  }

  cancelBenefit(){
    this.getProductCoverageList();
  }

  editproductCoverageList(id){
    if(this.buttonDisable == false){
      this.productCoverageListObj = {};
      this.buttonDisable = false;
      this.isReadonly = true;
      this.isVariantReadonly = true;
      this.updateBtn = false;
      this.editproductCoverageListId = id;
      this.productCoverageArr.reset();
      for(let i = 0; i < this.productCoverageListArr.length; i++){
        if(this.productCoverageListArr[i].requestId){
        if(this.productCoverageListArr[i].requestId == this.editproductCoverageListId){
          this.productCoverageListObj = this.productCoverageListArr[i];
        }
      }
      else if(this.productCoverageListArr[i].id){
        if(this.productCoverageListArr[i].id == this.editproductCoverageListId){
          this.productCoverageListObj = this.productCoverageListArr[i];
          // this.productCoverageListObj.effectFromDate = new Date(this.productCoverageListArr[i].effectFromDate);
          // this.productCoverageListObj.effectToDate = new Date(this.productCoverageListArr[i].effectToDate);

        }
      }
      }
      this.buttonDisable = true;
      this.updateBtn = true;
      this.isReadonly = true;
      this.isVariantReadonly = true;
    }
  }

  deleteproductCoverageListId(id){
    if(this.buttonDisable == false){
      this.deleteproductCoverageListID = id;
      // this.variantForm.markAsPristine();
      // this.variantForm.markAsUntouched();
      this.productCoverageListObj = {};
      this.buttonDisable = false;
      this.updateBtn = false;
      this.isReadonly = true;
      this.isVariantReadonly = true;
      this.productCoverageArr.reset();
    }
  }

  deleteproductCoverageList(){
    if(this.buttonDisable == false){
      for(let i = 0; i < this.productCoverageListArr.length; i++){
        if(this.productCoverageListArr[i].requestId){
        if(this.deleteproductCoverageListID == this.productCoverageListArr[i].requestId){
          this.productCoverageListArr.splice(i, 1);
          break;
        }
      } else if(this.productCoverageListArr[i].id){
        if(this.deleteproductCoverageListID == this.productCoverageListArr[i].id){
          this.productCoverageListArr.splice(i, 1);
          break;
        }
      }
      }
      localStorage.setItem('productCoverageList', JSON.stringify(this.productCoverageListArr));
      this.getProductCoverageList();
    }
  }

  updateBenefits(){
    this.productCoverageListArr = JSON.parse(localStorage.getItem('productCoverageList'));
    for(let i = 0; i < this.productCoverageListArr.length; i++){
      if(this.productCoverageListArr[i].requestId){
      if(this.editproductCoverageListId == this.productCoverageListArr[i].requestId){
        this.productCoverageListArr.splice(i, 1);
        break;
      }
    }else if(this.productCoverageListArr[i].id){
      if(this.editproductCoverageListId == this.productCoverageListArr[i].id){
        this.productCoverageListArr.splice(i, 1);
        break;
      }
    }
    }
    localStorage.setItem('productCoverageList', JSON.stringify(this.productCoverageListArr));
    this.addBenefits();
  }

  variantForm = new FormGroup({
    verbiage: new FormControl(""),
    exclusion: new FormControl(""),
    remarks: new FormControl(""),
    coEfficientIds:  new FormControl([]),
    frequencyIds: new FormControl([]),
    nomineeRelationShipIds: new FormControl([]),
    relationShipIds: new FormControl([]),
    variantQuestionIdList: new FormControl([]),
    variantTaxStructureIdlist:new FormControl([]),

    ageProofDocumentList: new FormArray([this.ageProofDocument()]),
    productCoverageList: new FormArray([this.productCoverage()]),
    variant : new FormGroup({
      productID: new FormControl(""),
      autoIssuePolicyUpToFCLLimit: new FormControl(""),
      code:  new FormControl("",[Validators.required]),
      createdBy:  new FormControl(""),
      description:  new FormControl(""),
      effectiveDate: new FormControl("",[Validators.required]),
      startDate:  new FormControl("",[Validators.required]),
      endDate:  new FormControl("",[Validators.required]),
      freelookup: new FormControl(""),
      insurerID: new FormControl("",[Validators.required]),
      isEligibleforLoan: new FormControl(""),
      isUnderWritingApplicable: new FormControl(""),
      maxAge: new FormControl(""),
      maxSumAssured: new FormControl(""),
      maxTerm: new FormControl(""),
      maximumAgeTypeID: new FormControl(""),
      minAge: new FormControl(""),
      minSumAssured: new FormControl(""),
      minTerm: new FormControl(""),
      minimumAgeTypeID: new FormControl(""),
      noOfBackdatedForEndorsemant: new FormControl(""),
      noOfBackdatedForNB: new FormControl(""),
      planID: new FormControl("",[Validators.required]),
      productTypeID: new FormControl(""),
      uANNo: new FormControl("",[Validators.required]),
      waitingPeriodforClaim: new FormControl(""),
      waitingPeriodforLoan: new FormControl(""),
      remarks: new FormControl(""),
    })
  });

  ageProofDocument(){
    return new FormGroup({
      ageFrom: new FormControl(""),
      ageTo: new FormControl(""),
      documentTypeListId: new FormControl([""])
    })
  }

  get ageProofDocumentArr (){
    return <FormArray>this.variantForm.get('ageProofDocumentList');
  }

  productCoverage(){
    return new FormGroup({
      isBaseCoverage: new FormControl(""),
      isSelectable: new FormControl(""),
      isStampDutyApplicable: new FormControl(""),
      stampDutyRate: new FormControl(""),
      stampDutyType: new FormControl(""),
      coverageId: new FormControl(""),
   effectFromDate: new FormControl(""),
      effectToDate: new FormControl("")
    })
  }

  get productCoverageArr (){
    return <FormArray>this.variantForm.get('productCoverageList');
  }

  variantData(){


    if(this.variantForm.value.variant.startDate  >= this.variantForm.value.endDate){
      this.errorMsg = "Your Maximum Value Is Lower Than Or Equal In Minimum Value";
      console.log (this.errorMsg)
      this._snackBar.open(this.errorMsg, 'Error', {
        duration: 2000,
   
      });
    }else{
      this.errorMsg = 'true';
      console.log (this.errorMsg)
    }

    if(this.variantForm.value.variant.minAge >= this.variantForm.value.variant.maxAge){
      this.errorMsg = " Variant min age  should be less then Variant max age";
      this._snackBar.open(this.errorMsg, 'Error', {
        duration: 2000,
      });
    }else{
      this.errorMsg = 'true';
    }


    if(this.variantForm.value.variant.minTerm >= this.variantForm.value.variant.maxTerm){
      this.errorMsg = " Variant minimum term  should be less then Variant maximum term";
      this._snackBar.open(this.errorMsg, 'Error', {
        duration: 2000,
      });
    }else{
      this.errorMsg = 'true';
    }

    if(this.variantForm.value.variant.minSumAssured >= this.variantForm.value.variant.maxSumAssured){
      this.errorMsg = " Minimum sum assured should be less then Maximum sum assured";
      this._snackBar.open(this.errorMsg, 'Error', {
        duration: 2000,
      });
    }else{
      this.errorMsg = 'true';
    }

    this.variantForm.value.ageProofDocumentList = JSON.parse(localStorage.getItem('ageProofDocumentList'));
    this.variantForm.value.productCoverageList = JSON.parse(localStorage.getItem('productCoverageList'));
    this.variantForm.value.variant.createdBy = this.userId;
    this.variantForm.value.variant.remarks = this.variantForm.value.remarks;
    this.variantForm.value.variant.lineOfBusinessID = 1;
    // this.variantForm.value.variant.startDate = this.datePipe.transform(this.variantForm.value.variant.startDate, 'dd/MM/yyyy');
    // this.variantForm.value.variant.effectiveDate = this.datePipe.transform(this.variantForm.value.variant.effectiveDate, 'dd/MM/yyyy');
    // this.variantForm.value.variant.endDate = this.datePipe.transform(this.variantForm.value.variant.endDate, 'dd/MM/yyyy');
    this.variantForm.value.variant.autoIssuePolicyUpToFCLLimit = this.autoIssuePolicyUpToFCLLimit;
      this.variantDataObj = this.variantForm.value;
      console.log(this.variantDataObj)
      this._productService.addVariant(this.variantDataObj).subscribe(res =>{
        this._snackBar.open(res.message, 'Done', {
          duration: 2000,
        });
        // this.variantForm.reset();
        this.getVariant();
      },err =>{
        console.log(err);
      })
  }

  getVariant(){
    this.variantForm.reset();
    this.variantErrMsg = '';
    this.docProofErrMsg = '';
    this.prdctCvrAgeErrMsg = '';
    this.variantObj = {};
    this.variantDataObj = {};
    this.searchVariantObj = {};
    this.buttonDisable = false;
    this.isReadonly = true;
    this.isVariantReadonly = true;
    this.updateBtn = false;
    this.editRemarkInput = false;
    this.viewRemarkInput = false;
    this.productCoverageListArr = [];
    this.businessLvlPrfDocArr = [];
    localStorage.setItem('productCoverageList', JSON.stringify(this.productCoverageListArr));
    localStorage.setItem('ageProofDocumentList', JSON.stringify(this.businessLvlPrfDocArr));
    this.variantForm.reset();
    this._productService.getVariant().subscribe(res =>{
      this.variantArr = res.variantRequestList;
      this.spinner.hide();
      console.log( this.variantArr);
      if(this.variantArr.length == 0){
        this.variantErrMsg = 'Not Found'
      }
    },err =>{
      console.log(err);
    })
  }

  viewVariant(id){
    if(this.buttonDisable == false){
      this.spinner.show();
      this.variantObj = {};
      this.variantDataObj = {};  
      this.buttonDisable = false;
      this.isReadonly = true;
      this.editRemarkInput = false;
      this.viewRemarkInput = false;
      this.isVariantReadonly = true;
      this.updateBtn = false;
      this.variantForm.reset();
      this._productService.getSingleVariant(id).subscribe(res =>{
        this.variantHistoryList = res.historyList;
        this.variantDataObj = res.variantRequestObj;
        this.variantObj = res.variantRequestObj.variant;
        // this.variantObj.startDate = new Date(res.variantRequestObj.variant.startDate);
        // this.variantObj.endDate = new Date(res.variantRequestObj.variant.endDate);
        // this.variantObj.effectiveDate = new Date(res.variantRequestObj.variant.effectiveDate);
        this.productCoverageListArr = res.variantRequestObj.productCoverageList;
        this.businessLvlPrfDocArr = res.variantRequestObj.ageProofDocumentList;
        localStorage.setItem('productCoverageList', JSON.stringify(this.productCoverageListArr));
        localStorage.setItem('ageProofDocumentList', JSON.stringify(this.businessLvlPrfDocArr));
        this.buttonDisable = true;
        this.isReadonly = false;
        this.isVariantReadonly = false;
        this.viewRemarkInput = true;
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }
  }

  clearvariant(){
    this.spinner.show();
    this.getVariant();
  }

  editVariant(id){

    // console.log(id.productID)
    console.log(id)
    if(this.buttonDisable == false){
      this.spinner.show();
      this.variantDataObj = {};
      this.variantObj = {};
      this.buttonDisable = false;
      this.editRemarkInput = false;
      this.viewRemarkInput = false;
      this.isReadonly = true;
      this.isVariantReadonly = true;
      this.updateBtn = false;
      this.variantForm.reset();
      console.log(id.productID)
      console.log(id)
      this._productService.getSingleVariant(id).subscribe(res =>{
        this.variantHistoryList = res.historyList;
        this.variantDataObj = res.variantRequestObj;
        this.variantObj = res.variantRequestObj.variant;
        // this.variantObj.startDate = new Date(res.variantRequestObj.variant.startDate);
        // this.variantObj.endDate = new Date(res.variantRequestObj.variant.endDate);
        // this.variantObj.effectiveDate = new Date(res.variantRequestObj.variant.effectiveDate);
        this.productCoverageListArr = res.variantRequestObj.productCoverageList;
        this.businessLvlPrfDocArr = res.variantRequestObj.ageProofDocumentList;
        localStorage.setItem('productCoverageList', JSON.stringify(this.productCoverageListArr));
        localStorage.setItem('ageProofDocumentList', JSON.stringify(this.businessLvlPrfDocArr));
        this.buttonDisable = true;
        this.updateBtn = true;
        this.isReadonly = true;
        this.isVariantReadonly = true;
        this.editRemarkInput = true;
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }
  }

  deleteVariantId(id){
    if(this.buttonDisable == false){
      this.deleteVariantID = id;
      this.variantDataObj = {};
      this.variantObj = {};
      this.buttonDisable = false;
      this.editRemarkInput = false;
      this.viewRemarkInput = false;
      this.updateBtn = false;
      this.variantForm.reset();
      this.isReadonly = true;
      this.isVariantReadonly = true;
    }
  }

  deleteVariant(){
    if(this.buttonDisable == false){
      this.spinner.show();
     this._productService.deleteVariant(this.deleteVariantID, this.userId).subscribe(res =>{
       this.getVariant();
     },err =>{
       console.log(err);
     })
    }
  }

  searchVariant(){
    this.spinner.show();
    this.variantErrMsg = '';
    this.docProofErrMsg = '';
    this.prdctCvrAgeErrMsg = '';
    this.variantObj = {};
    this.variantDataObj = {};
    this.buttonDisable = false;
    this.isReadonly = true;
    this.isVariantReadonly = true;
    this.editRemarkInput = false;
    this.viewRemarkInput = false;
    this.updateBtn = false;
    this.variantForm.reset();
    this._productService.searchVariant(this.searchVariantObj).subscribe(res =>{
      this.variantArr = res.list;
      this.spinner.hide();
      if(this.variantArr.length == 0){
        this.variantErrMsg = 'Not Found'
      }
    },err =>{
      console.log(err);
    })
  }

}


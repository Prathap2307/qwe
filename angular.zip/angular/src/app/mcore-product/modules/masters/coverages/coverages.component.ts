import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from "moment"
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { CoveragesService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/coverages.service';

@Component({
  selector: 'app-coverages',
  templateUrl: './coverages.component.html',
  styleUrls: ['./coverages.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class CoveragesComponent implements OnInit {
  @ViewChild('picker', { static: true }) picker;
  @ViewChild('picker1', { static: true }) picker1;
  uinID: any;
  covdelete: boolean = false;
  uindelete: boolean = false;
  excdelete: boolean = false;
  id: any;
  deletebtn: any;
  lob: any;
  invalidsum: boolean;
  invalidcover: boolean;
  userID: string;
  LOB: any;
  lobform: FormGroup;
  open() {
    this.picker.open();
    this.picker1.open();
  }

  SearchBenefitsRidersform: FormGroup;
  AddBenefit: FormGroup;
  uinForm: FormGroup;
  Exclusionform: FormGroup;
  UINArray: any[] = [];
  ExclusionArray = [];
  submitted2: boolean;
  submitted: boolean;
  submitted3: boolean;
  SubchannelHeading: string = "Benefits / Riders";
  saveBtnMode: boolean = true;
  view: boolean = false;
  textSaveBtn: string = "Save";
  display: string;
  uinpush: boolean;
  ExclusionPush: boolean;
  view1: boolean = false;
  saveBtnMode1: boolean = true;
  SubchannelHeading1: string = "UIN";
  message: any;
  invalidDate: boolean;
  validform: boolean;
  invalidage: boolean;
  UINobj: any;
  textSaveBtn1: string = "Add";
  uinIndex: any;
  error: boolean;
  uinIndex2: any;
  exclusion: string = 'Save Exclusion';
  exIndex2: any;
  exobj: any;
  version: boolean = false;
  versionerror: boolean;
  submitted1: boolean;
  success: boolean;
  transaction: any;
  allCoverages: any;
  exist: boolean;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  coverages: any;

  constructor(private fb: FormBuilder, private CoverageService: CoveragesService) { }

  ngOnInit() {
    this.userID = localStorage.getItem('userID')
 
    this.GetLineOfBusiness()
    this.lobform = this.fb.group({
      lob: [1],
    })
    this.getallcoverages(this.lobform.value['lob']);
    this.SearchBenefitsRidersform = this.fb.group({
      coverageName: [''],
      description: [''],
    })

    this.AddBenefit = this.fb.group({
      coverageID: [''],
      coverageName: ['', Validators.required],
      description: [''],
      coverCode: [''],
      lineOfBusinessID: [''],
      houseHoldLimitPerYear: [''],
      sectionID: [''],
      createdBy: [''],
      createdOn: [''],
      isActive: [''],
      type: [''],
      amountPercentage: [''],
      uinMapDetails: this.fb.array([]),
      exclusion: this.fb.array([]),
    });

    this.uinForm = this.fb.group({
      uinID: [''],
      description: ['', Validators.required],
      coverageID: [''],
      uinNumber: ['', Validators.required],
      maximumMaturityAge: ['', Validators.required],
      maximumMaturityAgeType: ['', Validators.required],
      uinEffectiveFrom: ['', Validators.required],
      uinEffectiveTo: ['', Validators.required],
      minimumEntryAge: ['', Validators.required],
      minimumEntryAgeType: [],
      maximumEntryAge: ['', Validators.required],
      maximumEntryAgeType: ['', Validators.required],
      minimumSumAssured: ['', Validators.required],
      minimumSumAssuredType: ['', Validators.required],
      maximumSumAssured: ['', Validators.required],
      maximumSumAssuredType: ['', Validators.required],
      minimumFreeCoverLimit: [''],
      maximumFreeCoverLimit: [''],
      isActive: [''],
      versionNo: [''],
    })

    this.Exclusionform = this.fb.group({
      coverageId: [''],
      exclusionId: [''],
      description: ['', Validators.required],
      createdBy: [''],
      createdOn: [''],
      isActive: ['']
    })
  }
  get s() { return this.SearchBenefitsRidersform.controls; }

  SearchBenefit() {
    this.submitted3 = true;
    console.log(this.SearchBenefitsRidersform.value)
    
    this.CoverageService.getSearchCoverageDetails(this.SearchBenefitsRidersform.value)
    .subscribe(result => {
      console.log(result)
      this.allCoverages = result.data
      console.log(this.allCoverages.length)
      if (this.allCoverages) {
        this.config = {
          itemsPerPage: 10,
          currentPage: 1,
          totalItems: this.allCoverages.length
        }
      }
    })
  }

  get b() { return this.AddBenefit.controls }

  GetLineOfBusiness() {
    this.CoverageService.GetLineOfBusiness()
      .subscribe(result => {
        console.log(result)
        this.lob = result.data
      })
  }
  selectLOB(event:any){
    console.log(event.target.value)
    this.LOB=event.target.value
    this.getallcoverages(this.LOB)
  }
  getallcoverages(lob:any) {
    this.CoverageService.GetAllCoveragesByLineOfBusiness(lob)
      .subscribe(result => {
        console.log(result)
        this.allCoverages = result.data
        console.log(this.allCoverages.length)
        if (this.allCoverages) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allCoverages.length
          }
        }
      });
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  addBenefit() {
    this.submitted = true;
    this.AddBenefit.value['lineOfBusinessID'] = this.lobform.value["lob"]
    this.AddBenefit.value['sectionID'] = 1
    this.AddBenefit.value['createdBy'] = this.userID
    console.log(this.AddBenefit.value)
    this.result();


  }
  clearBenefit() {
    this.textSaveBtn1 = 'Add'
    this.textSaveBtn = 'Save'
    this.UINArray = []
    this.ExclusionArray = []
    this.uinpush = false
    this.ExclusionPush = false
    this.submitted = false;
    this.AddBenefit.reset();
    this.SubchannelHeading = 'Add - Benefits / Riders'
    this.clearUIn();
    this.clearExculsion()
    this.saveBtnMode = true;
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  clearsearch() {
    this.SearchBenefitsRidersform.reset()
    this.getallcoverages(this.lobform.value['lob'])
  }
  get a() { return this.uinForm.controls; }

  adduin() {
    this.submitted1 = true;
    console.log(this.uinForm.value)
    let fromvalue = moment(new Date(this.uinForm.value["uinEffectiveFrom"])).format('YYYY/MM/DD')
    let tovalue = moment(new Date(this.uinForm.value["uinEffectiveTo"])).format('YYYY/MM/DD')
    let uinEffectiveFrom = moment(fromvalue);
    let uinEffectiveTo = moment(tovalue);
    let result = uinEffectiveFrom.diff(uinEffectiveTo, 'days');
    console.log(result)
    if (result > 0) {
      let msg = 'UIN Effective To Date should not be lesser than UIN Effective From Date'
      this.openModalDialog(msg)
      this.invalidDate = true
      console.log("UIN Effective To Date should not be lesser than UIN Effective From Date")
    }
    console.log(this.uinForm.value["minimumEntryAge"])
    console.log(this.uinForm.value["maximumEntryAge"])
    if (this.uinForm.value["minimumEntryAge"] > this.uinForm.value["maximumEntryAge"]) {
      this.invalidage = true
      let msg = 'Minimum Entry Age should not be greater than Maximum Entry Age.'
      this.openModalDialog(msg)
      console.log("Minimum Entry Age should not be greater than Maximum Entry Age.")
    }
    if (this.uinForm.value["minimumSumAssured"] > this.uinForm.value["maximumSumAssured"]) {
      this.invalidsum = true
      let msg = 'Minimum Sum assured should not be greater than Maximum Sum assured.'
      this.openModalDialog(msg)
      console.log("Minimum Sum assured should not be greater than Maximus Sum assured.")
    }
    if (this.uinForm.value["minimumFreeCoverLimit"] > this.uinForm.value["maximumFreeCoverLimit"]) {
      this.invalidcover = true
      let msg = 'Minimum Free Cover Limit should not be greater than Maximum Free Cover Limit.'
      this.openModalDialog(msg)
      console.log("Minimum Sum assured should not be greater than Maximus Sum assured.")
    }
    if (this.uinForm.valid && !this.invalidDate && !this.invalidage && !this.invalidsum && !this.invalidcover) {
      console.log(this.uinForm.value)
      this.UINobj = this.UINArray.find(x => x.uinID == this.uinForm.value["uinID"]);
      console.log(this.uinIndex)
      console.log(this.UINobj)
      if (this.uinIndex == undefined) {
        this.uinForm.value["uinID"] = 0
        this.uinForm.value["coverageID"] = 0
        console.log(this.uinForm.value["uinEffectiveFrom"])
        // this.uinForm.value["uinEffectiveFrom"]= moment(this.uinForm.value["uinEffectiveFrom"]).format('DD-MM-YYYY ')
        // this.uinForm.value["uinEffectiveTo"]=moment(new Date(this.uinForm.value["uinEffectiveTo"])).format('DD-MM-YYYY ')
        this.UINArray.push(this.uinForm.value)
        console.log(this.UINArray)
        let message = "UIN Added SuccessFully"
        this.openModalDialog(message)
      }
      else {
        if (this.version) {
          this.UINArray.push(this.uinForm.value)
          this.version = false
        }
        else {
          this.UINArray[this.uinIndex] = this.uinForm.value
        }

        console.log(this.UINArray)
        let message = "UIN Updated SuccessFully"
        this.openModalDialog(message)
        this.uinIndex = undefined
      }
      this.validform = true
      this.uinpush = true
      this.clearUIn()
    }

  }
  delete_Click() {
    this.CoverageService.DeleteCoverage(this.id)
      .subscribe(result => {
        console.log(result)
        this.getallcoverages(this.lobform.value['lob'])
        this.covdelete = true
      })
  }
  setIdDelete(i, k) {
    console.log(k)
    this.deletebtn = k
    console.log(this.deletebtn)
    this.id = i
  }
  deleteUinDetail() {
    if (this.id !== -1) {
      this.UINArray.splice(this.id, 1);
      this.uindelete = true
    }
    console.log()
  }
  deleteExclusionDetail() {
    if (this.id !== -1) {
      this.ExclusionArray.splice(this.id, 1);
      this.excdelete = true
    }
    console.log()
  }
  clearUIn() {
    this.submitted1 = false;
    this.uinForm.reset();
    this.SubchannelHeading1 = 'UIN';
    this.saveBtnMode1 = true;
    this.textSaveBtn1 = 'Add'
    if (this.view1 === true) {
      this.view1 = false
      console.log(this.view1)
    }
  }

  get e() { return this.Exclusionform.controls; }

  onsaveExculsion() {
    this.submitted2 = true;
    console.log(this.Exclusionform.value)
    if (this.Exclusionform.valid) {
      if (this.exIndex2 == undefined) {
        this.ExclusionArray.push(this.Exclusionform.value)
        console.log(this.ExclusionArray)
        let message = "Exclusion Added SuccessFully"
        this.openModalDialog(message)
      }
      else {
        this.ExclusionArray[this.exIndex2] = this.Exclusionform.value
        console.log(this.ExclusionArray)
        let message = "Exclusion Updated SuccessFully"
        this.openModalDialog(message)
        this.exIndex2 = undefined
      }
      this.validform = true
      console.log(this.ExclusionArray)
      this.ExclusionPush = true
      this.clearExculsion()
    }

  }

  btngEdit_Click2(i: any) {
    this.exIndex2 = i
    this.exclusion = 'Update Exclusion'
    this.exobj = this.ExclusionArray[this.exIndex2];
    this.Exclusionform = this.fb.group({
      description: [{ value: this.exobj.description, disabled: false }, Validators.required],
      coverageId: [{ value: this.exobj.description, disabled: false }],
      exclusionId: [{ value: this.exobj.description, disabled: false }],
      createdBy: [{ value: this.exobj.description, disabled: false }],
      createdOn: [{ value: this.exobj.description, disabled: false }],
      isActive: [{ value: this.exobj.description, disabled: false }]
    })

  }
  clearExculsion() {
    this.submitted2 = false;
    this.Exclusionform.reset();
    this.exclusion = 'Save Exclusion'
  }

  btngEdit_Click(id: any) {
    this.SubchannelHeading = 'Edit - Benefits / Riders';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.GetCoverageByCoverageID(id)
  }

  GetCoverageByCoverageID(id: any) {
    this.CoverageService.GetCoverageByCoverageID(id)
      .subscribe(result => {
        console.log(result)
        this.coverages = result.data
        console.log(this.coverages)
        if (this.coverages) {
          this.AddBenefit = this.fb.group({
            coverageID: [{ value: this.coverages.coverageID, disabled: false }],
            coverageName: [{ value: this.coverages.coverageName, disabled: false }, Validators.required],
            description: [{ value: this.coverages.description, disabled: false }],
            coverCode: [{ value: this.coverages.coverCode, disabled: false }],
            lineOfBusinessID: [{ value: this.coverages.branchId, disabled: false }],
            houseHoldLimitPerYear: [{ value: this.coverages.branchId, disabled: false }],
            sectionID: [{ value: this.coverages.branchId, disabled: false }],
            createdBy: [''],
            createdOn: [''],
            isActive: [''],
            type: [{ value: this.coverages.branchId, disabled: false }],
            amountPercentage: [{ value: this.coverages.amountPercentage, disabled: false }],
            // uinMapDetails: this.fb.array([]),
            // exclusion: this.fb.array([]),
          })
          this.UINArray = this.coverages.coverageUINMapModalList
          this.ExclusionArray = this.coverages.coverageExclusionNewModalList
          if (this.UINArray && this.UINArray.length > 0) {
            for (let i = 0; i < this.UINArray.length; i++) {
              // this.uinForm.value["uinEffectiveFrom"]= moment(this.uinForm.value["uinEffectiveFrom"]).format('DD-MM-YYYY ')
              // this.uinForm.value["uinEffectiveTo"]=moment(new Date(this.uinForm.value["uinEffectiveTo"])).format('DD-MM-YYYY ')
              // var date1 = "28/01/2019".split('/')
              // var newDate = date1[1] + '/' +date1[0] +'/' +date1[2];

              // var date = new Date(newDate);
              let date1 = this.UINArray[i]["uinEffectiveFrom"].split('-')
              let newdate = date1[1] + '-' + date1[0] + '-' + date1[2]
              this.UINArray[i]["uinEffectiveFrom"] = new Date(newdate);

              // this.UINArray[i]["uinEffectiveTo"] = this.UINArray[i]["uinEffectiveTo"]
            }
          }
          console.log(this.UINArray)
        }

      })
  }

  btngView_Click(id: any) {
    this.SubchannelHeading = 'View - Benefits / Riders';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.GetCoverageByCoverageID(id)

  }

  btngEdit_Click1(uinID: any, i: any) {
    this.uinIndex = i
    this.SubchannelHeading1 = 'Edit - UIN';
    this.saveBtnMode = true;
    this.view1 = false;
    this.textSaveBtn1 = 'Update'
    this.getuin()
  }
  getuin() {
    this.UINobj = this.UINArray[this.uinIndex];
    console.log(this.UINobj)
    if (this.UINobj) {
      this.uinForm = this.fb.group({
        uinID: [{ value: this.UINobj.uinID, disabled: false }],
        description: [{ value: this.UINobj.description, disabled: false }, Validators.required],
        coverageID: [{ value: this.UINobj.coverageID, disabled: false }],
        uinNumber: [{ value: this.UINobj.uinNumber, disabled: false }, Validators.required],
        maximumMaturityAge: [{ value: this.UINobj.maximumMaturityAge, disabled: false }, Validators.required],
        maximumMaturityAgeType: [{ value: this.UINobj.maximumMaturityAgeType, disabled: false }, Validators.required],
        uinEffectiveFrom: [{ value: new Date(this.UINobj.uinEffectiveFrom), disabled: false }, Validators.required],
        uinEffectiveTo: [{ value: new Date(this.UINobj.uinEffectiveTo), disabled: false }, Validators.required],
        minimumEntryAge: [{ value: this.UINobj.minimumEntryAge, disabled: false }, Validators.required],
        minimumEntryAgeType: [{ value: this.UINobj.minimumEntryAgeType, disabled: false }],
        maximumEntryAge: [{ value: this.UINobj.maximumEntryAge, disabled: false }, Validators.required],
        maximumEntryAgeType: [{ value: this.UINobj.maximumEntryAgeType, disabled: false }, Validators.required],
        minimumSumAssured: [{ value: this.UINobj.minimumSumAssured, disabled: false }, Validators.required],
        minimumSumAssuredType: [{ value: this.UINobj.minimumSumAssuredType, disabled: false }, Validators.required],
        maximumSumAssured: [{ value: this.UINobj.maximumSumAssured, disabled: false }, Validators.required],
        maximumSumAssuredType: [{ value: this.UINobj.maximumSumAssuredType, disabled: false }, Validators.required],
        minimumFreeCoverLimit: [{ value: this.UINobj.minimumFreeCoverLimit, disabled: false }],
        maximumFreeCoverLimit: { value: this.UINobj.maximumFreeCoverLimit, disabled: false },
        isActive: [{ value: this.UINobj.isActive, disabled: false }],

      })
      console.log(this.uinForm.value)
    }
  }
  uinVersion() {
    this.version = true
    console.log(this.UINobj.uinNumber)
    console.log(this.uinForm.value["uinNumber"])
    if (this.uinForm.value["uinNumber"] === this.UINobj.uinNumber) {
      this.adduin()
    }
    else {
      let message = "UIN Number should remains the same during version update."
      this.openModalDialog(message)
      this.error = true
    }

  }
  dateValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (charCode === 32 || (charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)

        event.preventDefault();
      }
    }
  }
  ageValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 2) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  restrictSpecialchar(event: any) {
    var a = event.target.value;
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
        if ((keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
  }
  numValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(event.keyCode)
        event.preventDefault();
      }
    }
  }
  btngView_Click1(uinID: any, i: any) {
    this.uinIndex = i
    this.SubchannelHeading1 = 'View - UIN';
    this.view1 = true
    console.log(this.view)
    this.saveBtnMode1 = false;
    this.getuin()
  }

  openModalDialog(data: string) {
    this.display = 'block'; //Set block css
    this.submitted = false
    this.message = data;
    // this.AddBenefit.reset()


  }

  closeModalDialog() {
    if (this.invalidDate) {
      this.invalidDate = false
    }
    if (this.validform) {
      this.validform = false
    }
    if (this.invalidage) {
      this.invalidage = false
    }
    this.success = false
    this.validform = false
    this.exist = false
    this.error = false
    this.covdelete = false;
    this.uindelete = false;
    this.excdelete = false;
    this.invalidsum=false
    this.invalidcover=false
    console.log(this.uindelete)
    console.log(this.excdelete)
    this.display = 'none'; //set none css after close dialog

  }


  openModalDialog1() {
    this.display = 'block'; //Set block css
    this.submitted = false

  }
  result() {

    let result = {}


    if (this.AddBenefit.invalid) {
      console.log("Please fill Riders")
      let message = "Please fill Riders"
      this.openModalDialog(message)
      this.error = true
    }
    else {

      if (this.UINArray && this.UINArray.length === 0) {
        let message = "Please fill UIN details"
        this.openModalDialog(message)
        this.error = true
      }
      else if (this.UINArray && this.UINArray.length > 0) {

        this.AddBenefit.value['uinMapDetails'] = this.UINArray
      }
    }

    if (this.ExclusionArray && this.ExclusionArray.length > 0) {
      this.AddBenefit.value['exclusion'] = this.ExclusionArray
    }


    if (this.AddBenefit.valid && this.UINArray && this.UINArray.length > 0) {
      this.validform = true

      result = this.AddBenefit.value
      console.log(result)
      this.IsCoverageExistNew(this.AddBenefit.value)
    }

  }
  IsCoverageExistNew(data: any) {
    if (this.textSaveBtn === 'Save') {
      this.AddBenefit.value['coverageID'] = 0
    }
    this.AddBenefit.value['lineOfBusinessID'] = this.lobform.value["lob"]
    this.AddBenefit.value['sectionID'] = 1
    this.AddBenefit.value['createdBy'] = this.userID
    this.AddBenefit.value['createdOn'] = null
    this.AddBenefit.value['isActive'] = 1
    this.AddBenefit.value['houseHoldLimitPerYear'] = 12
    for (let i = 0; i < this.UINArray.length; i++) {
      this.UINArray[i]["uinEffectiveFrom"] = moment(this.UINArray[i]["uinEffectiveFrom"]).format('DD-MM-YYYY')
      this.UINArray[i]["uinEffectiveTo"] = moment(this.UINArray[i]["uinEffectiveTo"]).format('DD-MM-YYYY')
    }
    this.CoverageService.IsCoverageExistNew(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === false) {
          console.log("data >>", data)

          this.CoverageService.InsertOrUpdateCoverageNew(data)
            .subscribe(result => {
              console.log(result)
              if (result.data = "Success") {
                this.success = true
                this.validform = true
                if (this.textSaveBtn === 'Save') {
                  let transaction = "Benefits/Riders are Added Successfully"
                  this.openModalDialog(transaction)
                }
                else {
                  let transaction = "Benefits/Riders are Updated Successfully"
                  this.openModalDialog(transaction)
                }
                this.clearBenefit()
                this.clearUIn()
                this.clearExculsion()
                this.getallcoverages(this.lobform.value['lob']);
              }
              //this.clearBenefit()
            });
        }
        else {
          this.exist = true
          let transaction = "Benefits Already  Exists"
          this.openModalDialog(transaction)
        }

      });
  }

}

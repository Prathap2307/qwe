import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthorisedsignatoryComponent } from './authorisedsignatory.component';

describe('AuthorisedsignatoryComponent', () => {
  let component: AuthorisedsignatoryComponent;
  let fixture: ComponentFixture<AuthorisedsignatoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthorisedsignatoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthorisedsignatoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
// import { Taxstructure } from 'src/app/mcore-product/mcore-shared/mcore-entity/taxstructure';
import * as moment from "moment"
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { TaxstructureService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/taxstructure.service';
@Component({
  selector: 'app-taxstructure',
  templateUrl: './taxstructure.component.html',
  styleUrls: ['./taxstructure.component.css'],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})


export class TaxstructureComponent implements OnInit {
  @ViewChild('picker',{static: true}) picker;
  @ViewChild('picker1',{static: true}) picker1;
  invalidvalue: boolean;
  exmpted: any;
  open() {
    this.picker.open();
    this.picker1.open();
  }
  AddTaxStructure: FormGroup;
  Search_Tax_Structure: FormGroup;
  taxdetail: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  submitted2: boolean;
  submitted3: boolean;
  display: string = 'none';
  TaxDetailed: any[] = [];
  Taxdetailedadded: boolean;
  message: any;
  SubchannelHeading: string = 'Add New-Tax Structure';
  SubchannelHeading1: string = "Tax Details";
  view: boolean = false;
  saveBtnMode: boolean = true;
  view1: boolean = false;
  config: { itemsPerPage: number; currentPage: number; totalItems: number; };
  saveBtnMode1: boolean = true;

  dummyObj =
    [{ ID: '2', Name: 'Agent' }]
    row=[1,2,3,4,5,6,7,8,9,10]
  BRANCH = [
    { Id: '2', Name: 'Bangalore' },
    { Id: '3', Name: 'Kolkata' },
    { Id: '4', Name: 'Mumbai' }
  ]
  invalidDate: boolean;
  validform: boolean;
  Taxobj: any;
  taxIndex: any;
  invalidtax: boolean;
  alltax: any;
  success: boolean;
  transaction: string;
  exist: boolean;
  textSaveBtn: string;
  TaxStructure: any;
  error: boolean;
  taxStructureID: any;



  constructor(private fb: FormBuilder, private taxservice: TaxstructureService) { }

  ngOnInit() {
    this. getAllStatesWithCountry()
    this.getalltaxstructure()
    this.Search_Tax_Structure = this.fb.group({
      TaxStructureName: [''],
      BasedOn: ['']
    })
    this.addtaxdetailsform()
    this.addtaxstructureform()
  }

  addtaxdetailsform() {
    this.taxdetail = this.fb.group({
      // taxstructuredetailsID: [''],
      // taxstructureID: [''],
      taxStructureDetailsName: ['', Validators.required],
      parentTaxStructure: [1],
      parentTax: [''],
      modeID: ['', Validators.required],
      value: ['', Validators.required],
      rowNumber: [1, Validators.required],
      hierarchyID: [''],
      createdBy: [1],
      createdOn: [null],
      isActive: [1],
      // MODIFIEDBY
      // MODIFIEDON
      // DELETEDBY
      // DELETEDON
    })
  }
  addtaxstructureform() {
    this.AddTaxStructure = this.fb.group({
      taxstructureID: [0],
      taxStructureName: ['', [Validators.required]],
      description: ['', [Validators.required]],
      fromDate: ['', [Validators.required]],
      toDate: ['', [Validators.required]],
      exemptedInID: this.fb.array([]),
      createdBy: [1],
      createdOn: [null],
      isActive: [1],
      taxDetails: this.fb.array([]),
      modifiedBy: [1],
      modifiedOn: [null],
      // DELETEDBY
      // DELETEDON
    })
  }
  onCheckChange(event: any) {
    console.log(event)
    console.log(event.source.value)
    const formArray: FormArray = this.AddTaxStructure.get('exemptedInID') as FormArray;
    /* Selected */
    if (event.checked) {
      // Add a new control in the arrayForm
      formArray.push(new FormControl(event.source.value));
    }
    /* unselected */
    else {
      // find the unselected element
      let i: number = 0;

      formArray.controls.forEach((ctrl: FormControl) => {
        if (ctrl.value == event.source.value) {
          // Remove the unselected element from the arrayForm
          formArray.removeAt(i);
          return;
        }

        i++;
      });
    }
  }
  getalltaxstructure() {

    // ===========get all tax structure===================

    this.taxservice.GetAllTaxStructure()
      .subscribe(result => {
        console.log(result)
        this.alltax = result.data
        if (this.alltax) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.alltax.length
          }
        }
      });
  }
  getAllStatesWithCountry() {

    // ===========get all tax structure===================

    this.taxservice.getAllStatesWithCountry()
      .subscribe(result => {
        console.log(result)
        this.exmpted = result.data
 
      });
  }

  

  get a() { return this.AddTaxStructure.controls; }

  addTaxStructure() {
    this.submitted2 = true;
    console.log(this.AddTaxStructure.value)
    this.AddTaxStructure.value['taxDetails'] = this.TaxDetailed
    if (this.AddTaxStructure.valid) {
      let fromvalue = moment(new Date(this.AddTaxStructure.value["fromDate"])).format('YYYY/MM/DD')
      let tovalue = moment(new Date(this.AddTaxStructure.value["toDate"])).format('YYYY/MM/DD')
      let fromDate = moment(fromvalue);
      let toDate = moment(tovalue);
      let result1 = fromDate.diff(toDate, 'days');
      console.log(result1)
      if (result1 >= 0) {
        this.openModalDialog1()
        this.invalidDate = true
        console.log("From Date should not be greater than or equal To Date")
      }
      if (this.AddTaxStructure.valid && !this.invalidDate) {
        this.validform = true
        console.log(this.AddTaxStructure.value)
        this.AddTaxStructure.value["fromDate"]=moment(new Date(this.AddTaxStructure.value["fromDate"])).format('DD-MM-YYYY ')
        this.AddTaxStructure.value["toDate"]=moment(new Date(this.AddTaxStructure.value["toDate"])).format('DD-MM-YYYY ')
        // let message = " Successfully Added Tax Structure"
        // this.openModalDialog(message);
        // if (this.textSaveBtn === 'Save') {
        this.IsTaxStructureExist(this.AddTaxStructure.value)
        // }
        // this.validatxdetails()
        // this.AddTaxStructure.reset();
        // this.taxdetail.reset()
      }

    }

  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  validatxdetails() {
    console.log(this.AddTaxStructure.value['taxDetails'].length)
    if (!this.AddTaxStructure.value['taxDetails']) {
      let message = "Please fill Tax Structure details"
      this.openModalDialog1()
      this.invalidtax = true
    }
    else if (this.AddTaxStructure.value['taxDetails']) {

      // this.AddTaxStructure.value['taxDetails'].push(this.TaxDetailed)  
      this.TaxDetailed = [];
      let message = " Successfully Added Tax Structure"
      this.openModalDialog(message);
    }
  }

  clearTaxStructure() {
    this.submitted2 = false;
    this.submitted3 = false;
    this.SubchannelHeading = 'Add New - Tax Structure';
    this.SubchannelHeading1 = 'Tax Details';
    this.AddTaxStructure.reset();
    this.taxdetail.reset();
    this.saveBtnMode = true;
    this.saveBtnMode1=true
    this.TaxDetailed = []
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
    this.addtaxstructureform()
    this.addtaxdetailsform()

  }


  deletetaxstructure() {
    // =============delete tax structure========//


    this.taxservice.DeleteTaxStructure(this.taxStructureID)
      .subscribe(result => {
        console.log(result)
        this.getalltaxstructure()
      });
  }
  setIdDelete(data){
    this.taxStructureID=data.taxStructureID

  }
  deleteTaxDetail(index) {
    if (index !== -1) {
      this.TaxDetailed.splice(index, 1);
    }
    console.log()
  }
  get t() { return this.taxdetail.controls; }

  AddTaxDetail() {
    this.submitted3 = true;
    console.log(this.taxdetail.value)
    if (this.taxdetail.value["modeID"]=== "2" && this.taxdetail.value["value"]>100) {
      this.invalidvalue = true
      console.log(this.invalidvalue)
      let msg = "Value cannot be greater than 100%."
      this.openModalDialog1()
      console.log("Value  cannot be greater than 100%.")
    }
    if (this.taxdetail.valid && !this.invalidvalue) {
      this.Taxdetailedadded = true
      let detailed = {};
      detailed = this.taxdetail.value;
      this.TaxDetailed.push(this.taxdetail.value)
      this.validform = true
      let message = " Succesfully Added Tax Detail"
      this.openModalDialog(message);
      let result = this.TaxDetailed
      this.taxdetail.reset()
      this.submitted3 = false;
      // =============insert tax detail========//      

      // this.taxservice.InsertTaxStructureDetails(result)
      // .subscribe(result => {
      //   console.log(result)
      //   let module = result.data
      // });
    }

  }
  cleartaxdetail() {
    this.submitted3 = false;
    this.taxdetail.reset();

    if (this.SubchannelHeading != 'View - Tax Structure') {
      this.SubchannelHeading1 = 'Tax Details';
    }

    this.saveBtnMode1 = true;

    if (this.view1 === true) {
      this.view1 = false
      console.log(this.view1)
    }
  }

  deletetaxdetails() {

    // =============delete tax detail========//

    this.taxservice.DeleteTaxStructureDetails(1)
      .subscribe(result => {
        console.log(result)
        let module = result.data
      });
  }

  get s() { return this.Search_Tax_Structure.controls; }

  SearchTax() {
    this.submitted = true;
    console.log(this.Search_Tax_Structure.value)
    let result = this.Search_Tax_Structure.value['TaxStructureName']
    // =============search============//
    this.taxservice.GetAllTaxStructureBasedonTaxName(result)
      .subscribe(result => {
        console.log(result)
        this.alltax = result.data
      });

  }
  clearSearch() {
    this.submitted = false;
    this.Search_Tax_Structure.reset();
    this.getalltaxstructure()
  }

  IsTaxStructureExist(data: any) {
    this.taxservice.IsTaxStructureExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data.message === "NOTEXISTS") {
          this.taxservice.InsertOrUpdateTaxStructure(this.AddTaxStructure.value)
            .subscribe(result => {
              console.log(result)
              if (result.data.TaxStructureId > 0) {
                this.TaxDetailed = []
                this.success = true
                this.validform = true
                this.transaction = "Tax Structure Created Successfully"
                this.openModalDialog(this.transaction)
              }
              else {
                this.error = true
                this.transaction = "Failed to insert Tax Structure data"
                this.openModalDialog(this.transaction)
              }
              this.success = true
              this.validform = true
              this.transaction = "Tax Structure Created Successfully"
              this.openModalDialog(this.transaction)
              this.getalltaxstructure()
              this.clearTaxStructure()
            });
        }
        else {
          this.exist = true
          this.openModalDialog1()
        }

      });
  }
  restrictSpecialchar(event: any) {
    var a = event.target.value;
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
        if ((keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
  }
  NumValidate(event: any) {
    var a = event.target.value;
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
  }
  dateValidate(event: any){
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (charCode===32||(charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222)||(charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)
       
        event.preventDefault();
      }
    }
  }
  btngView_Click(data) {
    console.log(data.taxStructureID)
    this.SubchannelHeading = 'View - Tax Structure';
    this.SubchannelHeading1 = 'View - Tax Details';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.gettaxdetailsbyid(data.taxStructureID)
  }
  gettaxdetailsbyid(id) {

    // ===========get tax detail by id===================

    this.taxservice.GetTaxStructureDetailsByID(id)
      .subscribe(result => {
        console.log(result)
        this.TaxStructure = result.data.TaxStructureModal
        console.log(this.TaxStructure)
        if (this.TaxStructure) {
          this.AddTaxStructure = this.fb.group({
            taxstructureID: [{ value: this.TaxStructure.taxStructureID, disabled: false }],
            taxStructureName: [{ value: this.TaxStructure.taxStructureName, disabled: false }, Validators.required],
            description: [{ value: this.TaxStructure.description, disabled: false }, Validators.required],
            fromDate: [{ value: new Date(this.TaxStructure.fromDate), disabled: false }, Validators.required],
            toDate: [{ value: new Date(this.TaxStructure.toDate), disabled: false }, Validators.required],
            exemptedInID: [{ value: this.TaxStructure.exemptedInID, disabled: false }],
            isActive: [{ value: this.TaxStructure.isActive, disabled: false }],
          })
          this.TaxDetailed = this.TaxStructure.taxStructureDetails
          console.log(this.TaxDetailed)
          console.log(this.AddTaxStructure.value)
          console.log(new Date(this.TaxStructure.fromDate))
        }
      });
  }

  btngViewTaxdetail_Click(i) {
    this.taxIndex = i
    this.SubchannelHeading1 = 'View - Tax Details';
    this.view1 = true
    console.log(this.view)
    this.saveBtnMode1 = false;
    this.gettaxDetails()
  }
  gettaxDetails() {
    this.Taxobj = this.TaxDetailed[this.taxIndex];
    console.log(this.Taxobj)
    if (this.Taxobj) {
      this.taxdetail = this.fb.group({
        taxstructuredetailsID: [{ value: this.Taxobj.taxstructuredetailsID, disabled: false }],
        taxstructureID: [{ value: this.Taxobj.taxstructureID, disabled: false }],
        parentTaxStructure: [{ value: this.Taxobj.parentTaxStructure, disabled: false }],
        taxStructureDetailsName: [{ value: this.Taxobj.taxStructureDetailsName, disabled: false }, Validators.required],
        parentTax: [{ value: this.Taxobj.parentTax, disabled: false }],
        modeID: [{ value: this.Taxobj.modeID, disabled: false }, Validators.required],
        value: [{ value: this.Taxobj.value, disabled: false }, Validators.required],
        rowNumber: [{ value: this.Taxobj.rowNumber, disabled: false }, Validators.required],
        hierarchyID: [{ value: this.Taxobj.hierarchyID, disabled: false }],
        isActive: [{ value: this.Taxobj.isActive, disabled: false }],

      })
      console.log(this.taxdetail.value)
    }
  }
  openModalDialog(message) {
    this.message = message
    this.display = 'block'; //Set block css
  }

  openModalDialog1() {
    this.display = 'block'; //Set block css
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    if (this.validform) {
      this.validform = false
    }
    if (this.invalidDate) {
      this.invalidDate = false
    }
    this.invalidtax = false
    this.error = false
    this.invalidvalue=false
  }




}






// DeleteTaxStructure


// GetAllTaxStructure

// GetTaxStructureDetailsByID




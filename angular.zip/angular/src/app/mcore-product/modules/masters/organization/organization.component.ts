import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Organization } from 'src/app/mcore-product/mcore-shared/mcore-entity/organization';
import { OrganizationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/organization.service';
import { AddressService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/address.service';
import { Address, country, state, district, postOffice } from 'src/app/mcore-product/mcore-shared/mcore-entity/address';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
@Component({
  selector: 'app-organization',
  templateUrl: './organization.component.html',
  styleUrls: ['./organization.component.css']
})
export class OrganizationComponent implements OnInit {

  organizationForm: FormGroup;
  get organizationFormAction() {
    return this.organizationForm.get('organizationFormAction') as FormGroup;
  }
  constructor(private fb: FormBuilder, private addressService: AddressService, private organizationService: OrganizationService, private BranchService: BranchService) { }
  organizationGridObj: Organization[];
  organizationFilterGridObj: Organization[];
  addressObj: Address[];
  countryObj: country[];
  stateObj: state[];
  districtObj: district[];
  talukObj: postOffice[];
  selectedValue: number;
  createBtn: boolean;
  actionHeading: string;
  saveBtnMode: boolean;
  fieldDisable: Boolean;
  textSaveBtn: string;
  organizationColumns: string[] = ['View', 'Edit', 'shortName', 'organisationName'];
  dataSource = new MatTableDataSource<Organization>(this.organizationGridObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngOnInit() {
    this.dataSource = new MatTableDataSource<Organization>(this.organizationGridObj);
    this.actionHeading = 'Add New - Organization';
    this.saveBtnMode = true;
    this.createBtn = true;
    this.textSaveBtn = 'Save';
    this.getOrganizationGridDetails();
    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({

        organisationId: [''],
        shortName: ['', [Validators.required]],
        organisationName: ['', [Validators.required]],
        address1: ['', [Validators.required]],
        address2: [''],
        address3: [''],
        countryId: ['', [Validators.required]],
        stateId: [''],
        districtId: [''],
        talukId: [''],
        zipCode: ['', [Validators.required]],
        phoneNo: [''],
        mobileNo: [''],
        conferenceNo: [''],
        faxNo: [''],
        email: ['', [Validators.email]],
        gstNo: [''],
        panNo: ['', [Validators.required, Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$'), Validators.minLength]],
        sacCode: ['', [Validators.required]]

      })

    });



    this.getAllCountries();
  }

  allowNumberFn(event) {
    const keyCode = event.keyCode;

    const excludedKeys = [8, 37, 39, 46];

    if (!((keyCode >= 48 && keyCode <= 57) ||
      (keyCode >= 96 && keyCode <= 105) ||
      (excludedKeys.includes(keyCode)))) {

      event.preventDefault();
    }
  }
  getOrganizationGridDetails(): void {
    this.organizationService.getOrganizationGridDetails().subscribe(a => {
      this.organizationGridObj = a;

      this.dataSource = new MatTableDataSource<Organization>(this.organizationGridObj);
      this.dataSource.data = this.organizationGridObj = a;
      this.dataSource.paginator = this.paginator;
    });

  }
  btngvView_Click(a) {
    // this.getAllCountries();
    this.actionHeading = 'View - Organization';
    this.saveBtnMode = false;
    this.fieldDisable = true;
    this.organizationFilterGridObj = this.organizationGridObj.filter((unit) => unit.organisationId == a);



    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({

        organisationId: this.organizationFilterGridObj[0].organisationId,
        shortName: this.organizationFilterGridObj[0].shortName,
        organisationName: this.organizationFilterGridObj[0].organisationName,
        address1: this.organizationFilterGridObj[0].address1,
        address2: this.organizationFilterGridObj[0].address2,
        address3: this.organizationFilterGridObj[0].address3,
        countryId: this.organizationFilterGridObj[0].countryId,
        stateId: this.organizationFilterGridObj[0].stateId,
        districtId: this.organizationFilterGridObj[0].districtId,
        talukId: this.organizationFilterGridObj[0].talukId,
        zipCode: this.organizationFilterGridObj[0].zipCode,
        phoneNo: this.organizationFilterGridObj[0].phoneNo,
        mobileNo: this.organizationFilterGridObj[0].mobileNo,
        conferenceNo: this.organizationFilterGridObj[0].conferenceNo,
        faxNo: this.organizationFilterGridObj[0].faxNo,
        email: this.organizationFilterGridObj[0].email,
        gstNo: this.organizationFilterGridObj[0].gstNo,
        panNo: this.organizationFilterGridObj[0].panNo,
        sacCode: this.organizationFilterGridObj[0].sacCode

      })

    });

  }

  btngvEdit_Click(a) {
    this.actionHeading = 'Edit - Organization';
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.createBtn = false;
    this.organizationFilterGridObj = this.organizationGridObj.filter((unit) => unit.organisationId == a);



    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({
        organisationId: this.organizationFilterGridObj[0].organisationId,
        shortName: this.organizationFilterGridObj[0].shortName,
        organisationName: this.organizationFilterGridObj[0].organisationName,
        address1: this.organizationFilterGridObj[0].address1,
        address2: this.organizationFilterGridObj[0].address2,
        address3: this.organizationFilterGridObj[0].address3,
        countryId: this.organizationFilterGridObj[0].countryId,
        stateId: this.organizationFilterGridObj[0].stateId,
        districtId: this.organizationFilterGridObj[0].districtId,
        talukId: this.organizationFilterGridObj[0].talukId,
        zipCode: this.organizationFilterGridObj[0].zipCode,
        phoneNo: this.organizationFilterGridObj[0].phoneNo,
        mobileNo: this.organizationFilterGridObj[0].mobileNo,
        conferenceNo: this.organizationFilterGridObj[0].conferenceNo,
        faxNo: this.organizationFilterGridObj[0].faxNo,
        email: this.organizationFilterGridObj[0].email,
        gstNo: this.organizationFilterGridObj[0].gstNo,
        panNo: this.organizationFilterGridObj[0].panNo,
        sacCode: this.organizationFilterGridObj[0].sacCode

      })

    });

  }
  getAddressDetails(e) {
    // zipcode = 625203;

    this.addressService.getAddressByIDzipCode(e.target.value)
      .subscribe(addressObj => {
        this.addressObj = addressObj;

      });


  }

  getAllCountries() {
    this.addressService.getAllCountries()
      .subscribe(a => {
        this.countryObj = a;

      });
    let c = this.organizationForm.get('organizationFormAction.countryId').value;
    //console.log('Country Id test', c);
    if(c != ''){
      this.getAllStates(c);
    }
    
  }

  change_country_fn() {
    let a = this.organizationForm.get('organizationFormAction.countryId').value;
    this.getAllStates(a);

  }

  getAllStates(a) {
    this.addressService.getAllStates(a)
      .subscribe(b => {
        this.stateObj = b;

      });


  }

  getAllDistricts(a) {
    this.addressService.getAllDistricts(a)
      .subscribe(districtObj => {
        this.districtObj = districtObj;
      });


  }
  getAllTaluk(a) {
    this.addressService.getAllTaluk(a)
      .subscribe(a => {
        this.talukObj = a;
      });


  }
  change_state_fn() {
    let a = this.organizationForm.get('organizationFormAction.stateId').value;

    this.getAllDistricts(a);
  }


  change_district_fn() {
    let a = this.organizationForm.get('organizationFormAction.districtId').value;

    this.getAllTaluk(a);
  }



  onBtnSaveOrganization() {
    this.organizationForm.get('organizationFormAction').markAllAsTouched();
    if (this.organizationForm.get('organizationFormAction').valid) {
      if (this.createBtn) {



        this.organizationForm.get('organizationFormAction').patchValue({
          organisationId: '0'
        });
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('noOfDays', new FormControl(1));
        this.organizationFormAction.addControl('isActive', new FormControl(1));
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('createdOn', new FormControl(new Date()));


        let a = this.organizationForm.get('organizationFormAction').value;
        if (this.organizationGridObj.length < 1) {
          console.log("create");
          this.organizationService.createOrganization(a).subscribe(a => {
  
            this.getOrganizationGridDetails();
          });
        }


      } else {
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('noOfDays', new FormControl(1));
        this.organizationFormAction.addControl('isActive', new FormControl(1));
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('createdOn', new FormControl(new Date()));

        let a = this.organizationForm.get('organizationFormAction').value;
        if (this.organizationGridObj.length <= 1) {
          console.log("edit org");
          this.organizationService.createOrganization(a).subscribe(a => {
  
            this.getOrganizationGridDetails();
          });
        }
      }

     


      this.onBtnClearAction();
    }
  }

  onBtnClearAction() {
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.actionHeading = 'Add New - Organization';

    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({

        organisationId: '',
        shortName: '',
        organisationName: '',
        address1: '',
        address2: '',
        address3: '',
        countryId: '',
        stateId: '',
        districtId: '',
        talukId: '',
        zipCode: '',
        phoneNo: '',
        mobileNo: '',
        conferenceNo: '',
        faxNo: '',
        email: ['', [Validators.email]],
        gstNo: '',
        panNo: '',
        sacCode: '',

      })

    });

  }

  cfn(a) {
    console.log(a);
  }



  GstnValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      // State code
      if (l <= 1) {
        console.log(l)

        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN alphabets
      else if (l >= 2 && l <= 6) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN numeric
      else if (l > 6 && l <= 10) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      } // PAN alphabet
      else if (l >= 11 && l < 12) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 12 && l < 13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // alphabet
      else if (l >= 13 && l < 14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 14 && l < 15) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 15) {

        event.preventDefault();

      }

    }
  }

  pinValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }

  detectpin(event: any) {
    //console.log(event.target.value.length);
    if (event.target.value.length === 6) {
      this.getdetailsbypin(this.organizationFormAction.value["zipCode"])
    }
  }
  pinobj: any;
  getdetailsbypin(a) {
   // console.log(a)
    this.BranchService.GetAllDetailsByZipCode(a)
      .subscribe(result => {
      //  console.log(result)
        if (result.data.length > 0) {
          this.pinobj = result.data[0]
          this.getAllStates(this.pinobj.countryID)
          this.getAllDistricts(this.pinobj.stateID)
          this.getAllTaluk(this.pinobj.districtID)
          let pin = {
            countryId: this.pinobj.countryID,
            stateId: this.pinobj.stateID,
            districtId: this.pinobj.districtID,
            talukId: this.pinobj.talukID,
          }
          console.log(pin);
          this.organizationFormAction.patchValue(pin);
        }
        else {
          let pin = {
            countryId: '',
            stateId: '',
            districtId: '',
            talukId: '',
          }

          this.organizationFormAction.patchValue(pin);
        }

      });
  }
}

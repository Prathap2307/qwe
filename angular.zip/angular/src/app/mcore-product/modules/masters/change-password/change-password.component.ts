import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MustMatch } from 'src/app/mcore-product/mcore-shared/mcore-helpers/must-matchvalidator';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  account: FormGroup;
  submitted1: boolean
  display: string;
  msg: any;
  userName: any;
  userID: any;
  constructor(private fb:FormBuilder, private user: UserService, private el: ElementRef) { }


  ngOnInit() {
    console.log(localStorage.getItem('userID'))
    this.userID = localStorage.getItem('userID')
    this.userName = localStorage.getItem('userName')

    this.account = this.fb.group({

    OldPassword  :['',[Validators.required]],
    NewPassword :['',[Validators.required, Validators.pattern('(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$')]] ,    
    ConfirmPassword :['',[Validators.required]]

     },
     {
      validator: MustMatch('NewPassword', 'ConfirmPassword')
  } )
  }

  onsubmit() {
    for (const key of Object.keys(this.account.controls)) {
      if (this.account.controls[key].invalid) {
        const invalidControl = this.el.nativeElement.querySelector('[formcontrolname="' + key + '"]');
        invalidControl.focus();
        break;
      }
    }
if(this.account.valid){
  console.log(this.account.value);
  this.submitted1 = true
  if (this.account.value)
    this.account.value["userID"] = this.userID
  this.account.value["userName"] = this.userName

  {
    this.user.changepwd(this.account.value)
    .subscribe(result => {
      console.log(result)
      this.msg = result.data

    });
    console.log(this.account.value);
    this.openModalDialog()
  }
}

  }
  
  Cancel(){
    this.account.reset()
  }
  get am() { return this.account.controls; }
  
  get passwordError() {

    if (this.account.controls['NewPassword'].hasError('required')) {
      return 'Please enter the Password';
    } 
    else if (this.account.controls['NewPassword'].hasError('pattern')) {
        return 'Password must contain Minimum 8 Characters,Minimum 1 Alphabet,Minimum 1 Numeric,Minimum 1 Special Character and No Spaces';
      }
    }

    get confirmpasswordError() {

      if (this.account.controls['ConfirmPassword'].hasError('required')) {
        return 'Please confirm  the Password';
      } 
   else if (this.account.controls['ConfirmPassword'].hasError('mustMatch')) {
          return ' confirm password must match password';
        }
      }

      openModalDialog() {
        this.display = 'block'; //Set block css
        this.submitted1 = false
        this.account.reset()
    
    
      }
    
      closeModalDialog() {
        this.display = 'none'; //set none css after close dialog
      }


}

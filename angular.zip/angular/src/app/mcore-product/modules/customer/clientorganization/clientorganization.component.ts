import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { TooltipPosition } from '@angular/material';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import { MatTableDataSource } from '@angular/material/table';
import { ClientOrgService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/client-org.service';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
import { MasterPolicyService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/master-policy.service';
@Component({
  selector: 'app-clientorganization',
  templateUrl: './clientorganization.component.html',
  styleUrls: ['./clientorganization.component.css']
})
export class ClientorganizationComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  dummyObj: string[];
  dataObj;
  salutation: any;
  country: any;
  state: any;
  District: any;
  pinobj: any;
  address: any;
  Taluka: any;
  change: boolean;
  clientformdetails: FormGroup;
  gradeform: FormGroup;
  addressform: FormGroup;
  IsgstType: boolean;
  submitted: boolean;
  show: boolean;
  gradelist: any[] = [];
  gradeIndex: any;
  saveBtnMode1: boolean;
  view1: boolean;
  gradeSaveBtn: string = 'Save';
  gradeobj: any;
  deletebtn: any;
  id: any;
  gradedelete: boolean;
  Addressdata: any[] = [];
  transaction: string;
  validaddress: boolean;
  msg: any;
  display: any = 'none';
  validform: boolean;
  addressid: any;
  adressSaveBtn: string = 'Save address';
  AddAdressBtnMode: boolean;
  addressdelete: boolean;
  organisationID: string;
  allbranch: any;
  textSaveBtn: string = 'Save';
  allclient: any;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  clientHeading: string = 'Add New - Client Organization';
  saveBtnMode: boolean=true;
  view: boolean;
  searchform: FormGroup;
  clientobj: any;
  fieldDisable: boolean;
  saveBtnMode2: boolean=true;
  risk=[{"ID":1,"Name":"Preferred"},{"ID":2,"Name":"Medium"},{"ID":3,"Name":"High"},{"ID":4,"Name":"Negative"},]
  client = [{ ID: '1', Name: 'Regular Customer' },
  { ID: '2', Name: 'SEZ Customer' },]
  gst = [{ ID: '1', Name: 'GST' },
  { ID: '2', Name: 'NO GST' },]
  sezgst_ = [{ ID: '3', Name: 'GST Payable ' },
  { ID: '4', Name: 'NO GST Payable' },]
  showgst: any[];
  addressType: any;
  enabled: boolean=true;
  filteredItems: any;
  autocompletedata: any;

  constructor(private user: UserService, private masterpolicyservice: MasterPolicyService, private fchannelService: FchannelService,private fb: FormBuilder, private BranchService: BranchService, private clientOrgService: ClientOrgService) { }

  ngOnInit() {
    console.log(localStorage.getItem('organisationID'))
    this.organisationID = localStorage.getItem('organisationID')
    this.GetAllcountries()
    this.getaddresstype() 
    this.GetAllSalutation()
    this.getallbranches()
    this.getallclient()
    this.clientform()
  }
  clientform() {
    this.searchform = this.fb.group({
      groupName: ['',],
      customerGroupId: ['',],
      contactFirstName: ['',],
      contactLastName: ['',],
      branchId: ['',],
    })
    this.clientformdetails = this.fb.group({
      groupId: ['',],
      groupName: ['',],
      customerGroupId: ['',],
      coreBusiness: ['',],
      salutationId: ['', Validators.required],
      contactFirstName: ['', Validators.required],
      contactMiddleName: ['',],
      contactLastName: ['',],
      contact: ['',],
      masterPolicyAgeem: ['',],
      agreementStartDate: ['',],
      agreementEndDate: ['',],
      branchId: ['',],
      email: ['',],
      employeeURLKey: ['',],
      password: ['',],
      logo: ['',],
      createdBy: ['',],
      createdOn: ['',],
      isActive: ['',],
      isSms: [0,],
      isEmail: [0,],
      shortName: ['',],
      riskCategoryId: ['',],
      turnOver: ['',],
      salesHierarchyId: ['',],
      isParentGroup: ['',],
      parentGroupId: ['',],
      hierarchyId: ['',],
      panNo: ['',[ Validators.required,Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]],
      gstNo: ['',],
      clientTypeId: ['',],
      gstTypeId: ['',],
      sacCode: ['',],
      MasterGrade: this.fb.array([
      ]),
      clientAddressDetails: this.fb.array([
      ]),
    })
    this.gradeform = this.fb.group({
      gradeId: ['',],
      description: ['',],
    })

    this.addressform = this.fb.group({
      addressID: ['',],
      address1: ['', Validators.required],
      address2: ['',],
      address3: ['',],
      address4: ['',],
      address5: ['',],
      countryID: ['', Validators.required],
      stateID: ['', Validators.required],
      districtID: ['', Validators.required],
      talukID: ['',],
      zipCode: ['', Validators.required],
      phoneNo: ['',],
      mobileNo: ['',],
      email: ['',],
      createdBy: ['',],
      createdOn: ['',],
      isActive: ['',],
      addressTypeTypeID: ['',],
    })
    this.IsgstTypeId()
  }
  clientColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];


  get co() { return this.clientformdetails.controls; }
  get addr() { return this.addressform.controls; }
  getallclientorganisation() {

  }
  getallbranches() {
    let branch = {
      "OrganisationID": this.organisationID,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
      });
  }
  IsgstTypeId() {
    this.clientformdetails.get('gstTypeId').valueChanges.subscribe((data: number) => {
      console.log(data)
      this.onchangeIsgstTypeId(data)
    }
    )
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  getallclient() {
    this.clientOrgService.getALlClientOrg()
      .subscribe(result => {
        console.log(result)
        this.allclient = result.list
        if (this.allclient) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allclient.length
          }
        }
      }

      )
  }

  search() {
    console.log(this.searchform.value)
    this.clientOrgService.search(this.searchform.value)
      .subscribe(result => {
        console.log(result)

      })
  }
  clear(){
    this.searchform.reset()
  }
  btngEdit_Click(id: any) {
    this.clientHeading = 'Edit - Client Organization';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.getbyid(id)
    this.fieldDisable = false;
  }
  btngView_Click(id: any) {
    this.clientHeading = 'View - Client Organization';
    this.saveBtnMode = false;
    this.view = true;
    this.getbyid(id)
    this.fieldDisable = true;
  }
  getbyid(id) {
    this.clientOrgService.getClientById(id)
      .subscribe(result => {
        console.log(result)
        this.clientobj=result.masterGroupDetails
        this.clientformdetails = this.fb.group({
          groupId: { value: this.clientobj.groupId, disabled: false },
          groupName: [{ value: this.clientobj.groupName, disabled: false },],
          customerGroupId: [{ value: this.clientobj.customerGroupId, disabled: false },],
          coreBusiness: [{ value: this.clientobj.coreBusiness, disabled: false },],
          salutationId: [{ value: this.clientobj.salutationId, disabled: false }, Validators.required],
          contactFirstName: [{ value: this.clientobj.contactFirstName, disabled: false }, Validators.required],
          contactMiddleName: [{ value: this.clientobj.contactMiddleName, disabled: false },],
          contactLastName: [{ value: this.clientobj.contactLastName, disabled: false },],
          contact: [{ value: this.clientobj.contact, disabled: false },],
          masterPolicyAgeem: [{ value: this.clientobj.masterPolicyAgeem, disabled: false },],
          agreementStartDate: [{ value: this.clientobj.agreementStartDate, disabled: false },],
          agreementEndDate: [{ value: this.clientobj.agreementEndDate, disabled: false },],
          branchId: [{ value: this.clientobj.branchId, disabled: false },],
          email: [{ value: this.clientobj.email, disabled: false },],
          employeeURLKey: [{ value: this.clientobj.employeeURLKey, disabled: false },],
          password: [{ value: this.clientobj.password, disabled: false },],
          logo: [{ value: this.clientobj.logo, disabled: false },],
          createdBy: [{ value: this.clientobj.groupId, disabled: false },],
          createdOn: ['',],
          isActive: ['',],
          isSms: [{ value: this.clientobj.isSms, disabled: false },,],
          isEmail: [{ value: this.clientobj.isEmail, disabled: false },],
          shortName: [{ value: this.clientobj.shortName, disabled: false },],
          riskCategoryId: [{ value: this.clientobj.riskCategoryId, disabled: false },],
          turnOver: [{ value: this.clientobj.turnOver, disabled: false },],
          salesHierarchyId: [{ value: this.clientobj.salesHierarchyId, disabled: false },],
          isParentGroup: [{ value: this.clientobj.isParentGroup, disabled: false },],
          parentGroupId: [{ value: this.clientobj.parentGroupId, disabled: false },],
          hierarchyId: [{ value: this.clientobj.hierarchyId, disabled: false },],
          panNo: [{ value: this.clientobj.panNo, disabled: false },],
          gstNo: [{ value: this.clientobj.gstNo, disabled: false },],
          clientTypeId: [{ value: this.clientobj.clientTypeId, disabled: false },],
          gstTypeId: [{ value: this.clientobj.gstTypeId, disabled: false },],
          sacCode: [{ value: this.clientobj.sacCode, disabled: false },],
        })
        this.Addressdata=this.clientobj.clientAddressDetails
        this.gradelist=this.clientobj.MasterGrade
      })
  }
  cancel(){
    this.textSaveBtn = 'Save'
    this.Addressdata = []
    this.gradelist = []
    this.clientformdetails.reset();
    this.clientHeading = 'Add New - Client Organization';
    this.cancelGrade()
    this.Addresscancel()
    this.saveBtnMode = true;
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  isparent(event:any){
    console.log(event)
    if(event.checked===true){
      this.enabled=false
    }
  else{
    this.enabled=true
  }
  }
  onchangeIsgstTypeId(selected: any) {
    this.IsgstType = false

    console.log(selected);
    const gstNo = this.clientformdetails.get('gstNo')


    if (selected === "1" || selected === "3") {
      this.submitted = false

      gstNo.setValidators(Validators.required);

      this.show = true;
    }
    else {
      gstNo.clearValidators();

      this.show = false
    }
    gstNo.updateValueAndValidity();
  }
  // bindsearchdata(data: any) {
  //   console.log(data)
  //   this.autocompletedata = data
  //   this.masterpolicyservice.getbygroupid(data.groupId).subscribe(res => {
  //     console.log(res)
  //   })
  // }
deleteclient(){
  this.clientOrgService.addClientOrganization(this.clientformdetails.value)
        .subscribe(result => {
          console.log(result)
        })
}
filterItem(value: any) {
  console.log(value)
  // if(!value){
  //     this.assignCopy();
  // } // when nothing has typed
  if (value) {
    this.masterpolicyservice.search(value)
      .subscribe(result => {
        console.log(result)
        this.filteredItems = Object.assign([], result.list).filter(
          item => item.groupName.toLowerCase().indexOf(value.toLowerCase()) > -1
        )
        console.log(this.filteredItems)
      })
  }
}
Officer(value: any) {
  console.log(value)
  // if(!value){
  //     this.assignCopy();
  // } // when nothing has typed
  if (value) {
    this.clientOrgService.getbyofficercode(value)
      .subscribe(result => {
        console.log(result)
      
        if(  result&& result[0]&&result[0]["FIRSTNAME"]){
          let sales = {
            shortName:   result[0]["FIRSTNAME"],
          }
          this.clientformdetails.patchValue(sales);
        }
       
      })
  }
}
  AddClient() {
    this.clientformdetails.markAllAsTouched()
    console.log(JSON.stringify(this.clientformdetails.value))
    if (this.clientformdetails.value["isSms"] === true) {
      this.clientformdetails.value["isSms"] = 1
    }
    else {
      this.clientformdetails.value["isSms"] = 0
    }
    if (this.clientformdetails.value["isEmail"] === true) {
      this.clientformdetails.value["isEmail"] = 1
    } else {
      this.clientformdetails.value["isEmail"] = 0
    }
    if (this.clientformdetails.valid) {
      this.clientformdetails["clientAddressDetails"] = this.Addressdata
      this.clientformdetails["MasterGrade"] = this.gradelist
      console.log(this.clientformdetails.value)
      this.clientOrgService.addClientOrganization(this.clientformdetails.value)
        .subscribe(result => {
          console.log(result)
          this.validform = true
          if (this.textSaveBtn === 'Update') {
            this.transaction = 'Client Organization updated Successufully'
            this.openModalDialog(this.transaction)
          }
          else {
            this.transaction = 'Client Organization Added Successufully'
            this.openModalDialog(this.transaction)
          }
          this.cancel()
        this.getallclient()
        })
    }

  }
  setIdDelete(i, k) {
    console.log(k)
    this.deletebtn = k
    console.log(this.deletebtn)
    this.id = i
  }
  deleteGrade() {
    if (this.id !== -1) {
      this.gradelist.splice(this.id, 1);
      this.gradedelete = true
    }
    console.log()
  }
  editGrade(i: any) {
    this.gradeIndex = i;
    this.saveBtnMode1 = true;
    this.view1 = false;
    this.gradeSaveBtn = 'Update'
    this.getgrade()
  }
  getgrade() {
    this.gradeobj = this.gradelist[this.gradeIndex];
    console.log(this.gradelist)
    console.log(this.gradeobj)
    this.gradeform = this.fb.group({
      description: [{ value: this.gradeobj.description, disabled: false }]
    })
  }
  addgrade() {
    console.log(this.gradeform.value)
    console.log(this.gradeIndex)
    if (this.gradeIndex === -1 || this.gradeIndex === undefined) {
      this.gradelist.push(this.gradeform.value);
      console.log(this.gradelist)
    } else {
      this.gradelist[this.gradeIndex] = this.gradeform.value
    }
    this.cancelGrade()
    this.gradeIndex=undefined
  }
  cancelGrade() {
    this.gradeform.reset()
    this.gradeSaveBtn = 'Save'
  }


  //addresss
  AddressEdit_Click(id) {
    console.log(id)
    this.saveBtnMode2=true
    this.AddAdressBtnMode = true;
    this.adressSaveBtn = 'Update Address'
    this.addressid = id
    this.addressform = this.fb.group({
      address1: { value: this.Addressdata[id].address1, disabled: false },
      address2: { value: this.Addressdata[id].address2, disabled: false },
      address3: { value: this.Addressdata[id].address3, disabled: false },
      addressTypeID: { value: this.Addressdata[id].addressTypeID, disabled: false },
      zipCode: { value: this.Addressdata[id].zipCode, disabled: false },
      countryID: { value: this.Addressdata[id].countryID, disabled: false },
      stateID: { value: this.Addressdata[id].stateID, disabled: false },
      districtID: { value: this.Addressdata[id].districtID, disabled: false },
      phoneNo: { value: this.Addressdata[id].phoneNo, disabled: false },
      mobileNo: { value: this.Addressdata[id].mobileNo, disabled: false },
      conferenceNo: { value: this.Addressdata[id].conferenceNo, disabled: false },
      faxNo: { value: this.Addressdata[id].faxNo, disabled: false },
      email: { value: this.Addressdata[id].email, disabled: false },
    })
    if (this.Addressdata[id].countryID) {
      this.GetAllStates(this.Addressdata[id].countryID);
    }
    if (this.Addressdata[id].stateID) {
      this.GetAllDistricts(this.Addressdata[id].stateID);
    }
  }

  AddAdress() {
    this.addressform.markAllAsTouched()
    if (this.addressform.valid) {
      this.validform = true
      console.log(this.id)
      if (this.addressid === -1 || this.addressid === undefined) {
        console.log(this.addressform.value)
        this.Addressdata.push(this.addressform.value);
        this.transaction = 'Address Details Added Successufully'
        this.openModalDialog(this.transaction)
        console.log(this.Addressdata);
      } else {
        this.Addressdata[this.addressid] = this.addressform.value;
        this.transaction = 'Address Details Updated Successufully'
        this.openModalDialog(this.transaction)
        console.log(this.Addressdata);
      }
      this.Addresscancel()

    }
  }
  deleteAddress() {
    if (this.id !== -1) {
      this.Addressdata.splice(this.id, 1);
      this.addressdelete = true
    }
    console.log()
  }
  Addresscancel() {
    this.addressform.reset()
    this.AddAdressBtnMode = true;
    this.adressSaveBtn = 'Add Address'
  }
  getaddresstype() {
    this.fchannelService.getaddresstype()
      .subscribe(result => {
        console.log(result)
        this.addressType = result.addressTypeList
      })
  }
  GetAllSalutation() {
    this.user.GetAllSalutation()
      .subscribe(result => {
        console.log(result)
        this.salutation = result.salutationList
      })
  }

  Select_country(event: any) {
    console.log(event.target.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetTaluk(event.target.value);
  }
  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();

        }
        console.log(event.keyCode)
        // event.target.value = event.target.value.slice(0, 5).replace(/[^a-zA-Z]/g, "");
      }
      else if (l >= 5 && l <= 8) {

        console.log(l)
        console.log(charCode)
        // console.log(event.target.value.slice(5,9))
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l >= 8 && l <= 9) {
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  getdetailsbypin(a) {
    console.log(a)
    this.BranchService.GetAllDetailsByZipCode(a)
      .subscribe(result => {
        console.log(result)
        if (result.data.length > 0) {
          this.pinobj = result.data[0]
          this.GetAllStates(this.pinobj.countryID)
          this.GetAllDistricts(this.pinobj.stateID)

          let pin = {
            countryID: this.pinobj.countryID,
            stateID: this.pinobj.stateID,
            districtID: this.pinobj.districtID,

          }

          this.addressform.patchValue(pin);
        }
        else {
          let pin = {
            countryID: '',
            stateID: '',
            districtID: '',
          }

          this.addressform.patchValue(pin);
        }

      });
  }
  typeof(event: any) {
    this.showgst = []
    console.log(event.value)
    if (event.value === "1") {
      this.showgst = this.gst
      console.log(this.gst)
    }
    else if (event.value === "2") {
      this.showgst = this.sezgst_
      console.log(this.sezgst_)
    }
  }
  detectpin(event: any) {
    console.log(event.target.value.length);
    if (event.target.value.length === 6) {
      this.getdetailsbypin(this.addressform.value["zipCode"])
    }
  }
  pinValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    console.log(keychar)
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (  keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  GstnValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      // State code
      if (l <= 1) {
        console.log(l)

        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN alphabets
      else if (l >= 2 && l <= 6) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN numeric
      else if (l > 6 && l <= 10) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      } // PAN alphabet
      else if (l >= 11 && l < 12) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 12 && l < 13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // alphabet
      else if (l >= 13 && l < 14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 14 && l < 15) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 15) {

        event.preventDefault();

      }

    }
  }
  mobValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  
  get PanError() {
    // return this.email.hasError('required') ? 'You must enter a value' :
    //     this.email.hasError('email') ? 'Not a valid email' :
    //         '';
   if (this.clientformdetails.controls['panNo'].hasError('pattern')) {
      return 'Please enter valid PAN Number';
    } else if (this.clientformdetails.controls['panNo'].hasError('minlength')) {
      return 'Please Enter 10 digits of PAN Number.';
    }
  }
  openModalDialog(msg) {
    console.log(this.display)
    this.msg = msg
    this.display = 'block'; //Set block css
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.addressdelete = false
    this.gradedelete = false
    this.validform = false

  }

}

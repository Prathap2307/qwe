import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Claimintimation, BeneficiaryDetails, AdditionalDocument, MandatoryDocument, DocumentUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/claimintimation';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ClaimintimationService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  getGroupDetails(a: any): Observable<MemberUpload[]> {
    const url = this.baseUrl + `/GetGroupDetails`;
    return this.http.post<MemberUpload[]>(url, a)
      .pipe();
  }

  getmasterPolicyDetails(Groupid: number): Observable<MemberUpload[]> {
    const url = this.baseUrl + `/GetMasterPolicyDetails/${Groupid}`;
    return this.http.get<MemberUpload[]>(url)
      .pipe();
  }

  // Get Search Claim Intimation
  getSearchClaimIntimationDetails(masterPolicyNo: string): Observable<Claimintimation[]> {
    const searchClaimIntimationUrl = this.baseUrl + `/searchClaimDetails/${masterPolicyNo}`;
    return this.http.get<Claimintimation[]>(searchClaimIntimationUrl).pipe();
  }

}

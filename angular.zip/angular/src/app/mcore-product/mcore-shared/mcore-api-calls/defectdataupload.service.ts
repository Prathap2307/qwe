import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { DefectDataUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/defectdataupload';


@Injectable({
  providedIn: 'root'
})
export class DefectdatauploadService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  getGroupDetails(a: any): Observable<DefectDataUpload[]> {
    const url = this.baseUrl + `/GetGroupDetails`;
    return this.http.post<DefectDataUpload[]>(url, a)
      .pipe();
  }

  getmasterPolicyDetails(Groupid: number): Observable<DefectDataUpload[]> {
    const url = this.baseUrl + `/GetMasterPolicyDetails/${Groupid}`;
    return this.http.get<DefectDataUpload[]>(url)
      .pipe();
  }
  
  // Get DefectDataUpload 
  DefectDataUploadUrl = this.baseUrl + '/GetallDefectData';
  getAllDefectDataUploadDetails(): Observable<DefectDataUpload[]> {
    return this.http.get<DefectDataUpload[]>(this.DefectDataUploadUrl).pipe();
  }
}

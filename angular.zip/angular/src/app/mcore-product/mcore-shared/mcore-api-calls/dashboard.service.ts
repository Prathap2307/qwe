import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }


  getTotalClientCreated(): Observable<any> {
    const url = this.baseUrl + `/dashBoard`;
    return this.http.get<any>(url)
      .pipe();
  }


}

import { TestBed } from '@angular/core/testing';

import { AdvanceReceiptingService } from './advance-receipting.service';

describe('AdvanceReceiptingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdvanceReceiptingService = TestBed.get(AdvanceReceiptingService);
    expect(service).toBeTruthy();
  });
});

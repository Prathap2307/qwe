import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class MasterPolicyService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  search(data:any): Observable<any> {
    return this.http.get(this.baseUrl + '/client/masterGroupDetails/search?groupName='+data).pipe(tap((response) => response));
  }
  GetAllmasterpolicy(data:any): Observable<any> {
    return this.http.post(this.baseUrl + '/client/search?groupName=',data).pipe(tap((response) => response));
  }
    insertMasterpolicy(data:any): Observable<any> {
    return this.http.post(this.baseUrl + '/client/addMasterPolicyNo/update',data).pipe(tap((response) => response));
  }
  getbygroupid(data:any): Observable<any> {
    return this.http.get(this.baseUrl + '/client/searchMasterPolicyDetailsByGroupId?groupId='+data).pipe(tap((response) => response));
  }
  getbyagreementNumber(data:any): Observable<any> {
    return this.http.get(this.baseUrl + '/client/searchMasterPolicyDetailsByGroupId?groupId='+data.groupId+'&agreementNumber='+data.agreementNumber).pipe(tap((response) => response));
  }
  delete(data:any): Observable<any> {
    return this.http.get(this.baseUrl + '/client/getSearchGroupDetailsByAgreementNo?groupId='+data.groupId+'&agreementNumber='+data.agreementNumber).pipe(tap((response) => response));
  }
  getbyofficercode(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/salesHierarchy/'+data).pipe(tap((response) => response));
  }
}

import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Product, ProductCategory } from 'src/app/mcore-product/mcore-shared/mcore-entity/product';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  baseUrl = environment.API_URL;
  private _getVariant =this.baseUrl+ '/configuration/product/get';
  private _getProductPremiumType = this.baseUrl+ '/configuration/product-premium-type/get';

  constructor(
    private http: HttpClient
  ) { }

  // getProductBySearch(searchPlanName: string): Observable<Product[]> {  
  //   const productByNameUrl = this.baseUrl + `/product/${searchPlanName}`;    
  //   return this.http.get<Product[]>(productByNameUrl).pipe();
  // }

  // Get Product
  // productUrl = this.baseUrl + '/product';
  // getProductDetails(): Observable<Product[]> {
  //   console.log(this.productUrl);
  //   return this.http.get<Product[]>(this.productUrl).pipe();
  // }

  GetAllCategory(lobId: number): Observable<ProductCategory[]> {  
    const getCategoryUrl = this.baseUrl + `/category/${lobId}`;    
    return this.http.get<ProductCategory[]>(getCategoryUrl).pipe();
  }

  // Create a Product
  // createproductUrl = this.baseUrl + '/createProduct';
  // addProduct(product: Product): Observable<Product> {
  //   // console.log(this.createproductUrl);
  //   // console.log(productRow);
  //   return this.http.post<Product>(this.createproductUrl, product);
  // }

  // Delete Product
  // public deleteProduct(productId: number): Observable<{}> {
  //   const deleteProductUrl = this.baseUrl + `/productDelete/${productId}`;
  //   console.log(deleteProductUrl);
  //   return this.http.delete(deleteProductUrl).pipe();
  //   //return this.http.delete(`${this.baseUrl}/productDelete/${productId}`);    
  // }

  // deleteProduct(productRow: Product): Observable<Product> {
  //   const deleteProductUrl = this.baseUrl + `/deleteProduct`;
  //   return this.http.put<Product>(deleteProductUrl, productRow)
  //     .pipe();
  // }

  // public deleteProduct(productId: number): Observable<{}> {
  //   return this.http.delete(`${this.baseUrl}/deleteproduct/${productId}`);
  // }

  // Update the Product
  // updateProduct(product: Product): Observable<void> {
  //   //console.log(product);
  //   const updateProductUrl = this.baseUrl + `/createproduct/${product.productId}`;
  //   console.log(updateProductUrl);
  //   return this.http.put<void>(this.productUrl, product).pipe(catchError(this.handleError));
  // }  

  // getProductBySearch(productId: number): Observable<Product[]> {
  //   console.log(productId);
  //   const productByIDUrl = this.baseUrl + `/product/${productId}`;
  //   console.log(productByIDUrl);
  //   return this.http.get<Product[]>(productByIDUrl).pipe();
  // }  

  // Error Handling
  handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput <any> {
    throw new Error("Method not implemented.");
  }
  consoleLogFn(val) {
    console.log(val);
  }

  // Product(product: Product): Observable<Product[]> {

  //   console.log(product);
  //   let createproductUrl = this.baseUrl + '/configuration/product/getAllPlanCategory?LobId=${edit}`'
  //   return this.http.get<Product[]>(createproductUrl).pipe();



  // }

  getProductBySearch(searchPlanName: string): Observable<Product[]> {  
    const productByNameUrl = this.baseUrl + `/configuration/product/getAllPlanDetailsByPlanName?planName=${searchPlanName}`;    
    return this.http.get<Product[]>(productByNameUrl).pipe();
  }



  deleteProduct(data): Observable<Product> {
    const deleteProductUrl = this.baseUrl + `/configuration/product/deleteProduct`;
    return this.http.post<Product>(deleteProductUrl,data)
      .pipe();
  }


  productUrl = this.baseUrl + '/configuration/product/getAllProduct';
  getProductDetails(): Observable<Product[]> {
    console.log(this.productUrl);
    return this.http.get<Product[]>(this.productUrl).pipe();
  }


  createproductUrl = this.baseUrl + '/configuration/product/insertOrUpdatePlanDetails';
 // createproductUrl = this.baseUrl + ' /product/insertOrUpdatePlanDetails';
    addProduct(product: Product): Observable<Product> {
    // console.log(this.createproductUrl);
    // console.log(productRow);
    return this.http.post<Product>(this.createproductUrl, product);
  }

  // /configuration/product/getAllProduct

  // addproduct = /configuration/product/insertOrUpdatePlanDetails
  // getAllProduct(grid) = /configuration/product/getAllProduct
  // delete Product = /configuration/product/deleteProduct planId, deletedBy,Deleted on
  // serchabyname = /configuration/product/getAllPlanDetailsByPlanName?planName=
  // getAllPlanCategory = /configuration/product/getAllPlanCategory?LobId=

  getVariant()
  {
    return this.http.get<any>(this._getVariant);
  }
  
    //ProductPremiumType
    getProductPremiumType(id)
    {
      return this.http.get<any>(this._getProductPremiumType + '/' + id)
    }
}


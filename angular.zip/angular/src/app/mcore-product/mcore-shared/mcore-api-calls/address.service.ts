import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Insurer } from 'src/app/mcore-product/mcore-shared/mcore-entity/insurer';

import { Address, country, state, district, postOffice } from 'src/app/mcore-product/mcore-shared/mcore-entity/address';
@Injectable({
  providedIn: 'root'
})
export class AddressService {

  
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addressUrl = this.baseUrl + '/address';

   /* GET Address by ZIPCODE */
   getAddressByIDzipCode(zipCode: string): Observable<Address[]> {

    const departmentByIDUrl = this.baseUrl + `/address/${zipCode}`;

    console.log(departmentByIDUrl);
    return this.http.get<Address[]>(departmentByIDUrl)
      .pipe();
  }


  
  getAllCountries(): Observable<country[]> {
   const addressCountryUrl = this.baseUrl + '/countries';
    return this.http.get<country[]>(addressCountryUrl)
      .pipe();
  }
    
   getAllStates(a: number): Observable<state[]> {

      const stateUrl = this.baseUrl + `/state/${a}`;
    
      return this.http.get<state[]>(stateUrl)
        .pipe();
    }

        
   getAllDistricts(a: number): Observable<district[]> {

    const districtUrl = this.baseUrl + `/Districts/${a}`;
  
    return this.http.get<district[]>(districtUrl)
      .pipe();
  }

  getAllTaluk(a: number): Observable<postOffice[]> {

    const postOfficetUrl = this.baseUrl + `/PostOffice/${a}`;
  
    return this.http.get<postOffice[]>(postOfficetUrl)
      .pipe();
  }
  
}

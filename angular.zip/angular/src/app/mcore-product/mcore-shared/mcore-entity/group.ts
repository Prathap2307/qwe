export class Group {
	groupName: string;
}	


export class Claimintimation {
    //searchgroupID: number;
    groupID: number;
    groupName: string;
    // searchMasterPolicyNo: string;
    // searchAgreementNo: string;

    groupid: number;
    masterpolicyno: string;
    agreementno: string;
    searchPolicyNo: string;
    searchInsuredFirstName: string;
    searchEmployeeId: string;
    searchMemberId: string;
    // ADD Claim
    selectClaim: string;
    certificateNo: string;
    memberName: string;
    companyName: string;
    sumAssured: number;
    plan: string;
    dateofJoining: Date;
    dateofEvent: Date;
    claimIntimationDate: Date;
    locationofDeath: string;
    causeofDeath: number;

    id: number;
    description: string;
}

export interface SuccessMessage {
    headerId: number;
    totalRecords: number;
    successRecords: number;
    failureRecords: number;
    fileName: string;
    uploadDate: Date;

}

export interface UploadFileurl {
    headerId: number;
    filePath: string;
    fileName: string;
    groupID: number;
    masterPolicyID: number;
    createdBy: number;
    createdOn: Date;
    type: string;
    authorisedSignatoryID: number;

}

export class BeneficiaryDetails {
    beneficiaryName: string;
    beneficiaryAccountHolderName: string;
    relationshipWithDeceased: number;
    ifscCode: string;
    accountType: number;
    bankName: string;
    accountNo: string;
    contactNo: number;
    emailId: string;
    share: string;
    claimAmountbasedonShare: string;
}

export class AdditionalDocument {
    newRequirementAdded: number;
    documentName: string;
}

export class MandatoryDocument {
    checklistofMandatoryDocument: string;
}

export class DocumentUpload {
    documentTypeId: number;
    documentNo: string;
}
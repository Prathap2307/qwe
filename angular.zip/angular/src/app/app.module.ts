import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './mcore-product/modules/login/login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginMasterComponent } from './mcore-product/modules/login/login-master/login-master.component';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableModule } from '@angular/material/table';
import { MatRadioModule } from '@angular/material/radio';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MasterPageComponent } from './mcore-product/mcore-common/core/master-page/master-page.component';
import { DepartmentComponent } from './mcore-product/modules/masters/department/department.component';
import { InsurerComponent } from './mcore-product/modules/masters/insurer/insurer.component';
import { ZoneComponent } from './mcore-product/modules/masters/zone/zone.component';
import { DivisionComponent } from './mcore-product/modules/masters/division/division.component';
import { BranchComponent } from './mcore-product/modules/masters/branch/branch.component';
import { OrganizationComponent } from './mcore-product/modules/masters/organization/organization.component';
import { DesignationComponent } from './mcore-product/modules/masters/designation/designation.component';
import { GradeComponent } from './mcore-product/modules/masters/grade/grade.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { ProductComponent } from './mcore-product/modules/masters/product/product.component';
import { VariantComponent } from './mcore-product/modules/masters/variant/variant.component';
import { PremiumComponent } from './mcore-product/modules/masters/premium/premium.component';
import { PremiumpaymentfrequencyComponent } from './mcore-product/modules/masters/premiumpaymentfrequency/premiumpaymentfrequency.component';
import { LoadinganddiscountComponent } from './mcore-product/modules/masters/loadinganddiscount/loadinganddiscount.component';
import { FchannelComponent } from './mcore-product/modules/masters/fchannel/fchannel.component';
import { FsaleshierarchyComponent } from './mcore-product/modules/masters/fsaleshierarchy/fsaleshierarchy.component';
import { UserComponent } from './mcore-product/modules/masters/user/user.component';
import { GroupComponent } from './mcore-product/modules/masters/group/group.component';
import { PrivilegesComponent } from './mcore-product/modules/masters/privileges/privileges.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { LookupComponent } from './mcore-product/modules/masters/lookup/lookup.component';
import { BankmasterComponent } from './mcore-product/modules/masters/bankmaster/bankmaster.component';
import { AddressstructureComponent } from './mcore-product/modules/masters/addressstructure/addressstructure.component';
import { DestinationdocumentuploadComponent } from './mcore-product/modules/masters/destinationdocumentupload/destinationdocumentupload.component';
import { BankbranchComponent } from './mcore-product/modules/masters/bankbranch/bankbranch.component';
import { MatListModule } from '@angular/material/list';
import { CoveragesComponent } from './mcore-product/modules/masters/coverages/coverages.component';
import { QuestionsComponent } from './mcore-product/modules/masters/questions/questions.component';
import { TaxstructureComponent } from './mcore-product/modules/masters/taxstructure/taxstructure.component';
import { StampdutyComponent } from './mcore-product/modules/masters/stampduty/stampduty.component';
import { CommissionComponent } from './mcore-product/modules/masters/commission/commission.component';
import { AuthorisedsignatoryComponent } from './mcore-product/modules/masters/authorisedsignatory/authorisedsignatory.component';
import { ClientorganizationComponent } from './mcore-product/modules/customer/clientorganization/clientorganization.component';
import { MasterpolicyComponent } from './mcore-product/modules/customer/masterpolicy/masterpolicy.component';
import { AdvancedepositreceiptingComponent } from './mcore-product/modules/customer/advancedepositreceipting/advancedepositreceipting.component';
import { AffinityquestionmapComponent } from './mcore-product/modules/customer/affinityquestionmap/affinityquestionmap.component';
import { AdvancedepositreceiptComponent } from './mcore-product/modules/customer/advancedepositreceipt/advancedepositreceipt.component';
import { MemberuploadComponent } from './mcore-product/modules/newbusiness/memberupload/memberupload.component';
import { DefectdataComponent } from './mcore-product/modules/newbusiness/defectdata/defectdata.component';
import { PolicyviewinformationComponent } from './mcore-product/modules/newbusiness/policyviewinformation/policyviewinformation.component';
import { MAEndorsementComponent } from './mcore-product/modules/endorsement/maendorsement/maendorsement.component';

import { MemberdeletionComponent } from './mcore-product/modules/endorsement/memberdeletion/memberdeletion.component';
import { SumassuredendorsementComponent } from './mcore-product/modules/endorsement/sumassuredendorsement/sumassuredendorsement.component';
import { NmendorsementComponent } from './mcore-product/modules/endorsement/nmendorsement/nmendorsement.component';
import { AccountingprocessComponent } from './mcore-product/modules/accounting/accountingprocess/accountingprocess.component';
import { AccountingclassificationComponent } from './mcore-product/modules/accounting/accountingclassification/accountingclassification.component';
import { ProcesstaxmappingComponent } from './mcore-product/modules/accounting/processtaxmapping/processtaxmapping.component';

import { DayclosemonitorComponent } from './mcore-product/modules/accounting/dayclosemonitor/dayclosemonitor.component';
import { VoucherreportComponent } from './mcore-product/modules/accounting/voucherreport/voucherreport.component';
import { GlconfigurationsComponent } from './mcore-product/modules/accounting/glconfigurations/glconfigurations.component';
import { AccountinggroupComponent } from './mcore-product/modules/accounting/accountinggroup/accountinggroup.component';
import { AccountingheadComponent } from './mcore-product/modules/accounting/accountinghead/accountinghead.component';
import { AccountingsubheadComponent } from './mcore-product/modules/accounting/accountingsubhead/accountingsubhead.component';
import { QuotationComponent } from './mcore-product/modules/masters/quotation/quotation.component';
import { UnderwritinglevelComponent } from './mcore-product/modules/underwriting/underwritinglevel/underwritinglevel.component';
import { UnderwritingruleComponent } from './mcore-product/modules/underwriting/underwritingrule/underwritingrule.component';
import { UnderwritingpoolComponent } from './mcore-product/modules/underwriting/underwritingpool/underwritingpool.component';
import { UnderwritingmedicalComponent } from './mcore-product/modules/underwriting/underwritingmedical/underwritingmedical.component';
import { UnderwritingpendingpaymentComponent } from './mcore-product/modules/underwriting/underwritingpendingpayment/underwritingpendingpayment.component';
import { FilterPipe } from './mcore-product/mcore-shared/mcore-pipes/filter.pipe';
import { SearchPipe } from './mcore-product/mcore-shared/mcore-pipes/search.pipe';
import { FemailSmsComponent } from './mcore-product/modules/masters/femail-sms/femail-sms.component';
import { FsubChannelComponent } from './mcore-product/modules/masters/fsub-channel/fsub-channel.component';
import { DatePipe, CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ChangePasswordComponent } from './mcore-product/modules/masters/change-password/change-password.component';
import { DashboardComponent } from './mcore-product/modules/account/dashboard/dashboard.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';

import { ClaimintimationComponent } from './mcore-product/modules/claims/claimintimation/claimintimation.component';
import { ClaimsregistrationnewComponent } from './mcore-product/modules/claims/claimsregistrationnew/claimsregistrationnew.component';
import { ClaimssettlementnewComponent } from './mcore-product/modules/claims/claimssettlementnew/claimssettlementnew.component';
import { ClaimsstatusreportComponent } from './mcore-product/modules/claims/claimsstatusreport/claimsstatusreport.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LoginMasterComponent,
    MasterPageComponent,
    DepartmentComponent,
    InsurerComponent,
    ZoneComponent,
    DivisionComponent,
    BranchComponent,
    OrganizationComponent,
    DesignationComponent,
    GradeComponent,
    ProductComponent,
    VariantComponent,
    PremiumComponent,
    PremiumpaymentfrequencyComponent,
    LoadinganddiscountComponent,
    FchannelComponent,
    FsaleshierarchyComponent,
    UserComponent,
    GroupComponent,
    PrivilegesComponent,
    LookupComponent,
    BankmasterComponent,
    AddressstructureComponent,
    DestinationdocumentuploadComponent,
    BankbranchComponent,
    CoveragesComponent,
    QuestionsComponent,
    TaxstructureComponent,
    StampdutyComponent,
    ChangePasswordComponent,
    CommissionComponent,
    AuthorisedsignatoryComponent,
    ClientorganizationComponent,
    MasterpolicyComponent,
    AdvancedepositreceiptingComponent,
    AffinityquestionmapComponent,
    AdvancedepositreceiptComponent,
    MemberuploadComponent,
    DefectdataComponent,
    PolicyviewinformationComponent,
    MAEndorsementComponent,
    MemberdeletionComponent,
    SumassuredendorsementComponent,
    NmendorsementComponent,
    AccountingprocessComponent,
    AccountingclassificationComponent,
    ProcesstaxmappingComponent,
    DayclosemonitorComponent,
    VoucherreportComponent,
    GlconfigurationsComponent,
    AccountinggroupComponent,
    AccountingheadComponent,
    AccountingsubheadComponent,
    QuotationComponent,
    UnderwritinglevelComponent,
    UnderwritingruleComponent,
    UnderwritingpoolComponent,
    UnderwritingmedicalComponent,
    UnderwritingpendingpaymentComponent,
    DashboardComponent,
    MasterpolicyComponent,
    AdvancedepositreceiptingComponent,
    AffinityquestionmapComponent,
    AdvancedepositreceiptComponent,
    MemberuploadComponent,
    DefectdataComponent,
    PolicyviewinformationComponent,
    MAEndorsementComponent,
    MemberdeletionComponent,
    SumassuredendorsementComponent,
    NmendorsementComponent,
    AccountingprocessComponent,
    AccountingclassificationComponent,
    ProcesstaxmappingComponent,
    DayclosemonitorComponent,
    VoucherreportComponent,
    GlconfigurationsComponent,
    AccountinggroupComponent,
    AccountingheadComponent,
    AccountingsubheadComponent,

    QuotationComponent,
    UnderwritinglevelComponent,
    UnderwritingruleComponent,
    UnderwritingpoolComponent,
    UnderwritingmedicalComponent,
    UnderwritingpendingpaymentComponent,
    FilterPipe,
    SearchPipe,
    FemailSmsComponent,
    FsubChannelComponent,

    ClaimintimationComponent,
    ClaimsregistrationnewComponent,
    ClaimssettlementnewComponent,
    ClaimsstatusreportComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRippleModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatTableModule,
    MatRadioModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatSlideToggleModule,
    MatPaginatorModule,
    MatListModule,
    MatSnackBarModule,
    AngularEditorModule,
    MatExpansionModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }

package com.LIC.dao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.LIC.model.CommissionModal;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.exception.ExceptionProcess;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class CommissionDao 
{
	 @Autowired	JdbcTemplate jdbcTemplate;
		
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryDao.class);	
	
	public List<CommissionModal> GelAllPlan(int lineOfBusinessID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		CommissionModal  		commission 		= null;
		List<CommissionModal>  	commissionList 	= null;
		
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllProductByLOB(?,?)");
			
			cstm.setLong(1,	lineOfBusinessID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
 			cstm.execute();
			
 			result = ((OracleCallableStatement)cstm).getCursor(2);
 			
			if(result != null) {
				commissionList		= new ArrayList<CommissionModal>();
				while(result.next()) {
					commission = new CommissionModal();
					
					
					commissionList.add(commission);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		}
		finally
		{
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return commissionList;
	}

	public String IsCommssionDetailExists(CommissionModal commisioin) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		String 					status 				= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spIsCommissionDetailsExists(?,?,?,?,?,?,?,?,?,?,?,?)");
			cstm.setLong(1, 		commisioin.getCommissionID());
			cstm.setLong(2, 		commisioin.getPlanID());
			cstm.setLong(3, 		commisioin.getMainChannelID());
			cstm.setLong(4,		 	commisioin.getSubChannelID());
			cstm.setTimestamp(5, 	commisioin.getFromDate());
			cstm.setTimestamp(6, 	commisioin.getToDate());
			cstm.setLong(7, 		commisioin.getPolicyYearTypeID());
			cstm.setLong(8, 		commisioin.getRangeFrom());
			cstm.setLong(9, 		commisioin.getRangeTo());
			cstm.setShort(10, 		commisioin.getIsActive());
			cstm.setLong(11, 		commisioin.getPolicyTermID());
			cstm.registerOutParameter(12, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(12);
			
			status	= "NOTEXIST";
			if(result != null) {
				
				int count = result.getRow();
				System.out.println("count >>"+count);
				if(count > 0) {
					status = "EXIST";
				}
				
			}
			return status;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return "Error";
	}
	
	public long InsertorUpdateCommsion(CommissionModal commission) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spInsertOrUpdateCommision(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			cstm.setLong(1, 		commission.getPlanID());
			cstm.setLong(2, 		commission.getPolicyYearTypeID());
			cstm.setLong(3, 		commission.getMainChannelID());
			cstm.setLong(4, 		commission.getSubChannelID());
			cstm.setTimestamp(5, 	commission.getFromDate());
			cstm.setTimestamp(6, 	commission.getToDate());
			cstm.setLong(7, 		commission.getRangeFrom());
			cstm.setLong(8, 		commission.getRangeTo());
			cstm.setDouble(9, 		commission.getAmount());
			cstm.setLong(10, 		commission.getCreatedBy());
			cstm.setShort(11, 		commission.getIsActive());
			cstm.setLong(12, 		commission.getPolicyTermID());
			cstm.setLong(13, 		commission.getCommissionID());
			cstm.setLong(14,		commission.getSalesHierarchyID());
			cstm.registerOutParameter(15, OracleTypes.CURSOR); //REF CURSOR
			cstm.executeUpdate();

			result = ((OracleCallableStatement)cstm).getCursor(15);
			
			if(result != null) {
				if(result.next()) {
					return result.getLong("CommissionId");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		return 0;
	}
	
	public List<CommissionModal> GetCommissionDetails() throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		CommissionModal 		commission			= null;
		List<CommissionModal>  	commissionList 		= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetCommissionDetails(?)");
			
			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				
				commissionList	= new ArrayList<CommissionModal>();
				
				while(result.next()) {
					commission = new CommissionModal();
					commission.setCommissionID(result.getLong("CommissionID"));
					commission.setFromDateStr(result.getString("FromDate"));
					commission.setToDateStr(result.getString("ToDate"));
					commission.setFromDate(result.getTimestamp("FromDate"));
					commission.setToDate(result.getTimestamp("ToDate"));
					commission.setRangeFrom(result.getLong("RangeFrom"));
					commission.setPlanID(result.getLong("PlanID"));
					commission.setAmount(result.getDouble("Amount"));
					commission.setPlan(result.getString("Plan"));
					commission.setMainChannel(result.getString("MainChannel"));
					commission.setMainChannelID(result.getLong("MainChannelID"));
					commission.setSubChannelID(result.getLong("SubChannelID"));
					commission.setChannelName(result.getString("ChannelName"));
					commissionList.add(commission);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return commissionList;
	}
	
	public List<CommissionModal> GetCommissionDetailsByCommissionID(long commissionId) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		CommissionModal 		commission 		= null;
		List<CommissionModal>  	commissionList 		= null;
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetCommissionDetailsByCommissionID(?,?)");
			cstm.setLong(1, commissionId);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				commissionList	= new ArrayList<CommissionModal>();
				
				while(result.next()) {
					commission = new CommissionModal();
					commission.setCommissionID(result.getLong("CommissionID"));
					commission.setFromDate(result.getTimestamp("FromDate"));
					commission.setToDate(result.getTimestamp("ToDate"));
					commission.setRangeFrom(result.getLong("RangeFrom"));
					commission.setRangeTo(result.getLong("RangeTo"));
					commission.setPlanID(result.getLong("PlanID"));
					commission.setAmount(result.getDouble("Amount"));
					commission.setPlan(result.getString("Plan"));
					commission.setMainChannel(result.getString("MainChannel"));
					commission.setMainChannelID(result.getLong("MainChannelID"));
					commission.setSubChannelID(result.getLong("SubChannelID"));
					commission.setChannelName(result.getString("ChannelName"));
					commission.setPolicyYearTypeID(result.getLong("PolicyYearTypeID"));
					commission.setPolicyTermID(result.getLong("PolicyTermID"));
					commission.setSalesHierarchyID(result.getLong("SalesHierarchyID"));
					commissionList.add(commission);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return commissionList;
	}
	
	public void DeleteCommission(long commissionID, long deletedBy )throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteCommission(?,?) ");
			cstm.setLong(1, commissionID);
			cstm.setLong(2, deletedBy);
			cstm.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		
	}
	
	public List<CommissionModal> GetCommissionDetailsBySearch(CommissionModal commissionModal) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		CommissionModal        	commission         = null;
		List<CommissionModal>  	commissionList 		= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetCommissionWithSearchParam(?,?,?,?,?)");
			cstm.setTimestamp(1, commissionModal.getFromDate());
			cstm.setTimestamp(2, commissionModal.getToDate());
			cstm.setLong(3, commissionModal.getPlanID());
			cstm.setLong(4, commissionModal.getMainChannelID());
			cstm.registerOutParameter(5, OracleTypes.CURSOR); //REF CURSOR
			cstm.executeUpdate();
			result = ((OracleCallableStatement)cstm).getCursor(5);
			
			if(result != null) {
				commissionList	= new ArrayList<CommissionModal>();
				
				while(result.next()) {
					commission = new CommissionModal();
					commission.setCommissionID(result.getLong("CommissionID"));
					commission.setFromDate(result.getTimestamp("FromDate"));
					commission.setToDate(result.getTimestamp("ToDate"));
					commission.setRangeFrom(result.getLong("RangeFrom"));
					commission.setRangeTo(result.getLong("RangeTo"));
					if(ExceptionProcess.isColumnThereInResultSet(result,"RangeToForNull")) {
						System.out.println("result.getString(\"RangeToForNull\")"+result.getString("RangeToForNull"));
						commission.setRangeToForNull(result.getString("RangeToForNull"));
					}
					commission.setPlanID(result.getLong("PlanID"));
					commission.setAmount(result.getDouble("Amount"));
					commission.setPlan(result.getString("Plan"));
					if(ExceptionProcess.isColumnThereInResultSet(result,"PolicyYearExpressedAs"))
					commission.setPolicyYearExpressed(result.getString("PolicyYearExpressedAs"));
					commission.setMainChannel(result.getString("MainChannel"));
					commission.setMainChannelID(result.getLong("MainChannelID"));
					commission.setSubChannelID(result.getLong("SubChannelID"));
					commission.setChannelName(result.getString("ChannelName"));
					if(ExceptionProcess.isColumnThereInResultSet(result,"PolicyYearTypeID"))
					commission.setPolicyYearTypeID(result.getLong("PolicyYearTypeID"));
					commissionList.add(commission);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return commissionList;
	}
	
	
	/*
	 public DataTable GetAllMarketingHierarchy(int subChannelID)
        {
            DataTable dt = new DataTable();
            try
            {
                Database DB = DatabaseFactory.CreateDatabase("ConnectionString");
                using (DbCommand Cmd = DB.GetStoredProcCommand("spGetAllMarketingHierarchy"))
                {
                    DB.AddInParameter(Cmd, "@SubChannelID", DbType.Int32, subChannelID);
                    DataSet ds = DB.ExecuteDataSet(Cmd);
                    if (ds.Tables.Count > 0)
                    {
                        dt = ds.Tables[0];

                    }
                    else
                    {
                        dt = null;
                    }
                    return dt;
                }
            }

            catch (Exception sqlExc)
            {
                Logger.Write(sqlExc.Message.ToString());
                return null;
            }

        }
	 */
	public List<CommissionModal> GetAllMarketingHierarchy(Long subChannelID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		CommissionModal        commisioin            = null;
		List<CommissionModal>  commissionList = null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllMarketingHierarchy(?)");
			cstm.setLong(1, subChannelID);
			result = ((OracleCallableStatement)cstm).getCursor(1);
			if(result != null)
			{
				commissionList	= new ArrayList<CommissionModal>();
				while(result.next())
				{
					commisioin = new CommissionModal();
					commissionList.add(commisioin);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		}
		finally
		{
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return commissionList;
	}
	/*
	 public DataTable GetAllPolicyTermValuesByProudctID(Int32 PrductID)
        {
            try
            {
                DataTable dtProductFeatures;
                Database DB = DatabaseFactory.CreateDatabase("ConnectionString");


                using (DbCommand Cmd = DB.GetStoredProcCommand("spGetAllPolicyTermValuesByProudctID"))
                {
                    DB.AddInParameter(Cmd, "@ProductID", DbType.Int32, PrductID);

                    using (DataSet ds = DB.ExecuteDataSet(Cmd))
                    {
                        if (ds.Tables.Count > 0)
                        { dtProductFeatures = ds.Tables[0]; }
                        else { return null; }
                    }
                }
                DB = null;
                return dtProductFeatures;


            }
            catch (SqlException sqlExc)
            {
                Logger.Write(sqlExc.Message.ToString());
            }
            return null;
        }
	  */
	
	public List<CommissionModal> GetAllPolicyTermValuesByProudctID(Long PrductID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		CommissionModal        commisioin            = null;
		List<CommissionModal>  commissionList = null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllPolicyTermValuesByProudctID(?)");
			cstm.setLong(1, PrductID);
			result = ((OracleCallableStatement)cstm).getCursor(1);
			if(result != null)
			{
				commissionList	= new ArrayList<CommissionModal>();
				while(result.next())
				{
					commisioin = new CommissionModal();
					commissionList.add(commisioin);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		}
		finally
		{
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return commissionList;
	}
}

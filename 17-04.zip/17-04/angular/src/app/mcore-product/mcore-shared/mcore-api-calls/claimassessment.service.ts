import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ClaimassessmentService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

  getAllPendingClaims(pLineOfBusinessID,pClaimNumber,pFirstName,pLastName,pPolicyNumber,pContactID,pAgeing,pStatusID,pAssessorID): Observable<any> {
    const url = this.baseUrl + `/ClaimsAssessment/getAllPendingClaims/${pLineOfBusinessID}/${pClaimNumber}/${pFirstName}/${pLastName}/${pPolicyNumber}/${pContactID}/${pAgeing}/${pStatusID}/${pAssessorID}`;
    return this.http.get<any>(url)
      .pipe();
  }


  getAllCauseOfDeath(): Observable<any> {
    const url = this.baseUrl + `/GetAllCauseOfDeath`;
    return this.http.get<any>(url)
      .pipe();
  }

  getClaimDetailsByClaimId(pClaimID: number): Observable<any> {
    const url = this.baseUrl + `/ClaimsAssessment/getClaimDetailsByClaimId/${pClaimID}`;
    return this.http.get<any>(url)
      .pipe();
  }

  updateClaimsPayableDetails(a: any): Observable<any> {
    const url = this.baseUrl + `/ClaimsApproval/updateClaimsPayableDetails`;
    return this.http.post<any>(url, a)
      .pipe();
  }

  getRelationshipDetails(): Observable<any> {
    const url = this.baseUrl + `/relationshipDetails`;
    return this.http.get<any>(url)
      .pipe();
  }

  getAllPaymentMode(): Observable<any> {
    const url = this.baseUrl + `/GetAllPaymentMode`;
    return this.http.get<any>(url)
      .pipe();
  }

  insertClaimsBeneficiary(a: any): Observable<any> {
    const url = this.baseUrl + `/claimRegis/insertClaimsBeneficiary`;
    return this.http.post<any>(url, a)
      .pipe();
  }
}

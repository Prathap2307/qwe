import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Claimintimation, BeneficiaryDetails, AdditionalDocument, MandatoryDocument, DocumentUpload , CauseofDeath, RelationshipDeceased} from 'src/app/mcore-product/mcore-shared/mcore-entity/claimintimation';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ClaimintimationService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }



  getAllClaimDetails(a: any): Observable<any> {
    const url = this.baseUrl + `/GetSearchDetailForClaimIntimation`;
    return this.http.post<any>(url, a)
      .pipe();
  }


}

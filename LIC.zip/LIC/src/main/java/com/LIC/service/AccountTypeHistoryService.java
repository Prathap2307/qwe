package com.LIC.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.LIC.dao.IAccountTypeHistoryDAO;
import com.LIC.model.AccountTypeHistory;

@Service
@Transactional
public class AccountTypeHistoryService implements IAccountTypeHistoryService {
	
	@Autowired
	IAccountTypeHistoryDAO dao;
	
 
	@Override
	public List<AccountTypeHistory> getAll(Integer accountTypeID) throws SQLException{
		return dao.getAll(accountTypeID);
	}
}

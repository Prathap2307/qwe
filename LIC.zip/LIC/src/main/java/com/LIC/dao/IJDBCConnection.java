package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;

public interface IJDBCConnection {
	public Connection getConnection() throws SQLException ;
}

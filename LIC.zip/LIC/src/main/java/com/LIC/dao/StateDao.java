package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.State;
import com.LIC.model.StateModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class StateDao implements IStateDAO {

	
	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(StateDao.class);
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(State obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateState(?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getCountryId());
		  callableStatement.setInt(2, obj.getStateId());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setString(4, obj.getTinNumber());
		  callableStatement.setInt(5, obj.getCreatedBy());
		  callableStatement.setInt(6, obj.getIsDeclined());
		  callableStatement.setString(7, obj.getRemarks());
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateState executed successfully.");
		  logger.info("SP>spInsertOrUpdateState executed successfully.");
	}
	 
	@Override
	public void delete(Integer id, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteState(?,?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteState executed successfully.");
		  logger.info("SP>spDeleteState executed successfully.");
	} 
	
	@Override
	public List<State> getAll(State filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<State> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllStates(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, filterObj.getCountryId());
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  State obj = null;
			  list = new ArrayList<State>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("StateID")+" | "+rs.getString("DESCRIPTION")); 
		        obj = new State();
		        obj.setStateId(rs.getInt("StateID"));
		        obj.setCountryId(rs.getInt("CountryID"));
		        obj.setDescription(rs.getString("Description"));/*
		        obj.setTinNumber(rs.getString("TINNUMBER"));
		        obj.setIsDeclined(rs.getInt("ISDECLINED"));*/
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllStates executed successfully.");
			  logger.info("SP>spGetAllStates executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetAllStates exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public State get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  State obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetStateByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		    	System.out.println(rs.getInt("StateID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("TINNUMBER")+rs.getString("ISDECLINED")); 
		        obj = new State();
		        obj.setStateId(rs.getInt("StateID"));
		        obj.setCountryId(rs.getInt("CountryID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setTinNumber(rs.getString("TINNUMBER"));
		        obj.setIsDeclined(rs.getInt("ISDECLINED"));
		      }
			  System.out.println("SP>spGetStateByID executed successfully.");
			  logger.info("SP>spGetStateByID executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetStateByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
	public List<StateModal> getAllStatesByCountryId(long countryID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		StateModal				stateModal			= null;
		List<StateModal>		stateList			= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			 
			cstm 		= conn.prepareCall("call spGetAllStates(?,?) ");
			
			cstm.setLong(1, countryID); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {
		    	
		    	stateList	= new ArrayList<StateModal>();
		    	
		    	while (result.next ()) {
		    		stateModal = new StateModal();
		    		
		    		stateModal.setStateID(result.getLong("StateID"));
		    		stateModal.setDescription(result.getString("Description"));
		    		stateModal.setCountryID(result.getLong("CountryID"));
		    		
		    		stateList.add(stateModal);
		    	}
		    }
		
		    return stateList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return null;
	}
	
	public List<StateModal> GetAllStateCountry() throws Exception {
		CallableStatement				cstm						= null;
		Connection 						conn 						= null;
		ResultSet 						result 						= null;
		StateModal 						stateModel 			= null;
		List<StateModal> 				stateList 			= null;
		
			 
			try {
				conn   		= ResourceManager.getConnection();
				
				cstm 		= conn.prepareCall("call spGetAllStatesWithCountry(?)");
				
				cstm.registerOutParameter(1, OracleTypes.CURSOR);  //REF CURSOR
				cstm.executeUpdate();
				
				result = ((OracleCallableStatement)cstm).getCursor(1);
				 
				 if(result != null) {
					 stateList 	= new ArrayList<StateModal>();
					 while(result.next()) {
						 stateModel	= new StateModal();
						 stateModel.setStateID(result.getLong("StateID"));
						 stateModel.setDescription(result.getString("Description"));
						 stateModel.setCountryID(result.getLong("CountryID"));
						 stateList.add(stateModel);
					 }
				 	}
				 } catch(Exception e) {
					e.printStackTrace();
					logger.error(e.getMessage(), e);	
				} finally {
					cstm.close();
					cstm	= null;
		  			ResourceManager.freeConnection(conn);
		  			conn	= null;
				}
				return stateList;
			}
			
	
}

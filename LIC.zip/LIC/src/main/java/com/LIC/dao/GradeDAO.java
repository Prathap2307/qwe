
	
	
	package com.LIC.dao;


	import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.LIC.model.GetGradeModel;
import com.LIC.model.GradeModel;


	@Repository
	public class GradeDAO {
		@Autowired
		private EntityManager em;
		
		   @SuppressWarnings("unchecked")

		   public List<GetGradeModel>GetAllGrades(GetGradeModel grade ) {
               
               StoredProcedureQuery query = em
                      .createStoredProcedureQuery("GetAllGradeByOraganisationID")
                      .registerStoredProcedureParameter("vOrganizationID",Integer.class, ParameterMode.IN)
                      .registerStoredProcedureParameter("vGradeName", String.class, ParameterMode.IN)
                     
                      .registerStoredProcedureParameter("oGrade", Class.class, ParameterMode.REF_CURSOR)
                                .setParameter("vOrganizationID",grade.getOrganisationId())
                                .setParameter("vGradeName",grade.getDescription());
                                
               
                                query.execute();
                   
                       List<Object[]> list  =  (List<Object[]>)query.getResultList();
                       List<GetGradeModel> gradeList = list.stream().map(
                               o -> new GetGradeModel((Number) o[0],(String) o[1])).collect(Collectors.toList());
                       
                      return gradeList;  
                               }


		   public void postGrade(GradeModel model){
				
		   StoredProcedureQuery query = em
	                 .createNamedStoredProcedureQuery("createOrUpdateGrade");
	                query .setParameter("p_OrganisationID", model.getOrganisationId());
	                query .setParameter("p_GradeID",model.getGradeId());
	                query.setParameter("p_Description",model.getDescription());
	                query.setParameter("p_CreatedBy", model.getCreatedBy());  
	                query.getParameter("cur");
	                query.execute() ;
	            
	     	        
		}
		
		
		
		/*
		
		public void creategradeInfo(GradeModel model) {

			StoredProcedureQuery addGradeStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateGrade");
			addGradeStoredProcedure.setParameter("vOrganisationID", model.getOrganisationId());
			addGradeStoredProcedure.setParameter("vGradeID", model.getGradeId());
			addGradeStoredProcedure.setParameter("vDescription", model.getDescription());
			addGradeStoredProcedure.setParameter("vCreatedBy", model.getCreatedBy());
			addGradeStoredProcedure.setParameter("vCreatedOn", model.getCreatedOn());
			
			addGradeStoredProcedure.setParameter("vIsActive", model.getIsActive());
			addGradeStoredProcedure.execute();
			
			
			
			

		}*/
	
		public void deleteGrade(GradeModel model) {

			StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteGrade");
			query.setParameter("vGradeID",model.getGradeId());
			
			query.setParameter("vDELETEDBY",model.getDeletedBy());
			query.setParameter("vDELETEDON",model.getDeletedOn());
			query.getParameter("RESULT1");
	        query.execute();
		}
		
	
	
	
	
	}
		
		
		
	
	
	
		

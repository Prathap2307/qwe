package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.Occupation;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class OccupationDAO implements IOccupationDAO {
	
	static final Logger LOGGER = LogManager.getLogger(OccupationDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(Occupation obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateOccupation(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getOccupationId());
		  callableStatement.setString(2, obj.getShortDescription());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setInt(4, obj.getCreatedBy());
		  callableStatement.setString(5, obj.getRemarks());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  LOGGER.info("SP>spInsertOrUpdateOccupation executed successfully.");
	}
	
	@Override
	public void delete(Integer occupationID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteOccupation(?,?,?); END;");
		  callableStatement.setInt(1, occupationID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteOccupation executed successfully.");
		  LOGGER.info("SP>spDeleteOccupation executed successfully.");
	} 
	
	@Override
	public List<Occupation> getAll(Occupation filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Occupation> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllOccupation(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Occupation obj = null;
			  list = new ArrayList<Occupation>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")); 
		        obj = new Occupation();
		        obj.setOccupationId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllOccupation executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllOccupation exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public Occupation get(Integer occupationID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  Occupation obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetOccupation(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, occupationID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new Occupation();
		        obj.setOccupationId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		      }
			  LOGGER.info("SP>spGetAllOccupation executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllOccupation exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

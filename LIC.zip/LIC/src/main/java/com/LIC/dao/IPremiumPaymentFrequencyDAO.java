package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.PremiumPaymentFrequency;


public interface IPremiumPaymentFrequencyDAO {
	public void saveOrUpdate(PremiumPaymentFrequency obj) throws SQLException ;
	public void delete(Integer premiumPaymentFrequencyID, Integer deleteBy) throws SQLException;
	public List<PremiumPaymentFrequency> getAll(PremiumPaymentFrequency filterObj) throws SQLException;
	public PremiumPaymentFrequency get(Integer premiumPaymentFrequencyID) throws SQLException;
}

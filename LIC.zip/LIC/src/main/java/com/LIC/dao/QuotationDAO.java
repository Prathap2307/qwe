package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.DropDownModel;
import com.LIC.model.MasterPolicyPremiumModel;
import com.LIC.model.QuotationModel;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class QuotationDAO {

	@Autowired
	private EntityManager em;
	Connection conn = null;
	CallableStatement cstm = null;
	@Autowired
	private JDBCConnection jdbcConnection;

	public List<HashMap> getSalesHierarchyDetails(String moCode) {

		List<HashMap> salesHierarchyDetails = new ArrayList();

		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetSalesHierarchySubChannelDetailsByCode(?,?,?) ");

			cstm.setString(1, moCode);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); // REF CURSOR
			cstm.registerOutParameter(3, OracleTypes.CURSOR); // REF CURSOR
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(3);

			if (result != null) {
				salesHierarchyDetails = ResourceManager.resultSetToArrayList(result);

			}

			/*
			 * if (result != null) { while (result.next()) {
			 * qm.setSalesHierarchyId(result.getInt("SalesHierarchyID"));
			 * qm.setMarketingOffName(result.getString("Name"));
			 * qm.setDirectChannel(result.getString("MainChannelCode");
			 * qm.setSubChannel(result.getString("SubChannelCode")); qm.setMoCode(moCode);
			 * 
			 * } }
			 */

			for (HashMap salesHierarchyDetail : salesHierarchyDetails) {

				Number salesHierarchyID = (Number) salesHierarchyDetail.get("SALESHIERARCHYID");
				List<HashMap> branchList = getBranchBySalesHierarchy(salesHierarchyID.intValue());
				salesHierarchyDetails.addAll(branchList);
			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			closeConnection();

		}
		return salesHierarchyDetails;
	}

	private void closeConnection() {
		try {
			//cstm.close();
			ResourceManager.freeConnection(conn);
			//cstm = null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<DropDownModel> getAllPlans() {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetPlan")
				.registerStoredProcedureParameter("oPlan", Class.class, ParameterMode.REF_CURSOR);
		query.execute();

		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<DropDownModel> planList = list.stream().map(o -> new DropDownModel((Number) o[0], (String) o[2]))
				.collect(Collectors.toList());

		return planList;
	}

	public List<DropDownModel> getAllPremium() {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllPaymentFrequency")
				.registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR);
		query.execute();

		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<DropDownModel> premiumList = list.stream().map(o -> new DropDownModel((Number) o[0], (String) o[1]))
				.collect(Collectors.toList());

		return premiumList;
	}

	public List<DropDownModel> getVariant(int lineOfBusinessID) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("SPGETALLPRODUCTBYLOB")
				.registerStoredProcedureParameter("P_LineOfBusinessID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR)
				.setParameter("P_LineOfBusinessID", lineOfBusinessID);
		query.execute();

		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<DropDownModel> premiumList = list.stream().map(o -> new DropDownModel((Number) o[0], (String) o[1]))
				.collect(Collectors.toList());

		return premiumList;
	}

	public List getBranchBySalesHierarchy(int salesSubChannelID) throws Exception {

		List<Object> branchBySalesHierarchy = new ArrayList();
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetBranchBySalesHierarchyOrSubChannelID(?,?,?,?) ");
			cstm.setInt(1, salesSubChannelID);
			cstm.setString(2, "SalesHierarchy");
			cstm.registerOutParameter(3, OracleTypes.CURSOR); // REF CURSOR
			cstm.registerOutParameter(4, OracleTypes.CURSOR); // REF CURSOR
			cstm.execute();
			ResultSet result = ((OracleCallableStatement) cstm).getCursor(3);

			if (result != null) {
				branchBySalesHierarchy = ResourceManager.resultSetToArrayList(result);

			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			closeConnection();
		}
		return branchBySalesHierarchy;
	}

	public List getPremiumDetailsByMasterPolicy(int productId) {
		List<Object> premiumDetailsByMPList = new ArrayList();
		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetPremiumDetailsByMasterPolicyID(?,?,?,?,?,?) ");

			cstm.setInt(1, productId);
			cstm.setInt(2, 0);
			cstm.setInt(3, 0);
			cstm.setString(4, "PRODUCT");
			cstm.setInt(5, 0);
			cstm.registerOutParameter(6, OracleTypes.CURSOR); // REF CURSOR
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(6);

			if (result != null) {
				premiumDetailsByMPList = ResourceManager.resultSetToArrayList(result);

			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			closeConnection();

		}
		return premiumDetailsByMPList;
	}

	
	public List getClientDetails(int clientId, int typeId){
		List<Object> clientDetailsList = new ArrayList();
		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetPartyNameByPartyID(?,?,?) ");

			cstm.setInt(1, clientId);
			cstm.setInt(2, typeId);
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(3);

			if (result != null) {
				clientDetailsList = ResourceManager.resultSetToArrayList(result);

			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			closeConnection();

		}
		return clientDetailsList;
	}
	

	
	public List saveQuotationDetails(QuotationModel quotationModel) {
		StoredProcedureQuery query = em
                .createStoredProcedureQuery("spInsertOrUpdateQuotation")
                .registerStoredProcedureParameter("p_LineOfBusinessID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_BranchID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_QuotationID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_QuotationDate", Date.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_QuotationNo", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_SalesHierarchyID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_SubChannelID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_MainChannelID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_SalesType", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_QuotationPartyMapID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_ProductID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PlanID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_SumInsured", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PolicyStartDate", Date.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PolicyEndDate", Date.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PolicyIssueDate", Date.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PremiumPaymentTerm", Integer.class, ParameterMode.IN)               
                .registerStoredProcedureParameter("p_PremiumPaymentFrequencyID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_BasePremium", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_NetPremium", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PolicyTerm", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_NetPayableAmount", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_DiscretionaryPercentage", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_DiscretionaryDiscountLoading", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_DiscretionaryAmount", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_IsServiceTax", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_LoanID", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_OutstandingLoanAmt", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_RateOfInterest", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_EMITypeID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_LoanTenture", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_LoanTypeID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_EMI", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_StatusID", Integer.class, ParameterMode.IN)               
                .registerStoredProcedureParameter("p_CreatedBy", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_CreatedOn", Date.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_IsActive", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_TypeID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_TotalMembers", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_TotalSumInsured", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_FileName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_FileHeaderID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_Remarks", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_QuotationVersion", Integer.class, ParameterMode.IN) 
                .registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR)
                .setParameter("p_LineOfBusinessID",quotationModel.getLineOfBusinessID())
                .setParameter("p_BranchID",quotationModel.getBranchID())
                .setParameter("p_QuotationID",quotationModel.getQuotationID())
                .setParameter("p_QuotationDate",quotationModel.getQuotationDate())
                .setParameter("p_QuotationNo",quotationModel.getQuotationNo())
                .setParameter("p_SalesHierarchyID",quotationModel.getSalesHierarchyID())
                .setParameter("p_SubChannelID",quotationModel.getSubChannelID())
                .setParameter("p_MainChannelID",quotationModel.getMainChannelID())
                .setParameter("p_SalesType",quotationModel.getSalesType())
                .setParameter("p_QuotationPartyMapID",quotationModel.getQuotationPartyMapID())
                .setParameter("p_ProductID",quotationModel.getProductID())
                .setParameter("p_PlanID",quotationModel.getPlanID())
                .setParameter("p_SumInsured",quotationModel.getSumInsured())
                .setParameter("p_PolicyStartDate", quotationModel.getPolicyStartDate())
                .setParameter("p_PolicyEndDate", quotationModel.getPolicyEndDate())
                .setParameter("p_PolicyIssueDate",quotationModel.getPolicyIssueDate())
                .setParameter("p_PremiumPaymentTerm",quotationModel.getPremiumPaymentTerm())           
                .setParameter("p_PremiumPaymentFrequencyID",quotationModel.getPremiumPaymentFrequencyID())
                .setParameter("p_BasePremium",quotationModel.getBasePremium())
                .setParameter("p_NetPremium",quotationModel.getNetPremium())               
                .setParameter("p_NetPayableAmount",quotationModel.getNetPayableAmount())
                .setParameter("p_DiscretionaryPercentage",quotationModel.getDiscretionaryPercentage())
                .setParameter("p_PolicyTerm",quotationModel.getPolicyTerm())
                .setParameter("p_DiscretionaryDiscountLoading",quotationModel.getDiscretionaryDiscountLoading())
                .setParameter("p_DiscretionaryAmount",quotationModel.getDiscretionaryAmount())
                .setParameter("p_IsServiceTax",quotationModel.getIsServiceTax())
                .setParameter("p_LoanID",quotationModel.getLoanID())
                .setParameter("p_OutstandingLoanAmt",quotationModel.getOutstandingLoanAmt())
                .setParameter("p_RateOfInterest",quotationModel.getRateOfInterest())
                .setParameter("p_EMITypeID",quotationModel.geteMITypeID())
                .setParameter("p_LoanTenture",quotationModel.getLoanTenture())
                .setParameter("p_LoanTypeID",quotationModel.getLoanTypeID())
                .setParameter("p_EMI",quotationModel.geteMI())
                .setParameter("p_StatusID",quotationModel.getStatusID())
                .setParameter("p_CreatedBy",quotationModel.getCreatedBy())
                .setParameter("p_CreatedOn",quotationModel.getCreatedOn())
                .setParameter("p_IsActive",quotationModel.getIsActive())
                .setParameter("p_TypeID",quotationModel.getTypeID())
                .setParameter("p_TotalMembers",quotationModel.getTotalMembers())
                .setParameter("p_TotalSumInsured",quotationModel.getTotalSumInsured())
                .setParameter("p_FileName",quotationModel.getFileName())
                .setParameter("p_FileHeaderID",quotationModel.getFileHeaderID())
                .setParameter("p_Remarks",quotationModel.getRemarks())
                .setParameter("p_QuotationVersion",quotationModel.getQuotationVersion());    
    			query.execute();
    			List<Object[]> list = (List<Object[]>) query.getResultList();
    			return list;
	}
	
	public List migrationQuotationDataUpload(QuotationModel quotationModel,String filePath) {
		
		List<Object> migrationQuotationDataUploadList = new ArrayList();
		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spMigrationQuotationDataUpload(?,?,?,?,?) ");

			cstm.setString(1, filePath);
			cstm.setInt(2, quotationModel.getQuotationID());
			cstm.setInt(3, quotationModel.getProductID());
			cstm.setInt(4, 0);
			cstm.registerOutParameter(5, OracleTypes.CURSOR);
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(5);

			if (result != null) {
				migrationQuotationDataUploadList = ResourceManager.resultSetToArrayList(result);

			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			closeConnection();

		}
		return migrationQuotationDataUploadList;
		
		
	}
	
	//avalo dhanclosing.. please save
	public void insertMasterPolicyPremium(MasterPolicyPremiumModel masterPolicyPremiumModel) {
		StoredProcedureQuery query = em
                .createStoredProcedureQuery("spInsertMasterPolicyPremium")
                .registerStoredProcedureParameter("p_ProductID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_QuotationID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_MasterPolicyID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_GroupID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PremiumID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_CoverageID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_PremiumValue", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("p_ActualPremiumValue", Integer.class, ParameterMode.IN)
                .setParameter("p_ProductID",masterPolicyPremiumModel.getProductID())
                .setParameter("p_QuotationID",masterPolicyPremiumModel.getQuotationID())
                .setParameter("p_MasterPolicyID",masterPolicyPremiumModel.getMasterPolicyID())
                .setParameter("p_GroupID",masterPolicyPremiumModel.getGroupID())
                .setParameter("p_PremiumID",masterPolicyPremiumModel.getPremiumID())
                .setParameter("p_CoverageID",masterPolicyPremiumModel.getCoverageID())
                .setParameter("p_PremiumValue",masterPolicyPremiumModel.getPremiumValue())
                .setParameter("p_ActualPremiumValue",masterPolicyPremiumModel.getActualPremiumValue());
                 
    			query.execute();
		
	}

}

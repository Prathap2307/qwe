package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.GetProductModel;
import com.LIC.model.ProductModel;
import com.LIC.utils.exception.ExceptionProcess;

@RestController
@SuppressWarnings("unchecked")
public class ProductDAO {
	private static final String		TRACE_ID = InsurerDao.class.getName();
	
	@Autowired	private EntityManager entityManager;
	
	
	
	public long InsertorUpdatePlanDetails(ProductModel productModel) throws Exception {
		long 					vPlanID =0;
		StoredProcedureQuery 	addProductStoredProcedure = null;
		try {
				addProductStoredProcedure = entityManager.createNamedStoredProcedureQuery("createOrUpdateProduct");
				
				addProductStoredProcedure.setParameter("vOrganisationID", productModel.getOrganisationId());
				addProductStoredProcedure.setParameter("vPlanID", productModel.getPlanId());
				addProductStoredProcedure.setParameter("vPlanName", productModel.getPlanName());
				addProductStoredProcedure.setParameter("vShortName", productModel.getShortName());
				addProductStoredProcedure.setParameter("vCategory", productModel.getCategory());
				addProductStoredProcedure.setParameter("vCreatedBy", productModel.getCreatedBy());
				addProductStoredProcedure.setParameter("vCreatedOn", productModel.getCreatedOn());
				addProductStoredProcedure.setParameter("vIsActive", productModel.getIsActive());
				addProductStoredProcedure.getParameter("vResult");
				 
				addProductStoredProcedure.execute();
				
				if(addProductStoredProcedure.getOutputParameterValue("vResult") != null) {
					vPlanID = (long) addProductStoredProcedure.getOutputParameterValue("vResult");
				}
				System.out.println("InsertorUpdatePlanDetails(vPlanID) "+vPlanID);
				return vPlanID;
		}catch(Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
			
		} finally {
			productModel	= null;
		}
	}
	
	public String deleteProduct(ProductModel model) throws Exception {
		String					deletedStatus		= null;
		StoredProcedureQuery 	query				= null;
		try {
				query = entityManager.createNamedStoredProcedureQuery("deleteProduct");
				query.setParameter("vPlanID",model.getPlanId());
				
				query.setParameter("vDeletedBy",model.getDeletedBy());
				query.setParameter("vDeletedOn",model.getDeletedOn());
				query.getParameter("RESULT1");
		        
				query.execute();
				if(query.getOutputParameterValue("RESULT1") != null) {
					deletedStatus = (String) query.getOutputParameterValue("RESULT1");
				}
				System.out.println("deleteProduct(deletedStatus) "+deletedStatus);
		        
			return deletedStatus;
		} catch(Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		} finally {
		}
	}
	
	
	public List<GetProductModel>getAllPlanDetailsByPlanName(String planName)throws Exception {
		StoredProcedureQuery query = null;
		try {
			query = entityManager.createStoredProcedureQuery("spGetAllPlanDetails")
					.registerStoredProcedureParameter("vPlanName",String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("oPlan", Class.class, ParameterMode.REF_CURSOR)
					.setParameter("vPlanName",planName);
			// return query.execute() ? query.getResultList() : null;


			query.execute();
			List<Object[]> list  =  (List<Object[]>)query.getResultList();
			List<GetProductModel> accList = list.stream().map(
					o -> new GetProductModel((Number) o[0],(String) o[1],(String) o[2],(Number) o[3], (Number) o[4])).collect(Collectors.toList());

			return accList;
		}catch(Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		} finally {
			
		}


	}
	
	
	
	public List<GetProductModel>GetAllPlan()throws Exception {
		try {
			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("GetAllPlan")
					.registerStoredProcedureParameter("oPlan", Class.class, ParameterMode.REF_CURSOR);


			//return query.execute() ? query.getResultList() : null;


			query.execute();
			List<Object[]> list  =  (List<Object[]>)query.getResultList();
			List<GetProductModel> accList = list.stream().map(
					o -> new GetProductModel((Number)o[0],(Number)o[1],(String)o[2],(String)o[3],(Number)o[4], (Number) o[5],(Number)o[6])).collect(Collectors.toList());

			return accList;


		}catch (Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);		
		}finally {

		}


	}
	
	
	public List<GetProductModel> getAllPlanCategory(long LobId) throws Exception {
		StoredProcedureQuery query = null;
		try {
			query = entityManager.createStoredProcedureQuery("spGetAllProductTypesNew")
					.registerStoredProcedureParameter("vLobID",Long.class, ParameterMode.IN)
					.registerStoredProcedureParameter("oCategory", Class.class, ParameterMode.REF_CURSOR)
					.setParameter("vLobID",LobId);


			// return query.execute() ? query.getResultList() : null;


			query.execute();
			List<Object[]> list  =  (List<Object[]>)query.getResultList();
			List<GetProductModel> accList = list.stream().map(
					o -> new GetProductModel((Number) o[0],(String) o[1])).collect(Collectors.toList());

			return accList;


		}catch(Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {

		}


	}
	
	public GetProductModel getPlanDetailsByPlanId(long planId)throws Exception {
		StoredProcedureQuery query 				= null;
		GetProductModel 	getProductModel 	= null;
		try {
			query = entityManager.createStoredProcedureQuery("SPGETPLANBYID")
					.registerStoredProcedureParameter("vPlanID",Long.class, ParameterMode.IN)
					.registerStoredProcedureParameter("oPlan", Class.class, ParameterMode.REF_CURSOR)
					.setParameter("vPlanID",planId);
			// return query.execute() ? query.getResultList() : null;


			query.execute();
			List<Object[]> list  =  (List<Object[]>)query.getResultList();
			List<GetProductModel> accList = list.stream().map(
					o -> new GetProductModel((Number)o[0],(String)o[1],(String)o[2],(Number)o[3])).collect(Collectors.toList());
			
			if(accList != null && accList.size() > 0 ) {
				getProductModel = accList.get(0);
				getProductModel.setPlanId(planId);
			}

			return getProductModel;
		}catch(Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		} finally {
			
		}


}
	
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.LIC.model.Insurer;

@Repository
public interface IInsurerDAO {
	
	public List<Insurer> getAll(Insurer filterObj) throws SQLException ;

}

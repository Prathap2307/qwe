package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.AddressType;

public interface IAddressTypeDAO {
	public void saveOrUpdate(AddressType obj) throws SQLException ;
	public void delete(Integer addressTypeID, Integer deleteBy) throws SQLException;
	public List<AddressType> getAll(AddressType filterObj) throws SQLException;
	public AddressType get(Integer addressTypeID) throws SQLException;
}


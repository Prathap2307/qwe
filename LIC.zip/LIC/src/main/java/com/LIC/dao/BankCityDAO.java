
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.BankCity;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class BankCityDAO implements IBankCityDAO {
	
	static final Logger LOGGER = LogManager.getLogger(BankCityDAO.class);
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(BankCity obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateBankCity(?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getDistrictId());
		  callableStatement.setInt(2, obj.getBankCityId());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setString(4, obj.getShortDescription());
		  callableStatement.setInt(5, obj.getCreatedBy());
		  callableStatement.setString(6, obj.getRemarks());
		  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateBankCity executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateBankCity executed successfully.");
	}
	  
	@Override
	public void delete(Integer id, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteBankCity(?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteBankCity executed successfully.");
		  LOGGER.info("SP>spDeleteBankCity executed successfully.");
	} 
	
	@Override
	public List<BankCity> getAll(BankCity filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<BankCity> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllBankCity(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, filterObj.getDistrictId());
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  BankCity obj = null;
			  list = new ArrayList<BankCity>();
		      while (rs.next()) {
		        obj = new BankCity();
		        obj.setBankCityId(rs.getInt("BankCityID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setShortDescription(rs.getString("shortDescription"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllBankCity executed successfully.");
			  LOGGER.info("SP>spGetAllBankCity executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllBankCitys exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public BankCity get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  BankCity obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetBankCityByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new BankCity();
		        obj.setBankCityId(rs.getInt("BankCityID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setShortDescription(rs.getString("shortDescription"));
		      }
			  System.out.println("SP>spGetBankCityByID executed successfully.");
			  LOGGER.info("SP>spGetBankCityByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetBankCityByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	}  
	 
}

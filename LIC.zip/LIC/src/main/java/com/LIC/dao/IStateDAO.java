package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.State;

public interface IStateDAO {
	public void saveOrUpdate(State obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<State> getAll(State filterObj) throws SQLException;
	public State get(Integer id) throws SQLException;
}

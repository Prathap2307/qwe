package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductDocumentMap;

import oracle.jdbc.OracleTypes;

	@Repository
	public class ProductDocumentMapDAO implements IProductDocumentMapDAO {
		
		static final Logger LOGGER = LogManager.getLogger(ProductDocumentMapDAO.class);
	
		@Override
		public Integer saveOrUpdate(Connection connection,ProductDocumentMap obj) throws SQLException {
		
			  CallableStatement callableStatement = connection.prepareCall("BEGIN spInserProductDocumentMap(?,?,?,?); END;");
			  callableStatement.setInt(1, obj.getProductID());
			  callableStatement.setInt(2, obj.getDocumentTypeId());
			  callableStatement.setInt(3, obj.getCreatedBy());
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  //callableStatement.registerOutParameter(3, Types.VARCHAR);
			  callableStatement.executeUpdate();
			  /*ResultSet rs = null;
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, obj.getId());
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(48);
		      while (rs.next()) {
		    	obj.setId(rs.getInt("ID"));
		      }*/
			  LOGGER.info("SP>spInserProductDocumentMap executed successfully.");
			  return 1;
		
		}
	
		
}

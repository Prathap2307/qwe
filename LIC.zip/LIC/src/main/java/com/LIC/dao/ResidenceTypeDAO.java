package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ResidenceType;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class ResidenceTypeDAO implements IResidenceTypeDAO {
	
	static final Logger LOGGER = LogManager.getLogger(ResidenceTypeDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(ResidenceType obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateResidenceType(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getResidenceTypeId());
		  callableStatement.setString(2, obj.getShortDescription());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setInt(4, obj.getCreatedBy());
		  callableStatement.setString(5, obj.getRemarks());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateResidenceType executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateResidenceType executed successfully.");
	}
	
	@Override
	public void delete(Integer accountTypeID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteResidenceType(?,?,?); END;");
		  callableStatement.setInt(1, accountTypeID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteResidenceType executed successfully.");
		  LOGGER.info("SP>spDeleteResidenceType executed successfully.");
	} 
	
	@Override
	public List<ResidenceType> getAll(ResidenceType filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<ResidenceType> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllResidenceType(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  ResidenceType obj = null;
			  list = new ArrayList<ResidenceType>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")); 
		        obj = new ResidenceType();
		        obj.setResidenceTypeId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllResidenceType executed successfully.");
			  LOGGER.info("SP>spGetAllResidenceType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllResidenceType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public ResidenceType get(Integer accountTypeID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  ResidenceType obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetResidenceType(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, accountTypeID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")); 
		        obj = new ResidenceType();
		        obj.setResidenceTypeId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		      }
			  System.out.println("SP>spGetResidenceType executed successfully.");
			  LOGGER.info("SP>spGetResidenceType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetResidenceType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

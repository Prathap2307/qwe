package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.DocumentType;

public interface IDocumentTypeDAO {
	public void saveOrUpdate(DocumentType obj) throws SQLException ;
	public void delete(Integer documentTypeID, Integer deleteBy) throws SQLException;
	public List<DocumentType> getAll(DocumentType filterObj) throws SQLException;
	public DocumentType get(Integer documentTypeID) throws SQLException;
	
}

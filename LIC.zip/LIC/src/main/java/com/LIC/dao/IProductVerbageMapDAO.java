package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.LIC.model.ProductVerbageMap;

public interface IProductVerbageMapDAO {
	public void saveOrUpdate(Connection connection,ProductVerbageMap obj) throws SQLException ;
	public void delete(Connection connection,Integer productID) throws SQLException ;	

}

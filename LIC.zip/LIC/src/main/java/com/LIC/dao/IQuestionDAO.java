package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Question;

public interface IQuestionDAO {
	public List<Question> getAll(Question filterObj) throws SQLException ;

}

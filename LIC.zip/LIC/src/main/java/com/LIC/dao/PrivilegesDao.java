package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.LIC.model.FeatureModal;
import com.LIC.model.PrivilegesModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
public class PrivilegesDao 
{
	@Autowired	JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(PrivilegesDao.class);
	
	public List<PrivilegesModal> GetUserModulesFeatureByUserID(long UserID, long LineOfBusinessID) throws Exception{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		PrivilegesModal 		privilage 			= null;
	    List<PrivilegesModal> 	privilagemodallist 	= null;
		try {
			 conn   		= ResourceManager.getConnection();
			 cstm 		= conn.prepareCall("call spGetUserModulesFeatureByUserID(?,?,?)");
			 cstm.setLong(1, UserID);
			 cstm.setLong(2, LineOfBusinessID);
			 cstm.registerOutParameter(3, OracleTypes.CURSOR);
			 cstm.executeUpdate();
			 
			 result = ((OracleCallableStatement)cstm).getCursor(3);
			 
			 if(result != null) {
				 
				privilagemodallist	= new ArrayList<PrivilegesModal>();
				while(result.next()){
					privilage = new PrivilegesModal();
					privilage.setUserID(UserID);
					privilage.setModuleID(result.getLong("ModuleID"));
					privilage.setFeatureID(result.getLong("FeatureID"));
					privilagemodallist.add(privilage);
				}
			}
			 
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return privilagemodallist;
	}
	
	public List<PrivilegesModal> GetUserGroupModulesFeaturesRolesByID(int TypeID, long UserGroupID, long DesignationID) throws Exception{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		PrivilegesModal 		privilage 			= null;
	    List<PrivilegesModal> 	privilagemodallist 	= null;
		try {
			 conn   	= ResourceManager.getConnection();
			 cstm 		= conn.prepareCall("call spGetUserGroupModulesFeaturesRolesByID(?,?,?,?)");
			 cstm.setLong(1, TypeID);
			 cstm.setLong(2, UserGroupID);
			 cstm.setLong(3, DesignationID);
			 cstm.registerOutParameter(4, OracleTypes.CURSOR);
			 cstm.executeUpdate();
			 
			 result = ((OracleCallableStatement)cstm).getCursor(4);
			
			 if(result != null) {
				 privilagemodallist	= new ArrayList<PrivilegesModal>();
					
				 while(result.next()) {
					privilage = new PrivilegesModal();
					privilage.setModuleID(result.getLong("ModuleID"));
					privilage.setFeatureID(result.getLong("FeatureID"));
					if(TypeID == 2) {
						privilage.setGroupRoles(result.getString("Roles"));
					} else {
						privilage.setUserRoles(result.getString("Roles"));
						
					}
					privilage.setDesignationID(DesignationID);
					privilage.setType(result.getInt("Type"));
					
					privilagemodallist.add(privilage);
				}
			}
			 return privilagemodallist;
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return privilagemodallist;
	}
	
	public long InsertPrivileges(List<PrivilegesModal> privilagemodallist) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		try {
			conn   	= ResourceManager.getConnection();
			
			for (PrivilegesModal privilegesModal : privilagemodallist) {
				
				cstm   = conn.prepareCall("call spInsertOrUpdatePrivileges(?,?,?,?,?,?,?,?,?,?,?,?,?)");
				cstm.setLong(1, privilegesModal.getUserID());
				cstm.setLong(2, privilegesModal.getGroupID());
				cstm.setLong(3, privilegesModal.getModuleID());
				cstm.setLong(4, privilegesModal.getFeatureID());
				cstm.setString(5, privilegesModal.getUserRoles());
				cstm.setString(6, privilegesModal.getGroupRoles());
				cstm.setLong(7, privilegesModal.getCreatedBy());
				cstm.setTimestamp(8, privilegesModal.getCreatedOn());
				cstm.setLong(9, privilegesModal.getType());
				cstm.setLong(10, privilegesModal.getDepartmentID());
				cstm.setLong(11, privilegesModal.getDesignationID());
				cstm.setLong(12, privilegesModal.getLineOfBusinessID());
				cstm.registerOutParameter(13, OracleTypes.CURSOR);
				cstm.executeUpdate();

				result = ((OracleCallableStatement)cstm).getCursor(13);
				
				System.err.println("sddd"+result);
				if(result != null) {
					if(result.next()) {
						System.err.println("sddd"+result.getLong("PrivilegID"));
						return result.getLong("PrivilegID");
					}
				}
				
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return 0;
	}

	public List<FeatureModal> getAllFeaturesForProcess() throws Exception {
		   CallableStatement		cstm				= null;
		   Connection 				conn 				= null; 
		   ResultSet 				result 				= null;
		   FeatureModal 			featureModal 		= null;
		   List<FeatureModal>		featureModalList	= null;   
			
		   try {
			   conn = ResourceManager.getConnection();
			   cstm = conn.prepareCall("call spGetAllFeaturesForProcess(?)");
			   
			   cstm.registerOutParameter(1, OracleTypes.CURSOR);
			   cstm.execute();
			   
			   result = ((OracleCallableStatement)cstm).getCursor(1);
			   
			   if(result != null) {
				  
				   featureModalList =  new ArrayList<FeatureModal>();
				   
				   while(result.next()) {
					   featureModal = new FeatureModal();
					   featureModal.setFeatureID(result.getLong("FeatureID"));
					   featureModal.setDescription(result.getString("Description"));
					   featureModalList.add(featureModal);
				   }
			   }
				   
			} catch (Exception e)  {
				e.printStackTrace();
				logger.error(e.getMessage(), e);
			} finally {
				cstm.close();
				cstm	= null;
				ResourceManager.freeConnection(conn);
				conn	= null;	
			}
			return featureModalList;
		}
	
}

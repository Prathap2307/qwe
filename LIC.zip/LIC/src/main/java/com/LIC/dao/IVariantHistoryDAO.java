package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.VariantHistory;

public interface IVariantHistoryDAO {
	public List<VariantHistory> getAll(Integer id) throws SQLException;

}


package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductQuestionMap;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

	@Repository
	public class ProductQuestionMapDAO implements IProductQuestionMapDAO{
		
		static final Logger LOGGER = LogManager.getLogger(ProductQuestionMapDAO.class);
		
		@Override
		public void saveOrUpdate(Connection connection,ProductQuestionMap obj) throws SQLException {
		
			  CallableStatement callableStatement = connection.prepareCall("BEGIN spInserProductQuestionMap(?,?,?,?); END;");
			  callableStatement.setInt(1, obj.getProductID());
			  callableStatement.setInt(2, obj.getQuestionId());
			  callableStatement.setInt(3, obj.getCreatedBy());
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  //callableStatement.registerOutParameter(3, Types.VARCHAR);
			  callableStatement.executeUpdate();
			  LOGGER.info("SP>spInserProductQuestionMap executed successfully.");
		
		}
		@Override
		public List<Integer> get(Connection connection,Integer id) throws SQLException {
			  ResultSet rs = null;
			  CallableStatement callableStatement = null;
			  ProductQuestionMap obj = null;
			  List<Integer> list = null;
			  try {
				  callableStatement = connection.prepareCall("BEGIN spGetProductQuestionByID(?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  callableStatement.setInt(1, id);
				  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
				  callableStatement.execute();
				  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
				  list=new ArrayList<Integer>();
			      while (rs.next()) {
			        obj = new ProductQuestionMap();
			        obj.setProductID(rs.getInt("PRODUCTID"));
			        obj.setQuestionId(rs.getInt("QUESTIONID"));
			        list.add(obj.getQuestionId());

			      }
				  LOGGER.info("SP>spGetProductQuestionByID executed successfully.");
			  }catch (Exception e) {
				  LOGGER.error("SP>spGetProductQuestionByID exception occured."+e.getMessage());
				  e.printStackTrace();
			  }finally {
				
			  }
			  return list;
		} 
		
		@Override
		public void delete(Connection connection,Integer productID) throws SQLException {	
			CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductQuestionByID(?,?); END;");
			  callableStatement.setInt(1, productID);
			  callableStatement.registerOutParameter(2, Types.VARCHAR); 
			  callableStatement.executeUpdate();
			  System.out.println("SP>spDeleteProductQuestionByID executed successfully.");
			  LOGGER.info("SP>spDeleteProductQuestionByID executed successfully.");
		}
}


package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.Premium;
import com.LIC.model.PremiumType;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class PremiumDAO implements IPremiumDAO {

	static final Logger LOGGER = LogManager.getLogger(VariantDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	
	@Override
	public Integer saveOrUpdate( Connection connection,Premium obj) throws SQLException {
	  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateMasterPremium(?,?,?,?,?,?,?,?,?,?); END;");
	  callableStatement.setInt(1, obj.getId());
	  callableStatement.setString(2, obj.getRuleSetName());
	  callableStatement.setInt(3, obj.getVariantId());
	  callableStatement.setInt(4, obj.getVariantPremiumTypeId());
	  callableStatement.setInt(5, obj.getBenefitRiderId());
	  callableStatement.setInt(6, obj.getProcessID());
	  callableStatement.setString(7, obj.getAmountTypeId().toString());
	  callableStatement.setDouble(8, obj.getPremiumValue());
	  callableStatement.setInt(9,obj.getCreatedBy());
	  callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
	  ResultSet rs = null;
	  callableStatement = callableStatement.unwrap(CallableStatement.class);
	  callableStatement.setInt(1, obj.getId());
	  callableStatement.registerOutParameter(10, OracleTypes.CURSOR); 
	  callableStatement.executeUpdate();
	  rs = ((OracleCallableStatement)callableStatement).getCursor(10);
      while (rs.next()) {
    	obj.setId(rs.getInt("PremiumID"));
      } 
	  LOGGER.info("SP>spInsertOrUpdateMasterPremium executed successfully.");
	  return 1;
	}
	
	
	@Override
	public void delete(Connection connection,Integer premiumID, Integer deleteBy) throws SQLException {
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteMasterPremium(?,?,?); END;");
		  callableStatement.setInt(1, premiumID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteMasterPremium executed successfully.");
		  LOGGER.info("SP>spDeleteMasterPremium executed successfully.");
	} 
	
	@Override
	public Premium get(Connection connection,Integer premiumID) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  Premium obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetMasterPremium(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, premiumID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new Premium();
		        obj.setId(rs.getInt("ID"));
		        obj.setVariantId(rs.getInt("PRODUCTID"));
		        obj.setVariantPremiumTypeId(rs.getInt("PRODUCTPREMIUMTYPEID"));
		        obj.setBenefitRiderId(rs.getInt("COVERAGEID"));
		        obj.setRuleSetName(rs.getString("RULESETNAME"));
		        obj.setAmountTypeId(Integer.parseInt(rs.getString("AMOUNTTYPEID")));
		        obj.setPremiumValue(rs.getDouble("PREMIUMVALUE"));
		      }
			  LOGGER.info("SP>spGetMasterPremium executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetMasterPremium exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
	
	@Override
	public List<Premium> getAll(Premium filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Premium> list = null;
		  try {
			  System.out.println("filterObj pramod >>> "+filterObj);
			  callableStatement = connection.prepareCall("BEGIN spGetAllMasterPremium(?,?,?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, filterObj.getVariantId());
			  callableStatement.setInt(2, filterObj.getVariantPremiumTypeId());
			  callableStatement.setInt(3, filterObj.getBenefitRiderId());
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(4);
			  Premium obj = null;
			  list = new ArrayList<Premium>();
		      while (rs.next()) {
		    	  obj = new Premium();
			      obj.setId(rs.getInt("ID"));
			      obj.setRuleSetName(rs.getString("RULESETNAME"));
		          list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllMasterPremium executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllMasterPremium exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	

	
	@Override
	public List<PremiumType> getPreimumTypeByBusinessId(Integer lineOfBusinessId, Integer productId) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  PremiumType obj = null;
		  List<PremiumType> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN GetProductPremiumTypeByProductID(?,?,?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, lineOfBusinessId);
			  callableStatement.setInt(2, productId);
			  callableStatement.setInt(3, 0);
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(4);
			  list = new ArrayList<PremiumType>();
		      while (rs.next()) {
		    	  obj = new PremiumType();
			      obj.setId(rs.getInt("PRODUCTPREMIUMTYPEID"));
			      obj.setDescription(rs.getString("DESCRIPTION"));
			      obj.setVariantId(productId);
		          list.add(obj);
		      }
			  LOGGER.info("SP>GetProductPremiumTypeByProductID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>GetProductPremiumTypeByProductID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
}
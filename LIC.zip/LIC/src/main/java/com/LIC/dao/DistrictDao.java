package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.District;
import com.LIC.model.DistrictModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class DistrictDao implements IDistrictDAO {

	
	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(DistrictDao.class);

	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(District obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateDistrict(?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getStateId());
		  callableStatement.setInt(2, obj.getDistrictId());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setString(4, obj.getZipCode());
		  callableStatement.setInt(5, obj.getCreatedBy());
		  callableStatement.setString(6, obj.getRemarks());
		  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateDistrict executed successfully.");
		  logger.info("SP>spInsertOrUpdateDistrict executed successfully.");
	}
 
	 
	@Override
	public void delete(Integer id, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteDistrict(?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteDistrict executed successfully.");
		  logger.info("SP>spDeleteDistrict executed successfully.");
	} 
	
	@Override
	public List<District> getAll(District filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<District> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllDistricts(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, filterObj.getStateId());
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  District obj = null;
			  list = new ArrayList<District>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("DISTRICTID")+" | "+rs.getString("Description")+" | "+rs.getString("ZipCode")); 
		        obj = new District();
		        obj.setDistrictId(rs.getInt("DISTRICTID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setZipCode(rs.getString("ZipCode"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllDistricts executed successfully.");
			  logger.info("SP>spGetAllDistricts executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetAllDistricts exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public District get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  District obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetDistrictByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		    	System.out.println(rs.getInt("DistrictID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("ZipCode")); 
		        obj = new District();
		        obj.setDistrictId(rs.getInt("DistrictID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setZipCode(rs.getString("ZipCode"));
		      }
			  System.out.println("SP>spGetDistrictByID executed successfully.");
			  logger.info("SP>spGetDistrictByID executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetDistrictByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	
	public List<DistrictModal> getAllDistrictsByStateId(long stateID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DistrictModal			districtModal		= null;
		List<DistrictModal>		districtList		= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			 
			cstm 		= conn.prepareCall("call spGetAllDistricts(?,?) ");
			
			cstm.setLong(1, stateID); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {
		    	
		    	districtList	= new ArrayList<DistrictModal>();
		    	
		    	while (result.next()) {
		    		districtModal = new DistrictModal();
		    		
		    		districtModal.setDistrictId(result.getLong("DistrictID"));
		    		districtModal.setStateID(stateID);
		    		districtModal.setZipCode(result.getString("ZipCode"));
		    		districtModal.setDescription(result.getString("Description"));
		    		
		    		districtList.add(districtModal);
		    	}
		    }
		
		    return districtList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			districtList	= null;
		}
		return null;
	}
	
}

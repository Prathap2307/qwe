package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.DepartmentModel;
import com.LIC.model.GetBankBranch;
import com.LIC.model.GetDepartmentModel;

@Repository
public class DepartmentDAO {
	@Autowired
	private EntityManager em;
	
	
@SuppressWarnings("unchecked")

	
public List<GetDepartmentModel> getAllDepartmentInfo() {
    
    
    StoredProcedureQuery query = em
                 .createStoredProcedureQuery("spGetAllBindDepartment")
                /* .registerStoredProcedureParameter(
                     1,
                     Integer.class,
                     ParameterMode.IN
                 )
                 .registerStoredProcedureParameter(
                     2,
                     String.class,
                     ParameterMode.IN
                 )*/
                 .registerStoredProcedureParameter(
                         1,
                         Class.class,
                         ParameterMode.REF_CURSOR
                     );
                 //.setParameter(1, 1).setParameter(2, "Human Resource");
    
                 
  //  return query.execute() ? query.getResultList() : null;
    
    List<Object[]> list  =  (List<Object[]>)query.getResultList();
    List<GetDepartmentModel> accList = list.stream().map(
            o -> new GetDepartmentModel((Number) o[0], (String) o[1],(String) o[2], (Number) o[3])).collect(Collectors.toList());
    
   return accList;
}


public void createDepartmentInfo(DepartmentModel model) {

	StoredProcedureQuery addDepStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateDep");
	addDepStoredProcedure.setParameter("vDepartmentID", model.getDepartmentId());
	addDepStoredProcedure.setParameter("vShortName", model.getShortName());
	addDepStoredProcedure.setParameter("vDescription", model.getDescription());
	addDepStoredProcedure.setParameter("pCreatedBy", model.getCreatedBy());
	addDepStoredProcedure.setParameter("pCreatedOn", model.getCreatedOn());
	addDepStoredProcedure.setParameter("pIsActive", 1);
	addDepStoredProcedure.execute();
	

}

public void deleteDepartment(DepartmentModel  model) {

	StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteDep");
	query.setParameter("vDepartmentID",model.getDepartmentId());
	
	query.setParameter("pDELETEDBY",model.getDeletedBy());
	query.setParameter("pDELETEDON",model.getDeletedOn());
	query.getParameter("pRESULT");
    query.execute();
}











public List<GetDepartmentModel>GetDepartmentByDepartMentName(Number departmentId,String description) {
    StoredProcedureQuery query = em
           .createStoredProcedureQuery("spGetAllDepartment")
           .registerStoredProcedureParameter("v_DeparmentID",Long.class, ParameterMode.IN)
           .registerStoredProcedureParameter("v_Description",String.class, ParameterMode.IN)
           .registerStoredProcedureParameter("c1", Class.class, ParameterMode.REF_CURSOR)
                     .setParameter("v_DeparmentID",departmentId)
    .setParameter("v_Description",description);

    
     // return query.execute() ? query.getResultList() : null;
  
    
    query.execute();
    List<Object[]> list  =  (List<Object[]>)query.getResultList();
    List<GetDepartmentModel> accList = list.stream().map(
    		  o -> new GetDepartmentModel((Number) o[0], (String) o[1],(String) o[2],(Number) o[3])).collect(Collectors.toList());
    
   return accList;
   
     
   }





}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.Relationship;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class RelationshipDAO implements IRelationshipDAO {
	
	static final Logger LOGGER = LogManager.getLogger(RelationshipDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(Relationship obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateRelationship(?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getRelationshipId());
		  callableStatement.setString(2, obj.getDescription());
		  callableStatement.setInt(3, obj.getCreatedBy());
		  callableStatement.setString(4, obj.getRemarks());
		  callableStatement.registerOutParameter(5, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateRelationship executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateRelationship executed successfully.");
	}
	
	@Override
	public void delete(Integer relationshipID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteRelationship(?,?,?); END;");
		  callableStatement.setInt(1, relationshipID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteRelationship executed successfully.");
		  LOGGER.info("SP>spDeleteRelationship executed successfully.");
	} 
	
	@Override
	public List<Relationship> getAll(Relationship filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Relationship> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllRelationship(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Relationship obj = null;
			  list = new ArrayList<Relationship>();
		      while (rs.next()) {
		        obj = new Relationship();
		        obj.setRelationshipId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllRelationship executed successfully.");
			  LOGGER.info("SP>spGetAllRelationship executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllRelationship exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public Relationship get(Integer relationshipID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  Relationship obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetRelationship(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, relationshipID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new Relationship();
		        obj.setRelationshipId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		      }
			  System.out.println("SP>spGetRelationship executed successfully.");
			  LOGGER.info("SP>spGetRelationship executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetRelationship exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	
	
	
	 
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.PaymentMode;

public interface IPaymentModeDAO {
	public void saveOrUpdate(PaymentMode obj) throws SQLException ;
	public void delete(Integer paymentModeID, Integer deleteBy) throws SQLException;
	public List<PaymentMode> getAll(PaymentMode filterObj) throws SQLException;
	public PaymentMode get(Integer paymentModeID) throws SQLException;
}

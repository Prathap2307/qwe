package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Occupation;

public interface IOccupationDAO {
	public void saveOrUpdate(Occupation obj) throws SQLException ;
	public void delete(Integer occupationID, Integer deleteBy) throws SQLException;
	public List<Occupation> getAll(Occupation filterObj) throws SQLException;
	public Occupation get(Integer occupationID) throws SQLException;
}

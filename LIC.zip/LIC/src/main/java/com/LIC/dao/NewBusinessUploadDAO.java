package com.LIC.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.LIC.model.GetAllAuthorisedSignatoriesModel;
import com.LIC.model.GetGroupDetailsModel;
import com.LIC.model.GetMasterPolicyDetailsModel;
import com.LIC.model.NewBusinessModel;
import com.LIC.model.NewBusinessOutputModel;




@Repository
@SuppressWarnings("unchecked") 
public  class NewBusinessUploadDAO {

	@PersistenceContext
	private EntityManager em;
	
	
	//@Value("${newBusinessUploadPath.location}")
	private String UploadPath;
	
	
	public List<NewBusinessModel> SaveUploadedFile(MultipartFile file) throws IOException {
        List<NewBusinessModel> NBmodellist=new ArrayList<NewBusinessModel>();

     String OutputFile=UploadPath+file.getOriginalFilename();
     File convFile = new File(UploadPath+file.getOriginalFilename());
     convFile.createNewFile(); 
          
     FileOutputStream fos = new FileOutputStream(convFile); 
     fos.write(file.getBytes());
     fos.close(); 
     
     NewBusinessModel NBmodel=new NewBusinessModel();
     
     NBmodel.setFilePath(OutputFile);
     NBmodel.setFileName(file.getOriginalFilename());
     NBmodellist.add(NBmodel);
     return NBmodellist;

}


	
	
	public String ValidateExcelFile(NewBusinessModel NBmodel)
	{
		try {

			 File file = new File(NBmodel.getFilePath());
			 if(file.exists()) 
			 { 
		
			 String FileEx=getFileExtension(file);
	      
		     FileInputStream input_document = new FileInputStream(new File(NBmodel.getFilePath()));

		     Iterator<Row> rowIterator;
		     
		    // int columnCount = 70,FileColumnCount=0;
		     
		      if(FileEx.toUpperCase().equals("XLSX"))
		      {
		    	  XSSFWorkbook  my_xls_workbook = new XSSFWorkbook (input_document);
			      XSSFSheet  my_worksheet = my_xls_workbook.getSheetAt(0);
			      rowIterator = my_worksheet.iterator();
		      }
		      else {
		    	  HSSFWorkbook  my_xls_workbook = new HSSFWorkbook(input_document);
			      HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0);
			      rowIterator = my_worksheet.iterator();
		      }
		      	  Row row = rowIterator.next(); 
	              if(row!=null && row.getLastCellNum() > 0)
	              {
		            Iterator<Cell> cellIterator = row.cellIterator();
				
	                while(cellIterator.hasNext())
                     {
                   	  	  Cell nextCell = cellIterator.next();
                             
                             int columnIndex = nextCell.getColumnIndex();
                            // FileColumnCount=FileColumnCount+1;
                             switch (columnIndex) 
                             {
                             case 0:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("TYPE")) //Type
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Type";	
	                        	    }
	                        	    break;
	                          case 1:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("SCHEMENO")) //SchemeNo
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column SchemeNo";	
	                        	    }
	                        	    break;
	                          case 2: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("EMPLOYEENO")) //EmployeeNo
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column EmployeeNo";	
		                      	    }
		                      	    break;
	                          case 3: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("UNIQUEID")) //UniqueID
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column UniqueID";	
		                      	    }
		                      	    break;
	                          case 4: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("TITLE")) //Title
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Title";	
		                      	    }
		                      	    break;
	                          case 5: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("FIRSTNAME")) //FirstName
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column FirstName";	
		                      	    }
		                      	    break;
	                          case 6: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("MIDDLENAME")) //MiddleName
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column MiddleName";	
		                      	    }
		                      	    break;
	                          case 7: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("LASTNAME")) //LastName
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column LastName";	
		                      	    }
		                      	    break;
	                          case 8: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("DATEOFBIRTH")) //DateOfBirth
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column DateOfBirth";	
		                      	    }
		                      	    break;
	                          case 9: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("DATEOFJOINING")) //DateOfJoining
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column DateOfJoining";	
		                      	    }
		                      	    break;
	                          case 10: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("SCHEMEJOININGDATE")) //SchemeJoiningDate
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column SchemeJoiningDate";	
		                      	    }
		                      	    break;
		                      	    
		                      	    
	                          case 11:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("NBINTIMATIONDATE")) //NBIntimationDate
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NBIntimationDate";	
	                        	    }
	                        	    break;
	                          case 12: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("AGE")) //Age
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Age";	
		                      	    }
		                      	    break;
	                          case 13: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("BASICSALARY")) //BasicSalary
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column BasicSalary";	
		                      	    }
		                      	    break;
	                          case 14: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GENDER")) //Gender
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Gender";	
		                      	    }
		                      	    break;
	                          case 15: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("EMAILID")) //EmailID
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column EmailID";	
		                      	    }
		                      	    break;
	                          case 16: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("ADDRESSTYPE")) //AddressType
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column AddressType";	
		                      	    }
		                      	    break;
	                          case 17: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("ADDRESS1")) //Address1
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Address1";	
		                      	    }
		                      	    break;
	                          case 18: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("ADDRESS2")) //Address2
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Address2";	
		                      	    }
		                      	    break;
	                          case 19: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("ADDRESS3")) //Address3
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Address3";	
		                      	    }
		                      	    break;
	                          case 20: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("PINCODE")) //PinCode
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column PinCode";	
		                      	    }
		                      	    break;
		                      	    
		                      	    
	                          case 21:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("CITY")) //City
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column City";	
	                        	    }
	                        	    break;
	                          case 22: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("STATE")) //State
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column State";	
		                      	    }
		                      	    break;
	                          case 23: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("COUNTRY")) //Country
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Country";	
		                      	    }
		                      	    break;
	                          case 24: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("PHONENUMBER")) //PhoneNumber
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column PhoneNumber";	
		                      	    }
		                      	    break;
	                          case 25: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("MOBILENUMBER")) //MobileNumber
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column MobileNumber";	
		                      	    }
		                      	    break;
	                          case 26: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("PANNO")) //PanNo
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column PanNo";	
		                      	    }
		                      	    break;
	                          case 27: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("BENEFITOPTION")) //BenefitOption
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column BenefitOption";	
		                      	    }
		                      	    break;
	                          case 28: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSSUMASSURED")) //GPSSumAssured
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSSumAssured";	
		                      	    }
		                      	    break;
	                          case 29: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERAD")) //GPSRiderAD
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderAD";	
		                      	    }
		                      	    break;
	                          case 30: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERADD")) //GPSRiderADD
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderADD";	
		                      	    }
		                      	    break;
		                      	    
	                          case 31:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERTPD")) //GPSRiderTPD
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderTPD";	
	                        	    }
	                        	    break;
	                          case 32: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERAT")) //GPSRiderAT
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderAT";	
		                      	    }
		                      	    break;
	                          case 33: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERCI4")) //GPSRiderCI4
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderCI4";	
		                      	    }
		                      	    break;
	                          case 34: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERCIRC")) //GPSRiderCIRC
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderCIRC";	
		                      	    }
		                      	    break;
	                          case 35: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERCIP")) //GPSRiderCIP
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderCIP";	
		                      	    }
		                      	    break;
	                          case 36: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERCIA")) //GPSRiderCIA
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderCIA";	
		                      	    }
		                      	    break;
	                          case 37: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERTIP")) //GPSRiderTIP
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderTIP";	
		                      	    }
		                      	    break;
	                          case 38: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GPSRIDERATIR")) //GPSRiderATIR
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column GPSRiderATIR";	
		                      	    }
		                      	    break;
	                          case 39: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("SINGLEJOINTLIFE")) //SIngleJointLife
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column SingleJointLife";	
		                      	    }
		                      	    break;
	                          case 40: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("BENEFITTERM")) //BenefitTerm
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column BenefitTerm";	
		                      	    }
		                      	    break;
		                      	    
	                          case 41:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("TENUREOFTHELOAN")) //TenureOfTheLoan
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column TenureOfTheLoan";	
	                        	    }
	                        	    break;
	                          case 42: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("PREMIUMTERM")) //PremiumTerm
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column PremiumTerm";	
		                      	    }
		                      	    break;
	                          case 43: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEEEFFECTIVEDATE")) //NomineeEffectiveDate
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeEffectiveDate";	
		                      	    }
		                      	    break;
	                          case 44: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEENAME1")) //NomineeName1
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeName1";	
		                      	    }
		                      	    break;
	                          case 45: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEERELATIONSHIP1")) //NomineeRelationship1
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeRelationship1";	
		                      	    }
		                      	    break;
	                          case 46: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEEPERCENTAGE1")) //NomineePercentage1
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineePercentage1";	
		                      	    }
		                      	    break;
	                          case 47: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEENAME2")) //NomineeName2
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeName2";	
		                      	    }
		                      	    break;
	                          case 48: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEERELATIONSHIP2")) //NomineeRelationship2
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeRelationship2";	
		                      	    }
		                      	    break;
	                          case 49: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEEPERCENTAGE2")) //NomineePercentage2
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineePercentage2";	
		                      	    }
		                      	    break;
	                          case 50: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEENAME3")) //NomineeName3
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeName3";	
		                      	    }
		                      	    break;
		                      	    
	                          case 51:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEERELATIONSHIP3")) //NomineeRelationship3
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeRelationship3";	
	                        	    }
	                        	    break;
	                          case 52: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEEPERCENTAGE3")) //NomineePercentage3
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineePercentage3";	
		                      	    }
		                      	    break;
	                          case 53: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEENAME4")) //NomineeName4
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeName4";	
		                      	    }
		                      	    break;
	                          case 54: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEERELATIONSHIP4")) //NomineeRelationship4
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineeRelationship4";	
		                      	    }
		                      	    break;
	                          case 55: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("NOMINEEPERCENTAGE4")) //NomineePercentage4
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column NomineePercentage4";	
		                      	    }
		                      	    break;
	                          case 56: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("BRANCHCODEOFBANK")) //BranchCodeOfBank
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column BranchCodeOfBank";	
		                      	    }
		                      	    break;
	                          case 57: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("PREMIUMRECEIVED")) //PremiumReceived
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column PremiumReceived";	
		                      	    }
		                      	    break;
	                          case 58: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("DATEOFDISBURSEMENTOFLOAN")) //DateOfDisbursementOfLoan
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column DateOfDisbursementOfLoan";	
		                      	    }
		                      	    break;
	                          case 59: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("UNDERWRITINGDOCUMENTTYPE")) //UnderwritingDocumentType
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column UnderwritingDocumentType";	
		                      	    }
		                      	    break;
	                          case 60: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("HDFDATE")) //HDFDate
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column HDFDate";	
		                      	    }
		                      	    break;
		                      	    
	                          case 61:
	                        	    if(!nextCell.getStringCellValue().toUpperCase().equals("TYPEOFLOAN")) //TypeOfLoan
	                        	    {
	                        	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column TypeOfLoan";	
	                        	    }
	                        	    break;
	                          case 62: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("OCCUPATIONNAME")) //OccupationName
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column OccupationName";	
		                      	    }
		                      	    break;
	                          case 63: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("LOCATION")) //Location
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Location";	
		                      	    }
		                      	    break;
	                          case 64: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("ISWINDOWPERIODAPPLICABLE")) //IsWindowPeriodApplicable
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column IsWindowPeriodApplicable";	
		                      	    }
		                      	    break;
	                          case 65: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("GRADE")) //Grade
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Grade";	
		                      	    }
		                      	    break;
	                          case 66: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("TYPEOFCLAIM")) //TypeOfClaim
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column TypeOfClaim";	
		                      	    }
		                      	    break;
	                          case 67: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("CLAIMPAYOUTOPTION")) //ClaimPayOutOption
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column ClaimPayOutOption";	
		                      	    }
		                      	    break;
	                          case 68: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("OCCUPATIONRISK")) //OccupationRisk
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column OccupationRisk";	
		                      	    }
		                      	    break;
	                          case 69: 
	                        	  	if(!nextCell.getStringCellValue().toUpperCase().equals("PAYMENTFREQUENCY")) //PaymentFrequency
		                      	    {
		                      	    	return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column PaymentFrequency";	
		                      	    }
		                      	    break;
		                      case 70: 
			                    	  if(!nextCell.getStringCellValue().equals(""))
			                    	  {
			                      	    return "Duplicate/Excess of Column " + nextCell.getStringCellValue() + " is not allowed.Please Update the Column";	
			                      	  }
		                      	    break;    
		                      	  
	  
                             }
                     }
	                
				/*
				 * if(columnCount!=FileColumnCount) { return
				 * "File is rejected  Please upload Proper Excel Template"; }
				 */
                     
	              }
		      

		      input_document.close();
			 }
			 else {
				 return "File does not exists";
			 }
		  }
			catch (Exception e){
			  e.printStackTrace();
		  }
		return "";
	}
	
	@Transactional
	@Modifying
	public void BulkInsert(NewBusinessModel NBmodel) throws Exception {
	
		try {

			 File file = new File(NBmodel.getFilePath());
				
			 String FileEx=getFileExtension(file);
	      
		     Query sql_statement = em.createNativeQuery("INSERT INTO GNBDataUpload "
		     		+ "(FILENAME, SCHEMENO,EMPLOYEENO,UNIQUEID,TITLE,FIRSTNAME,MIDDLENAME,LASTNAME,DATEOFBIRTH,DATEOFJOINING"
		     		+ ",SCHEMEJOININGDATE,NBINTIMATIONDATE,AGE,BASICSALARY,GENDER,EMAILID,ADDRESSTYPE,ADDRESS1,ADDRESS2,ADDRESS3"
		     		+ ",PINCODE,CITY,STATE,COUNTRY,PHONENUMBER,MOBILENUMBER,PANNO,BENEFITOPTION,GPSSUMASSURED,GPSRIDERAD"
		     		+ ",GPSRIDERADD,GPSRIDERTPD,GPSRIDERAT,GPSRIDERCI4,GPSRIDERCIRC,GPSRIDERCIP,GPSRIDERCIA,GPSRIDERTIP,GPSRIDERATIR,SINGLEJOINTLIFE"
		     		+ ",BENEFITTERM,TENUREOFTHELOAN,PREMIUMTERM,NOMINEEEFFECTIVEDATE,NOMINEEBENEFICIARYDETAILS,NOMINEERELATIONSHIP,NOMINEEPERCENTAGE,NOMINEENAME2,NOMINEERELATIONSHIP2,NOMINEEPERCENTAGE2"
		     		+ ",NOMINEENAME3,NOMINEERELATIONSHIP3,NOMINEEPERCENTAGE3,NOMINEENAME4,NOMINEERELATIONSHIP4,NOMINEEPERCENTAGE4,BRANCHCODEOFBANK,PREMIUMRECEIVED,DATEOFDISBURSEMENTOFLOAN,UNDERWRITINGDOCUMENTTYPE"
		     		+ ",HDFDATE,TYPEOFLOAN,OCCUPATIONNAME,LOCATION,ISWINDOWPERIODAPPLICABLE,GRADE,TYPEOFCLAIM,CLAIMPAYOUTOPTION,OCCUPATIONRISK,PAYMENTFREQUENCY)"
		     		+ " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?"
		     		+ " ,?,?,?,?,?,?,?,?,?,? ,?,?,?,?,?,?,?,?,?,? ,?,?,?,?,?,?,?,?,?,? ,?,?,?,?,?,?,?,?,?,?) ");

		     FileInputStream input_document = new FileInputStream(new File(NBmodel.getFilePath()));

		     Iterator<Row> rowIterator;
     
		      if(FileEx.toUpperCase().equals("XLSX"))
		      {

			      XSSFWorkbook  my_xls_workbook = new XSSFWorkbook (input_document);

			      XSSFSheet  my_worksheet = my_xls_workbook.getSheetAt(0);
			      rowIterator = my_worksheet.iterator();
			      // we loop through and insert data
		      }
		      else {
		    	  HSSFWorkbook my_xls_workbook = new HSSFWorkbook(input_document);
			      HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0);
			      rowIterator = my_worksheet.iterator();
		      }
		      
		      rowIterator.next();
		      rowIterator.next();
		      rowIterator.next();
		      
		      while(rowIterator.hasNext())
		      {
	              Row row = rowIterator.next(); 
	              if(row!=null && row.getLastCellNum() > 0)
	              {
		              Iterator<Cell> cellIterator = row.cellIterator();
                      while(cellIterator.hasNext())
                      {
                    	  	  Cell nextCell = cellIterator.next();
                              
                              int columnIndex = nextCell.getColumnIndex();
                              switch (columnIndex) 
                              {
	                              case 0:
	                            	  sql_statement.setParameter(1, NBmodel.getFileName());
	                                  break;
	                              case 1:
	                            	  sql_statement.setParameter(2,nextCell.getStringCellValue());
	                            	  break;
	                              case 2:
	                            	  sql_statement.setParameter(3,nextCell.getStringCellValue());
	                            	  break;  
	                              case 3:
	                            	  sql_statement.setParameter(4,nextCell.getStringCellValue());
	                            	  break;  
	                              case 4:
	                            	  sql_statement.setParameter(5,nextCell.getStringCellValue());
	                            	  break;  
	                              case 5:
	                            	  sql_statement.setParameter(6,nextCell.getStringCellValue());
	                            	  break;  
	                              case 6:
	                            	  sql_statement.setParameter(7,nextCell.getStringCellValue());
	                            	  break; 
	                              case 7:
	                            	  sql_statement.setParameter(8,nextCell.getStringCellValue());
	                            	  break;
	                              case 8:
	                            	  sql_statement.setParameter(9, nextCell.getDateCellValue());
 	                            	  break;
	                              case 9:
	                            	  sql_statement.setParameter(10, nextCell.getDateCellValue());
 	                            	  break;
	                              case 10:
	                            	  sql_statement.setParameter(11, nextCell.getDateCellValue());
 	                            	  break;
	                              case 11:
	                            	  sql_statement.setParameter(12, nextCell.getDateCellValue());
 	                            	  break;
	                              case 12:
	                            	  sql_statement.setParameter(13, nextCell.getStringCellValue());
 	                            	  break;
	                              case 13:
	                            	  sql_statement.setParameter(14, nextCell.getStringCellValue());
 	                            	  break;
	                              case 14:
	                            	  sql_statement.setParameter(15, nextCell.getStringCellValue());
 	                            	  break;
	                              case 15:
	                            	  sql_statement.setParameter(16, nextCell.getStringCellValue());
 	                            	  break;
	                              case 16:
	                            	  sql_statement.setParameter(17, nextCell.getStringCellValue());
 	                            	  break;
	                              case 17:
	                            	  sql_statement.setParameter(18, nextCell.getStringCellValue());
 	                            	  break;
	                              case 18:
	                            	  sql_statement.setParameter(19, nextCell.getStringCellValue());
 	                            	  break;
	                              case 19:
	                            	  sql_statement.setParameter(20, nextCell.getStringCellValue());
 	                            	  break;
	                              case 20:
	                            	  sql_statement.setParameter(21, nextCell.getStringCellValue());
 	                            	  break;
	                              case 21:
	                            	  sql_statement.setParameter(22, nextCell.getStringCellValue());
 	                            	  break;
	                              case 22:
	                            	  sql_statement.setParameter(23, nextCell.getStringCellValue());
 	                            	  break;
	                              case 23:
	                            	  sql_statement.setParameter(24, nextCell.getStringCellValue());
 	                            	  break;  
	                              case 24:
	                            	  sql_statement.setParameter(25, nextCell.getStringCellValue());
 	                            	  break;
	                              case 25:
	                            	  sql_statement.setParameter(26, nextCell.getStringCellValue());
 	                            	  break;
	                              case 26:
	                            	  sql_statement.setParameter(27, nextCell.getStringCellValue());
 	                            	  break;
	                              case 27:
	                            	  sql_statement.setParameter(28, nextCell.getStringCellValue());
 	                            	  break;
	                              case 28:
	                            	  sql_statement.setParameter(29, nextCell.getStringCellValue());
 	                            	  break;
	                              case 29:
	                            	  sql_statement.setParameter(30, nextCell.getStringCellValue());
 	                            	  break;
	                              case 30:
	                            	  sql_statement.setParameter(31, nextCell.getStringCellValue());
 	                            	  break;
	                              case 31:
	                            	  sql_statement.setParameter(32, nextCell.getStringCellValue());
 	                            	  break;
	                              case 32:
	                            	  sql_statement.setParameter(33, nextCell.getStringCellValue());
 	                            	  break;
	                              case 33:
	                            	  sql_statement.setParameter(34, nextCell.getStringCellValue());
 	                            	  break;  
	                              case 34:
	                            	  sql_statement.setParameter(35, nextCell.getStringCellValue());
 	                            	  break;
	                              case 35:
	                            	  sql_statement.setParameter(36, nextCell.getStringCellValue());
 	                            	  break;
	                              case 36:
	                            	  sql_statement.setParameter(37, nextCell.getStringCellValue());
 	                            	  break;
	                              case 37:
	                            	  sql_statement.setParameter(38, nextCell.getStringCellValue());
 	                            	  break;
	                              case 38:
	                            	  sql_statement.setParameter(39, nextCell.getStringCellValue());
 	                            	  break;
	                              case 39:
	                            	  sql_statement.setParameter(40, nextCell.getStringCellValue());
 	                            	  break;  
 	                            	  
	                              case 40:
	                            	  sql_statement.setParameter(41, nextCell.getStringCellValue());
 	                            	  break;
	                              case 41:
	                            	  sql_statement.setParameter(42, nextCell.getStringCellValue());
 	                            	  break;
	                              case 42:
	                            	  sql_statement.setParameter(43, nextCell.getStringCellValue());
 	                            	  break;
	                              case 43:
	                            	  sql_statement.setParameter(44, nextCell.getDateCellValue());
 	                            	  break;  
	                              case 44:
	                            	  sql_statement.setParameter(45, nextCell.getStringCellValue());
 	                            	  break;
	                              case 45:
	                            	  sql_statement.setParameter(46, nextCell.getStringCellValue());
 	                            	  break;
	                              case 46:
	                            	  sql_statement.setParameter(47, nextCell.getStringCellValue());
 	                            	  break;
	                              case 47:
	                            	  sql_statement.setParameter(48, nextCell.getStringCellValue());
 	                            	  break;
	                              case 48:
	                            	  sql_statement.setParameter(49, nextCell.getStringCellValue());
 	                            	  break;
	                              case 49:
	                            	  sql_statement.setParameter(50, nextCell.getStringCellValue());
 	                            	  break; 
 	                            	  
	                              case 50:
	                            	  sql_statement.setParameter(51, nextCell.getStringCellValue());
 	                            	  break;
	                              case 51:
	                            	  sql_statement.setParameter(52, nextCell.getStringCellValue());
 	                            	  break;
	                              case 52:
	                            	  sql_statement.setParameter(53, nextCell.getStringCellValue());
 	                            	  break;
	                              case 53:
	                            	  sql_statement.setParameter(54, nextCell.getStringCellValue());
 	                            	  break;  
	                              case 54:
	                            	  sql_statement.setParameter(55, nextCell.getStringCellValue());
 	                            	  break;
	                              case 55:
	                            	  sql_statement.setParameter(56, nextCell.getStringCellValue());
 	                            	  break;
	                              case 56:
	                            	  sql_statement.setParameter(57, nextCell.getStringCellValue());
 	                            	  break;
	                              case 57:
	                            	  sql_statement.setParameter(58, nextCell.getStringCellValue());
 	                            	  break;
			                     case 58:
	                            	  sql_statement.setParameter(59, nextCell.getDateCellValue()); 
	                            	  break;
			                     case 59: 
	                            	  sql_statement.setParameter(60, nextCell.getStringCellValue());
	                            	  break;
	                            	  
			                     case 60:
	                            	  sql_statement.setParameter(61, nextCell.getDateCellValue());
	                            	  break;
	                              case 61:
	                            	  sql_statement.setParameter(62, nextCell.getStringCellValue());
	                            	  break;
	                              case 62:
	                            	  sql_statement.setParameter(63, nextCell.getStringCellValue());
	                            	  break;
	                              case 63:
	                            	  sql_statement.setParameter(64, nextCell.getStringCellValue());
	                            	  break;  
	                              case 64:
	                            	  sql_statement.setParameter(65, nextCell.getStringCellValue());
	                            	  break;
	                              case 65:
	                            	  sql_statement.setParameter(66, nextCell.getStringCellValue());
	                            	  break;
	                              case 66:
	                            	  sql_statement.setParameter(67, nextCell.getStringCellValue());
	                            	  break;
	                              case 67:
	                            	  sql_statement.setParameter(68, nextCell.getStringCellValue());
	                            	  break;
			                     case 68:
	                            	  sql_statement.setParameter(69, nextCell.getStringCellValue()); 
	                            	  break;
			                     case 69: 
	                            	  sql_statement.setParameter(70, nextCell.getStringCellValue());
	                            	  break;
						 
						 
 	                            	  
                              }
                      }
		                 sql_statement.executeUpdate();
	              }
		      }

		      input_document.close();
		      
		  }
			catch (Exception e){
			  e.printStackTrace();
		  }
			
		}

	private String getFileExtension(File file) {
	        String fileName = file.getName();
	        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
	        return fileName.substring(fileName.lastIndexOf(".")+1);
	        else return "";
	    }
	
	public List<GetGroupDetailsModel> GetGroupDetails(GetGroupDetailsModel GDmodel) {
	   	 StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spGetSearchGroupDetailsNew")
	               .registerStoredProcedureParameter("vGroupName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("vContactFirstName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("vContactLastName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("vCustomerGroupID", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("vBranchID", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("vUserID", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("oGROUP", Class.class, ParameterMode.REF_CURSOR)
				    .setParameter("vGroupName", GDmodel.getGroupName())
				    .setParameter("vContactFirstName", GDmodel.getContactFirstName())
				    .setParameter("vContactLastName",GDmodel.getContactLastName())
				    .setParameter("vCustomerGroupID", GDmodel.getCustomerGroupID())
				    .setParameter("vBranchID", GDmodel.getBranchID())
				    .setParameter("vUserID",GDmodel.getUserID());
	   	 query.execute();
	   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	   	 List<GetGroupDetailsModel> groupList = list.stream().map(
	                o -> new GetGroupDetailsModel((Number) o[0], (String) o[1]  ,(Number) o[2],(String) o[3]
	                		,(String) o[4],(String) o[5],(Number) o[6],(String) o[7],(String) o[8],(String) o[9],(String) o[10],(Number) o[11]
	                				,(String) o[12],(String) o[13],(Number) o[14],(Number) o[15],(Number) o[16],(String) o[17],(String) o[18])).collect(Collectors.toList());
	   	 
	    	return groupList;
		}
	
	public List<GetMasterPolicyDetailsModel> GetMasterPolicyDetails(int Groupid) {
	   	 StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spgetmasterpolicynumberbygroupidbylob_1")
	               .registerStoredProcedureParameter("p_groupid", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR)
				    .setParameter("p_groupid",Groupid);
	   	 query.execute();
	   	  List<Object[]> list  =  (List<Object[]>)query.getResultList();
		 
	   	  List<GetMasterPolicyDetailsModel> MasterPolicyList = list.stream().map( o ->
		  new GetMasterPolicyDetailsModel((Number) o[0], (String) o[1] ,(Number)
		  o[2],(String) o[3] ,(String) o[4],(Number) o[5],(String) o[6],(Number)
		  o[7],(Number) o[8],(String) o[9] ,(Number) o[10],(Number) o[11],(String)
		  o[12],(Number) o[13])).collect(Collectors.toList());
 	    	
	   	  return MasterPolicyList;
		}
	
	public List<GetAllAuthorisedSignatoriesModel> GetAllAuthorisedSignatories(int ModuleID) {
	   	 StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spGetAllAuthorisedSignatories")
	               .registerStoredProcedureParameter("PModuleID", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("oGROUP", Class.class, ParameterMode.REF_CURSOR)
				    .setParameter("PModuleID",ModuleID);
	   	 query.execute();
	   	  List<Object[]> list  =  (List<Object[]>)query.getResultList();
		 
	   	  List<GetAllAuthorisedSignatoriesModel> OutList = list.stream().map( o ->
		  new GetAllAuthorisedSignatoriesModel((Number) o[0], (String) o[1])).collect(Collectors.toList());
   	
	   	  return OutList;
		}
	
	public int CheckGNBUHeaderFileExist(NewBusinessModel NBmodel) {
	   	 StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spIsGNBUHeaderFileExist")
	               .registerStoredProcedureParameter("pFileName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("oCount", Integer.class, ParameterMode.OUT)
				    .setParameter("pFileName",NBmodel.getFileName());
	   	 query.execute();
 	   	 return (int)query.getOutputParameterValue("oCount");

		}
	
	
	public List<NewBusinessOutputModel> MigrationGNBDataUpload(NewBusinessModel NBModel) {
		StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spMigrationGNBDataUpload")
	               .registerStoredProcedureParameter("p_FileName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("p_GroupID", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("p_MasterPolicyID", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("p_CreatedBy", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("p_CreatedOn", Date.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("p_Type", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("p_AuthorisedSignatoryID", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR)
	               .setParameter("p_FileName",NBModel.getFileName())
				    .setParameter("p_GroupID",NBModel.getGroupID())
				    .setParameter("p_MasterPolicyID",NBModel.getMasterPolicyID())
				    .setParameter("p_CreatedBy",NBModel.getCreatedBy())
				    .setParameter("p_CreatedOn",NBModel.getCreatedOn())
				    .setParameter("p_Type",NBModel.getType())
				    .setParameter("p_AuthorisedSignatoryID",NBModel.getAuthorisedSignatoryID());
	   	 query.execute();
	   	    
	   	 	List<Object[]> list  =  (List<Object[]>)query.getResultList();
		 
  	        List<NewBusinessOutputModel> OutList = list.stream().map( o -> new
  	        		NewBusinessOutputModel((Number) o[0], (Number) o[1],(Number) o[2]
		   ,(Number) o[3] ,(String) o[4])).collect(Collectors.toList());
		 
	   	  return OutList;
		}

	
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.BenefitType;

public interface IBenefitTypeDAO {
	public void saveOrUpdate(BenefitType obj) throws SQLException ;
	public void delete(Integer benefitTypeID, Integer deleteBy) throws SQLException;
	public List<BenefitType> getAll(BenefitType filterObj) throws SQLException;
	public BenefitType get(Integer benefitTypeID) throws SQLException;
}

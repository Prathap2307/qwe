package com.LIC.dao;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.GetAccountGroupModel;
import com.LIC.model.GetGlConfigurationModel;
import com.LIC.model.GetOrganisationModel;
import com.LIC.model.GlConfigurationModel;

@Repository
public class GlConfigurationDAO {
	
	
	@Autowired
	private EntityManager em;
	
	
	
	public void createGlConfigurationInfo(GlConfigurationModel model) {
		System.out.println(" hari prasath");
		System.out.println(model.getGlconfigurationId());
		StoredProcedureQuery addGlConfigurationStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateGLConfiguration");
		addGlConfigurationStoredProcedure.setParameter("vGLCONFIGURATIONID", model.getGlconfigurationId());
		addGlConfigurationStoredProcedure.setParameter("vPAYMENTMODE", model.getPaymentMode());
		addGlConfigurationStoredProcedure.setParameter("vPRODUCTID", model.getProductId());
		addGlConfigurationStoredProcedure.setParameter("vPROCESSID", model.getProcessId());
		addGlConfigurationStoredProcedure.setParameter("vCREDITGLCODE", model.getCreditGlCode());
		addGlConfigurationStoredProcedure.setParameter("vDEBITGLCODE", model.getDebitGlCode());
		addGlConfigurationStoredProcedure.setParameter("vCREDITNARRATION", model.getCreditNarration());
		addGlConfigurationStoredProcedure.setParameter("vDEBITNARRATION", model.getDebitNarration());
		addGlConfigurationStoredProcedure.setParameter("vRemark", model.getReMarks());
		addGlConfigurationStoredProcedure.setParameter("vISACTIVE", model.getIsActive());
		addGlConfigurationStoredProcedure.setParameter("vCREATEDBY", model.getCreatedBy());
		addGlConfigurationStoredProcedure.setParameter("vCREATEDON", model.getCreatedOn());
		addGlConfigurationStoredProcedure.setParameter("vCOUNTRYID", model.getCountryId());
		addGlConfigurationStoredProcedure.setParameter("vStateID", model.getStateId());
		addGlConfigurationStoredProcedure.getParameter("VRESULT");
		
		addGlConfigurationStoredProcedure.execute();
		
}
	
	
	
	public List<GetGlConfigurationModel>GetAllProcess() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAccountingProcessName")
               .registerStoredProcedureParameter("oAP", Class.class, ParameterMode.REF_CURSOR);
                         

        
         // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetGlConfigurationModel> accList = list.stream().map(
        		  o -> new GetGlConfigurationModel((Number) o[0],(String) o[1],(String) o[2],(Number) o[3])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	public List<GetGlConfigurationModel>GetAllPaymentInfo() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllPaymentMode")
               .registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR);
                         

        
         // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetGlConfigurationModel> payment = list.stream().map(
        		  m -> new GetGlConfigurationModel((Number) m[0],(String) m[1])).collect(Collectors.toList());
        
       return payment;
       
         
       }
	
	
	
	
	
	
	
	
	public List<GetGlConfigurationModel>GetAllVariantInfo(Integer lob) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllPlanByLOB")
               .registerStoredProcedureParameter("vLineOfBusinessID",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("obank", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vLineOfBusinessID",lob);
         //return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetGlConfigurationModel> accList = list.stream().map(
        		  o -> new GetGlConfigurationModel((Number) o[0],(String) o[1],(Number) o[2],(Number) o[3],(String) o[4],(Number) o[5],(String) o[6],(String) o[7],(String) o[8],(String) o[9])).collect(Collectors.toList());
        
       return accList;
       
	}

	public List<GetGlConfigurationModel>GetAll(Integer processId,Integer productId,Integer paymentMode) {
		
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllGLConfiguration")
               .registerStoredProcedureParameter("vPRODUCTID",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vPAYMENTMODE", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vPROCESSID", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oBANK", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vPRODUCTID",productId)
                         .setParameter("vPAYMENTMODE",paymentMode)
                         .setParameter("vPROCESSID",processId);
        // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetGlConfigurationModel> accList = list.stream().map(
        		  o -> new GetGlConfigurationModel((Number) o[0],(Number) o[1],(String) o[2],(Number) o[3],(String) o[4],(String) o[5],(Number) o[6],(String) o[7],(Number) o[8],(Number) o[9],(String) o[10],(String) o[11],(String) o[12],(String) o[13],(Number) o[14],(String) o[15],(Number) o[16],(String) o[17],(Number) o[18],(String) o[19],(Number) o[20],(Number) o[21],(Number) o[22])).collect(Collectors.toList());
        
       return accList;
       
        
	}
        
        
        
        
        
        
        
        
        
        
	public List<GetGlConfigurationModel>GetAllDebirCreditGlcode(Integer id) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllSubAccountDropdown")
               .registerStoredProcedureParameter("vAccountHeadID",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("pResult", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vAccountHeadID",id);
         //return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetGlConfigurationModel> accList = list.stream().map(
        		  o -> new GetGlConfigurationModel((Number) o[0],(String) o[1],(String) o[2])).collect(Collectors.toList());
        
       return accList;
       
       
  
         
       }
	
	
	
	public List<GetGlConfigurationModel>GetAllCountryNames() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllCountries")
               .registerStoredProcedureParameter("p_recordset", Class.class, ParameterMode.REF_CURSOR);
                    

        
          //return query.execute() ? query.getResultList() : null;
      
        
       query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetGlConfigurationModel> accList = list.stream().map(
        		  o -> new GetGlConfigurationModel((Number) o[0],(String) o[1],(String) o[2],(String) o[3],(Number) o[4])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	public List<GetGlConfigurationModel>GetAllStateNames(Number countryId) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllStates")
               .registerStoredProcedureParameter("p_CountryID",Long.class, ParameterMode.IN)
               .registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("p_CountryID",countryId);

        
        //return query.execute() ? query.getResultList() : null;
      
        
       query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetGlConfigurationModel> accList = list.stream().map(
        		  o -> new GetGlConfigurationModel((Number) o[0],(String) o[1],(Number) o[2])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	
	
	
}

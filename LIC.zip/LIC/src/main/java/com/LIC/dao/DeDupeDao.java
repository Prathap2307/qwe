package com.LIC.dao;

import java.sql.Connection;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.BankMasterModel;
import com.LIC.model.DeDupeModel;
import com.LIC.model.GetBankBranch;
import com.LIC.model.GroupModal;
import com.LIC.model.UserModal;
import com.LIC.resource.ResourceManager;

@Repository
public class DeDupeDao {
	
	@Autowired
	private EntityManager em; 
	
	private static final Logger logger = Logger.getLogger(GroupDao.class);
	
	
	public void InsertUpdateDedupe(DeDupeModel model) {

		int 					statusGroupMap		= 0;  
		
		try {
			
			StoredProcedureQuery aadDedupe = em.createNamedStoredProcedureQuery("spInsertUpdateDedupe");
    		//aadDedupe.setParameter("vBankID", model.get);
    		//aadDedupe.setParameter("vDescription", model.getBankName());
    		//aadDedupe.setParameter("vShortDescription", model.getBankShortName());
    		aadDedupe.setParameter("vCreatedBy", model.getCreatedBy());
    		aadDedupe.setParameter("vCreatedOn", model.getCreatedOn());
    		aadDedupe.getParameter("vResult");
    		
    		aadDedupe.execute();
			

		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
			
		}
		//return groupID;
	}
	

	
}

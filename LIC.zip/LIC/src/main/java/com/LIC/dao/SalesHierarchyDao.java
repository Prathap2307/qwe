package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.BranchModal;
import com.LIC.model.SalesHierarchyAddressModal;
import com.LIC.model.SalesHierarchyModal;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.datetime.DateTimeUtility;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class SalesHierarchyDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	private static final Logger logger = Logger.getLogger(SalesHierarchyDao.class);

	public long InsertOrUpdate(SalesHierarchyModal objSalesHierarchyModal, Connection conn) throws Exception {

		CallableStatement cstm = null;
		ResultSet result = null;
		long salesHierarchyId = 0;

		try {

			cstm = conn.prepareCall(
					"call spInsertUpdateSalesHierarchy(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
			cstm.setLong(1, objSalesHierarchyModal.getSalesHierarchyID());
			cstm.setLong(2, objSalesHierarchyModal.getLineOfBusinessID());
			cstm.setLong(3, objSalesHierarchyModal.getSalutationID());
			cstm.setString(4, objSalesHierarchyModal.getFirstName());
			cstm.setString(5, objSalesHierarchyModal.getLastName());
			cstm.setString(6, objSalesHierarchyModal.getCode());
			cstm.setLong(7, objSalesHierarchyModal.getFireTypeID());
			cstm.setLong(8, objSalesHierarchyModal.getDesignationID());
			cstm.setLong(9, objSalesHierarchyModal.getParentHierarchyID());
			cstm.setLong(10, objSalesHierarchyModal.getBranchID());
			cstm.setLong(11, objSalesHierarchyModal.getSalesTypeID());
			cstm.setLong(12, objSalesHierarchyModal.getChannelID());
			cstm.setLong(13, objSalesHierarchyModal.getSubChannelID());
			cstm.setLong(14, objSalesHierarchyModal.getCreatedBy());
			cstm.setTimestamp(15, objSalesHierarchyModal.getCreatedOn());
			cstm.setShort(16, objSalesHierarchyModal.getIsActive());
			cstm.setLong(17, objSalesHierarchyModal.getSalesType());
			cstm.setLong(18, objSalesHierarchyModal.getAccountBranchID());
			cstm.setDouble(19, objSalesHierarchyModal.getTriggerLimit());
			cstm.setShort(20, objSalesHierarchyModal.getIsEmployee());
			cstm.setLong(21, objSalesHierarchyModal.getPolicyHolderID());
			cstm.setShort(22, objSalesHierarchyModal.getIsAdvanceDeposit());
			cstm.setLong(23, objSalesHierarchyModal.getDepartmentID());
			cstm.setShort(24, objSalesHierarchyModal.getPayableFeature());
			cstm.setTimestamp(25, objSalesHierarchyModal.getApplicationDate());
			cstm.setTimestamp(26, objSalesHierarchyModal.getDateofJoining());
			cstm.setLong(27, objSalesHierarchyModal.getGender());
			cstm.setTimestamp(28, objSalesHierarchyModal.getDOB());
			cstm.setLong(29, objSalesHierarchyModal.getAge());
			cstm.setLong(30, objSalesHierarchyModal.getMonth());
			cstm.setString(31, objSalesHierarchyModal.getPanNumber());
			cstm.setString(32, objSalesHierarchyModal.getRegistredunder());
			cstm.setTimestamp(33, objSalesHierarchyModal.getRegistrationdate());
			cstm.setTimestamp(34, objSalesHierarchyModal.getMIAagreementdate());
			cstm.setTimestamp(35, objSalesHierarchyModal.getCodeIssuancedate());
			cstm.setTimestamp(36, objSalesHierarchyModal.getCodeExpiredate());
			cstm.setTimestamp(37, objSalesHierarchyModal.getRenewaldate());
			cstm.setTimestamp(38, objSalesHierarchyModal.getEffectivedate());
			cstm.setTimestamp(39, objSalesHierarchyModal.getExpiredate());
			cstm.setString(40, objSalesHierarchyModal.getBankName());
			cstm.setString(41, objSalesHierarchyModal.getBranchName());
			cstm.setString(42, objSalesHierarchyModal.getAccountHolderName());
			cstm.setString(43, objSalesHierarchyModal.getAccountNO());
			cstm.setString(44, objSalesHierarchyModal.getAccountType());
			cstm.setString(45, objSalesHierarchyModal.getIFSCcode());
			cstm.setString(46, objSalesHierarchyModal.getMicrcode());
			cstm.setString(47, objSalesHierarchyModal.getRemarks());
			cstm.setTimestamp(48, objSalesHierarchyModal.getRemarksDate());
			cstm.setString(49, objSalesHierarchyModal.getOrganisationName());
			cstm.setString(50, objSalesHierarchyModal.getAgentLocation());
			cstm.registerOutParameter(51, OracleTypes.CURSOR);
			cstm.executeUpdate();
			result = ((OracleCallableStatement) cstm).getCursor(51);

			if (result != null) {
				if (result.next()) {
					salesHierarchyId = result.getLong("SalesHierarchyID");
				}
			}
			objSalesHierarchyModal.setSalesHierarchyID(salesHierarchyId);

			return salesHierarchyId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm = null;
		}
		return 0;
	}

	public void InsertSalesHierarchyAddress(long SalesHierarchyID,
			List<SalesHierarchyAddressModal> objSalesHierachryAddressModalList, Connection conn) throws Exception {

		CallableStatement cstm = null;
		ResultSet result = null;
		long addressId = 0;

		try {

			DeleteAddressMap(SalesHierarchyID, conn);

			String sp = "call spInsertUpdateSalesHierarchyAddress(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			for (SalesHierarchyAddressModal salesHierarchyAddressModal : objSalesHierachryAddressModalList) {

				cstm = conn.prepareCall(sp);
				System.out.println("salesHierarchyAddressModal  "+salesHierarchyAddressModal);
				salesHierarchyAddressModal.setSalesHierArchyID(SalesHierarchyID);
				if(salesHierarchyAddressModal.getCreatedOn()== null) {
					salesHierarchyAddressModal.setCreatedOn(DateTimeUtility.getCurrentTimeStamp());
				}

				cstm.setLong(1, salesHierarchyAddressModal.getAddressID());
				cstm.setString(2, salesHierarchyAddressModal.getAddress1());
				cstm.setString(3, salesHierarchyAddressModal.getAddress2());
				cstm.setString(4, salesHierarchyAddressModal.getAddress3());
				cstm.setString(5, salesHierarchyAddressModal.getAddress4());
				cstm.setString(6, salesHierarchyAddressModal.getAddress5());
				cstm.setLong(7, salesHierarchyAddressModal.getCountryID());
				cstm.setLong(8, salesHierarchyAddressModal.getStateID());
				cstm.setString(9, salesHierarchyAddressModal.getTehsil());
				cstm.setLong(10, salesHierarchyAddressModal.getDistrictID());
				cstm.setLong(11, salesHierarchyAddressModal.getTalukID());
				cstm.setString(12, salesHierarchyAddressModal.getZipCode());
				cstm.setString(13, salesHierarchyAddressModal.getPhoneNo());
				cstm.setString(14, salesHierarchyAddressModal.getMobileNo());
				cstm.setString(15, salesHierarchyAddressModal.getConferenceNo());
				cstm.setString(16, salesHierarchyAddressModal.getFaxNo());
				cstm.setString(17, salesHierarchyAddressModal.getEmail());
				cstm.setLong(18, salesHierarchyAddressModal.getCreatedBy());
				cstm.setTimestamp(19, salesHierarchyAddressModal.getCreatedOn());
				cstm.setShort(20, salesHierarchyAddressModal.getIsActive());
				cstm.setLong(21, salesHierarchyAddressModal.getAddressTypeTypeID());

				cstm.registerOutParameter(22, OracleTypes.CURSOR);

				cstm.executeUpdate();

				result = ((OracleCallableStatement) cstm).getCursor(22);

				if (result != null) {
					if (result.next()) {
						addressId = result.getLong("partyAddressId");
						System.out.println("partyAddressId " + addressId);
					}
				}

				if (addressId > 0) {
					InsertUpdateSalesHierarchyAddressMap(addressId, salesHierarchyAddressModal, conn);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm = null;
		}
	}

	public void InsertUpdateSalesHierarchyAddressMap(long partyAddressId,
			SalesHierarchyAddressModal salesHierarchyAddressModal, Connection conn) throws Exception {
		CallableStatement cstm = null;

		try {

			String sp = "call spInsertUpdateSalesHierarchyAddressMap(?,?,?,?)";

			cstm = conn.prepareCall(sp);
			cstm.setLong(1, salesHierarchyAddressModal.getSalesHierArchyID());
			cstm.setLong(2, partyAddressId);
			cstm.setLong(3, salesHierarchyAddressModal.getCreatedBy());
			cstm.setTimestamp(4, DateTimeUtility.getCurrentTimeStamp());
			cstm.setTimestamp(4, salesHierarchyAddressModal.getCreatedOn());
			cstm.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm = null;
		}
	}

	public void DeleteAddressMap(long SalesHierarchyID, Connection conn) throws Exception {
		CallableStatement cstm = null;

		try {

			conn.setAutoCommit(false);
			cstm = conn.prepareCall("call spDeleteSalesHierarchyAddressMapBySalesHierachID(?) ");
			cstm.setLong(1, SalesHierarchyID);
			cstm.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());

		} finally {
			cstm.close();
			cstm = null;
		}
	}

	public void InsertSalesBranchID(long SalesHierarchyID, List<BranchModal> SalesHierachyInfoObjectList,
			Connection conn) throws Exception {

		CallableStatement cstm = null;

		try {

			DeleteBranchID(SalesHierarchyID, conn);

			for (BranchModal branchModal : SalesHierachyInfoObjectList) {

				if(branchModal.getCreatedOn()== null) {
					branchModal.setCreatedOn(DateTimeUtility.getCurrentTimeStamp());
				}
				cstm = conn.prepareCall("call spInsertBranchIDBySalesHierarchyID(?,?,?,?)");
				cstm.setLong(1, branchModal.getBranchId());
				cstm.setLong(2, SalesHierarchyID);
				cstm.setLong(3, branchModal.getCreatedBy());
				cstm.setTimestamp(4, branchModal.getCreatedOn());
				cstm.executeUpdate();
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm = null;
		}
	}

	public void DeleteBranchID(long SalesHierarchyID, Connection conn) throws Exception {

		CallableStatement cstm = null;

		try {

			cstm = conn.prepareCall("call spDeleteSalesHierarchyBranchIDBySalesHierachID(?) ");
			cstm.setLong(1, SalesHierarchyID);
			cstm.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm = null;
		}
	}

	public int IsSalesHierarchyExist(long SalesHierarchyID, String Code, long LineOfBusinessID) throws Exception {
		CallableStatement cstm = null;
		Connection conn = null;
		ResultSet result = null;
		int iCount = 0;

		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spIsSalesHierarchyExist(?,?,?,?) ");
			cstm.setLong(1, SalesHierarchyID);
			cstm.setString(2, Code);
			cstm.setLong(3, LineOfBusinessID);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.executeUpdate();

			result = ((OracleCallableStatement) cstm).getCursor(4);

			if (result != null) {
				if (result.next()) {
					iCount = result.getInt("ExistCount");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		return iCount;
	}

	public List<SalesHierarchyModal> getAllSalesHierarchy(long lineOfBusinessID) throws Exception {
		CallableStatement cstm = null;
		Connection conn = null;
		ResultSet result = null;
		List<SalesHierarchyModal> salesHierarchyList = null;
		SalesHierarchyModal salesHierarchyModal = null;
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllSalesHierarchy(?,?)");
			cstm.setLong(1, lineOfBusinessID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.execute();

			result = ((OracleCallableStatement) cstm).getCursor(2);

			if (result != null) {
				salesHierarchyList = new ArrayList<SalesHierarchyModal>();

				while (result.next()) {
					salesHierarchyModal = new SalesHierarchyModal();

					salesHierarchyModal.setSalesHierarchyID(result.getLong("salesHierarchyID"));
					salesHierarchyModal.setLineOfBusinessID(result.getLong("LineOfBusinessID"));
					salesHierarchyModal.setName(result.getString("Name"));
					salesHierarchyModal.setFirstName(result.getString("FirstName"));
					salesHierarchyModal.setLastName(result.getString("LastName"));
					salesHierarchyModal.setMainChannelName(result.getString("MainChannelName"));
					salesHierarchyModal.setSubChannelName(result.getString("SubChannelName"));
					salesHierarchyModal.setDesignation(result.getString("Designation"));
					salesHierarchyModal.setDescription(result.getString("Description"));
					salesHierarchyModal.setSalutationID(result.getLong("SalutationID"));
					salesHierarchyModal.setCode(result.getString("Code"));
					salesHierarchyModal.setIsActive(result.getShort("IsActive"));
					salesHierarchyModal.setBranchName(result.getString("BranchName"));
					salesHierarchyModal.setIsActive(result.getShort("IsActive"));
					salesHierarchyList.add(salesHierarchyModal);
				}
			}

			return salesHierarchyList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		return null;
	}

	public SalesHierarchyModal getSalesHierarchyByID(long salesHierarchyID, long lineOfBusinessID) throws Exception {
		CallableStatement 		cstm = null;
		Connection 				conn = null;
		ResultSet 				result = null;
		ResultSet 				result1 = null;
		ResultSet 				result2 = null;
		SalesHierarchyModal 	salesHierarchyModal = null;

		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllSalesHierarchyByID(?,?,?,?,?)");
			cstm.setLong(1, salesHierarchyID);
			cstm.setLong(2, lineOfBusinessID);
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.registerOutParameter(5, OracleTypes.CURSOR);
			cstm.execute();

			result = ((OracleCallableStatement) cstm).getCursor(3);

			
			salesHierarchyModal = new SalesHierarchyModal();
			getSalesHierarchyData(result, salesHierarchyModal);
			System.out.println("salesHierarchyModal.getPanNumber() >>>>>>>> "+salesHierarchyModal.getPanNumber());
			
			result1 = ((OracleCallableStatement) cstm).getCursor(4);
			getSalesHierarchyAddressData(result1, salesHierarchyModal);

			result2 = ((OracleCallableStatement) cstm).getCursor(5);
			getSalesHierarchyBranchData(result2, salesHierarchyModal);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		return salesHierarchyModal;
	}

	private void getSalesHierarchyData(ResultSet result, SalesHierarchyModal salesHierarchyModal) throws Exception {
		try {

			if (result != null) {
				if (result.next()) {
					
					salesHierarchyModal.setSalesHierarchyID(result.getLong("SalesHierarchyID"));
					salesHierarchyModal.setLineOfBusinessID(result.getLong("LineOfBusinessID"));
					salesHierarchyModal.setIsCDAccount(result.getShort("IsCDAccount"));
					salesHierarchyModal.setName(result.getString("FirstName"));
					salesHierarchyModal.setFirstName(result.getString("FName"));
					salesHierarchyModal.setLineOfBusinessID(result.getLong("LineOfBusinessID"));
					salesHierarchyModal.setLastName(result.getString("LastName"));
					salesHierarchyModal.setCode(result.getString("Code"));
					salesHierarchyModal.setFireTypeID(result.getLong("FireTypeID"));
					salesHierarchyModal.setDepartmentID(result.getLong("DepartmentID"));
					salesHierarchyModal.setDesignationID(result.getLong("DesignationID"));
					salesHierarchyModal.setBranchID(result.getLong("BranchID"));
					salesHierarchyModal.setSalesTypeID(result.getLong("SalesTypeID"));
					salesHierarchyModal.setSalesType(result.getLong("SalesType"));
					salesHierarchyModal.setMainChannelName(result.getString("MainChannelName"));
					salesHierarchyModal.setMainChannelCode(result.getString("MainChannelCode"));
					salesHierarchyModal.setSubChannelCode(result.getString("SubChannelCode"));
					salesHierarchyModal.setSubChannelName(result.getString("SubChannelName"));
					salesHierarchyModal.setMainChannelID(result.getLong("MainChannelID"));
					salesHierarchyModal.setSubChannelID(result.getLong("SubChannelID"));
					salesHierarchyModal.setChannelID(result.getLong("MainChannelID"));
					salesHierarchyModal.setChannelID(result.getLong("ChannelID"));
					salesHierarchyModal.setAccountBranchID(result.getLong("AccountBranchID"));
					salesHierarchyModal.setTriggerLimit(result.getDouble("TriggerLimit"));
					salesHierarchyModal.setIsPayableFeature(result.getLong("IsPayableFeature"));
					salesHierarchyModal.setSalutationID(result.getLong("SalutationID"));
					salesHierarchyModal.setIsEmployee(result.getShort("IsEmployee"));
					salesHierarchyModal.setPolicyHolderID(result.getLong("PolicyHolderID"));
					salesHierarchyModal.setIsAdvanceDeposit(result.getShort("IsAdvanceDeposit"));
					salesHierarchyModal.setApplicationDate(result.getTimestamp("ApplicationDate"));
					salesHierarchyModal.setDateofJoining(result.getTimestamp("DateofJoining"));
					salesHierarchyModal.setDOB(result.getTimestamp("DOB"));
					salesHierarchyModal.setAge(result.getLong("Age"));
					salesHierarchyModal.setMonth(result.getLong("Month"));
					System.out.println("result.getString(\"PanNumber\") "+result.getString("PanNumber"));
					salesHierarchyModal.setPanNumber(result.getString("PanNumber"));
					salesHierarchyModal.setRegistrationdate(result.getTimestamp("Registrationdate"));
					salesHierarchyModal.setMIAagreementdate(result.getTimestamp("MIAagreementdate"));
					salesHierarchyModal.setCodeIssuancedate(result.getTimestamp("CodeIssuancedate"));
					salesHierarchyModal.setCodeExpiredate(result.getTimestamp("CodeExpiredate"));
					salesHierarchyModal.setRenewaldate(result.getTimestamp("Renewaldate"));
					salesHierarchyModal.setEffectivedate(result.getTimestamp("Effectivedate"));
					salesHierarchyModal.setExpiredate(result.getTimestamp("Expiredate"));
					salesHierarchyModal.setRemarksDate(result.getTimestamp("RemarksDate"));
					salesHierarchyModal.setBranchName(result.getString("BranchName"));
					salesHierarchyModal.setBankName(result.getString("BankName"));
					salesHierarchyModal.setAccountHolderName(result.getString("AccountHolderName"));
					salesHierarchyModal.setAccountNO(result.getString("AccountNO"));
					salesHierarchyModal.setAccountType(result.getString("AccountType"));
					salesHierarchyModal.setIFSCcode(result.getString("IFSCcode"));
					salesHierarchyModal.setMicrcode(result.getString("Micrcode"));
					salesHierarchyModal.setRemarks(result.getString("Remarks"));
					salesHierarchyModal.setIsActive(result.getShort("IsActive"));
					salesHierarchyModal.setOrganisationName(result.getString("OrganisationName"));
					salesHierarchyModal.setAgentLocation(result.getString("AgentLocation"));
					salesHierarchyModal.setGender(result.getLong("GENDER"));
					System.out.println("SalesHierarchyModal >>>>." + salesHierarchyModal);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
	}

	private void getSalesHierarchyAddressData(ResultSet result, SalesHierarchyModal salesHierarchyModal)
			throws Exception {
		SalesHierarchyAddressModal salesHierarchyAddress = null;
		List<SalesHierarchyAddressModal> salesHierarchyAddressList = null;

		try {

			if (result != null) {
				salesHierarchyAddressList = new ArrayList<SalesHierarchyAddressModal>();

				while (result.next()) {

					salesHierarchyAddress = new SalesHierarchyAddressModal();

					salesHierarchyAddress.setAddressID(result.getLong("AddressID"));
					salesHierarchyAddress.setAddress1(result.getString("Address1"));
					salesHierarchyAddress.setAddress2(result.getString("Address2"));
					salesHierarchyAddress.setAddress3(result.getString("Address3"));
					salesHierarchyAddress.setAddress4(result.getString("Address4"));
					salesHierarchyAddress.setAddress5(result.getString("Address5"));
					salesHierarchyAddress.setCountryID(result.getLong("CountryID"));
					salesHierarchyAddress.setCountryName(result.getString("Country"));
					salesHierarchyAddress.setStateID(result.getLong("StateID"));
					salesHierarchyAddress.setStateName(result.getString("State"));
					salesHierarchyAddress.setDistrictID(result.getLong("DistrictID"));
					salesHierarchyAddress.setDistrictName(result.getString("District"));
					salesHierarchyAddress.setTalukID(result.getLong("TalukID"));
					salesHierarchyAddress.setTalukName(result.getString("Taluk"));
					salesHierarchyAddress.setVillageID(result.getLong("VillageID"));
					salesHierarchyAddress.setVillageName(result.getString("Village"));
					salesHierarchyAddress.setZipCode(result.getString("ZipCode"));
					salesHierarchyAddress.setAddressType(result.getString("AddressType"));
					salesHierarchyAddress.setAddressTypeID(result.getShort("AddressTypeID"));
					salesHierarchyAddress.setPhoneNo(result.getString("PhoneNo"));
					salesHierarchyAddress.setMobileNo(result.getString("MobileNo"));
					salesHierarchyAddress.setConferenceNo(result.getString("ConferenceNo"));
					salesHierarchyAddress.setFaxNo(result.getString("FaxNo"));
					salesHierarchyAddress.setEmail(result.getString("Email"));
					// salesHierarchyAddress.setAddressID(result.getLong("TempID"));
					salesHierarchyAddress.setPersonalEmailID(result.getString("PersonalEmailID"));
					salesHierarchyAddress.setOtherDistrict(result.getString("OtherDistrict"));
					salesHierarchyAddress.setOtherTaluk(result.getString("OtherTaluk"));
					salesHierarchyAddress.setOtherVillage(result.getString("OtherVillage"));

					salesHierarchyAddress.setTalukID(result.getLong("TalukID"));

					salesHierarchyAddressList.add(salesHierarchyAddress);
					System.out.println("salesHierarchyAddressList------>"+salesHierarchyAddressList);
				}

				if (salesHierarchyModal != null)
					salesHierarchyModal.setSalesHierarchyAddressList(salesHierarchyAddressList);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}

	}

	private void getSalesHierarchyBranchData(ResultSet result, SalesHierarchyModal salesHierarchyModal)
			throws Exception {

		BranchModal branchModal = null;
		List<BranchModal> branchModalList = null;

		try {

			if (result != null) {
				branchModalList = new ArrayList<BranchModal>();

				while (result.next()) {

					branchModal = new BranchModal();

					branchModal.setBranchId(result.getLong("BranchID"));

					branchModalList.add(branchModal);

				}

				if (salesHierarchyModal != null)
					salesHierarchyModal.setBranchModalList(branchModalList);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}

	}

}

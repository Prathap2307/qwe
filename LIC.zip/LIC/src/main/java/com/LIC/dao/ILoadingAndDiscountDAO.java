package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.LoadingAndDiscount;

public interface ILoadingAndDiscountDAO {
	public void saveOrUpdate(LoadingAndDiscount obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<LoadingAndDiscount> getAll(LoadingAndDiscount filterObj) throws SQLException;
	public LoadingAndDiscount get(Integer id) throws SQLException;
}

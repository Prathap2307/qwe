package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Region;

public interface IRegionDAO {
	public void saveOrUpdate(Region obj) throws SQLException ;
	public void delete(Integer regionID, Integer deleteBy) throws SQLException;
	public List<Region> getAll(Region filterObj) throws SQLException;
	public Region get(Integer regionID) throws SQLException;

}

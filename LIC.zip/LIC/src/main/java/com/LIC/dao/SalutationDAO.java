package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.Salutation;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class SalutationDAO implements ISalutationDAO {
	
	static final Logger LOGGER = LogManager.getLogger(SalutationDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(Salutation obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateSalutation(?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getSalutationId());
		  callableStatement.setString(2, obj.getDescription());
		  callableStatement.setInt(3, 1);
		  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateSalutation executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateSalutation executed successfully.");
	}
	
	@Override
	public void delete(Integer id) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteSalutation(?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.registerOutParameter(2, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteSalutation executed successfully.");
		  LOGGER.info("SP>spDeleteSalutation executed successfully.");
	} 
	
	@Override
	public List<Salutation> getAll(Salutation filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Salutation> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllSalutation(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Salutation obj = null;
			  list = new ArrayList<Salutation>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")); 
		        obj = new Salutation();
		        obj.setSalutationId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllSalutation executed successfully.");
			  LOGGER.info("SP>spGetAllSalutation executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllSalutation exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public Salutation get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  Salutation obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetSalutation(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")); 
		        obj = new Salutation();
		        obj.setSalutationId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		      }
			  System.out.println("SP>spGetSalutation executed successfully.");
			  LOGGER.info("SP>spGetSalutation executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetSalutation exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

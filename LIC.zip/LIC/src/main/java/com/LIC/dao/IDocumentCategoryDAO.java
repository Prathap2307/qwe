package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.DocumentCategory;

public interface IDocumentCategoryDAO {
	public void saveOrUpdate(DocumentCategory obj) throws SQLException ;
	public void delete(Integer documentCategoryID, Integer deleteBy) throws SQLException;
	public List<DocumentCategory> getAll(DocumentCategory filterObj) throws SQLException;
	public DocumentCategory get(Integer documentCategoryID) throws SQLException;
}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.TalukaModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class TalukDao {
	
	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(TalukDao.class);

	public List<TalukaModal> getAllTalukasByDistrictId(long districtId) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		TalukaModal				talukaModal			= null;
		List<TalukaModal>		districtList		= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			 
			cstm 		= conn.prepareCall("call spGetAllTaluks(?,?) ");
			
			cstm.setLong(1, districtId); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {
		    	
		    	districtList	= new ArrayList<TalukaModal>();
		    	
		    	while (result.next()) {
		    		talukaModal = new TalukaModal();
		    		
		    		talukaModal.setDistrictId(districtId);
		    		talukaModal.setTalukId(result.getLong("TalukID"));
		    		talukaModal.setZipCode(result.getString("ZipCode"));
		    		talukaModal.setDescription(result.getString("Description"));
		    		
		    		districtList.add(talukaModal);
		    	}
		    }
		
		    return districtList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			districtList	= null;
		}
		return null;
	}
	
}

package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Premium;
import com.LIC.model.PremiumType;

public interface IPremiumDAO {
	public Integer saveOrUpdate(Connection connection, Premium obj) throws SQLException;
	public void delete(Connection connection,Integer premiumID, Integer deleteBy) throws SQLException;
	public Premium get(Connection connection, Integer premiumID) throws SQLException;
	public List<Premium> getAll(Premium filterObj) throws SQLException;
	public List<PremiumType> getPreimumTypeByBusinessId(Integer lineOfBusinessId, Integer productId) throws SQLException;
}

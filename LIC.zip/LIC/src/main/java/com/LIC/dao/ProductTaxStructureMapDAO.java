
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductTaxStructureMap;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class ProductTaxStructureMapDAO implements IProductTaxStructureMapDAO{
		
	static final Logger LOGGER = LogManager.getLogger(ProductTaxStructureMapDAO.class);

	
	 
	@Override
	public void saveOrUpdate(Connection connection,ProductTaxStructureMap obj) throws SQLException {
	  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertProductTaxStructureMap(?,?,?,?); END;");
	  callableStatement.setInt(1, obj.getProductID());
	  callableStatement.setInt(2, obj.getTaxStructureId());
	  callableStatement.setInt(3, obj.getCreatedBy());
	  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
	  //callableStatement.registerOutParameter(3, Types.VARCHAR);
	  callableStatement.executeUpdate();
	  LOGGER.info("SP>spInsertProductTaxStructureMap executed successfully.");
	
	}
	@Override
	public List<Integer> get(Connection connection,Integer id) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  ProductTaxStructureMap obj = null;
		  List<Integer> list = null;

		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetProductTaxStructureByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  list=new ArrayList<Integer>();

		      while (rs.next()) {
		        obj = new ProductTaxStructureMap();
		        obj.setProductID(rs.getInt("PRODUCTID"));
		        obj.setTaxStructureId(rs.getInt("TAXSTRUCTUREID"));
		        list.add(obj.getTaxStructureId());

		      }
			  LOGGER.info("SP>spGetProductTaxStructureByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetProductTaxStructureByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
		
		  }
		  return list;
	} 
	
	@Override
	public void delete(Connection connection,Integer productID) throws SQLException {	
		CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductTaxStructureByID(?,?); END;");
		  callableStatement.setInt(1, productID);
		  callableStatement.registerOutParameter(2, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteProductTaxStructureByID executed successfully.");
		  LOGGER.info("SP>spDeleteProductTaxStructureByID executed successfully.");
	}
}

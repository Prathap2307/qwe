package com.LIC.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//import com.LIC.entity.DefectDataModel;
import com.LIC.model.GetGNBUploadHeader;

@Repository
public class DefectDataDAO {
	
	@Autowired
	private EntityManager defect;

	/*@SuppressWarnings("unchecked")
	public List<DefectDataModel>GetGNBDataUpload(DefectDataModel model) {
		StoredProcedureQuery query = defect.createStoredProcedureQuery("spGetGNBDataUpload")
				.registerStoredProcedureParameter("P_HeaderID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("P_FileName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("P_Status", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("P_IsPolicyIssuance", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oPlan", Class.class, ParameterMode.REF_CURSOR)
				.setParameter("P_HeaderID", model.getHeaderId())
		.setParameter("P_FileName", model.getFileName())
		.setParameter("P_Status", model.getStatus())
		.setParameter("P_IsPolicyIssuance", model.getIsPolicyIssuance());

	//	return query.execute() ? query.getResultList() : null;
		
		
		
		
		
		query.execute();
		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<DefectDataModel> defectList = list.stream()
				.map(o -> new DefectDataModel((String) o[0], (String) o[1], (String) o[2], (String) o[3],
						(String) o[4], (String) o[5], (String) o[6], (String) o[7], (String) o[8], (String) o[9], (String) o[10], (Number) o[11], (Number) o[12], (String) o[13], (String) o[14], (String) o[15], (String) o[16], (String) o[17], (String) o[18], (String) o[19], (String) o[20], (String) o[21], (String) o[22], (String) o[23], (String) o[24], (String) o[25], (String) o[26], (Number) o[27], (Number) o[28], (Number) o[29], (Number) o[30], (Number) o[31], (Number) o[32], (Number) o[33], (Number) o[34], (Number) o[35], (Number) o[36], (Number) o[37], (String) o[38], (Number) o[39], (Number) o[40], (Number) o[41], (String) o[42], (String) o[43], (String) o[44], (String) o[45], (Number) o[46], (String) o[47], (String) o[48], (String) o[49], (String) o[50], (String) o[51],(String) o[52], (String) o[53],(String) o[54]))
				.collect(Collectors.toList());

		return defectList;

	}*/


	
	
	public List<GetGNBUploadHeader>getGNBuploadHeader(GetGNBUploadHeader model ) {
	    StoredProcedureQuery query = defect
	           .createStoredProcedureQuery("SPGETGNBDATAUPLOADHEADER")
	           .registerStoredProcedureParameter("P_GroupID",Integer.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("P_MasterPolicyID",Integer.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("P_FromDate",Date.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("P_ToDate",Date.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("P_FileName",String.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("P_MasterPolicyAgreementID",Integer.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("oPlan",Class.class,ParameterMode.REF_CURSOR)
	             .setParameter("P_GroupID",model.getGroupId())
	            .setParameter("P_MasterPolicyID",model.getMatserPolicyId())
	            .setParameter("P_FromDate",model.getFromDate())
	            .setParameter("P_ToDate",model.getToDate())
	            .setParameter("P_FileName",model.getFileName())
	            .setParameter("P_MasterPolicyAgreementID",model.getMasterPolicyAgreementId());
	             query.getParameter("oPlan");


	    
	     // return query.execute() ? query.getResultList() : null;
	  
	    
	    query.execute();
	    List<Object[]> list  =  (List<Object[]>)query.getResultList();
	    List<GetGNBUploadHeader> accList = list.stream().map(
	    		o -> new GetGNBUploadHeader((Number) o[0],(Number) o[1],(Number) o[2],(String)
	    				  o[3],(Number) o[4],(Number) o[5],(Number) o[6],(Number) o[7],(Date)
	    				  o[8],(Number) o[9],(Number) o[10],(Number)
	    				  o[10])).collect(Collectors.toList());
	    
	   return accList;
	   
	     
	   }


}

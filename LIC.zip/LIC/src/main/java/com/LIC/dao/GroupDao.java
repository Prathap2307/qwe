package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.GetUserEmployeeModel;
import com.LIC.model.GroupModal;
import com.LIC.model.UserModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class GroupDao {

	private static final Logger logger = Logger.getLogger(GroupDao.class);
	
	public long InsertOrUpdate(GroupModal groupmodal, List<UserModal> userModallist) throws Exception{
		
		Connection 				conn 				= null;
		long 					groupID 			= 0;
		int 					statusGroupMap		= 0;
		
		try {
			
			if(groupmodal != null){
				
				conn   		= ResourceManager.getConnection();
				conn.setAutoCommit(false);
				
				DeleteGroupUserMap(groupmodal.getGroupID(), conn);
				
				groupID = InsertOrUpdateGroup(groupmodal, conn);
				System.out.println("groupid: "+groupID);
				
				if(groupID > 0) {
					statusGroupMap = InsertGroupUserMap(groupID, userModallist, conn);
				}
				System.out.println("statusGroupMap >>"+statusGroupMap);
				conn.commit();
				if(groupID == 0 && statusGroupMap > 0) {
					conn.rollback();
				} 
			}
		} catch(Exception e) {
			conn.rollback();
			e.printStackTrace();
			groupID	= 0;
			logger.error(e.getMessage(), e);	
			
		} finally {
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return groupID;
	}
	
	public void DeleteGroupUserMap(long GroupID, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			cstm = conn.prepareCall("call spDeleteGroupUserMap(?)");
			cstm.setLong(1, GroupID);
			cstm.executeUpdate();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
	}
	
	public long InsertOrUpdateGroup(GroupModal groupModal, Connection conn) throws Exception {
			
		CallableStatement		cstm				= null;
		ResultSet 				result 				= null;
		long 					groupID 			= 0;
       
        try {
        	
        	if(conn == null)
        		conn = ResourceManager.getConnection();
        	
        	cstm = conn.prepareCall("call spInsertOrUpdateGroup(?,?,?,?,?,?,?)");
			cstm.setLong(1, 		groupModal.getOrganisationID());
			cstm.setLong(2, 		groupModal.getGroupID());
			cstm.setString(3, 		groupModal.getGroupName());
			cstm.setLong(4, 		groupModal.getCreatedBy());
			cstm.setTimestamp(5, 	groupModal.getCreatedOn());
            cstm.setShort(6, 		groupModal.getIsActive());
            cstm.registerOutParameter(7, OracleTypes.CURSOR);
			System.out.println(cstm.toString());
            cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(7);
			
			if(result != null) {
				if(result.next()) {
					System.err.println("sddd"+result.getLong("GroupID"));
					groupID = result.getLong("GroupID");
				}
			}
			return groupID;
        } catch(Exception e) {
        	conn.rollback();
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
        
		return 0;
	}
	
	public int InsertGroupUserMap(long groupId, List<UserModal> userModalList, Connection conn) throws Exception {
		CallableStatement		cstm				= null;
		
		try {
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			System.out.println("branchList >>"+userModalList);
			if(userModalList != null) {
				for (UserModal userModal : userModalList) {
					cstm = conn.prepareCall("call spInsertGroupUserMap(?,?,?,?)");
					cstm.setLong(1, 		groupId);
					System.out.println("userModal.getUserID()" + userModal.getUserID());
					cstm.setLong(2,	 		userModal.getUserID());
					cstm.setLong(3, 		userModal.getCreatedBy());
					cstm.setTimestamp(4, 	userModal.getCreatedOn());
					cstm.executeUpdate();
				}
				 
			}
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("ddddddd");
			logger.error(e.getMessage(), e);
			return 1;
		} finally {
			if(cstm != null)
				cstm.close();
		}
		return 0;
	}
	
	
	public String DeleteGroup(long GroupID, long DeletedBy) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		String 					Status				= "Delete";
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteGroup(?,?)");
			cstm.setLong(1, GroupID);
			cstm.setLong(2, DeletedBy);
			int count =cstm.executeUpdate();
			
			if(count != 0) {
				return Status;
			} else {
				return "Error";
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
	}

	public List<GroupModal> GetAllGroupsByOrg(long organisationId, String groupName) throws Exception {
		CallableStatement 	cstm 			= null;
		Connection 			conn 			= null;
		ResultSet 			result 			= null;
		List<GroupModal> 	searchmodallist = null;
		GroupModal 			groupModal 		= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllGroupsBySearch(?,?,?)");
			cstm.setLong(1, 	organisationId);
			cstm.setString(2, 	groupName);
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement) cstm).getCursor(3);
			
			if (result != null) {
				searchmodallist = new ArrayList<GroupModal>();
				
				while (result.next()) {
					groupModal = new GroupModal();
					groupModal.setOrganisationID(result.getLong("OrganisationID"));
					groupModal.setGroupID(result.getLong("GroupID"));
					groupModal.setGroupName(result.getString("GroupName"));
					groupModal.setCreatedBy(result.getLong("CreatedBy"));
					searchmodallist.add(groupModal);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		return searchmodallist;
	}
	
	public List<GetUserEmployeeModel> GetAllUsersGroupByOrg(long organisationID) throws Exception {
		CallableStatement 			cstm 				= null;
		Connection 					conn 				= null;
		ResultSet 					result 				= null;
		GetUserEmployeeModel 		getUserEmployee		= null;
		List<GetUserEmployeeModel> 	getUserEmployeeList = null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllUsersGroupByOrg(?,?)");
			
			cstm.setLong(1,  organisationID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement) cstm).getCursor(2);
			
			if (result != null) {
				getUserEmployeeList  = new ArrayList<GetUserEmployeeModel>();
				
				while(result.next()) {
					getUserEmployee = new GetUserEmployeeModel();
					
					getUserEmployee.setSelected(result.getInt("Selected"));
					getUserEmployee.setOrganisationID(result.getLong("ORGANISATIONID"));
					getUserEmployee.setEmployeeID(result.getLong("EMPLOYEEID"));
					getUserEmployee.setUserID(result.getLong("USERID"));
					getUserEmployee.setUserName(result.getString("USERNAME"));
					getUserEmployee.setPassword(result.getString("PASSWORD"));
					getUserEmployee.setFirstName(result.getString("FIRSTNAME"));
					getUserEmployee.setLastName(result.getString("LASTNAME"));
					getUserEmployee.setInitial(result.getString("middlename"));
					getUserEmployee.setReportingTo(result.getLong("REPORTINGTO"));
					getUserEmployee.setEmployeeIsActive(result.getShort("EmployeeIsActive"));
					getUserEmployee.setUserIsActive(result.getShort("UserIsActive"));
					getUserEmployee.setIsAdmin(result.getShort("IsAdmin"));
					getUserEmployee.setIsSuperUser(result.getShort("IsSuperUser"));
					getUserEmployee.setGroupName(result.getString("GroupName"));
					getUserEmployeeList.add(getUserEmployee);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		return getUserEmployeeList;
	}
	
	public int IsGroupExist(long GroupID,  String GroupName) throws Exception {
	   CallableStatement		cstm				= null;
	   Connection 				conn 				= null; 
	   ResultSet 				result 				= null;
		   
		try{
		   conn = ResourceManager.getConnection();
		   cstm = conn.prepareCall("call spIsGroupExist(?,?,?)");
		   cstm.setLong(1, GroupID);
		   cstm.setString(2, GroupName);
		   cstm.registerOutParameter(3, OracleTypes.CURSOR);
		   cstm.execute();
		   
		   result = ((OracleCallableStatement)cstm).getCursor(3);
		   
		   if(result != null) {
		    	if(result.next()) {
		    		return result.getInt("ExistCount");
		    	}
		    		
		    }
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return 0;
	}
		
	public GroupModal GetGroupByGroupID(long GroupID) throws Exception {
	   CallableStatement		cstm				= null;
	   Connection 				conn 				= null; 
	   ResultSet 				result 				= null;
	   GroupModal 				groupmodal 			= null;
		
	   try {
		   conn = ResourceManager.getConnection();
		   cstm = conn.prepareCall("call spGetGroupByGroupID(?,?)");
		   cstm.setLong(1, GroupID);
		   cstm.registerOutParameter(2, OracleTypes.CURSOR);
		   cstm.execute();
		   
		   result = ((OracleCallableStatement)cstm).getCursor(2);
		   
		   if(result != null) {
			   
			   if(result.next()) {
				   groupmodal = new GroupModal();
				   groupmodal.setGroupID(result.getLong("GroupID"));
				   groupmodal.setGroupName(result.getString("GroupName"));
			   }
		   }
			   
		} catch (Exception e)  {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return groupmodal;
	}
}

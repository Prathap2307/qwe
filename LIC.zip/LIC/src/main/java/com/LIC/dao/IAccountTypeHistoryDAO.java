package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.LIC.model.AccountTypeHistory;
@Repository
public interface IAccountTypeHistoryDAO {
	
	public List<AccountTypeHistory> getAll(Integer accountTypeID) throws SQLException;
}

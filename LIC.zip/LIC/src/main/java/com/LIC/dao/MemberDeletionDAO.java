package com.LIC.dao;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.springframework.web.multipart.MultipartFile;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import com.LIC.model.MemberAdditionModel;
import com.LIC.model.MemberDeletionModel;
import org.springframework.beans.factory.annotation.Value;
@Repository
@SuppressWarnings("unchecked")
public class MemberDeletionDAO {
	
	@PersistenceContext
	private EntityManager em;
	
	
	//@Value("${newBusinessUploadPath.location}")
	private String UploadPath;
    
 public MemberDeletionModel SaveUploadedFile(MultipartFile file) throws IOException {

	 MemberDeletionModel NBmodel=new MemberDeletionModel();
        
             String OutputFile=UploadPath+file.getOriginalFilename();
             File convFile = new File(UploadPath+file.getOriginalFilename());
             convFile.createNewFile(); 
                  
             FileOutputStream fos = new FileOutputStream(convFile); 
             fos.write(file.getBytes());
             fos.close(); 
             
          NBmodel.setFilePath(OutputFile);
       NBmodel.setFileName(file.getOriginalFilename());
          System.out.println(file.getOriginalFilename());
          return NBmodel;

    }

	public String ValidateExcelFile(MemberDeletionModel endrosement) {
		{
			try {

				 File file = new File(endrosement.getFilePath());
				 if(file.exists()) 
				 { 
			
				 String FileEx=getFileExtension(file);
		      
			     FileInputStream input_document = new FileInputStream(new File(endrosement.getFilePath()));

			     Iterator<Row> rowIterator;
			     
			    // int columnCount = 70,FileColumnCount=0;
			     
			      if(FileEx.toUpperCase().equals("XLSX"))
			      {
			    	  XSSFWorkbook  my_xls_workbook = new XSSFWorkbook (input_document);
				      XSSFSheet  my_worksheet = my_xls_workbook.getSheetAt(0);
				      rowIterator = my_worksheet.iterator();
			      }
			      else {
			    	  HSSFWorkbook  my_xls_workbook = new HSSFWorkbook(input_document);
				      HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0);
				      rowIterator = my_worksheet.iterator();
			      }
			      	  Row row = rowIterator.next(); 
		              if(row!=null && row.getLastCellNum() > 0)
		              {
			            Iterator<Cell> cellIterator = row.cellIterator();
					
		                while(cellIterator.hasNext())
	                     {
	                   	  	  Cell nextCell = cellIterator.next();
	                             
	                             int columnIndex = nextCell.getColumnIndex();
	                            // FileColumnCount=FileColumnCount+1;
	                             switch (columnIndex)  {
				case 0:
                    if(!nextCell.getStringCellValue().toUpperCase().equals("SCHEMENO")) //SchemoNo
                    {
                    	//System.out.println("hello");
                    	//System.out.println(nextCell.getStringCellValue());
                       return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Type";      
                    }
                    break;
               case 1:
                    if(!nextCell.getStringCellValue().toUpperCase().equals("EMPLOYEEID")) //Employeeid
                    {
                    	
                    	//System.out.println(nextCell.getStringCellValue().toUpperCase());
                    	
                    	//return nextCell.getStringCellValue();
                       return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column SchemeNo";  
                    }
                    break;
               case 2: 
                         if(!nextCell.getStringCellValue().toUpperCase().equals("DATEOFLEAVING")) //DateOfLeaving
                           {
                              return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column EmployeeNo"; 
                           }
                           break;
               case 3: 
                         if(!nextCell.getStringCellValue().toUpperCase().equals("REASONFORLEAVING")) //ReasonForleaving
                           {
                              return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column UniqueID";  
                           }
                           break;
               case 4: 
                       if(!nextCell.getStringCellValue().toUpperCase().equals("DATEOFINTIMATIONOFREQUEST")) //DateOfIntimationOfRequest
                           {
                              return "COLUMN " +nextCell.getStringCellValue()+ " is not Matching with MF Insure defined Column Name. Please Update the Column Title";     
                           }
                           break;
              
                  case 5: 
                          if(!nextCell.getStringCellValue().equals(""))
                         {
                                  return "Duplicate/Excess of Column " + nextCell.getStringCellValue() + " is not allowed.Please Update the Column"; 
                                }
                           break;    
                      	  
                     	  
	                             }
	                     }
		                
					/*
					 * if(columnCount!=FileColumnCount) { return
					 * "File is rejected  Please upload Proper Excel Template"; }
					 */
	                     
		              }
			      

			      input_document.close();
				 }
				 else {
					 return "File does not exists";
				 }
			  }
				catch (Exception e){
				  e.printStackTrace();
			  }
			return "";
		}
	}
		
	@Transactional
	@Modifying
	public void BulkInsert(MemberDeletionModel emodel) throws Exception {

		try {

			File file = new File(emodel.getFilePath());

			String FileEx = getFileExtension(file);

			Query sql_statement = em.createNativeQuery("INSERT INTO MemberDeletionDataUpload"
					+ "(FILENAME,SCHEMENO,EMPLOYEEID,DATEOFLEAVING,REASONFORLEAVING,DATEOFINTIMATIONOFREQUEST)"
					
					+ " VALUES (?,?,?,?,?,?)");
				//	+ "?,?,?,?)");
			FileInputStream input_document = new FileInputStream(new File(emodel.getFilePath()));

			Iterator<Row> rowIterator;

			if (FileEx.toUpperCase().equals("XLSX")) {

				XSSFWorkbook my_xls_workbook = new XSSFWorkbook(input_document);

				XSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0);
				rowIterator = my_worksheet.iterator();
				// we loop through and insert data
			} else {
				System.out.println("pls upload excel file only");
				HSSFWorkbook my_xls_workbook = new HSSFWorkbook(input_document);
				HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0);
				rowIterator = my_worksheet.iterator();
			}

		//	rowIterator.next();
			//rowIterator.next();
			rowIterator.next(); 
		
			
			System.out.println(rowIterator.hasNext());
			while(rowIterator.hasNext()) {
				
				Row row = rowIterator.next();
				if (row != null && row.getLastCellNum() > 0) {
					Iterator<Cell> cellIterator = row.cellIterator();
					while (cellIterator.hasNext()) {
						Cell nextCell = cellIterator.next();

						int columnIndex = nextCell.getColumnIndex();
						switch (columnIndex) {
						case 0:
							sql_statement.setParameter(1, emodel.getFileName());
							sql_statement.setParameter(2,nextCell.getStringCellValue());
							break;
						case 1:
							
							sql_statement.setParameter(3, nextCell.getStringCellValue());
							break;
						 case 2: //System.out.println(nextCell.getStringCellValue());
						  sql_statement.setParameter(4, nextCell.getDateCellValue()); 
						  break;
						 
							
						case 3:
							sql_statement.setParameter(5, nextCell.getStringCellValue());
							break;
						
						case 4:
							sql_statement.setParameter(6, nextCell.getDateCellValue());
							break;
					
						}
					}
					
					
					  sql_statement.executeUpdate();
					  break;
				}
			}
			 input_document.close();
		}
		catch (Exception e){
            e.printStackTrace();
}
          
}

	private String getFileExtension(File file) {
		String fileName = file.getName();
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		else
			return "";
	}


	}
	

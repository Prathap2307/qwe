package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.controller.ConfigurationController;
import com.LIC.model.BranchModal;
import com.LIC.model.ChannelModal;
import com.LIC.model.SalesCategoryModal;
import com.LIC.model.SubChannelModal;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.exception.ExceptionProcess;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class ChannelDao {
	 
	private static final Logger logger = Logger.getLogger(ConfigurationController.class);
	
	public List<ChannelModal>  getMainChannel() throws Exception {
		CallableStatement			cstm				= null;
		Connection 					conn 				= null;
		ResultSet 					result 				= null; 
		ChannelModal 				channelModal		= null;
		ArrayList<ChannelModal> 	channelModalList	= null;
		
		try {
        	conn   		= ResourceManager.getConnection();
 			cstm 		= conn.prepareCall("call spGetAllMainChannel(?) ");
             
 			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
 			cstm.execute();
 			
 			result = ((OracleCallableStatement)cstm).getCursor(1);

 		    if(result != null) {
 		    	
 		    	channelModalList	= new ArrayList<ChannelModal>();
 		    	
 		    	while(result.next()) {
 		    	
 		    		channelModal = new ChannelModal();
 		    		channelModal.setChannelName(result.getString("ChannelName"));
 		    		channelModal.setChannelID(result.getLong("ChannelID"));
 		    		channelModal.setChannelNameWithCode(result.getString("ChannelNameWithCode"));
 		    		channelModal.setChannelCode(result.getString("ChannelCode"));
 		    		channelModalList.add(channelModal);
 		    	}
 		    }
                
             return channelModalList;
             
         }  catch (SQLException sqlExc) {
        	 sqlExc.printStackTrace();
             logger.info(sqlExc.getMessage());
         } finally {
        	 ResourceManager.freeConnection(conn);
        	 cstm				= null; 
        	 conn 				= null; 
        	 result 			= null; 
        	 channelModal		= null; 
        	 channelModalList	= null; 
         }
		return channelModalList;
     }
	
	public List<SubChannelModal>  GetAllChannel(ChannelModal channel) throws Exception {
		CallableStatement			cstm				= null;
		Connection 					conn 				= null;
		ResultSet 					result 				= null; 
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllChannel(?,?,?) ");
			
			cstm.setString(1, channel.getChannelName()); 
			cstm.setString(2, channel.getChannelCode()); 
			cstm.registerOutParameter(3, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);
			
			if(result != null) {
				
				return getChannelValuesFromResultSet(result);
			}
			
		}  catch (SQLException sqlExc) {
			sqlExc.printStackTrace();
			logger.info(sqlExc.getMessage());
		} finally {
			ResourceManager.freeConnection(conn);
			cstm				= null; 
			conn 				= null; 
			result 			= null; 
		}
		// return null;
		return null;
	}
    
	
     public ArrayList<BranchModal> GetAllBranches(long organisationID) throws Exception {
    	CallableStatement			cstm				= null;
 		Connection 					conn 				= null;
 		ResultSet 					result 				= null; 
 		BranchModal 				branchModal			= null;
 		ArrayList<BranchModal> 		branchModalList		= null;
    	 
 		try {
        	 
 			conn   		= ResourceManager.getConnection();
  			cstm 		= conn.prepareCall("call spGetAllBranch(?,?) ");
              
            cstm.setLong(1, organisationID); 
  			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
  			cstm.execute();
  			
  			result = ((OracleCallableStatement)cstm).getCursor(2);

  		    if(result != null) {
  		    	
  		    	branchModalList	= new ArrayList<BranchModal>();
  		    	
  		    	while(result.next()) {
  		    		branchModal	= new BranchModal();
  		    		branchModal.setOrganisationId(organisationID);
					branchModal.setBranchId(result.getLong("BranchID"));
					branchModal.setShortName(result.getString("ShortName"));
					branchModal.setBranchName(result.getString("Description"));
					branchModal.setParentBranchId(result.getLong("ParentBranchID"));
					branchModal.setAddressId(result.getLong("AddressID"));
  		    		branchModalList.add(branchModal);
  		    	}
  		    }
             
  		    return branchModalList;
         } catch (SQLException sqlExc)  {
             logger.info(sqlExc.getMessage());
             throw sqlExc;
         }  finally {
        	 ResourceManager.freeConnection(conn);
        	 cstm				= null; 
        	 conn 				= null; 
        	 result 			= null; 
         }
     }
     
     public void InsertOrUpdateChannel(ChannelModal channel) throws Exception {
    	CallableStatement			cstm				= null;
   		Connection 					conn 				= null;
 			
       try {
	        conn   		= ResourceManager.getConnection();
	        cstm 		= conn.prepareCall("call spInsertOrUpdateChannel(?,?,?,?)");
	        
	        cstm.setLong(1,		channel.getChannelID());
	        cstm.setString(2,	channel.getChannelName());
	        cstm.setString(3,	channel.getChannelCode());
	        cstm.setLong(4, 	channel.getCreatedBy());
	        
	        cstm.executeUpdate();
        
       } catch(SQLException sqlExc) {
     	  logger.info(sqlExc.getMessage());
           throw sqlExc;
       } finally {
    	   	ResourceManager.freeConnection(conn);
    	    cstm					= null;
    	    conn 					= null;
       }
     }

     public void InsertChannel(ChannelModal channel) throws Exception {
         
    	 CallableStatement		cstm				= null;
 		 Connection 			conn 				= null;
 			
       try {
        
    	   	conn   		= ResourceManager.getConnection();
	        cstm 		= conn.prepareCall("call spInsertUpdateChannel(?,?,?,?,?,?)");
	        
	        cstm.setLong(1,		channel.getChannelID());
	        cstm.setString(2,	channel.getChannelName());
	        cstm.setString(3,	channel.getChannelCode());
	        cstm.setLong(4, 	channel.getCreatedBy());
	        cstm.setShort(5, 	channel.getIsActive());
	        cstm.setLong(6, 	channel.getCategroyID());
	        cstm.executeUpdate();
        
       } catch(SQLException sqlExc) {
      	  logger.info(sqlExc.getMessage());
          throw sqlExc;
      } finally {
	   	   	ResourceManager.freeConnection(conn);
	   	    cstm					= null;
	   	    conn 					= null;
	      }
     }

     public String IsChannelExist(long ChannelID, String ChannelName, String ChannelCode)  throws Exception{
        
    	 CallableStatement		cstm				= null;
 		 Connection 			conn 				= null;
 		 ResultSet 				result 				= null; 
    	 String 				status 				= null;
      
    	 try {

        	conn   		= ResourceManager.getConnection();
 	        cstm 		= conn.prepareCall("call spIsChannelExists(?,?,?,?)");
            
 	        cstm.setLong(1,		ChannelID);
	        cstm.setString(2,	ChannelName);
	        cstm.setString(3,	ChannelCode);
	        cstm.registerOutParameter(4, OracleTypes.CURSOR); //REF CURSOR
  			cstm.execute();
  			System.out.println("ddd >ddd");
  			
  			result = ((OracleCallableStatement)cstm).getCursor(4);

  		    if(result != null) {
  		    	
  		    	if(result.next()) {
  		    		status = result.getString("ExistStatus");
  		    		System.out.println("ddd >ddd"+ status);
  		    	}
  		    }
  		   
  		    return status;
         } catch(SQLException sqlExc) {
         	  logger.info(sqlExc.getMessage());
              throw sqlExc;
          } finally {
       	   	ResourceManager.freeConnection(conn);
       	    cstm					= null;
       	    conn 					= null;
          }
     }
     
 	public String DeleteChannel(ChannelModal channel) throws Exception {
 		CallableStatement		cstm				= null;
 		Connection 				conn 				= null;
 		ResultSet 				result 				= null;
 		String					deletedStatus		= null;
 		
 		try {
 			conn   		= ResourceManager.getConnection();
 			cstm 		= conn.prepareCall("call spDeleteChannel(?,?,?,?)");
 			cstm.setLong(1,channel.getChannelID());
 			cstm.setLong(2,channel.getDeletedBy());
 			cstm.setTimestamp(3,channel.getDeletedOn());
 			cstm.registerOutParameter(4, OracleTypes.CURSOR); //REF CURSOR
   			cstm.execute();
   			
   			System.out.println("rrrrr");
 			result = ((OracleCallableStatement)cstm).getCursor(4);
 			
 			if(result != null) {
 				if(result.next()) {
 					deletedStatus = result.getString("DeletedStatus");
 				}
 			}
 			return deletedStatus;
 		} catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			cstm.close();
 			cstm	= null;
 			ResourceManager.freeConnection(conn);
 			conn	= null;
 		}
 		return "Error";
 	}
 	
 	public String IsSubChannelExist(long SubChannelID, String ChannelName, String ChannelCode, long MainChannelID, String PolicyHolderCode) throws Exception {
 		
 		CallableStatement		cstm				= null;
 		Connection 				conn 				= null;
 		ResultSet 				result 				= null;
 		String					existStatus			= null;
 		
 		try {
 			
 			conn   			= ResourceManager.getConnection();
 			cstm 			= conn.prepareCall("call spIsSubChannelExistBySubChannelID(?,?,?,?,?,?)");
 			cstm.setLong(1,		SubChannelID);
 			cstm.setString(2, 	ChannelName);
 			cstm.setString(3, 	ChannelCode);
 			cstm.setLong(4,		MainChannelID);
 			cstm.setString(5,	PolicyHolderCode);
 			cstm.registerOutParameter(6, OracleTypes.CURSOR); //REF CURSOR
 			cstm.execute();
 			
 			result = ((OracleCallableStatement)cstm).getCursor(6);
 			
 			if(result != null) {
 				if(result.next()) {
 					System.out.println("fff"+ result.getString("ExistStatus"));
 					existStatus = result.getString("ExistStatus");
 				}
 			}
 			return existStatus;
 		} catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			cstm.close();
 			cstm	= null;
 			ResourceManager.freeConnection(conn);
 			conn	= null;
 		}
		return "Error";
 	}
 	
 	public long InsertSubChannel(SubChannelModal objChannelInfo) throws Exception {
 		CallableStatement		cstm				= null;
 		Connection 				conn 				= null;
 		ResultSet 				result 				= null;
 		long	 				subChannelID 		= 0;
       
        try {
        	conn   		= ResourceManager.getConnection();
        	conn.setAutoCommit(false);
 			
        	cstm 		= conn.prepareCall("call spInsertUpdateSubChannel(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
 			
 			cstm.setLong(1,			objChannelInfo.getSubChannelID());
 			cstm.setLong(2,			objChannelInfo.getMainChannelID());
 			cstm.setString(3,		objChannelInfo.getChannelName());
 			cstm.setString(4,		objChannelInfo.getChannelCode());
 			cstm.setLong(5,			objChannelInfo.getCreatedBy());
 			cstm.setShort(6,		objChannelInfo.getIsActive());
 			cstm.setLong(7,			objChannelInfo.getBranchID());
 			cstm.setShort(8,		objChannelInfo.getIsCDAccount());
 			cstm.setString(9,		objChannelInfo.getMobileNo());
 			cstm.setString(10,		objChannelInfo.getEmail());
 			cstm.setDouble(11,		objChannelInfo.getTriggerLimit());
 			cstm.setShort(12,		objChannelInfo.getIsPhysicalEntry());
 			cstm.setString(13,		objChannelInfo.getPolicyHolderCode());
 			cstm.setShort(14,		objChannelInfo.getIsBlanket());
 			cstm.setShort(15,		objChannelInfo.getIsChildrenAccess());
 			cstm.registerOutParameter(16, OracleTypes.CURSOR); //REF CURSOR
 			
 			cstm.executeUpdate();
 			
 			result = ((OracleCallableStatement)cstm).getCursor(16);
 			
 			if(result != null) {
 				if(result.next()) {
 					subChannelID = result.getLong("SubChannelID");
 				}
 			} 
 			
 			System.out.println("ChannelDao.subChannelID()"+subChannelID);
 			if(subChannelID > 0) {
 				
 				//InsertSalesBranchID(subChannelID , objChannelInfo.getBranchModalList(), conn);
 			}
 			
 			conn.commit();
        } catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			cstm.close();
 			cstm	= null;
 			ResourceManager.freeConnection(conn);
 			conn	= null;
 		}
		return subChannelID;
    }

 	 public long DeleteBranchID(long SalesHierarchyID)throws Exception {
 	    CallableStatement		cstm				= null;
 		Connection 				conn 				= null;
 	  
 		try  {
 			conn = ResourceManager.getConnection();
     		cstm = conn.prepareCall("call spDeleteSalesHierarchyBranchIDBySalesHierachID(?) ");	
     		cstm.setLong(1, SalesHierarchyID);
     		cstm.executeUpdate();
 		  } catch (Exception e) {
 			  e.printStackTrace();
 				logger.info(e.getMessage());
 		} finally  {
 			cstm.close();
   			cstm	= null;
   			ResourceManager.freeConnection(conn);
   			conn	= null;  
 		  }
 		  return 0;
 	  }
 	 
 	 public void InsertSalesBranchID(long SalesHierarchyID, List<BranchModal> SalesHierachyInfoObjectList,
	    		Connection conn)throws Exception {
	    	CallableStatement		cstm				= null;

	    	try{

	    		DeleteBranchID(SalesHierarchyID);
	    		
	    		for (BranchModal branchModal : SalesHierachyInfoObjectList) {
	    			
	    			cstm = conn.prepareCall("call spInsertBranchIDBySalesHierarchyID(?,?,?,?)");	
	    			cstm.setLong(1, branchModal.getAddressId());
	    			cstm.setLong(2, SalesHierarchyID);
	    			cstm.setLong(3, branchModal.getCreatedBy());
	    			cstm.setTimestamp(4, branchModal.getCreatedOn());
	    			cstm.executeUpdate();
	    		}
	    	}catch (Exception e) {
	    		e.printStackTrace();
	    		logger.info(e.getMessage());
	    	}finally{
	    		if(cstm != null) 
	    			cstm.close();
	    		cstm	= null;
	    	}
	    }
 	 
 	public List<SubChannelModal> GetChannelById(long channelID) throws Exception {
        
 		CallableStatement			cstm				= null;
 		Connection 					conn 				= null;
 		ResultSet 					result 				= null;
       
        try {
        	conn   		= ResourceManager.getConnection();
 			cstm 		= conn.prepareCall("call spGetChannelById(?,?)");
        
 			cstm.setLong(1,	channelID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
 			cstm.execute();
 			
 			result = ((OracleCallableStatement)cstm).getCursor(2);
 			
 			if(result != null) {
 				
 				return getChannelValuesFromResultSet(result);
 			}	
        } catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			cstm.close();
 			cstm	= null;
 			ResourceManager.freeConnection(conn);
 			conn	= null;
 		}
		return null;
     }

 	 public List<SubChannelModal> GetSubChannelDetailsbySubChannelID(long SubChannelID) throws Exception {
        
 		CallableStatement			cstm				= null;
 		Connection 					conn 				= null;
 		ResultSet 					result 				= null;
       
        try {
        	conn   		= ResourceManager.getConnection();
 			cstm 		= conn.prepareCall("call spGetSubChannelDetailsbySubChannelID(?,?)");
        
 			cstm.setLong(1,	SubChannelID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
 			cstm.execute();
 			
 			result = ((OracleCallableStatement)cstm).getCursor(2);
 			
 			if(result != null) {
 				
 				return getChannelValuesFromResultSet(result);
 				
 			}
 			
        } catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			cstm.close();
 			cstm	= null;
 			ResourceManager.freeConnection(conn);
 			conn	= null;
 		}
		return null;
     }
 	 
 	public String DeleteSubChannel(long MainChannelID) throws Exception {
 		CallableStatement		cstm				= null;
 		Connection 				conn 				= null;
 		ResultSet 				result 				= null;
 		String					deletedStatus		= null;
 		
 		try {
 			conn   		= ResourceManager.getConnection();
 			cstm 		= conn.prepareCall("call spDeleteSubChannel(?,?)");
 			cstm.setLong(1,	MainChannelID);
 			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
   			cstm.execute();
   			
 			result = ((OracleCallableStatement)cstm).getCursor(2);
 			
 			if(result != null) {
 				if(result.next()) {
 					deletedStatus = result.getString("DeletedStatus");
 				}
 			}
 			return deletedStatus;
 		} catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			cstm.close();
 			cstm	= null;
 			ResourceManager.freeConnection(conn);
 			conn	= null;
 		}
 		return "Error";
 	}
 	
 	private List<SubChannelModal> getChannelValuesFromResultSet(ResultSet result) throws Exception {
 		SubChannelModal 			subChannelModal		= null;
		List<SubChannelModal> 		subChannelModalList	= null;
 		
 		try {
 			
 			subChannelModalList	= new ArrayList<SubChannelModal>();
		    	
		    	while(result.next()) {
		    	
		    		subChannelModal = new SubChannelModal();
		    		subChannelModal.setChannelID(result.getLong("ChannelID"));
		    		if(ExceptionProcess.isColumnThereInResultSet(result,"SubChannelID"))
		    		subChannelModal.setSubChannelID(result.getLong("SubChannelID"));
		    		subChannelModal.setChannelName(result.getString("ChannelName"));
		    		subChannelModal.setChannelCode(result.getString("ChannelCode"));
		    		subChannelModal.setMainChannelName(result.getString("MainChannelName"));
		    		subChannelModal.setMainChannelID(result.getLong("MainChannelID"));
		    		subChannelModal.setDescription(result.getString("Description"));
		    		subChannelModal.setCategroyID(result.getLong("CategroyID"));
		    		subChannelModal.setBranchID(result.getLong("BranchID"));
		    		subChannelModal.setIsCDAccount(result.getShort("IsCDAccount"));
		    		subChannelModal.setMobileNo(result.getString("MobileNo"));
		    		subChannelModal.setEmail(result.getString("Email"));
		    		subChannelModal.setTriggerLimit(result.getDouble("TriggerLimit"));
		    		if(ExceptionProcess.isColumnThereInResultSet(result,"IsPhysicalEntry"))
		    		subChannelModal.setIsPhysicalEntry(result.getShort("IsPhysicalEntry"));
		    		if(ExceptionProcess.isColumnThereInResultSet(result,"PolicyHolderCode"))
		    		subChannelModal.setPolicyHolderCode(result.getString("PolicyHolderCode"));
		    		if(ExceptionProcess.isColumnThereInResultSet(result,"IsBlanket"))
		    		subChannelModal.setIsBlanket(result.getShort("IsBlanket"));
		    		if(ExceptionProcess.isColumnThereInResultSet(result,"IsChildrenAccess"))
		    		subChannelModal.setIsChildrenAccess(result.getShort("IsChildrenAccess"));
		    		
		    		subChannelModalList.add(subChannelModal);
		    	}
		    	return subChannelModalList;
		    	
 		} catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			subChannelModalList = null;
 		}
 		return null;
 	}
 	
 	public List<SubChannelModal>  GetSubChannel(SubChannelModal subChannel) throws Exception {
		CallableStatement			cstm				= null;
		Connection 					conn 				= null;
		ResultSet 					result 				= null;
		SubChannelModal 			subChannelModal		= null;
		List<SubChannelModal> 		subChannelModalList	= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetSubchannel(?,?,?) ");
			
			cstm.setString(1, subChannel.getChannelName()); 
			cstm.setString(2, subChannel.getChannelCode()); 
			cstm.registerOutParameter(3, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);
			
			if(result != null) {
				
				subChannelModalList	= new ArrayList<SubChannelModal>();
				
				while(result.next()) {
					subChannelModal	= new SubChannelModal();
					subChannelModal.setChannelName(result.getString("ChannelName"));	
					subChannelModal.setMainChannelID(result.getLong("MainChannelID"));
					subChannelModal.setSubChannelID(result.getLong("SubChannelID"));
					subChannelModal.setChannelID(result.getLong("ChannelID"));
					subChannelModal.setIsCDAccount(result.getShort("IsCDAccount"));
					subChannelModal.setDescription(result.getString("Description"));
					subChannelModal.setMainChannelName(result.getString("MainChannel"));
					subChannelModal.setChannelCode(result.getString("ChannelCode"));
					subChannelModalList.add(subChannelModal);
				}
			}
			
			return subChannelModalList;
		}  catch (SQLException sqlExc) {
			sqlExc.printStackTrace();
			logger.info(sqlExc.getMessage());
		} finally {
			ResourceManager.freeConnection(conn);
			cstm				= null; 
			conn 				= null; 
			result 			= null; 
		}
		return null;
	}
 	
 	public List<SubChannelModal> GetAllSubChannelByChannelID(long mainChannelID) throws Exception {
		CallableStatement		cstm					= null;
		Connection 				conn 					= null;
		ResultSet 				result 					= null;
		SubChannelModal         subChannelModal      	= null;
		List<SubChannelModal>   subChannelModalList 	= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetSubchannelByChannelID(?,?)");
			cstm.setLong(1, mainChannelID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				subChannelModalList	= new ArrayList<SubChannelModal>();
				
				while(result.next()) {
					subChannelModal = new SubChannelModal();
					subChannelModal.setChannelID(mainChannelID);
					subChannelModal.setChannelName(result.getString("ChannelName"));	
					subChannelModal.setMainChannelID(result.getLong("MainChannelID"));
					subChannelModal.setSubChannelID(result.getLong("SubChannelID"));
					subChannelModal.setIsCDAccount(result.getShort("IsCDAccount"));
					subChannelModal.setEmail(result.getString("Email"));
					subChannelModal.setSubChannelNameWithCode(result.getString("SubChannelNameWithCode"));
					subChannelModalList.add(subChannelModal);
				}
			}
			return subChannelModalList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return null;
	}
 	
 	public List<SalesCategoryModal> GetSalesCategory() throws Exception {
		CallableStatement			cstm					= null;
		Connection 					conn 					= null;
		ResultSet 					result 					= null;
		SalesCategoryModal         	salesCategory      		= null;
		List<SalesCategoryModal>   	salesCategoryList 		= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllSaleCategory(?)");
			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				salesCategoryList	= new ArrayList<SalesCategoryModal>();
				
				while(result.next()) {
					salesCategory = new SalesCategoryModal();
					salesCategory.setCategoryID(result.getLong("CategroyID"));
					salesCategory.setChannelName(result.getString("Description"));
					
					salesCategoryList.add(salesCategory);
				}
			}
			return salesCategoryList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return null;
	}
 	
 	
     /*
     public DataTable GetHeadOfficeBranchID()
     {
         try
         {
             Database DB = DatabaseFactory.CreateDatabase("ConnectionString");
             using (DbCommand Cmd = DB.GetStoredProcCommand("spGetHeadOfficeBranchID"))
             {
                 using (DataSet ds = DB.ExecuteDataSet(Cmd))
                 {
                     if (ds.Tables.Count > 0)
                     { return ds.Tables[0]; }
                     else { return null; }
                 }
             }
         }
         catch (SqlException sqlExc)
         {
             Logger.Write(sqlExc.Message.ToString());
             throw sqlExc;

         }
         return null;
     }
     #endregion


     #region "Check Channel Exist By Using Channel ID"
     /// <summary>
     /// Check Channel Exist By Using Channel ID
     /// </summary>
     /// <param name="ChannelID">Channel ID Object</param>
     /// <returns>Returns Boolean[True/False]</returns>

     public DataTable GetAllChannel(SearchInfo objSearchInfo)
     {
         try
         {
             DataTable _dt;
             Database DB = DatabaseFactory.CreateDatabase("ConnectionString");
             using (DbCommand Cmd = DB.GetStoredProcCommand("spGetAllChannel"))
             {
                 DB.AddInParameter(Cmd, "@ChannelID", DbType.Int32, objSearchInfo.ID);
                 DB.AddInParameter(Cmd, "@Description", DbType.String, objSearchInfo.Description);
                 using (DataSet ds = DB.ExecuteDataSet(Cmd))
                 {
                     if (ds.Tables.Count > 0)
                     { _dt = ds.Tables[0]; }
                     else
                     { _dt = null; }
                 }
             }
             DB = null;
             return _dt;
         }
         catch (SqlException sqlExc)
         {
             Logger.Write(sqlExc.Message.ToString());
         }
         return null;
     }
 
     #endregion

    
     #endregion


     #region "Delete Channel"
     /// <summary>
     /// Delete Channel
     /// </summary>
     /// <param name="ChannelID">Channel ID Object</param>
     /// <returns>Returns DataSet</returns>

     #endregion

     #region "Delete Channel"
     /// <summary>
     /// Delete Channel
     /// </summary>
     /// <param name="ChannelID">Channel ID Object</param>
     /// <returns>Returns DataSet</returns>

     public String DeleteChannelNew(Int32 ChannelID)
     {
         try
         {
             Database DB = DatabaseFactory.CreateDatabase("ConnectionString");
             DbCommand Cmd = DB.GetStoredProcCommand("spDeleteChannel");
             DB.AddInParameter(Cmd, "@ChannelID", DbType.Int32, ChannelID);
             string _Status = DB.ExecuteScalar(Cmd).ToString();
             DB = null;
             return _Status;
         }

         catch (SqlException sqlExc)
         {
            
         }
         return "ERROR";
     }
     #endregion


     # region  get All Sub Channel
     public DataTable GetAllSubChannelByCDAccount(Int32 SubChannelID)
     {
         try
         {
             DataTable _dt;
             Database StateDB = DatabaseFactory.CreateDatabase("ConnectionString");
             using (DbCommand StateCmd = StateDB.GetStoredProcCommand("spGetSubchannelByChannelIDByCDAccount"))
             {
                 StateDB.AddInParameter(StateCmd, "@ChannelID", DbType.Int32, SubChannelID);
                 using (DataSet ds = StateDB.ExecuteDataSet(StateCmd))
                 {
                     if (ds.Tables.Count > 0)
                     { _dt = ds.Tables[0]; }
                     else { _dt = null; }
                 }
             }
             return _dt;
         }
         catch (SqlException sqlExc)
         {
             Exception Exec = null; String ErrorMsg = "Database Error, Check inner exception for details";
            // bool rethrow = ExceptionPolicy.HandleException(sqlExc, "SQL Policy", out Exec);
             Logger.Write(sqlExc.Message.ToString());
         }
         return null;
     }
    */
}

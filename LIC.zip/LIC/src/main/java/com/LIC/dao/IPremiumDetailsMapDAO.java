package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.LIC.model.PremiumDetailsMap;

public interface IPremiumDetailsMapDAO {
	public void saveOrUpdate(Connection connection,PremiumDetailsMap obj) throws SQLException;
	public PremiumDetailsMap  get(Connection connection,Integer id) throws SQLException ;
	public void delete(Connection connection, Integer id) throws SQLException;

}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.Region;
import com.LIC.model.RegionModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class RegionDao implements IRegionDAO {
	
	private static final Logger logger = Logger.getLogger(RegionDao.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(Region obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateRegion(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getRegionId());
		  callableStatement.setString(2, obj.getShortDescription());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setInt(4, obj.getCreatedBy());
		  callableStatement.setString(5, obj.getRemarks());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  logger.info("SP>spInsertOrUpdateRegion executed successfully.");
	}
	
	@Override
	public void delete(Integer regionID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteRegion(?,?,?); END;");
		  callableStatement.setInt(1, regionID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  logger.info("SP>spDeleteRegion executed successfully.");
	} 
	
	@Override
	public List<Region> getAll(Region filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Region> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllRegion(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Region obj = null;
			  list = new ArrayList<Region>();
		      while (rs.next()) {
		        obj = new Region();
		        obj.setRegionId(rs.getInt("REGIONID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		        list.add(obj);
		      }
			  logger.info("SP>spGetAllRegion executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetAllRegion exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public Region get(Integer regionID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  Region obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetRegion(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, regionID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new Region();
		        obj.setRegionId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		      }
			  logger.info("SP>spGetAllRegion executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetAllRegion exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	
	
	public List<RegionModal> getAllRegions() throws Exception {

		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		RegionModal			   regionModal		          = null;
		List<RegionModal>		RegionModalList			= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			
			cstm 		= conn.prepareCall("call spGetAllRegion(?) ");
			
			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);

		    if(result != null) {
		    	
		    	RegionModalList	= new ArrayList<RegionModal>();
		    	
		    	while (result.next ()) {
		    		regionModal = new RegionModal();
		    		
		    		regionModal.setRegionId(result.getLong("RegionID"));
		    		regionModal.setDescription(result.getString("Description"));
		    
		    		
		    		RegionModalList.add(regionModal);
		    	}
		    }
		
		    return RegionModalList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return null;
	}
	
}

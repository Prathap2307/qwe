
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.Variant;
import com.LIC.utils.DateUtil;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class VariantDAO implements IVariantDAO {
	
	static final Logger LOGGER = LogManager.getLogger(VariantDAO.class);
	
	@Override
	public Variant saveOrUpdate(Connection connection, Variant obj) throws SQLException, ParseException {
		
		System.out.println(obj.toString());
		  Date startDate = DateUtil.getDateFromInputDate(obj.getStartDate());
		  Date endDate = DateUtil.getDateFromInputDate(obj.getEndDate());
		  Date effectiveDate = DateUtil.getDateFromInputDate(obj.getEffectiveDate());
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateProducts(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getProductID());
		  callableStatement.setInt(2, obj.getOrganisationID());
		  callableStatement.setInt(3, obj.getInsurerID());
		  callableStatement.setString(4, obj.getCode());
		  callableStatement.setString(5, obj.getDescription());
		  callableStatement.setInt(6, obj.getProductTypeID());
		  callableStatement.setInt(7, obj.getLineOfBusinessID());
		  callableStatement.setInt(8, obj.getPlanTypeId());
		  callableStatement.setString(9, obj.getProductVersion());
		  callableStatement.setDate(10,new java.sql.Date(startDate.getTime()));
		  callableStatement.setDate(11,new java.sql.Date(endDate.getTime()));  
		  callableStatement.setInt(12, obj.getMaxAge());
		  callableStatement.setInt(13, obj.getMinAge());
		  callableStatement.setInt(14, obj.getMinimumAgeTypeID());
		  callableStatement.setInt(15, obj.getMaximumAgeTypeID());
		  callableStatement.setInt(16, obj.getMaxTerm());
		  callableStatement.setInt(17, obj.getMinTerm());
		  callableStatement.setInt(18, obj.getMaxSumAssured());
		  callableStatement.setInt(19, obj.getMinSumAssured());
		  callableStatement.setInt(20, obj.getInterestRate());
		  callableStatement.setInt(21, obj.getIsParticipate());
		  callableStatement.setInt(22, obj.getFamilyDiscount());
		  callableStatement.setInt(23, obj.getLapseDays());
		  callableStatement.setInt(24, obj.getCreatedBy());
		  callableStatement.setString(25, obj.getNewBusinessGLCode());
		  callableStatement.setString(26, obj.getPremiumCollectionGLCode());
		  callableStatement.setInt(27, obj.getPlanCategoryID());
		  callableStatement.setInt(28, obj.getInsuredProductTypeID());
		  callableStatement.setInt(29, obj.getNoOfBackdatedForNB());
		  callableStatement.setInt(30, obj.getNoOfBackdatedForEndorsemant());
		  callableStatement.setInt(31, obj.getIsUnderWritingApplicable());
		  callableStatement.setInt(32, obj.getIsFloaterApplicable());
		  callableStatement.setInt(33, obj.getIsEmployeeApplicable());
		  callableStatement.setInt(34, obj.getPlanID());
		  callableStatement.setInt(35, obj.getLifeCategoryID());
		  callableStatement.setInt(36, obj.getFreelookup());
		  callableStatement.setInt(37, obj.getWaitingPeriodforClaim());
		  callableStatement.setInt(38, obj.getIsEligibleforLoan());
		  callableStatement.setInt(39, obj.getWaitingPeriodforLoan());
		  callableStatement.setInt(40, obj.getIsFreemium());
		  callableStatement.setInt(41, obj.getTypeOfCoverID());
		  callableStatement.setInt(42, obj.getVehicleCategory());
		  callableStatement.setString(43, obj.getPlanShortName());
		  callableStatement.setDate(44,new java.sql.Date(effectiveDate.getTime())); 
		  callableStatement.setString(45, obj.getuANNo());
		  callableStatement.setInt(46, obj.getAutoIssuePolicyUpToFCLLimit());
		  callableStatement.setString(47, obj.getRemarks());
		  callableStatement.registerOutParameter(48, OracleTypes.CURSOR);
		  ResultSet rs = null;
		  callableStatement = callableStatement.unwrap(CallableStatement.class);
		  callableStatement.setInt(1, obj.getProductID());
		  callableStatement.registerOutParameter(48, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  rs = ((OracleCallableStatement)callableStatement).getCursor(48);
	      while (rs.next()) {
	    	obj.setProductID(rs.getInt("PRODUCTID"));
	      } 
	      LOGGER.info("SP>spInsertOrUpdateProducts executed successfully.");
	      return obj;
	}
	
	@Override
	public Variant get(Connection connection,Integer id) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  Variant obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetProductByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new Variant();
		        
		        obj.setProductID(rs.getInt("PRODUCTID"));
		        obj.setPlanID(rs.getInt("PlanID"));
		        obj.setInsurerID(rs.getInt("InsurerID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setCode(rs.getString("Code"));
		        obj.setProductTypeID(rs.getInt("ProductTypeID"));
		        obj.setuANNo(rs.getString("UANNo"));
		        obj.setProductTypeID(rs.getInt("ProductTypeID"));
		        
		        if(null !=rs.getString("EffectiveDate")) {
		        	obj.setEffectiveDate(DateUtil.getStringFormatFromDbDate(rs.getString("EffectiveDate")));
		        }else {
		        	 obj.setEffectiveDate("");
		        } 
		        
		        if(null !=rs.getString("StartDate")) {
		        	obj.setStartDate(DateUtil.getStringFormatFromDbDate(rs.getString("StartDate")));
		        }else {
		        	 obj.setStartDate("");
		        } 
		        
		        if(null !=rs.getString("EndDate")) {
		        	obj.setEndDate(DateUtil.getStringFormatFromDbDate(rs.getString("EndDate")));
		        }else {
		        	 obj.setEndDate("");
		        } 
		        obj.setMinAge(rs.getInt("MinimumAge"));
		        obj.setMaxAge(rs.getInt("MaximumAge"));
		        obj.setMinimumAgeTypeID(rs.getInt("MinimumAgeTypeID"));
		        obj.setMaximumAgeTypeID(rs.getInt("MaximumAgeTypeID"));
		        obj.setMinTerm(rs.getInt("MinimumTerm"));
		        obj.setMaxTerm(rs.getInt("MaximumTerm"));
		        obj.setMinSumAssured(rs.getInt("MinimumSumAssured"));
		        obj.setMaxSumAssured(rs.getInt("MaximumSumAssured"));
		        obj.setFreelookup(rs.getInt("FreelookPeriod"));
		        obj.setIsEligibleforLoan(rs.getInt("IsEligibleforLoan"));
		        obj.setWaitingPeriodforLoan(rs.getInt("WaitingPeriodforLoan"));
		        obj.setNoOfBackdatedForNB(rs.getInt("NoOfBackdatedForNB"));
		        obj.setNoOfBackdatedForEndorsemant(rs.getInt("NoOfBackdatedForEndorsemant"));
		        obj.setIsUnderWritingApplicable(rs.getInt("IsUnderWritingApplicable"));
		        obj.setAutoIssuePolicyUpToFCLLimit(rs.getInt("AutoIssuePolicyUpToFCLLimit"));
		        obj.setWaitingPeriodforClaim(rs.getInt("WaitingPeriodforClaim"));
		        obj.setExclusion(rs.getString("EMdescription"));
		        obj.setVerbiage(rs.getString("SIGNATUREDESCRIPTION"));
		      }
			  LOGGER.info("SP>spGetProductByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetProductByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			 /* if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			  
				  connection.close();
			  }*/
		  }
		  return obj;
	}  
	

	@Override
	public List<Variant> getAll(Connection connection,Variant filterObj) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Variant> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllProduct(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Variant obj = null;
			  list = new ArrayList<Variant>();
		      while (rs.next()) {
		        obj = new Variant();
		        obj.setProductID(rs.getInt("ProductID"));
		        obj.setInsurerID(rs.getInt("INSURERID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setInsurerStr(rs.getString("INSURERNAME"));
		        obj.setProductTypeID(rs.getInt("ProductTypeID"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllProduct executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllProduct exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			   
		  }
		  return list;
	} 
	
	@Override
	public void delete(Connection connection,Integer productId, Integer deleteBy) throws SQLException {
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProduct(?,?,?); END;");
		  callableStatement.setInt(1, productId);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteProduct executed successfully.");
		  LOGGER.info("SP>spDeleteProduct executed successfully.");
	} 
	
	@Override
	public List<Variant> getAllVariantByLineofBusinessId(Connection connection,Integer lineofBusinessId) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Variant> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spgetallproductbylineofbusinessid(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, lineofBusinessId);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  Variant obj = null;
			  list = new ArrayList<Variant>();
		      while (rs.next()) {
		        obj = new Variant();
		        obj.setProductID(rs.getInt("ProductID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllProduct executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllProduct exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			   
		  }
		  return list;
	} 
}
package com.LIC.dao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.ContactAddressModal;
import com.LIC.model.Insurer;
import com.LIC.model.InsurerModal;
import com.LIC.model.LineOfBusinessInsurerModel;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.exception.ExceptionProcess;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
@Repository
public class InsurerDao implements IInsurerDAO {
	 @Autowired	JdbcTemplate jdbcTemplate;
		
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryDao.class);	
	private static final String		TRACE_ID = InsurerDao.class.getName();
	@Autowired private JDBCConnection jdbcConnection;
	 
	@Override
	public List<Insurer> getAll(Insurer filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Insurer> list = null;
		  try 
		  {
			  callableStatement = connection.prepareCall("BEGIN spGetAllInsurer(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Insurer obj = null;
			  list = new ArrayList<Insurer>();
		      while (rs.next()) {
		        obj = new Insurer();
		        obj.setInsurerID(rs.getInt("INSURERID"));
		        obj.setInsurerName(rs.getString("INSURERNAME"));
		        list.add(obj);
		      }
		      logger.info("SP>spGetAllInsurer executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetAllInsurer exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }  
		  }
		  return list;
	} 
	
	public long InsertorUpdateInsurer(InsurerModal insurerModal) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		long 					insurerId 			= 0;
		long 					addressId 			= 0;
		
		try {
			conn   		= ResourceManager.getConnection();
			conn.setAutoCommit(false);
			
			if(insurerModal.getInsurerID() > 0) {
				DeleteInsurerLineOfBusinessMap(insurerModal.getInsurerID(), conn);
			}
			System.out.println("insurerModal.getLineOfBusinessInsurerList() "+insurerModal.getLineOfBusinessInsurerList());
			System.out.println("insurerModal.getContactAddressModal()) "+insurerModal.getContactAddressModal());
			
			if(insurerModal.getContactAddressModal() != null) {
								
				addressId = 	InsertOrUpdateContactAddress(insurerModal.getContactAddressModal(),conn);
						insurerModal.setAddressId(addressId);
			}
			
			
			if(insurerModal.getAddressId() > 0) {
					cstm 		= conn.prepareCall("call spInsertOrUpdateInsurer(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					
					cstm.setLong(1, 		insurerModal.getInsurerID());
					cstm.setString(2, 		insurerModal.getInsurerName());
					cstm.setLong(3, 		insurerModal.getLineOfBusinessID());
					cstm.setTimestamp(4, 	insurerModal.getDateOfCommencement());
					cstm.setString(5, 		insurerModal.getGeographicalPresence());
					cstm.setLong(6, 		insurerModal.getDistributionID());
					cstm.setLong(7, 		insurerModal.getAddressId());
					cstm.setLong(8, 		insurerModal.getCreatedBy());
					cstm.setTimestamp(9, 	insurerModal.getCreatedOn());
					cstm.setLong(10, 		insurerModal.getIsActive());
					cstm.setString(11,      insurerModal.getCollectionGLCode());
					cstm.setString(12,      insurerModal.getPaymentGLCode());
					cstm.setString(13,      insurerModal.getFreshGLCode());
					cstm.setString(14,      insurerModal.getApOnlineGLCode());
					cstm.setString(15,      insurerModal.getLicPremiumPaymentGLCode());
					cstm.setString(16,      insurerModal.getRevivalGLCode());
					cstm.setString(17,      insurerModal.getMedicalGLCode());
					cstm.setString(18,      insurerModal.getClaimGLCode());
					cstm.setString(19,      insurerModal.getLogo());
					cstm.setLong(20,  	    insurerModal.getTriggerLimitforStampDuty());
					cstm.setString(21,      insurerModal.getIntimationEmailaddressforStampDuty());
					cstm.setString(22,      insurerModal.getIntimationMobileNumberforStampDuty());
					cstm.setString(23,      insurerModal.getPanNo());
					cstm.setString(24,      insurerModal.getGstNo());
					cstm.registerOutParameter(25, OracleTypes.CURSOR); //REF CURSOR
					cstm.executeUpdate();
					
					result = ((OracleCallableStatement)cstm).getCursor(25);
					 
					 if(result != null) {
						if(result.next()) {
							insurerId = result.getLong("InsurerID");
						}
					}
					 
					 insurerModal.setInsurerID(insurerId);
					 if(insurerId > 0 && insurerModal.getLineOfBusinessInsurerList() != null) {
						 InsertLineOfBusinessAndInsurerMap(insurerModal, insurerModal.getLineOfBusinessInsurerList(), conn);
					 }
					
					conn.commit();
			
			 }else { 
				 conn.rollback(); 
				 
			 }
			 
			 
		} catch(Exception e) {
			conn.rollback();
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
  			ResourceManager.freeConnection(conn);
  			conn	= null;
		}
		return insurerId;
	}
	
	public void InsertLineOfBusinessAndInsurerMap(InsurerModal insurer, List<LineOfBusinessInsurerModel> lineOfBusiinessList, Connection conn)throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			
			cstm = conn.prepareCall("call spInsertLineOfBusinessAndInsurerMap (?,?,?)"); //default need to assign procedures
			for(LineOfBusinessInsurerModel lob : lineOfBusiinessList) {
				
				cstm.setLong(1, lob.getLobID());
				cstm.setLong(2, insurer.getInsurerID());
				cstm.setLong(3, insurer.getCreatedBy());
				cstm.executeUpdate();
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			if(cstm != null)
				cstm.close();
		}
	}
	
	 public void DeleteInsurerLineOfBusinessMap(long insurerId, Connection conn)throws Exception {
         
		CallableStatement		cstm				= null;
		
		try {
			
			cstm = conn.prepareCall("call spDeleteInsurerLineOfBusinessMap (?)"); //default need to assign procedures
			cstm.setLong(1, insurerId);
			cstm.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			if(cstm != null)
				cstm.close();
		}
	}
	 
	  
	 public List<InsurerModal> GetInsurer() throws Exception {
	  		
	  		CallableStatement		cstm				= null;
	  		Connection 				conn 				= null;
	  		ResultSet 				result 				= null;
	  		InsurerModal			insurerModal			= null;
	  		List<InsurerModal>		insurerModallist		= null;
	  		
	  		try {
	  			conn   		= ResourceManager.getConnection();
	  			cstm 		= conn.prepareCall("call spGetInsurer(?) ");
	  			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
	  			cstm.execute();
	  			
	  			result = ((OracleCallableStatement)cstm).getCursor(1);
	  			
	  			if(result != null) {
	  				
	  				insurerModallist	= new ArrayList<InsurerModal>();
	  				
	  				while(result.next()) {
	  					
	  					insurerModal = new InsurerModal();
	  					insurerModal.setInsurerID(result.getLong("InsurerID"));
	  					insurerModal.setInsurerName(result.getString("InsurerName"));
	  					insurerModal.setDateOfCommencement(result.getTimestamp("DateOfCommencement"));
	  					insurerModal.setGeographicalPresence(result.getString("GeographicalPresence"));
	  					insurerModal.setDescription(result.getString("Description"));
	  			        insurerModallist.add(insurerModal);
	  				}
	  			}
	  			return insurerModallist;
	  		} catch (Exception e) {
	  			e.printStackTrace();
	  			logger.info(e.getMessage());
	  			
	  		} finally {
	  			cstm.close();
	  			cstm	= null;
	  			ResourceManager.freeConnection(conn);
	  			conn	= null;
	  		}
	  		return insurerModallist;
	  	}
	 
	 
	 
	 public InsurerModal GetInsurerByID(long Insurerid) throws Exception {
			
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		InsurerModal			insurerModal		= null;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetInsurerByID(?,?) ");
			
			cstm.setLong(1, Insurerid); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {
		    	
		    	if(result.next()) {
		    	
		    		insurerModal = new InsurerModal();
		    		insurerModal.setInsurerID(Insurerid);
		    		insurerModal.setInsurerName(result.getString("InsurerName"));
		    		insurerModal.setLineOfBusinessID(result.getLong("LineOfBusinessID"));
		    		insurerModal.setDateOfCommencement(result.getTimestamp("DateOfCommencement"));
		    		insurerModal.setGeographicalPresence(result.getString("GeographicalPresence"));
		    		insurerModal.setDistributionID(result.getLong("DistributionID"));
		    		insurerModal.setAddressId(result.getLong("AddressId"));
		    		insurerModal.setCollectionGLCode(result.getString("CollectionGLCode"));
		    	
		    		insurerModal.setPaymentGLCode(result.getString("PaymentGLCode"));
		    		insurerModal.setFreshGLCode(result.getString("FreshGLCode"));
		    		insurerModal.setApOnlineGLCode(result.getString("APOnlineGLCode"));
		    		insurerModal.setLicPremiumPaymentGLCode(result.getString("LICPremiumPaymentGLCode"));
		    		insurerModal.setRevivalGLCode(result.getString("RevivalGLCode"));
		    		insurerModal.setMedicalGLCode(result.getString("MedicalGLCode"));
		    		insurerModal.setClaimGLCode(result.getString("ClaimGLCode"));
		    		insurerModal.setLogo(result.getString("Logo"));
		    		insurerModal.setDescription(result.getString("Description"));
		    		insurerModal.setTriggerLimitforStampDuty(result.getLong("TriggerLimitforStampDuty"));
		    		insurerModal.setIntimationEmailaddressforStampDuty(result.getString("IntimationEmailaddressforStampDuty"));
		    		insurerModal.setIntimationMobileNumberforStampDuty(result.getString("IntimationMobileNumberforStampDuty"));
		    		insurerModal.setPanNo(result.getString("PANNo"));
		    		insurerModal.setGstNo(result.getString("GSTNo"));	  
			    }
		    }
		
		   return insurerModal;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return insurerModal;
	}
	 
	 public InsurerModal GetInsurerNew(long Insurerid,long LineOfBusinessID) throws Exception {	
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		InsurerModal				insurerModal			= null;		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetInsurerByID(?,?,?) ");				
			cstm.setLong(1, Insurerid); 
			cstm.setLong(2, LineOfBusinessID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();				
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {		    	
		    	if(result.next()) {		    	
		    		insurerModal = new InsurerModal();			    	
		    		insurerModal.setInsurerName(result.getString("InsurerName"));
		    		insurerModal.setLineOfBusinessID(result.getLong("LineOfBusinessID"));
		    		insurerModal.setDateOfCommencement(result.getTimestamp("DateOfCommencement"));
		    		insurerModal.setGeographicalPresence(result.getString("GeographicalPresence"));
		    		insurerModal.setDistributionID(result.getLong("DistributionID"));
		    		insurerModal.setAddressId(result.getLong("AddressId"));
		    		insurerModal.setCollectionGLCode(result.getString("CollectionGLCode"));			 	
		    		insurerModal.setPaymentGLCode(result.getString("PaymentGLCode"));
		    		insurerModal.setFreshGLCode(result.getString("FreshGLCode"));
		    		insurerModal.setApOnlineGLCode(result.getString("APOnlineGLCode"));
		    		insurerModal.setLicPremiumPaymentGLCode(result.getString("LICPremiumPaymentGLCode"));
		    		insurerModal.setRevivalGLCode(result.getString("RevivalGLCode"));
		    		insurerModal.setMedicalGLCode(result.getString("MedicalGLCode"));
		    		insurerModal.setClaimGLCode(result.getString("ClaimGLCode"));
		    		insurerModal.setLogo(result.getString("Logo"));
		    		insurerModal.setDescription(result.getString("Description"));
		    		insurerModal.setTriggerLimitforStampDuty(result.getLong("TriggerLimitforStampDuty"));
		    		insurerModal.setIntimationEmailaddressforStampDuty(result.getString("IntimationEmailaddressforStampDuty"));
		    		insurerModal.setIntimationMobileNumberforStampDuty(result.getString("IntimationMobileNumberforStampDuty"));
		    		insurerModal.setPanNo(result.getString("PANNo"));
		    		insurerModal.setGstNo(result.getString("GSTNo"));
		    	 }
		    }
		
		    return insurerModal;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return insurerModal;
	}
 
	 
	 public String IsInsurerExist(long InsurerID, String InsurerName) throws Exception {
			
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spIsInsurerExist(?,?,?)");
			cstm.setLong(1, 	InsurerID);
			cstm.setString(2, 	InsurerName);
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);
			
			if(result != null) {
				if(result.next()) {
					return result.getString("ExistStaus"); 
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;	
		}
		return null;
	}
	 
	 public String DeleteInsurer(InsurerModal insurerModal) throws Exception {
 		CallableStatement		cstm				= null;
 		Connection 				conn 				= null;
 		ResultSet 				result 				= null;
 		String					deletedStatus		= null;
 		
 		try {
 			conn   		= ResourceManager.getConnection();
 			cstm 		= conn.prepareCall("call spDeleteInsurer(?,?,?)");
 			cstm.setLong(1,insurerModal.getInsurerID());
 			cstm.setLong(2,insurerModal.getDeletedBy());
 			cstm.registerOutParameter(3, OracleTypes.CURSOR); //REF CURSOR
   			cstm.execute();
   			
 			result = ((OracleCallableStatement)cstm).getCursor(3);
 			
 			if(result != null) {
 				if(result.next()) {
 					deletedStatus = result.getString("DeletedStatus");
 				}
 			}
 			return deletedStatus;
 		} catch(Exception e) {
 			e.printStackTrace();
 			logger.info(e.getMessage());
 		} finally {
 			cstm.close();
 			cstm	= null;
 			ResourceManager.freeConnection(conn);
 			conn	= null;
 		}
 		return "Error";
 	}
	 
	 public List<LineOfBusinessInsurerModel> GetLineOfBusinssMapByUserId(long userId) throws Exception {
		 CallableStatement					cstm						= null;
		 Connection 						conn 						= null;
		 ResultSet 							result 						= null;
		 LineOfBusinessInsurerModel			lineOfBusinessInsurerModel	= null;
		 List<LineOfBusinessInsurerModel>	lineOfBusinessInsurerList	= null;
		 
		 try {
			 conn   	= ResourceManager.getConnection();
			 cstm 		= conn.prepareCall("call spGetLineOfBusinssMapByUserId(?,?)");
			 cstm.setLong(1,	userId);
			 cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			 cstm.execute();
			 
			 result = ((OracleCallableStatement)cstm).getCursor(2);
			 
			 if(result != null) {
				 lineOfBusinessInsurerList	= new ArrayList<LineOfBusinessInsurerModel>();
				
				 while(result.next()) {
					 lineOfBusinessInsurerModel = new LineOfBusinessInsurerModel();
					 lineOfBusinessInsurerModel.setLobID(result.getLong("ID"));
					 lineOfBusinessInsurerModel.setDescription(result.getString("Description"));
					 
					 lineOfBusinessInsurerList.add(lineOfBusinessInsurerModel);
				 }
			 }
		 } catch(Exception e) {
			 e.printStackTrace();
			 logger.info(e.getMessage());
		 } finally {
			 cstm.close();
			 cstm	= null;
			 ResourceManager.freeConnection(conn);
			 conn	= null;
		 }
		 return lineOfBusinessInsurerList;
	 }
	
	 public List<LineOfBusinessInsurerModel> GetAllLineOfBusiness() throws Exception {
		CallableStatement			cstm					= null;
		Connection 					conn 					= null;
		ResultSet 					result 					= null;
		LineOfBusinessInsurerModel 		LineOfBusinessInsurerModel 	= null;
		List<LineOfBusinessInsurerModel> 	lineOfBusinessList 		= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			
			cstm 		= conn.prepareCall("call spGetAllLineOfBusinessCategory(?,?)");
			 cstm.setLong(1,	0);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);  //REF CURSOR
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			 
			 if(result != null) {
				 lineOfBusinessList 	= new ArrayList<LineOfBusinessInsurerModel>();
				
				 while(result.next()) {
					LineOfBusinessInsurerModel	= new LineOfBusinessInsurerModel();
					LineOfBusinessInsurerModel.setLobID(result.getLong("ID"));
					LineOfBusinessInsurerModel.setDescription(result.getString("Description"));
					lineOfBusinessList.add(LineOfBusinessInsurerModel);
				}
			}
			
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
  			ResourceManager.freeConnection(conn);
  			conn	= null;
		}
		return lineOfBusinessList;
	}
	 
	 public List<LineOfBusinessInsurerModel> GetAllLineOfBusinessCategoryByInsurerID(long insurerID) throws Exception {
			CallableStatement					cstm					= null;
			Connection 							conn 					= null;
			ResultSet 							result 					= null;
			LineOfBusinessInsurerModel 			lineOfBusinessInsurer 	= null;
			List<LineOfBusinessInsurerModel> 	lineOfBusinessList 		= null;
			
			try {
				conn   		= ResourceManager.getConnection();
				
				cstm 		= conn.prepareCall("call SpGetLineOfBusinessByInsurerId(?,?)");
				cstm.setLong(1,	insurerID);
				cstm.registerOutParameter(2, OracleTypes.CURSOR);  //REF CURSOR
				cstm.executeUpdate();
				
				result = ((OracleCallableStatement)cstm).getCursor(2);
				 
				 if(result != null) {
					 lineOfBusinessList 	= new ArrayList<LineOfBusinessInsurerModel>();
					
					 while(result.next()) {
						lineOfBusinessInsurer	= new LineOfBusinessInsurerModel();
						//lineOfBusinessInsurer.setInsurerId(result.getLong("insurerid"));
						lineOfBusinessInsurer.setLobID(result.getLong("LOBID"));
						lineOfBusinessInsurer.setDescription(result.getString("Description"));
						lineOfBusinessList.add(lineOfBusinessInsurer);
					}
				}
				
			} catch(Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage(), e);	
			} finally {
				cstm.close();
				cstm	= null;
	  			ResourceManager.freeConnection(conn);
	  			conn	= null;
			}
			return lineOfBusinessList;
		}
	 
	/* public List<LineOfBusinessInsurerModel> GetAllLineOfBusinessCategoryByInsurerID(long insurerID) throws Exception {
			CallableStatement					cstm					= null;
			Connection 							conn 					= null;
			ResultSet 							result 					= null;
			LineOfBusinessInsurerModel 			lineOfBusinessInsurer 	= null;
			List<LineOfBusinessInsurerModel> 	lineOfBusinessList 		= null;
			
			try {
				conn   		= ResourceManager.getConnection();
				
				cstm 		= conn.prepareCall("call spGetAllLineOfBusinessCategory(?,?)");
				cstm.setLong(1,	insurerID);
				cstm.registerOutParameter(2, OracleTypes.CURSOR);  //REF CURSOR
				cstm.executeUpdate();
				
				result = ((OracleCallableStatement)cstm).getCursor(2);
				 
				 if(result != null) {
					 lineOfBusinessList 	= new ArrayList<LineOfBusinessInsurerModel>();
					
					 while(result.next()) {
						lineOfBusinessInsurer	= new LineOfBusinessInsurerModel();
						lineOfBusinessInsurer.setInsurerId(result.getLong("insurerid"));
						lineOfBusinessInsurer.setLobID(result.getLong("lineofbusinessid"));
						lineOfBusinessInsurer.setDescription(result.getString("description"));
						lineOfBusinessList.add(lineOfBusinessInsurer);
					}
				}
				
			} catch(Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage(), e);	
			} finally {
				cstm.close();
				cstm	= null;
	  			ResourceManager.freeConnection(conn);
	  			conn	= null;
			}
			return lineOfBusinessList;
		}*/
	 
	 public List<LineOfBusinessInsurerModel> getLineOfBusinessCategory() throws Exception {
		 CallableStatement					cstm					= null;
		 Connection 						conn 					= null;
		 ResultSet 							result 					= null;
		 LineOfBusinessInsurerModel 		LineOfBusinessInsurerModel 	= null;
		 List<LineOfBusinessInsurerModel> 	lineOfBusinessList 		= null;
		 
		 try {
			 conn   		= ResourceManager.getConnection();
			 
			 cstm 		= conn.prepareCall("call spGetAllLineOfBusiness(?)");
			 
			 cstm.registerOutParameter(1, OracleTypes.CURSOR);  //REF CURSOR
			 cstm.executeUpdate();
			 
			 result = ((OracleCallableStatement)cstm).getCursor(1);
			 
			 if(result != null) {
				 lineOfBusinessList 	= new ArrayList<LineOfBusinessInsurerModel>();
				 
				 while(result.next()) {
					 LineOfBusinessInsurerModel	= new LineOfBusinessInsurerModel();
					 LineOfBusinessInsurerModel.setLobID(result.getLong("ID"));
					 LineOfBusinessInsurerModel.setDescription(result.getString("description"));
					 lineOfBusinessList.add(LineOfBusinessInsurerModel);
				 }
			 }
			 System.out.println("lineOfBusinessList "+lineOfBusinessList);
			 
		 } catch(Exception e) {
			 e.printStackTrace();
			 logger.error(e.getMessage(), e);	
		 } finally {
			 cstm.close();
			 cstm	= null;
			 ResourceManager.freeConnection(conn);
			 conn	= null;
		 }
		 return lineOfBusinessList;
	 }
	 
	 public long InsertOrUpdateContactAddress(ContactAddressModal contactAddressModal, Connection conn) throws Exception {
			CallableStatement 		cstm 		= null;
			ResultSet 				result 		= null;
			long 					addressId 	= 0;
			try {

					String sp = "call spInsertOrUpdateContactAddress(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					cstm = conn.prepareCall(sp);
					
					
					cstm.setString(1, contactAddressModal.getAddress1());
					cstm.setString(2, contactAddressModal.getAddress2());
					cstm.setString(3, contactAddressModal.getAddress3());
					cstm.setString(4, contactAddressModal.getAddress4());
					cstm.setLong(5, contactAddressModal.getCountryID());
					cstm.setLong(6, contactAddressModal.getStateID());
					cstm.setLong(7, contactAddressModal.getDistrictID());
					cstm.setLong(8, contactAddressModal.getTalukID());
					cstm.setString(9, contactAddressModal.getTehsil());
					cstm.setString(10, contactAddressModal.getZipcode());
					cstm.setString(11, contactAddressModal.getPhoneNumber());
					cstm.setString(12, contactAddressModal.getMobilNumber());
					cstm.setString(13, contactAddressModal.getConferenceNumber());
					cstm.setString(14, contactAddressModal.getFaxNumber());
					cstm.setString(15, contactAddressModal.getEmail());
					cstm.setLong(16, contactAddressModal.getCreatedBy());
					cstm.setTimestamp(17, contactAddressModal.getCreatedOn());
					cstm.setShort(18, contactAddressModal.getIsActive());
					cstm.setLong(19, contactAddressModal.getAddressId());

					cstm.registerOutParameter(20, OracleTypes.CURSOR);
					

					cstm.executeUpdate();

					result = ((OracleCallableStatement) cstm).getCursor(20);

					if (result != null) {
						if (result.next()) {
							addressId = result.getLong("AddressID");
						}
					}
					return addressId;

					
				}catch (Exception e) {
					e.printStackTrace();
					logger.info(e.getMessage());
				}finally {
					cstm.close();
					cstm = null;
				}
			return addressId;
			}

	 public InsurerModal getContactAddressModalByAddressId(InsurerModal insurerModal) throws Exception {
			CallableStatement					cstm					= null;
			Connection 							conn 					= null;
			ResultSet 							result 					= null;
			
			try {
				conn   		= ResourceManager.getConnection();
				
				cstm 		= conn.prepareCall("call spGetContactAddressByAddressID(?,?)");
				cstm.setLong(1,	insurerModal.getAddressId());
				cstm.registerOutParameter(2, OracleTypes.CURSOR);  //REF CURSOR
				cstm.executeUpdate();
				
				result = ((OracleCallableStatement)cstm).getCursor(2);
				 
				 if(result != null) {
				        
					 while(result.next()) {
						 
						 insurerModal.setAddressId(result.getLong("AddressID"));
						 insurerModal.setAddress1(result.getString("Address1"));
						 insurerModal.setAddress2(result.getString("Address2"));	
						 insurerModal.setAddress3(result.getString("Address3"));
						 insurerModal.setAddress4(result.getString("Address4"));
						 insurerModal.setCountryID(result.getLong("CountryID"));
						 insurerModal.setStateID(result.getLong("StateID"));
						 insurerModal.setDistrictID(result.getLong("DistrictID"));
						 insurerModal.setTalukID(result.getLong("TalukID"));
						 insurerModal.setTehsil(result.getString("Tehsil"));
						 insurerModal.setZipcode(result.getString("ZipCode"));
						 insurerModal.setPhoneNumber(result.getString("PhoneNo"));
						 insurerModal.setMobilNumber(result.getString("MobileNo"));
						 insurerModal.setConferenceNumber(result.getString("ConferenceNo"));
						 insurerModal.setFaxNumber(result.getString("FaxNo"));
						 insurerModal.setEmail(result.getString("FaxNo"));
						 insurerModal.setIsActive(result.getShort("IsActive"));
						 
					}
				}
				 return insurerModal;
			} catch(Exception e) {
				e.printStackTrace();
				throw ExceptionProcess.execute(e, TRACE_ID);
			} finally {
				cstm.close();
				cstm	= null;
	  			ResourceManager.freeConnection(conn);
	  			conn	= null;
			}
			
		}
}

 


package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.DocumentType;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class DocumentTypeDAO implements IDocumentTypeDAO {
	
	static final Logger LOGGER = LogManager.getLogger(DocumentTypeDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(DocumentType obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  System.out.println("obj >>> "+obj);
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateDocumentType(?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getDocumentTypeId());
		  callableStatement.setString(2, obj.getDescription());
		  callableStatement.setInt(3, obj.getCreatedBy());
		  callableStatement.setString(4, obj.getRemarks());
		  callableStatement.registerOutParameter(5, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  LOGGER.info("SP>spInsertOrUpdateDocumentType executed successfully.");
	}
	
	@Override
	public void delete(Integer documentTypeID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteDocumentType(?,?,?); END;");
		  callableStatement.setInt(1, documentTypeID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteDocumentType executed successfully.");
		  LOGGER.info("SP>spDeleteDocumentType executed successfully.");
	} 
	
	@Override
	public List<DocumentType> getAll(DocumentType filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<DocumentType> list = null;
		  DocumentType documentType = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllDocumentType(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs 				= ((OracleCallableStatement)callableStatement).getCursor(1);
			  list 				= new ArrayList<DocumentType>();
		      while (rs.next()) {
		    	  documentType = new DocumentType();
		    	  documentType.setDocumentTypeId(rs.getInt("ID"));
		    	  documentType.setDescription(rs.getString("DESCRIPTION"));
		    	  System.out.println("documentType >>>>>> "+documentType);
		    	  list.add(documentType);
		      }
			  System.out.println("SP>spGetAllDocumentType executed successfully. "+list.size());
			  LOGGER.info("SP>spGetAllDocumentType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllDocumentType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public DocumentType get(Integer documentTypeID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  DocumentType obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetDocumentType(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, documentTypeID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new DocumentType();
		        obj.setDocumentTypeId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		      }
			  System.out.println("SP>spGetDocumentType executed successfully.");
			  LOGGER.info("SP>spGetDocumentType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetDocumentType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.LineOfBusiness;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class LineOfBusinessDAO implements ILineOfBusinessDAO {
	
	static final Logger LOGGER = LogManager.getLogger(LineOfBusinessDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	
	@Override
	public List<LineOfBusiness> getAll(LineOfBusiness filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<LineOfBusiness> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllLineOfBusiness(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  LineOfBusiness obj = null;
			  list = new ArrayList<LineOfBusiness>();
		      while (rs.next()) {
		        obj = new LineOfBusiness();
		        obj.setLineOfBusinessId(rs.getInt("LOBID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));

		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllLineOfBusiness executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllLineOfBusiness exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
}

package com.LIC.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.LIC.model.PolicyViewInformationModel;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


@Repository
@SuppressWarnings("unchecked")
public class PolicyDetailsDAO {
	
    @Autowired
    private EntityManager em;

	@Value("${CertificateLogoPath.location}")
	private String CertificateLogoPath;
	
	@Value("${PolicyCertificatePath.location}")
	private String PolicyCertificatePath;
	
	public String PolicyCertificatedownload(Integer applicationId) throws  IOException, DocumentException
	{	
		
        StoredProcedureQuery query = em.createStoredProcedureQuery("spGetABSLICertificateofInsuranceReport")
                .registerStoredProcedureParameter("PApplicationID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("oReport", Class.class, ParameterMode.REF_CURSOR)
                .setParameter("PApplicationID", applicationId);
   
         query.execute();
	     List<Object[]> list = (List<Object[]>) query.getResultList();
	     List<PolicyViewInformationModel> accList = list.stream()
	                .map(o -> new PolicyViewInformationModel((Number) o[0], (String) o[1], (String) o[2], (String) o[3],
	                              (String) o[4], (Number) o[5], (String) o[6], (String) o[7], (String) o[8], (String) o[9], (String) o[10], (String) o[11], (String) o[12], (String) o[13], (String) o[14], (String) o[15], (String) o[16], (String) o[17], (Number) o[18], (String) o[19], (String) o[20], (String) o[21], (String) o[22], (String) o[23], (String) o[24], (String) o[25], (String) o[26], (String) o[27], (String) o[28], (String) o[29], (String) o[30], (String) o[31], (String) o[32], (String) o[33], (Number) o[34], (Number) o[35], (Number) o[36], (Number) o[37], (Number) o[38], (Number) o[39], (Number) o[40], (Number) o[41], (Number) o[42], (String) o[43], (String) o[44], (String) o[45], (String) o[46], (String) o[47], (String) o[48], (String) o[49], (String) o[50], (String) o[51]))
	                .collect(Collectors.toList());

	    
	     
	   
	    String FileName="",CertificateFilePath="";
		if(accList!=null)
		{
			
		for (PolicyViewInformationModel PolicyInfo : accList) {
			
			CertificateFilePath=PolicyCertificatePath+PolicyInfo.getCertificateNo() +".pdf";
			File file = new File(CertificateFilePath);
		    if(file.exists()) 
				 { FileName=CertificateFilePath;} 
			else 
				 {
			    FileName=CertificateFilePath;	
				Document document = new Document(PageSize.A4);
				Font fontSize = FontFactory.getFont(FontFactory.HELVETICA, 9, Font.NORMAL);
				Font tcfont = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL);
				Font headerFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, new BaseColor(128,0, 0));
					
				PdfPTable Maintable = new PdfPTable(1);
				PdfPTable imgtbl = new PdfPTable(new float[] {350F});
				PdfPTable table = new PdfPTable(new float[] { 150F,10F,150F });
				Maintable.setWidthPercentage(100);
				imgtbl.setWidthPercentage(100);
				table.setWidthPercentage(100);
		
				
				Maintable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
				imgtbl.getDefaultCell().setBorder(PdfPCell.NO_BORDER);	
				table.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
				
				PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(FileName));
				imgtbl.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			   
				
				Image img1 = Image.getInstance(CertificateLogoPath);
				img1.scaleToFit(100f, 4f);
				imgtbl.addCell(img1);
				   
			    
			  	 table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
			  	  table.addCell("");
			  	  table.addCell("");
			  	  table.addCell(new Phrase("CertificateNo : "+PolicyInfo.getCertificateNo(),fontSize));
			  	  
			  	  Phrase NL = new Phrase();
				  NL.add(Chunk.NEWLINE);
				  
			  	  table.addCell(NL);
			  	  table.addCell("");
			  	  table.addCell("");
			 	  
			  	  Phrase pHeader = new Phrase();
				  Chunk hearDtls = new Chunk("A) CLIENT INFORMATION",headerFont);
				  //hearDtls.setUnderline(0.1f, -2f); //0.1 thick, -2 y-location
				  pHeader.add(hearDtls);
				  
			      PdfPCell Hcell1 = new PdfPCell(pHeader);
			      Hcell1.setBorder(PdfPCell.BOTTOM);
			      Hcell1.setBorderColor(new BaseColor(128,0,0));
			      
			      PdfPCell Hcell12 = new PdfPCell(new Paragraph(""));
			      Hcell12.setBorder(PdfPCell.BOTTOM);
			      Hcell12.setBorderColor(new BaseColor(128,0,0));
			      
			      PdfPCell Hcell13 = new PdfPCell(new Paragraph(""));
			      Hcell13.setBorder(PdfPCell.BOTTOM);
			      Hcell13.setBorderColor(new BaseColor(128,0,0));
		 		  
			      table.addCell(Hcell1);
			  	  table.addCell(Hcell12);
			  	  table.addCell(Hcell13);
				  	  
			  	  table.addCell(NL);
			  	  table.addCell("");
			  	  table.addCell("");
		
		          table.addCell(new Phrase("Group Policy Number", fontSize));
		          table.addCell(":");
		          table.addCell(new Phrase(PolicyInfo.getInsurerMasterAgreementNo(), fontSize));
		
		          table.addCell(new Phrase("Name of the Group Policy Holder", fontSize));
		          table.addCell(":");
		          table.addCell(new Phrase(PolicyInfo.getGroupPolicyHolderName(),fontSize));
		
		          table.addCell(new Phrase("ABSLI Member Insured Id", fontSize));
		          table.addCell(":");
                  table.addCell(new Phrase(PolicyInfo.getPartyId(), fontSize));
		
                  
		          table.addCell(new Phrase("Name of the Member Insured ", fontSize));
		          table.addCell(":");
                  table.addCell(new Phrase(PolicyInfo.getMemberInsuredName(), fontSize));
		          
		          table.addCell(new Phrase("Employee ID  ", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getEmployeeId()==null?"":PolicyInfo.getEmployeeId().toString()   , fontSize));
		          
                  table.addCell(new Phrase("Date of Birth   ", fontSize));
		          table.addCell(":");
                  table.addCell(new Phrase(PolicyInfo.getDateOfBirth(), fontSize));
		           
		          
		          table.addCell(new Phrase("Gender",fontSize));
		          table.addCell(":");
		          table.addCell(new Phrase(PolicyInfo.getGender(),fontSize));
		        
		          table.addCell(new Phrase("Nominee   ", fontSize));
		          table.addCell(":");
                  table.addCell(new Phrase(PolicyInfo.getNomineeName(), fontSize));
		          
		          table.addCell(new Phrase("Relationship with Member Insured", fontSize));
		          table.addCell(":");
                  table.addCell(new Phrase(PolicyInfo.getRelationshipWithMemberInsured(), fontSize));
		
		          table.addCell(new Phrase("Appointee", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getAppointeeName(), fontSize));
		         
		          table.addCell(NL);
			  	  table.addCell("");
			  	  table.addCell("");
		          
		          Phrase pHeader2 = new Phrase();
		          Chunk  hearDtls2 = new Chunk("B)  PREMIUM INFORMATION ",headerFont);
		          pHeader2.add(hearDtls2);
				  
				  PdfPCell Hcell2 = new PdfPCell(pHeader2);
				  Hcell2.setBorder(PdfPCell.BOTTOM);
				  Hcell2.setBorderColor(new BaseColor(128,0,0));
		          
				  table.addCell(Hcell2);
			  	  table.addCell(Hcell12);
			  	  table.addCell(Hcell13);
		          
		          table.addCell(new Phrase("Payment Term", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getPaymentTerm(), fontSize));
		
		          table.addCell(new Phrase("Payment Frequency", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getPaymentFrequency(),fontSize));
		
		          table.addCell(new Phrase("Premium Amount", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getPremiumAmount()==null?"":PolicyInfo.getPremiumAmount().toString(), fontSize));
		
		          table.addCell(new Phrase("CGST Amount" + 
		                          " ", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getSgstCgstAmount()==null?"":PolicyInfo.getSgstCgstAmount().toString(), fontSize));
		          
		          table.addCell(new Phrase("SGST Amount  ", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getSgstCgstAmount()==null?"":PolicyInfo.getSgstCgstAmount().toString(), fontSize));
		          
		          table.addCell(new Phrase("IGST Amount ", fontSize));
		          table.addCell(":");
                   table.addCell(new Phrase(PolicyInfo.getIgstAmount()==null?"":PolicyInfo.getIgstAmount().toString(), fontSize));
		        
		          
		          table.addCell(new Phrase("Total Annual Amount ", fontSize));
		          table.addCell(":");
		          table.addCell(new Phrase(PolicyInfo.getTotalAnnualAmount()==null?"":PolicyInfo.getTotalAnnualAmount().toString(),fontSize));
		
		          table.addCell(NL);
			  	  table.addCell("");
			  	  table.addCell("");
		          
		          
		          Phrase pHeader3 = new Phrase();
		          Chunk  hearDtls3 = new Chunk("C) BENEFIT INFORMATION",headerFont);
		          pHeader3.add(hearDtls3);
				  
				  PdfPCell Hcell3 = new PdfPCell(pHeader2);
			      Hcell3.setBorder(PdfPCell.BOTTOM);
			      Hcell3.setBorderColor(new BaseColor(128,0,0));
			      
			      table.addCell(Hcell3);
			  	  table.addCell(Hcell12);
			  	  table.addCell(Hcell13);
		          
			  	  table.addCell(new Phrase(" Sum Assured (Rs.)", fontSize));
				  table.addCell(":");
				  table.addCell(new Phrase(PolicyInfo.getSumAssured() + 
				                "", fontSize));
				
				 table.addCell(NL);
			  	 table.addCell("");
			  	 table.addCell("");
				
				table.addCell(new Phrase("Coverage Effective Date(CED)" + 
				                "", fontSize));
				table.addCell(":");
                table.addCell(new Phrase(PolicyInfo.getCoverageEffectiveDate(),fontSize));
				
			
				 table.addCell(NL);
			  	 table.addCell("");
			  	 table.addCell("");
				
				table.addCell(new Phrase("Coverage Expiry Date" + 
				                " ", fontSize));
				table.addCell(":");
                table.addCell(new Phrase(PolicyInfo.getCoverageExpiryDate(), fontSize));
				
				
				table.addCell(new Phrase("  ", fontSize));
				table.addCell(" ");
				table.addCell(new Phrase("(dd/mm/yyyy)" + 
				                "", fontSize));
				
				 table.addCell(NL);
			  	 table.addCell("");
			  	 table.addCell("");
				
				table.addCell(new Phrase("Renewal Due Date", fontSize));
				table.addCell(":");
                table.addCell(new Phrase(PolicyInfo.getNextRenewal(), fontSize));
				
				
				table.addCell(new Phrase(" ", fontSize));
				table.addCell(" ");
				table.addCell(new Phrase("(dd/mm/yyyy)", fontSize));
				
				 table.addCell(NL);
			  	 table.addCell("");
			  	 table.addCell("");
				
				table.addCell(new Phrase("Date of First Inception of Cover", fontSize));
				table.addCell(":");
                table.addCell(new Phrase(PolicyInfo.getDateOfFirstInceptionCover(), fontSize));
				
				table.addCell(new Phrase(" ", fontSize));
				table.addCell(" ");
				table.addCell(new Phrase("(dd/mm/yyyy)",fontSize));
				
				
				 table.addCell(NL);
			  	 table.addCell("");
			  	 table.addCell("");
			  	 
			  	 table.addCell("");
			  	 table.addCell("");
			  	 table.addCell(new Phrase("This is a computer generated certificate and does not require any signature",fontSize));
			  	 
			  	String pattern = "dd/MM/yyyy";
			  	String dateInString =new SimpleDateFormat(pattern).format(new java.util.Date());
			  	 
				table.addCell("");
				table.addCell("");
				table.addCell(new Phrase("Issued at Mumbai on   "+dateInString+" (dd/mm/yyyy)", fontSize));
				
		
				
			  	 table.addCell(new Phrase("'Important T & C of this coverage please refer overleaf'",fontSize));
			  	 table.addCell("");
			  	 table.addCell("");
			  	 		 	 
			  	 
			  	  Maintable.addCell(imgtbl);
			  	  Maintable.addCell(table);
			  	  document.open();
			      document.add(Maintable);
			      
			      document.newPage();
			      
			      PdfPTable contenttbl = new PdfPTable(2);
			      PdfPTable Cntbl1 = new PdfPTable(1);
			      PdfPTable Cntbl2 = new PdfPTable(1);
			      
			      contenttbl.setWidthPercentage(100);
			      Cntbl1.setWidthPercentage(100);
			      Cntbl2.setWidthPercentage(100);
			      
			      contenttbl.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
			      Cntbl1.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
			      Cntbl2.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
			      
			      
			      Phrase hd1 = new Phrase();
		          Chunk  hdtl1 = new Chunk("IMPORTANT TERMS & CONDITIONS",tcfont);
		          hd1.add(hdtl1);
				  
				  PdfPCell c1 = new PdfPCell(hd1);
				  c1.setBorder(PdfPCell.BOTTOM);
				  c1.setBorderColor(new BaseColor(128,0,0));
			      c1.setPaddingBottom(8);
				  Cntbl1.addCell(c1);
				  
			     // Cntbl1.addCell(new Phrase("IMPORTANT TERMS & CONDITIONS",tcfont));
			      
				  
				  
				  Phrase hd2 = new Phrase();
		          Chunk  hdtl2 = new Chunk("Definitions",tcfont);
		          hd2.add(hdtl2);
				  
				  PdfPCell c2 = new PdfPCell(hd2);
				  c2.setBorder(PdfPCell.BOTTOM);
				  c2.setBorderColor(new BaseColor(128,0,0));
				 c2.setPaddingBottom(8);
				  c2.setPaddingTop(8); 
				  Cntbl1.addCell(c2);
			     // Cntbl1.addCell(new Phrase("Definitions",tcfont));
				  
				  
				  
				  Phrase df = new Phrase();
		          Chunk  cdf = new Chunk("“ABSLI” means Birla Sun Life Insurance Company Limited and any of its successors. \"Certificate Of Insurance\" means statement evidencing the Coverage of the Member under the Policy, subject to the terms and conditions of the Policy. \"Coverage Effective Date\" means the date on which the Coverage in respect of a Member commences.",tcfont);
		          df.add(cdf);
				  
				  PdfPCell dfc = new PdfPCell(df);
				  dfc.setBorder(PdfPCell.NO_BORDER);
				  dfc.setPaddingTop(8);
				  Cntbl1.addCell(dfc);
			      
					/*
					 * Cntbl1.addCell(new Phrase(
					 * "“ABSLI” means Birla Sun Life Insurance Company Limited and any of its successors. "
					 * +
					 * "\"Certificate Of Insurance\" means statement evidencing the Coverage of the Member under "
					 * +
					 * "the Policy, subject to the terms and conditions of the Policy. \"Coverage Effective Date\" "
					 * + "means the date on which the Coverage in respect of a Member commences.",
					 * tcfont));
					 */
					Cntbl1.addCell(new Phrase("“Member” means a "
							+ "person whose cover is in effect under this Certificate of Insurance. “Policy” means"
							+ " the Group Protection Solution Policy taken by the Group Policyholder for providing "
							+ "Coverage to its Members. \"Group Policyholder\" - Policyholder name as mentioned in"
							+ " the first page of the COI is the policyholder for this Policy.", tcfont));

					Phrase hd3 = new Phrase();
			          Chunk  hdtl3 = new Chunk("Coverage Amount",tcfont);
			          hd3.add(hdtl3);
					  
					  PdfPCell c3 = new PdfPCell(hd3);
					  c3.setBorder(PdfPCell.BOTTOM);
					  c3.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl1.addCell(c3);
					
					//Cntbl1.addCell(new Phrase("Coverage Amount", tcfont));
					Cntbl1.addCell(new Phrase(
							"Sum Assured options are multiples of CTC: 1  x Annual CTC or 1.5 x Annual CTC or 2"
									+ "x Annual CTC or 2.5 x Annual CTC per employee",
							tcfont));

					  Cntbl1.addCell(NL);
					  Cntbl1.addCell(NL);
					  Phrase hd4 = new Phrase();
			          Chunk  hdtl4 = new Chunk("Benefits",tcfont);
			          hd4.add(hdtl4);
					  
					  PdfPCell c4 = new PdfPCell(hd4);
					  c4.setPaddingBottom(5);
					  c4.setBorder(PdfPCell.BOTTOM);
					  c4.setBorderColor(new BaseColor(128,0,0));
  				      Cntbl1.addCell(c4);
					  
					  
					//Cntbl1.addCell(new Phrase("Benefits", tcfont));
					Cntbl1.addCell(new Phrase("Basic Death Benefit ", tcfont));

					Cntbl1.addCell(new Phrase(
							"In an event of the death of the Member, ABSLI shall pay the Sum Assured as mentioned in"
									+ "the Certificate of Insurance to the Nominee.",
							tcfont));


					Phrase hd5 = new Phrase();
			          Chunk  hdtl5 = new Chunk("Nominations",tcfont);
			          hd5.add(hdtl5);
					  
					  PdfPCell c5 = new PdfPCell(hd5);
					  c5.setBorder(PdfPCell.BOTTOM);
					  c5.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl1.addCell(c5);
					
					Cntbl1.addCell(new Phrase(
							"Allowed as per the provisions of Section 39 of the Insurance Act, 1938 as amended from"
									+ "time to time. For more details on the nomination, please refer to our website www.adityabirlasunlifeinsurance.com ",
							tcfont));

					Phrase hd6 = new Phrase();
			          Chunk  hdtl6 = new Chunk("Exclusions (for voluntary and non employer-employee groups)",tcfont);
			          hd6.add(hdtl6);
					  
					  PdfPCell c6 = new PdfPCell(hd6);
					  c6.setBorder(PdfPCell.BOTTOM);
					  c6.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl1.addCell(c6);
					
					
					//Cntbl1.addCell(new Phrase("Exclusions (for voluntary and non employer-employee groups)", tcfont));

					Cntbl1.addCell(new Phrase("Exclusions for Death Benefit ", tcfont));

					Cntbl1.addCell(new Phrase(
							"•Suicide:We will refund 80% of the premiums paid to date (excluding service tax) in the event"
									+ "the member dies by suicide, whether medically sane or insane, within one year after the "
									+ "coverage issue date and will not pay the amount mentioned under the Death Benefit "
									+ "Provision i.e. sum assured.",
							tcfont));

					Cntbl1.addCell(new Phrase(
							"•Waiting Period: No Life insurance cover shall be available during a period of 45 days "
									+ "starting from the Date of First Inception of Coverage, except for death due to accident. This"
									+ "is only for existing employees who have formally opted out of the earlier scheme.",
							tcfont));
					
					Phrase hd7 = new Phrase();
			          Chunk  hdtl7 = new Chunk("Termination of Coverage",tcfont);
			          hd7.add(hdtl7);
					  
					  PdfPCell c7 = new PdfPCell(hd7);
					  c7.setBorder(PdfPCell.BOTTOM);
					  c7.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl1.addCell(c7);

					//Cntbl1.addCell(new Phrase("Termination of Coverage", tcfont));

					Cntbl1.addCell(new Phrase(
							"The Cover in respect of any Member under this policy will terminate on the earliest of the"
									+ "following " + "• Date Member attains cover ceasing age of 60 years"
									+ "• Date of death of the Member"
									+ "• Date of cessation of employment or retirement which ever occurs first. "
									+ "• Date this Policy is terminated "
									+ "• Group Policy renewal date , if not renewed.",
							tcfont));

					Phrase hd8 = new Phrase();
			          Chunk  hdtl8 = new Chunk("Claim Procedures",tcfont);
			          hd8.add(hdtl8);
					  
					  PdfPCell c8 = new PdfPCell(hd8);
					  c8.setBorder(PdfPCell.BOTTOM);
					  c8.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl2.addCell(c8);
					 
					
				//	Cntbl2.addCell(new Phrase("Claim Procedures", tcfont));
					Cntbl2.addCell(new Phrase("The Nominee should notify the claim with proof of claim to the "
							+ "'Claims Department' at ABSLI @ BSLI.Notificationclaims@adityabirlacapital.com, and"
							+ " the claim documents to be simultaneously sent at the registered office of the "
							+ "ABSLI within thirty days from the date on which claim arises. We will be able to "
							+ "proceed with the claim intimation request only on receipt of the following mandatory"
							+ " claim documents ", tcfont));

					Cntbl2.addCell(new Phrase(
							" * Copy of Death Certificate issued by municipal authority/ Gram Panchyat duly attested by"
									+ "the Gazette officer like (Advocate, Bank manager, Doctor, Gazette Officer, Head Master of"
									+ "high school, Head post master or Departmental sub-Post Master, Village sarpanch, Etc)."
									+ "* Death Claim Form (duly filled, signed by the Beneficiary )."
									+ "* Bank statement/ Pre-printed Cancel Cheque Copy & KYC proof of Beneficiary."
									+ "* Medical attendant Certificate.",
							tcfont));

					Cntbl2.addCell(
							new Phrase("In case of Unnatural death (Like - Suicide, Accident, Murder, etc) ", tcfont));

					Cntbl2.addCell(new Phrase(
							"* Attested Copies of FIR, Post Mortem Report, Police Inquest Report self-attested by the"
									+ "nominee. ",
							tcfont));

					Cntbl2.addCell(new Phrase("* New Paper Cutting, if any. ", tcfont));

					Cntbl2.addCell(
							new Phrase("PN: All the above documents should be self-attested by the claimant.", tcfont));

					Cntbl2.addCell(new Phrase(
							"ABSLI may request additional information or requirement to support a proof of claim along"
									+ "with proof of death/. If the information or requirements are not provided, benefits will not be"
									+ "payable till such information or requirements are received. However, ABSLI may waive any"
									+ "requirement in its sole discretion on such terms and conditions, as it deems appropriate.",
							tcfont));
					

					Phrase hd9 = new Phrase();
			          Chunk  hdtl9 = new Chunk("Grievance Redressal Procedure",tcfont);
			          hd9.add(hdtl9);
					  
					  PdfPCell c9 = new PdfPCell(hd9);
					  c9.setBorder(PdfPCell.BOTTOM);
					  c9.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl2.addCell(c9);

					//Cntbl2.addCell(new Phrase("Grievance Redressal Procedure", tcfont));

					Cntbl2.addCell(new Phrase(
							"You may register your grievance or complaint specific to this policy with our Head Customer"
									+ "Response & Resolution at Customer Care Unit, G-Corp Tech Park, 5th & 6th Floor,Kasar"
									+ "Wadavali, Ghodbunder Road,Thane - 400601, or call on our toll free no. 1-800-270-7000 or"
									+ "email us at bsli.grouphelpline@birlasunlife.com. The complaint should be made in writing duly"
									+ "signed or through email by the complainant or by his legal heirs with full details of the"
									+ "complaint and the contact information of complainant. ",
							tcfont));
					

					Phrase hd10 = new Phrase();
			          Chunk  hdtl10 = new Chunk("More Information",tcfont);
			          hd10.add(hdtl10);
					  
					  PdfPCell c10 = new PdfPCell(hd10);
					  c10.setBorder(PdfPCell.BOTTOM);
					  c10.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl2.addCell(c10);

					//Cntbl2.addCell(new Phrase("More Information", tcfont));

					Cntbl2.addCell(new Phrase(" • Premium is payable annually • Premium rates are annually reviewable"
							+ "• Goods & Service Tax and other levies, as applicable, will be extra and levied as   per the"
							+ "extant tax laws."
							+ "• As per extant tax laws, the member will be eligible for tax benefits under  Section 80C and"
							+ "Section 10(10D) of the Income Tax Act,1961. ", tcfont));
					
					Phrase hd11 = new Phrase();
			          Chunk  hdtl11 = new Chunk("Fraud and Misrepresentation",tcfont);
			          hd11.add(hdtl11);
					  
					  PdfPCell c11 = new PdfPCell(hd11);
					  c11.setBorder(PdfPCell.BOTTOM);
					  c11.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl2.addCell(c11);
					
					
					//Cntbl2.addCell(new Phrase("Fraud and Misrepresentation", tcfont));

					Cntbl2.addCell(new Phrase(
							"As per the provisions of Section 45 of the Insurance Act, 1938 and amended from time to"
									+ "time. For more details on Section 45 of the Insurance Act, 1938 please refer to our website"
									+ "www.insurance.birlasunlife.com",
							tcfont));
					
					Phrase hd12 = new Phrase();
			          Chunk  hdtl12 = new Chunk("Insurance Ombudsman",tcfont);
			          hd12.add(hdtl12);
					  
					  PdfPCell c12 = new PdfPCell(hd12);
					  c12.setBorder(PdfPCell.BOTTOM);
					  c12.setBorderColor(new BaseColor(128,0,0));
					  
					  Cntbl2.addCell(c12);
					

				//	Cntbl2.addCell(new Phrase("Insurance Ombudsman", tcfont));

					Cntbl2.addCell(new Phrase(
							"In case you are dissatisfied with the decision/resolution of the company, you may approach"
									+ "the Insurance Ombudsman located nearest to you (refer to Appendix I or our website"
									+ "www.adityabirlasunlifeinsurance.com) if your grievance pertains to: • Insurance claim that"
									+ "has been rejected or dispute of a claim on legal construction of the policy;"
									+ "• Delay in claim settlement;" + "• Dispute with regard to premium;"
									+ "As per provision 14(3) of the Ombudsman Rules 2017, the  complaint to the Ombudsman"
									+ "can be made only if:"
									+ "(a) the complainant makes a written representation to the insurer named in the complaint"
									+ "and" + "(i) either the insurer had rejected the complaint; or"
									+ "(ii) the complainant had not received any reply within a period of  one month after the insurer"
									+ "received his representation;or"
									+ "(iii) the complainant is not satisfied with the reply given to him by the insurer; "
									+ "(b) The complaint is made within one year"
									+ "(i) after the order of the insurer rejecting the representation is received; or"
									+ "(ii) after receipt of decision of the insurer which is not to the satisfaction of the complainant; "
									+ "(iii) after expiry of a period of one month from the date of sending  the written representation"
									+ "to the insurer if the insurer named fails to furnish reply to the complainant",
							tcfont));
		      
			      contenttbl.addCell(Cntbl1);
			      contenttbl.addCell(Cntbl2);
			      document.add(contenttbl);
			  	  document.close();
			  	  writer.close();
			  	  
				 }
		}
	}
  	  
  	  return FileName;
  }
}

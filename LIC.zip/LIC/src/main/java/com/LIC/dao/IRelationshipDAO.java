package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Relationship;

public interface IRelationshipDAO {
	public void saveOrUpdate(Relationship obj) throws SQLException ;
	public void delete(Integer relationshipID, Integer deleteBy) throws SQLException;
	public List<Relationship> getAll(Relationship filterObj) throws SQLException;
	public Relationship get(Integer relationshipID) throws SQLException;
}

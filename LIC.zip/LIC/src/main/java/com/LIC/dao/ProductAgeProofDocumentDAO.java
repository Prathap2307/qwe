package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductAgeProofDocument;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class ProductAgeProofDocumentDAO implements IProductAgeProofDocumentDAO {
	
	static final Logger LOGGER = LogManager.getLogger(ProductAgeProofDocumentDAO.class);

	@Override
	public void saveOrUpdate(Connection connection,ProductAgeProofDocument obj) throws SQLException {
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertProductAgeProofofDocument(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getProductId());
		  callableStatement.setString(2, obj.getDocumentTypeId());
		  callableStatement.setInt(3, obj.getAgeFrom());
		  callableStatement.setInt(4, obj.getAgeTo());
		  callableStatement.setInt(5, obj.getCreatedBy());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  LOGGER.info("SP>spInsertProductAgeProofofDocument executed successfully.");
	}
	
	@Override
	public List<ProductAgeProofDocument>  get(Connection connection,Integer id) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  ProductAgeProofDocument obj = null;
		List<ProductAgeProofDocument> list =null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetProductAgeProofofDocumentByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  list=new ArrayList<ProductAgeProofDocument>();
		      while (rs.next()) {
		        obj = new ProductAgeProofDocument();
		        obj.setId(rs.getInt("ID"));
		        obj.setProductId(rs.getInt("PRODUCTID"));
		        obj.setAgeFrom(rs.getInt("AGEFROM"));
		        obj.setAgeTo(rs.getInt("AGETO"));
		        obj.setDocumentTypeId(rs.getString("DOCUMENTTYPEIDS"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetProductDocumentByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetProductDocumentByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			/*  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			  
				  connection.close();
			  }*/
		  }
		  return list;
	}  
	@Override
	public void delete(Connection connection,Integer productID) throws SQLException {	
		CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductAgeProofofDocument(?,?); END;");
		  callableStatement.setInt(1, productID);
		  callableStatement.registerOutParameter(2, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteProductAgeProofofDocument executed successfully.");
		  LOGGER.info("SP>spDeleteProductAgeProofofDocument executed successfully.");
	}
}

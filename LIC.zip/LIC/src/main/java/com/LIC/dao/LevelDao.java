package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.LIC.model.LevelModel;
import com.LIC.resource.ResourceManager;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class LevelDao {
	@Autowired	JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryDao.class);	

	public List<LevelModel> getAllLevel() throws SQLException {
		LevelModel 		         obj 			= null;
		CallableStatement 		 cstm 			= null;
	    ResultSet 			     rs             = null;
	    Connection 			     conn 			= null;
	    List<LevelModel> 		 list 		    = null;
	  
			    try {
				  conn = ResourceManager.getConnection();
				  cstm = conn.prepareCall("BEGIN spGetAllLevels(?); END;");
				  cstm = cstm.unwrap(CallableStatement.class);
				  cstm.registerOutParameter(1, OracleTypes.CURSOR); 
				  cstm.execute();
				  
				  rs = ((OracleCallableStatement)cstm).getCursor(1);
				  
					  if(rs !=null) {
						  
						  list = new ArrayList<LevelModel>();
						  while (rs.next()) {
							  obj = new LevelModel();
							  obj.setLevelID(rs.getInt("LevelID"));
							  obj.setDescription(rs.getString("Description"));
							  list.add(obj);
						  }
					  }
				    logger.info("SP>spGetAllLevels executed successfully.");
				  } catch (Exception e) {
					  logger.error("SP>spGetAllLevels exception occured."+e.getMessage());
					  e.printStackTrace();
				  } finally {
					  
					  if(null != rs && !rs.isClosed()) {
						  rs.close();
					  }
					  if(null != cstm && !cstm.isClosed()) {
						  cstm.close();
					  }  
				  }
	     return list;
	}
}

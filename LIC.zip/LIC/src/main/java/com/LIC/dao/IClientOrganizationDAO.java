package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.LIC.model.ApplicationPremiumDetails;
import com.LIC.model.Bank;
import com.LIC.model.BankBranch;
import com.LIC.model.ClientAddressDetails;
import com.LIC.model.MasterBranch;
import com.LIC.model.MasterDedupe;
import com.LIC.model.MasterGrade;
import com.LIC.model.MasterGroupDetails;
import com.LIC.model.MasterModule;
import com.LIC.model.MasterPartyDetails;
import com.LIC.model.MasterPolicyNo;
import com.LIC.model.MasterPolicyUnitAddress;
import com.LIC.model.PartyReceiptDetails;
import com.LIC.model.PolicyAccountStatement;
import com.LIC.model.QuestionMap;
@Repository
public interface IClientOrganizationDAO {

	public void saveOrUpdate(MasterGroupDetails obj) throws SQLException;

	public ClientAddressDetails saveOrUpdateAddress(ClientAddressDetails obj) throws SQLException;

	public void deleteGroupGrade(Integer groupId) throws SQLException;

	public List<MasterBranch> getAll(MasterBranch masterBranch) throws SQLException;

	public List<MasterGroupDetails> searchBranch(MasterGroupDetails masterGroupDetails) throws Exception;

	public List<MasterGroupDetails> getAllCient(MasterGroupDetails masterGroupDetails) throws SQLException;

	public MasterGroupDetails getClientById(Integer clientId) throws SQLException;

	public MasterGrade gradeSave(MasterGrade masterGrade) throws SQLException;
	
	public void deleteAddressDetails(Integer addressId) throws SQLException;;

	public MasterPolicyUnitAddress saveOrUpdateMasterPolicyUnitAddress(MasterPolicyUnitAddress masterPolicyUnitAddress) throws SQLException;
	
	public List<MasterPolicyNo> searchAdvanceDepositReceipt(String clientName, String receiptNo ) throws SQLException; 
	
	public void saveOrUpdateMasterPolicyNo(MasterPolicyNo masterPolicyNo) throws  Exception;
	
	//public List<MasterPolicyNo> searchMasterPolicyDetails(String clientName, String ageementNo) throws SQLException;
	
	
	public ApplicationPremiumDetails saveOrUpdateApplicationPremiumDetails(ApplicationPremiumDetails applicationPremiumDetails)
			throws SQLException;
	
	public List<MasterPolicyNo> getMasterPolicyByGroupId(long groupId) throws SQLException;
	
	public List<ApplicationPremiumDetails> searchApplicationPremiumDetailsByPolicyId(long policyId) throws SQLException;
	
	public ApplicationPremiumDetails searchApplicationPremiumDetailsByAppPemiumId(long premiumId) throws SQLException;
	
	public void saveOrUpdateMasterDedupe(MasterDedupe masterDedupe) throws SQLException;
	
	public List<Bank> getAllBank() throws SQLException;
	
	public List<BankBranch> getBankBranchByBankId(long bankId) throws SQLException;
	
	public List<MasterModule> getAllMasterModule() throws SQLException;
	
	public List<MasterDedupe> getMasterDedupeByDedupeAndModuleId(String dedupe, long moduleId) throws SQLException;
	
	public String saveOrUpdateMasterPartyDetails(MasterPartyDetails partyDetails)
			throws SQLException;
	
	public String saveOrUpdatePartyReceiptDetails(PartyReceiptDetails partyReceiptDetails)
			throws SQLException;
	
public MasterPolicyUnitAddress saveOrUpdateMasterPolicyAddress(MasterPolicyUnitAddress masterPolicyUnitAddress) throws SQLException;
	
	public List<MasterPolicyNo> searchMasterPolicyNo(MasterPolicyNo masterPolicyNo) throws SQLException;
	
	public void deleteMasterPolicyAddress(Integer addressedid,Integer policyNoId) throws SQLException;
	
	public MasterPolicyNo searchMasterPolicyNoDetails(Integer masterPolicyNoId) throws SQLException;
	
	public List<MasterGroupDetails> searchMasterGroupDetailsByName(String groupName) throws SQLException;
	
	
	public List<PolicyAccountStatement> getPolicyAccountStatement(PolicyAccountStatement policyAccountStatement)  throws SQLException;
	
	public QuestionMap saveQuestionMap(QuestionMap questionMap) throws SQLException;
	
	public void deleteQuestionMap(long questionMap, long policyId) throws SQLException;
	
	public List<QuestionMap> getAllQuestionMap(long policyId) throws SQLException;
	
	public List<MasterPolicyNo> searchMasterPolicyDetails(long groupId) throws Exception;
	
	public List<MasterPolicyNo> getSearchGroupDetailsByAgreementNo(long gropId,String agreementNumber) throws Exception;
	
	public String deleteMasterPolicyNo(long policyId,long dletedBy) throws Exception;
	
	public List<MasterPolicyNo> getMasterPolicyDetailsByGroupId(long groupId,String pageType,long masterPolicyId ) throws Exception;

	
}



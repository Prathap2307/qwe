package com.LIC.dao;




import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.DashBoard;

@Repository
public class DashBoardDAO {
	
	
	@Autowired
	private EntityManager em;

	
	@SuppressWarnings("unchecked")
	public List<DashBoard> GetAllDashBoard() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllDetailsByClientLoad")
               .registerStoredProcedureParameter("oDashboard", Class.class, ParameterMode.REF_CURSOR);
                         
        
        return query.execute() ? query.getResultList() : null;
      
        
		/*
		 * query.execute(); List<Object[]> list = (List<Object[]>)query.getResultList();
		 * List<DashBoard> Dash = list.stream().map( o -> new DashBoard((Number)
		 * o[0])).collect(Collectors.toList());
		 */
        	          
        
		/* return Dash; */
       
      
       }
	
	
	
	
		
}

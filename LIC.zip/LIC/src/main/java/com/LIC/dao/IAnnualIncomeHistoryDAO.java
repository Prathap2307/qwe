package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.AnnualIncomeHistory;


public interface IAnnualIncomeHistoryDAO {
	public List<AnnualIncomeHistory> getAll(Integer id) throws SQLException ;
}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.CountryHistory;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class CountryHistoryDAO implements ICountryHistoryDAO {

	static final Logger LOGGER = LogManager.getLogger(CountryHistoryDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	 
	@Override
	public List<CountryHistory> getAll(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<CountryHistory> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllCountryHistory(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  CountryHistory obj = null;
			  list = new ArrayList<CountryHistory>();
		      while (rs.next()) {
		        obj = new CountryHistory();
		        obj.setHistoryId(rs.getInt("HISTORYID"));
		        obj.setCountryId(rs.getInt("ID"));
		        obj.setCountryCode(rs.getString("COUNTRYCODE"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		         
		        obj.setCreatedBy(rs.getInt("CREATEDBY"));
		        if(null != rs.getString("CREATEDON") && !rs.getString("CREATEDON").isEmpty()) {
		        	obj.setCreatedOnStr(rs.getString("CREATEDON"));
		        }
		        
		        obj.setModifiedBy(rs.getInt("MODIFIEDBY"));
		        if(null != rs.getString("MODIFIEDON") && !rs.getString("MODIFIEDON").isEmpty()) {
		        	obj.setModifiedOnStr(rs.getString("MODIFIEDON"));
		        }
		        
		        obj.setDeletedBy(rs.getInt("DELETEDBY"));
		        if(null != rs.getString("DELETEDON") && !rs.getString("DELETEDON").isEmpty()) {
		        	obj.setDeletedOnStr(rs.getString("DELETEDON"));
		        }
		        obj.setIsActive(rs.getInt("ISACTIVE"));
		        obj.setRemarks(rs.getString("REMARKS"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllCountryHistory executed successfully.");
			  LOGGER.info("SP>spGetAllCountryHistory executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllCountryHistory exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	}
	
}

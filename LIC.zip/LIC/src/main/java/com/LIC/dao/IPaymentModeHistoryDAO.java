package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.PaymentModeHistory;

public interface IPaymentModeHistoryDAO {
	public List<PaymentModeHistory> getAll(Integer id) throws SQLException ;

}


package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductVerbageMap;

import oracle.jdbc.OracleTypes;

	@Repository
	public class ProductVerbageMapDAO implements IProductVerbageMapDAO{
		
		static final Logger LOGGER = LogManager.getLogger(ProductVerbageMapDAO.class);
		
		 
		@Override
		public void saveOrUpdate(Connection connection,ProductVerbageMap obj) throws SQLException {
		
			  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertProductVerbage(?,?,?,?,?,?,?); END;");
			  callableStatement.setInt(1, obj.getProductID());
			  callableStatement.setInt(2, obj.getVerbageTypeID());
			  callableStatement.setInt(3, obj.getEndorsementID());
			  callableStatement.setInt(4, obj.getLineOfBusinessID());
			  callableStatement.setString(5, obj.getSignatureDescription());
			  callableStatement.setInt(6, obj.getCreatedBy());
			  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
			  //callableStatement.registerOutParameter(3, Types.VARCHAR);
			  callableStatement.executeUpdate();
			  LOGGER.info("SP>spInsertProductVerbage executed successfully.");
		
		}
		
		@Override
		public void delete(Connection connection,Integer productID) throws SQLException {	
			CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductVerbageByID(?,?); END;");
			  callableStatement.setInt(1, productID);
			  callableStatement.registerOutParameter(2, Types.VARCHAR); 
			  callableStatement.executeUpdate();
			  System.out.println("SP>spDeleteProductVerbageByID executed successfully.");
			  LOGGER.info("SP>spDeleteProductVerbageByID executed successfully.");
		} 
}


package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductCoefficientMap;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

	@Repository
	public class ProductCoefficientMapDAO implements IProductCoefficientMapDAO{
		
		static final Logger LOGGER = LogManager.getLogger(ProductCoefficientMapDAO.class);
	
		 
		@Override
		public void saveOrUpdate(Connection connection, ProductCoefficientMap obj) throws SQLException {
			  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertProductCoefficientMap(?,?,?,?); END;");
			  callableStatement.setInt(1, obj.getProductID());
			  callableStatement.setInt(2, obj.getCoefficientId());
			  callableStatement.setInt(3, obj.getCreatedBy());
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  callableStatement.executeUpdate();
			  LOGGER.info("SP>spInsertProductCoefficientMap executed successfully.");
		
		}
		
		@Override
		public List<Integer> get(Connection connection,Integer id) throws SQLException {
			  ResultSet rs = null;
			  CallableStatement callableStatement = null;
			  ProductCoefficientMap obj = null;
			  List<Integer> list = null;

			  try {
				  callableStatement = connection.prepareCall("BEGIN spGetProductCofficientByID(?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  callableStatement.setInt(1, id);
				  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
				  callableStatement.execute();
				  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
				  list=new ArrayList<Integer>();

			      while (rs.next()) {
			        obj = new ProductCoefficientMap();
			        obj.setProductID(rs.getInt("PRODUCTID"));
			        obj.setCoefficientId(rs.getInt("COEFFICIENTID"));
			        list.add(obj.getCoefficientId());

			      }
				  LOGGER.info("SP>spGetProductCofficientByID executed successfully.");
			  }catch (Exception e) {
				  LOGGER.error("SP>spGetProductCofficientByID exception occured."+e.getMessage());
				  e.printStackTrace();
			  }finally {
				
			  }
			  return list;
		}  
		
		@Override
		public void delete(Connection connection,Integer productID) throws SQLException {	
			CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductCofficientByID(?,?); END;");
			  callableStatement.setInt(1, productID);
			  callableStatement.registerOutParameter(2, Types.VARCHAR); 
			  callableStatement.executeUpdate();
			  System.out.println("SP>spDeleteProductCofficientByID executed successfully.");
			  LOGGER.info("SP>spDeleteProductCofficientByID executed successfully.");
		}
}

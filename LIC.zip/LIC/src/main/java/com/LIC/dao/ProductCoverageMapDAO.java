package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductCoverageMap;
import com.LIC.utils.DateUtil;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class ProductCoverageMapDAO implements IProductCoverageMapDAO {
	
	static final Logger LOGGER = LogManager.getLogger(ProductCoverageMapDAO.class);

	@Override
	public void saveOrUpdate(Connection connection,ProductCoverageMap obj) throws SQLException {
	
	  Date effectiveFromDate = null ,effectiveToDate=null;
	  if(null != obj.getIsStampDutyApplicable() && obj.getIsStampDutyApplicable().equals(1)) {
		effectiveFromDate = DateUtil.getDateFromInputDate(obj.getEffectFromDate());
		effectiveToDate = DateUtil.getDateFromInputDate(obj.getEffectToDate());
	  }
	  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertProductCoverage(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
	  callableStatement.setInt(1, obj.getId());
	  callableStatement.setInt(2, obj.getProductId());
	  callableStatement.setInt(3, obj.getCoverageId());
	  callableStatement.setInt(4, obj.getIsBaseCoverage());
	  callableStatement.setInt(5, obj.getIsSelectable());
	  callableStatement.setDouble(6, obj.getMaxCoverageSumAssured());
	  callableStatement.setInt(7, obj.getCreatedBy());
	  callableStatement.setInt(8, obj.getTypeofCoverID());
	  callableStatement.setInt(9, obj.getCalculationID());
	  callableStatement.setInt(10, obj.getPackageID());
	  callableStatement.setDouble(11, obj.getPackageRate());
	  callableStatement.setInt(12, obj.getIsStampDutyApplicable());
	  callableStatement.setInt(13, obj.getStampDutyType());
	  callableStatement.setDouble(14, obj.getStampDutyRate());
	  callableStatement.setDate(15,null != effectiveFromDate?new java.sql.Date(effectiveFromDate.getTime()):null);
	  callableStatement.setDate(16,null != effectiveToDate?new java.sql.Date(effectiveToDate.getTime()):null);
	  callableStatement.registerOutParameter(17, OracleTypes.CURSOR); 
	  //callableStatement.registerOutParameter(3, Types.VARCHAR);
	  
	  callableStatement.executeUpdate();
	  LOGGER.info("SP>spInsertProductCoverage executed successfully.");
	
	}
	
	@Override
	public  List<ProductCoverageMap> get(Connection connection,Integer id) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  ProductCoverageMap obj = null;
		 
		  List<ProductCoverageMap> list = null;

		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetProductCoverageByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  list = new ArrayList<ProductCoverageMap>();
		      while (rs.next()) {
		        obj = new ProductCoverageMap();
		        obj.setId(rs.getInt("ID"));
		        obj.setProductId(rs.getInt("PRODUCTID"));
		        obj.setCoverageId(rs.getInt("CoverageID"));
		        obj.setCoverageNameStr(rs.getString("COVERAGENAME"));
		        obj.setIsBaseCoverage(rs.getInt("IsBaseCoverage"));
		        obj.setIsSelectable(rs.getInt("IsSelectable"));
		        obj.setStampDutyRate(rs.getDouble("StampDutyRate"));
		        obj.setIsStampDutyApplicable(rs.getInt("ISSTAMDUTYAPPLICABLE"));
		        obj.setStampDutyType(rs.getInt("STAMPDUTYTYPE"));
		        if(null !=rs.getString("EFFECTFROMDATE")) {
		        	obj.setEffectFromDate(DateUtil.getStringFormatFromDbDate(rs.getString("EFFECTFROMDATE")));
		        }else {
		        	 obj.setEffectFromDate("");
		        }
		        if(null !=rs.getString("EFFECTTODATE")) {
		        	obj.setEffectToDate(DateUtil.getStringFormatFromDbDate(rs.getString("EFFECTTODATE")));
		        }else {
		        	 obj.setEffectToDate("");
		        }
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetProductCoverageByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetProductCoverageByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			
		  }
		  
		  return list;
	}  
	@Override
	public void delete(Connection connection,Integer productID) throws SQLException {	
		CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductCoverageByID(?,?); END;");
		  callableStatement.setInt(1, productID);
		  callableStatement.registerOutParameter(2, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteProductCoverageByID executed successfully.");
		  LOGGER.info("SP>spDeleteProductCoverageByID executed successfully.");
	}
}

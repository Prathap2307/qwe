package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.LIC.model.Variant;

public interface IVariantDAO {
	public Variant saveOrUpdate(Connection connection, Variant obj) throws SQLException, ParseException;
	public Variant get(Connection connection,Integer id) throws SQLException ;
	public List<Variant> getAll(Connection connection,Variant filterObj) throws SQLException ;
	public void delete(Connection connection,Integer productId, Integer deleteBy) throws SQLException;

	public List<Variant> getAllVariantByLineofBusinessId(Connection connection,Integer lineofBusinessId) throws SQLException;
}

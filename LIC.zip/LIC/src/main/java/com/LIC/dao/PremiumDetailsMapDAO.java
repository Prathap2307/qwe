
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.PremiumDetailsMap;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class PremiumDetailsMapDAO implements IPremiumDetailsMapDAO {
	
	static final Logger LOGGER = LogManager.getLogger(PremiumDetailsMapDAO.class);
	@Autowired
	private JDBCConnection jdbcConnection;
	
	@Override
	public void saveOrUpdate(Connection connection,PremiumDetailsMap obj) throws SQLException {

		
	  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdatePremiumDetailsMap(?,?,?,?,?,?,?,?); END;");
	  callableStatement.setInt(1, obj.getPremiumId());
	  callableStatement.setInt(2, obj.getInfluencingFactorID());
	  callableStatement.setInt(3, obj.getExpressAsID());
	  callableStatement.setInt(4, obj.getSpecificValuesID());
	  callableStatement.setDouble(5, obj.getMinimumValue());
	  callableStatement.setInt(6, obj.getMaximumValue());
	  callableStatement.setInt(7, obj.getMinimumValueMonth());
	  callableStatement.setInt(8, obj.getMaximumValueMonth());
	  
	  callableStatement.executeUpdate();
	  LOGGER.info("SP>spInsertOrUpdatePremiumDetailsMap executed successfully.");
	
	}
	
	@Override
	public PremiumDetailsMap  get(Connection connection,Integer id) throws SQLException {
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  PremiumDetailsMap obj = null;
		List<PremiumDetailsMap> list =null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetPremiumDetailsMapByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  list=new ArrayList<PremiumDetailsMap>();
		      while (rs.next()) {
		        obj = new PremiumDetailsMap();
		        obj.setPremiumDetailsId(rs.getInt("PREMIUMDETAILID"));
		        obj.setPremiumId(rs.getInt("ID"));
		        obj.setInfluencingFactorID(rs.getInt("INFLUENCINGFACTORID"));
		        obj.setSpecificValuesID(rs.getInt("SPECIFICVALUEID"));
		        obj.setMinimumValue(rs.getInt("MINIMUMINVALUE"));
		        obj.setMaximumValue(rs.getInt("MAXIMUMINVALUE"));
		        obj.setMinimumValueMonth(rs.getInt("MINIMUMINVALUEMONTH"));
		        obj.setMaximumValueMonth(rs.getInt("MAXIMUMINVALUEMONTH"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetPremiumDetailsMapByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetPremiumDetailsMapByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			/*  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			  
				  connection.close();
			  }*/
		  }
		return obj;
	}  
	
	@Override
	public void delete(Connection connection, Integer id) throws SQLException {
	  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeletePremiumDetailsMapByID(?,?); END;");
	  callableStatement.setInt(1, id);
	  callableStatement.registerOutParameter(2, Types.VARCHAR); 
	  callableStatement.executeUpdate();
	  System.out.println("SP>spDeletePremiumDetailsMapByID executed successfully.");
	  LOGGER.info("SP>spDeletePremiumDetailsMapByID executed successfully.");
	}
}
	
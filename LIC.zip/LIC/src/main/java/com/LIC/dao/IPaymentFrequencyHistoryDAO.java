package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.PaymentFrequencyHistory;

public interface IPaymentFrequencyHistoryDAO {
	public List<PaymentFrequencyHistory> getAll(Integer id) throws SQLException ;

}

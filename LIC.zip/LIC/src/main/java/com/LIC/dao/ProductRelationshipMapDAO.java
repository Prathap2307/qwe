
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductRelationshipMap;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

	@Repository
	public class ProductRelationshipMapDAO implements IProductRelationshipMapDAO{
		
		static final Logger LOGGER = LogManager.getLogger(ProductRelationshipMapDAO.class);
		
		
		@Override
		public void saveOrUpdate(Connection connection,ProductRelationshipMap obj) throws SQLException {
		
			  CallableStatement callableStatement = connection.prepareCall("BEGIN spInserProductRelationshipMap(?,?,?,?); END;");
			  callableStatement.setInt(1, obj.getProductID());
			  callableStatement.setInt(2, obj.getRelationshipId());
			  callableStatement.setInt(3, obj.getCreatedBy());
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  //callableStatement.registerOutParameter(3, Types.VARCHAR);
			  callableStatement.executeUpdate();
			  LOGGER.info("SP>spInserProductRelationshipMap executed successfully.");
		
		}
		
		@Override
		public List<Integer> get(Connection connection,Integer id) throws SQLException {
			  ResultSet rs = null;
			  CallableStatement callableStatement = null;
			  ProductRelationshipMap obj = null;
			  List<Integer> list = null;

			  try {
				  callableStatement = connection.prepareCall("BEGIN spGetProductRelationshipByID(?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  callableStatement.setInt(1, id);
				  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
				  callableStatement.execute();
				  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
				  list=new ArrayList<Integer>();
			      while (rs.next()) {
			        obj = new ProductRelationshipMap();
			        obj.setProductID(rs.getInt("PRODUCTID"));
			        obj.setRelationshipId(rs.getInt("RELATIONSHIPID"));
			        list.add(obj.getRelationshipId());

			      }
				  LOGGER.info("SP>spGetProductRelationshipByID executed successfully.");
			  }catch (Exception e) {
				  LOGGER.error("SP>spGetProductRelationshipByID exception occured."+e.getMessage());
				  e.printStackTrace();
			  }finally {
				
			  }
			  return list;
		} 
		
		@Override
		public void delete(Connection connection,Integer productID) throws SQLException {	
			CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductRelationshipByID(?,?); END;");
			  callableStatement.setInt(1, productID);
			  callableStatement.registerOutParameter(2, Types.VARCHAR); 
			  callableStatement.executeUpdate();
			  System.out.println("SP>spDeleteProductRelationshipByID executed successfully.");
			  LOGGER.info("SP>spDeleteProductRelationshipByID executed successfully.");
		}
}

package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.DesignationModel;
import com.LIC.model.GetDesignationModel;
import com.LIC.model.GetGradeModel;

@Repository
public class DesignationDAO {
	
	
	@Autowired
	private EntityManager em;
	
	   @SuppressWarnings("unchecked")
	   
	   
	
       public List<GetDesignationModel>GetAllDesignations(Number designationId,String description) {
	        StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spGetAllDesignationDepartment")
	               .registerStoredProcedureParameter("vDesignationID",Long.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("vDescription", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("oDesignation", Class.class, ParameterMode.REF_CURSOR)
	                         .setParameter("vDesignationID", designationId)
	                         .setParameter("vDescription", description);
	        
	         // return query.execute() ? query.getResultList() : null;
	      
	        
	        query.execute();
	        List<Object[]> list  =  (List<Object[]>)query.getResultList();
	        List<GetDesignationModel> accList = list.stream().map(
	        		  o -> new GetDesignationModel((Number) o[0],(String) o[1], (String) o[2], (Number) o[3], (String) o[4])).collect(Collectors.toList());
	        
	       return accList;
	       
	         
	       }
	   


	   
	   
	   
	   @SuppressWarnings("unchecked")
	   
	   
	   
		public void postDesignation(DesignationModel model){
	     	 StoredProcedureQuery query = em
	                 .createNamedStoredProcedureQuery("createOrUpdateDesig");
	                
	                query .setParameter("vDepartmentID",model.getDepartmentId());
	                query .setParameter("vDesignationID", model.getDesignationId());
	                query.setParameter("vShortName",model.getShortName());
	                query.setParameter("vDescription", model.getDescription());
	                query .setParameter("pCreatedBy",model.getCreatedBy());
	                query.setParameter("pIsActive",model.getIsActive());    
	                query.execute() ;
	            
	     	        
		}
	   
	   
	   @SuppressWarnings("unchecked")
	   
	   
		public void deleteDesignation(DesignationModel model) {

			StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteDesig");
			query.setParameter("vDesignationID",model.getDesignationId());
			
			query.setParameter("vDELETEDBY",model.getDeletedBy());
			query.setParameter("vDELETEDON",model.getDeletedOn());
			//query.getParameter("RESULT1");
	        query.execute();
		}
		
	
	

}

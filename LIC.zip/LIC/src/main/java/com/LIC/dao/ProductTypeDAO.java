package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductType;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class ProductTypeDAO implements IProductTypeDAO {
	
	static final Logger LOGGER = LogManager.getLogger(ProductTypeDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	
	@Override
	public List<ProductType> getAll(ProductType filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<ProductType> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllProductType(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  ProductType obj = null;
			  list = new ArrayList<ProductType>();
		      while (rs.next()) {
		        obj = new ProductType();
		        obj.setProductTypeId(rs.getInt("PRODUCTTYPEID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllProductType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllProductType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
}

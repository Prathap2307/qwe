package com.LIC.dao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.LIC.model.DataUploadModal;
import com.LIC.model.SearchModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class DataUploadDao {

	@Autowired JdbcTemplate jdbcTemplate;
	private static final Logger logger = Logger.getLogger(DistrictDao.class);
	// not done sp not found
	public List<DataUploadModal> GetSearchEndorsementDefectDataHeader(DataUploadModal dataUpload) throws Exception {
		
		/* StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spGetSearchEndorsementDefectDataHeader")
	               .registerStoredProcedureParameter("pFileName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("pGroupID", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("pMasterPolicyID", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("pFromDate", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("pToDate", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("pFileName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("pPageName", String.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("oCount", Integer.class, ParameterMode.OUT)
	               .setParameter("pFileName",dataUpload.getGroupID())
	               .setParameter("pFileName",dataUpload.getMasterPolicyID())
	               .setParameter("pFileName",dataUpload.getFromDate())
	               .setParameter("pFileName",dataUpload.getToDate())
	               .setParameter("pFileName",dataUpload.getFileName())
	               .setParameter("pFileName",dataUpload.getPageName());
		 
	   	 query.execute();
	   	 return (int)query.getOutputParameterValue("oCount");*/
		
	   	 
	   	 CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetSearchEndorsementDefectDataHeader(?,?) ");	
			cstm.setLong(1, dataUpload.getGroupID());
			cstm.setLong(2, dataUpload.getMasterPolicyID());
			cstm.setTimestamp(3, dataUpload.getFromDate());
			cstm.setTimestamp(4, dataUpload.getToDate());
			cstm.setString(5, dataUpload.getFileName());
			cstm.setString(6, dataUpload.getPageName());
			cstm.registerOutParameter(7, OracleTypes.CURSOR);
    		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(7);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	public List<DataUploadModal> GetLoadingDiscountQuestionByProductID(long ProductID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DataUploadModal         dataUpload          = null;
		List<DataUploadModal>   dataUploadModalList = null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetLoadingDiscountQuestionByProductID(?,?) ");
			cstm.setLong(1, ProductID);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.execute();
			result = ((OracleCallableStatement)cstm).getCursor(1);
			if(result != null)
			{
				dataUploadModalList	= new ArrayList<DataUploadModal>();
				while(result.next())
				{
					dataUpload = new DataUploadModal();
					
					dataUploadModalList.add(dataUpload);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null;
		}
		return null;	
	}
	
	
	public String IsGNBUHeaderFileExist (String FileName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DataUploadModal         dataUpload          = null;
		List<DataUploadModal>   dataUploadModalList = null;
	  try
	  {
		  
		  conn   		= ResourceManager.getConnection();
		  cstm 		= conn.prepareCall("call spIsGNBUHeaderFileExist(?) ");
		  cstm.setString(1, FileName);
		  cstm.registerOutParameter(2, OracleTypes.CURSOR);
		  cstm.execute();
		  result = ((OracleCallableStatement)cstm).getCursor(2);
		  if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		return result.getString("");
		    	}
		    		
		    }
	  }
	  catch (Exception e) {
		  e.printStackTrace();
			logger.info(e.getMessage());
	   } 
	  finally
	  {
		     cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null; 
	  }
	  return null;
	}
     
	
	public String IsGNBNMEndorsementDataUploadHeaderFileExist (String FileName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DataUploadModal         dataUpload          = null;
		List<DataUploadModal>   dataUploadModalList = null;
	  try
	  {
		  
		  conn   		= ResourceManager.getConnection();
		  cstm 		= conn.prepareCall("call spIsGNBNMEndorsementDataUploadHeaderFileExist(?) ");
		  cstm.setString(1, FileName);
		  cstm.registerOutParameter(2, OracleTypes.CURSOR);
		  cstm.execute();
		  result = ((OracleCallableStatement)cstm).getCursor(2);
		  if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		return result.getString("");
		    	}
		    		
		    }
	  }
	  catch (Exception e) {
		  e.printStackTrace();
			logger.info(e.getMessage());
	   } 
	  finally
	  {
		     cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null; 
	  }
	  return null;
	}
	
	
	public String IsGNBMemberAdditionEndorsementDataUploadHeaderFileExist(String FileName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DataUploadModal         dataUpload          = null;
		List<DataUploadModal>   dataUploadModalList = null;
	  try
	  {
		  
		  conn   		= ResourceManager.getConnection();
		  cstm 		= conn.prepareCall("call spIsGNBMemberAdditionEndorsementDataUploadHeaderFileExist(?,?) ");
		  cstm.setString(1, FileName);
		  cstm.registerOutParameter(2, OracleTypes.CURSOR);
		  cstm.execute();
		  result = ((OracleCallableStatement)cstm).getCursor(2);
		  if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		
		    		return result.getString("");
		    	}
		    		
		    }
	  }
	  catch (Exception e) {
		  e.printStackTrace();
			logger.info(e.getMessage());
	   } 
	  finally
	  {
		     cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null; 
	  }
	  return null;
	}
	
	public String IsMemberDeletionDataUploadHeaderFileExist(String FileName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DataUploadModal         dataUpload          = null;
		List<DataUploadModal>   dataUploadModalList = null;
	  try
	  {
		  conn   		= ResourceManager.getConnection();
		  cstm 		= conn.prepareCall("call spIsMemberDeletionDataUploadHeaderFileExist(?,?) ");
		  cstm.setString(1, FileName);
		  cstm.registerOutParameter(2, OracleTypes.CURSOR);
		  cstm.execute();
		  result = ((OracleCallableStatement)cstm).getCursor(2);
		  if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		
		    		return result.getString("");
		    	}
		    		
		    }
	  }
	  catch (Exception e) {
		  e.printStackTrace();
			logger.info(e.getMessage());
	   } 
	  finally
	  {
		     cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null; 
	  }
	  return null;
	}
	
	public String IsMemberSumAssuredDataUploadHeaderFileExist(String FileName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DataUploadModal         dataUpload          = null;
		List<DataUploadModal>   dataUploadModalList = null;
	  try
	  {
		  conn   		= ResourceManager.getConnection();
		  cstm 		= conn.prepareCall("call spIsMemberSumAssuredDataUploadHeaderFileExist(?,?) ");
		  cstm.setString(1, FileName);
		  cstm.registerOutParameter(2, OracleTypes.CURSOR);
		  cstm.execute();
		  result = ((OracleCallableStatement)cstm).getCursor(2);
		  if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		
		    		return result.getString("");
		    	}
		    		
		    }
	  }
	  catch (Exception e) {
		  e.printStackTrace();
			logger.info(e.getMessage());
	   } 
	  finally
	  {
		     cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null; 
	  }
	  return null;
	}
	
	public List<DataUploadModal> InsertDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal>   dataUploadModalList = null;
		try
		{
			 conn   	= ResourceManager.getConnection();
			 conn.setAutoCommit(false);
			if(dataUpload != null)
			{
				String sp_Name = "";
				if (dataUpload.getPageName() != "")
                {
                    sp_Name = "spDataUpload_" + dataUpload.getPageName();
                }
                try
                {
           		  cstm 	= conn.prepareCall("call sp_Name(?,?,?,?,?,?) ");
           		  cstm.setString(1, dataUpload.getFileName());
           		  cstm.setLong(2, dataUpload.getLineOfBusinessID());
           		  cstm.setLong(3, dataUpload.getTypeID());
           		  cstm.setLong(4, dataUpload.getCreatedBy());
           		  cstm.setTimestamp(5, dataUpload.getCreatedOn());
           		 cstm.registerOutParameter(6, OracleTypes.CURSOR);
           		  cstm.executeUpdate();
  			     result = ((OracleCallableStatement)cstm).getCursor(6);
  			   if(!result.isBeforeFirst())
  			    {
  			    	while(result.next()) {
  			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
  			    	}
  			    		
  			    }
                }
                catch(Exception e)
                {
                	e.printStackTrace();
        			logger.info(e.getMessage());
                }
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null;
		}
		return null;	
	}
	
	public List<DataUploadModal> GroupLifeQuotationUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal>   dataUploadModalList = null;
		try
		{
			 conn   	= ResourceManager.getConnection();
			 conn.setAutoCommit(false);
			if(dataUpload != null && dataUpload.getFileName() != null )
			{
                try
                {
           		  cstm 	= conn.prepareCall("call spGroupLifeQuotationUpload(?,?,?,?,?,?,?,?) ");
           		  cstm.setString(1, dataUpload.getFileName());
           		  cstm.setLong(2, dataUpload.getCreatedBy());
           		  cstm.setTimestamp(3, dataUpload.getCreatedOn());
           		  cstm.setLong(4, dataUpload.getTypeID());
           		  cstm.setLong(5, dataUpload.getLineOfBusinessID());
           		  cstm.setLong(6, dataUpload.getGroupID());
           		  cstm.setLong(7, dataUpload.getProductID());
           		 cstm.registerOutParameter(8, OracleTypes.CURSOR);
           		  cstm.executeUpdate();
  			     result = ((OracleCallableStatement)cstm).getCursor(8);
  			   if(!result.isBeforeFirst())
  			    {
  			    	while(result.next()) {
  			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
  			    	}
  			    		
  			    }
                }
                catch(Exception e)
                {
                	e.printStackTrace();
        			logger.info(e.getMessage());
                }
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null;
		}
		return null;	
	}
	

	public List<DataUploadModal> MigrationPremiumDetailDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal>   dataUploadModalList = null;
		try
		{
			 conn   	= ResourceManager.getConnection();
			 conn.setAutoCommit(false);
			if(dataUpload != null && dataUpload.getFileName() != null )
			{
                try
                {
           		  cstm 	= conn.prepareCall("call spMigrationPremiumDetailDataUpload(?,?,?,?,?,?,?,?) ");
           		  cstm.setString(1, dataUpload.getFileName());
           		  cstm.setLong(2, dataUpload.getCreatedBy());
           		  cstm.setTimestamp(3, dataUpload.getCreatedOn());
           		  cstm.setLong(4, dataUpload.getGroupID());
           		  cstm.setLong(5, dataUpload.getQuotationID());
           		  cstm.setLong(6, dataUpload.getMasterPolicyID());
           		  cstm.setLong(7, dataUpload.getProductID());
           		 cstm.registerOutParameter(8, OracleTypes.CURSOR);
           		  cstm.executeUpdate();
  			     result = ((OracleCallableStatement)cstm).getCursor(8);
  			   if(!result.isBeforeFirst())
  			    {
  			    	while(result.next()) {
  			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
  			    	}
  			    		
  			    }
                }
                catch(Exception e)
                {
                	e.printStackTrace();
        			logger.info(e.getMessage());
                }
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null;
		}
		return null;	
	}
	
	
	public List<DataUploadModal> MigrationMasterPremiumDetailDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal>   dataUploadModalList = null;
		try
		{
			 conn   	= ResourceManager.getConnection();
			 conn.setAutoCommit(false);
			if(dataUpload != null && dataUpload.getFileName() != null )
			{
                try
                {
           		  cstm 	= conn.prepareCall("call spMigrationMasterPremiumDetailDataUpload(?,?,?,?,?,?,?,?) ");
           		  cstm.setString(1, dataUpload.getFileName());
           		  cstm.setLong(2, dataUpload.getCreatedBy());
           		  cstm.setTimestamp(3, dataUpload.getCreatedOn());
           		  cstm.setLong(4, dataUpload.getProductID());
           		 cstm.registerOutParameter(5, OracleTypes.CURSOR);
           		  cstm.executeUpdate();
  			     result = ((OracleCallableStatement)cstm).getCursor(5);
  			   if(!result.isBeforeFirst())
  			    {
  			    	while(result.next()) {
  			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
  			    	}
  			    		
  			    }
                }
                catch(Exception e)
                {
                	e.printStackTrace();
        			logger.info(e.getMessage());
                }
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null;
		}
		return null;	
	}
	
	public List<DataUploadModal> GetGNBDataUploadHeader(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal>   dataUploadModalList = null;
		try
		{
			 conn   	= ResourceManager.getConnection();
			 conn.setAutoCommit(false);
			if(dataUpload != null && dataUpload.getFileName() != null )
			{
                try
                {
           		  cstm 	= conn.prepareCall("call spGetGNBDataUploadHeader(?,?,?,?,?,?,?) ");
           		  cstm.setLong(1, dataUpload.getProductID());
           		   cstm.setLong(2, dataUpload.getMasterPolicyID());
           		   cstm.setTimestamp(3, dataUpload.getFromDate());
           		   cstm.setTimestamp(4, dataUpload.getToDate());
           		   cstm.setString(6, dataUpload.getFileName());
           		   
           		  cstm.registerOutParameter(7, OracleTypes.CURSOR);
           		  cstm.executeUpdate();
  			     result = ((OracleCallableStatement)cstm).getCursor(7);
  			   if(!result.isBeforeFirst())
  			    {
  			    	while(result.next()) {
  			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
  			    	}
  			    		
  			    }
                }
                catch(Exception e)
                {
                	e.printStackTrace();
        			logger.info(e.getMessage());
                }
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null;
		}
		return null;	
	}
	
	public List<DataUploadModal> GroupQuotationDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal>   dataUploadModalList = null;
		try
		{
			 conn   	= ResourceManager.getConnection();
			 conn.setAutoCommit(false);
			if(dataUpload != null && dataUpload.getFileName() != null )
			{
                try
                {
           		  cstm 	= conn.prepareCall("call spGroupQuotationMigration(?,?,?,?,?,?,?) ");
           		  cstm.setString(1, dataUpload.getFileName());
           		  cstm.setLong(2, dataUpload.getCreatedBy());
           		  cstm.setTimestamp(3, dataUpload.getCreatedOn());
           		  cstm.setLong(4, dataUpload.getGroupID());
           		  cstm.setLong(5, dataUpload.getProductID());
           		  cstm.registerOutParameter(6, OracleTypes.CURSOR);
           		  cstm.executeUpdate();
  			     result = ((OracleCallableStatement)cstm).getCursor(6);
  			   if(!result.isBeforeFirst())
  			    {
  			    	while(result.next()) {
  			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
  			    	}
  			    		
  			    }
                }
                catch(Exception e)
                {
                	e.printStackTrace();
        			logger.info(e.getMessage());
                }
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null;
		}
		return null;	
	}
	
	public String IsDataUploadFileAlreadyExist(DataUploadModal dataModal) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DataUploadModal         dataUpload          = null;
		List<DataUploadModal>   dataUploadModalList = null;
	  try
	  {
		  conn   		= ResourceManager.getConnection();
		  String sp_Name = "";
		  if(dataModal != null)
		  {
			  sp_Name = "spIsDataUploadFileName_" +dataUpload.getPageName()+ "AlreadyExist";
		  }
		  cstm 		= conn.prepareCall("call spIsMemberSumAssuredDataUploadHeaderFileExist(?,?) ");
		  cstm.setString(1, dataUpload.getFileName());
		  cstm.setLong(2, dataUpload.getLineOfBusinessID());
		  cstm.registerOutParameter(2, OracleTypes.CURSOR);
		  cstm.execute();
		  result = ((OracleCallableStatement)cstm).getCursor(2);
		  if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		
		    		return result.getString("");
		    	}
		    		
		    }
	  }
	  catch (Exception e) {
		  e.printStackTrace();
			logger.info(e.getMessage());
	   } 
	  finally
	  {
		     cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			dataUploadModalList	= null; 
	  }
	  return null;
	}
	

	public List<DataUploadModal> GetQuotationDataUploadStatusByFileName(String FileName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			String sp_Name = "";
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetQuotationDataUploadStatusByFileName(?,?) ");
			cstm.setString(1, FileName);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.execute();
			 result = ((OracleCallableStatement)cstm).getCursor(2);
			  if(!result.isBeforeFirst())
			    {
			    	while(result.next()) {
                        dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
			    	}
			    		
			    }
		}
		catch (Exception e) {
			 e.printStackTrace();
				logger.info(e.getMessage());
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null; 
		}
		return null;
	}
	
	public List<DataUploadModal> GetQuotationDataUploadStatusByFileName(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetQuotationDataUploadStatusByFileName(?,?,?,?) ");	
			cstm.setString(1, dataUpload.getFileName());
			cstm.setLong(2, dataUpload.getGroupID());
			cstm.setLong(3, dataUpload.getProductID());
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
     		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(4);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	public List<DataUploadModal> GetPremiumDetailDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetPremiumDetailDataUpload(?,?,?,?) ");	
			cstm.setString(1, dataUpload.getFileName());
			cstm.setLong(2, dataUpload.getStatusID());
			cstm.setLong(3, dataUpload.getHeaderID());
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
     		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(4);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	public List<DataUploadModal> GetMasterPremiumDetailDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetMasterPremiumDetailDataUpload(?,?,?,?) ");	
			cstm.setString(1, dataUpload.getFileName());
			cstm.setLong(2, dataUpload.getStatusID());
			cstm.setLong(3, dataUpload.getHeaderID());
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
     		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(4);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	public List<DataUploadModal> GetGNBDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetGNBDataUpload(?,?,?,?) ");	
			cstm.setString(1, dataUpload.getFileName());
			cstm.setLong(2, dataUpload.getHeaderID());
			cstm.setString(3, dataUpload.getStatus());
			cstm.setShort(4, dataUpload.getIsPolicyIssuance());
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
     		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(4);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	public List<DataUploadModal> GetGNBEndorsementDataUpload(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetGNBEndorsementDataUpload(?,?,?,?) ");	
			cstm.setString(1, dataUpload.getFileName());
			cstm.setLong(2, dataUpload.getHeaderID());
			cstm.setString(3, dataUpload.getStatus());
			cstm.setString(5, dataUpload.getPageName());
			cstm.registerOutParameter(5, OracleTypes.CURSOR);
     		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(4);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	public List<DataUploadModal> GetGNBEndorsementDataUploadDelete(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetGNBEndorsementDataUploadDeletion(?,?,?,?) ");	
			cstm.setString(1, dataUpload.getFileName());
			cstm.setLong(2, dataUpload.getHeaderID());
			cstm.setString(3, dataUpload.getStatus());
			cstm.setString(4, dataUpload.getPageName());
			cstm.registerOutParameter(5, OracleTypes.CURSOR);
     		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(5);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	
	public String IsDataUploadFileNameAlreadyExist(String FileName, String UploadType) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		String result = "true";
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			
			String spName = "";
			conn = ResourceManager.getConnection();
			if (UploadType.toLowerCase() == "ind")
            {
                spName = "spIsLifeInsurnaceDataUploadFileNameAlreadyExist(?)";
            }
			 else if (UploadType.toLowerCase() == "qut")
             {
                 spName = "spGroupQuotationAlreadyExists(?)";
             }
             else if (UploadType.toLowerCase() == "gia")
             {
                 spName = "spIsExistsGroupLifeInsuranceDataUploadHeader(?)";
             }
             else if (UploadType.toLowerCase() == "premium")
             {
                 spName = "spIsExistsPremiumDetailDataUploadHeader(?)";
             }
             else if (UploadType.toLowerCase() == "masterpremium")
             {
                 spName = "spIsExistsMasterPremiumDetailDataUploadHeader(?)";
             }
             else
             {
                 spName = "spIs" + UploadType + "DataUploadFileNameAlreadyExist(?)";
             }
			
			cstm = conn.prepareCall(spName);
			cstm.setString(1, FileName);
		     int count = cstm.executeUpdate();
		     if(count == 0)
		     {
		    	 result = "true";
		     }
		     return result;
		}
		catch(Exception e)
		{
			 e.printStackTrace();
				logger.info(e.getMessage());		
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return result;
	}
	
	public List<SearchModal> GetDataUploadStatus (SearchModal searchModal) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<SearchModal> searchModalList   = null; 
		try
		{
			String sp_Name = "";
			 if (searchModal.getPageName() != "")
             {
                 sp_Name = "spGetDataUpload_" + searchModal.getPageName() + "_Status(?,?)";
                 conn = ResourceManager.getConnection();
     			cstm = conn.prepareCall(sp_Name);	
     			cstm.setTimestamp(1, searchModal.getFromDate());
     			cstm.setTimestamp(2, searchModal.getToDate());
     			cstm.registerOutParameter(3, OracleTypes.CURSOR);
       		     cstm.executeUpdate();
  		         result = ((OracleCallableStatement)cstm).getCursor(3);
  		          if(!result.isBeforeFirst())
  		        {
  		         	while(result.next()) {
  		    		searchModalList = new ArrayList<SearchModal>();
  		    		
  		    		return searchModalList;
  		    	}
  		    		
  		    }
             }
		}
		catch (Exception e) {
        e.printStackTrace();
		logger.info(e.getMessage());		
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				searchModalList	= null;	
		}
		return null;
	}
	
	
	public List<DataUploadModal> GetDataUploadStatusByFileName(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			String sp_Name = "";

            if (dataUpload.getPageName() != "")
            {
                sp_Name = "spGetDataUpload_" + dataUpload.getPageName() + "_StatusByFileName(?,?,?)";
            }

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall(sp_Name);	
			cstm.setLong(1, dataUpload.getStatusID());
			cstm.setString(2, dataUpload.getFileName());
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
     		  cstm.executeUpdate();
		     result = ((OracleCallableStatement)cstm).getCursor(3);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	public List<DataUploadModal> GetUploadHeaderFormat(long HeaderID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("spGetUploadHeaderFormat(?,?)");	
			cstm.setLong(1, HeaderID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
     		cstm.executeUpdate();
		    result = ((OracleCallableStatement)cstm).getCursor(2);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		dataUploadModalList = new ArrayList<DataUploadModal>();
		    		
		    		return dataUploadModalList;
		    	}
		    		
		    }
		}
		catch(Exception e)
		{
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
				dataUploadModalList	= null;	
		}
		return null;
	}
	
	
	public String IsSourceDocumentUploadFileName_AlreadyExist(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		String result ="false";
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("spIsSourceDocumentUploadFileName_AlreadyExist(?,?,?)");
			cstm.setLong(1, dataUpload.getGroupID());
			cstm.setLong(2, dataUpload.getProcessID());
			cstm.setString(3, dataUpload.getFileName());
			int count =  cstm.executeUpdate();
			if(count == 0)
			{
				result = "true";
			}
		}
		catch(Exception e)
		{
			   e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			   cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
		}
		return result;
	}
	
	
	public String IsDestinationDocumentUploadFileName_AlreadyExist(DataUploadModal dataUpload) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		String result ="false";
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("spIsDestinationDocumentUploadFileName_AlreadyExist(?,?)");
			cstm.setLong(1, dataUpload.getGroupID());
			cstm.setString(2, dataUpload.getFileName());
			int count =  cstm.executeUpdate();
			if(count == 0)
			{
				result = "true";
			}
		}
		catch(Exception e)
		{
			   e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			   cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
		}
		return result;
	}
	
	public long InsertSourceDocument(String XML, long GroupID, String FileName, String FilePath, long CreatedBy, long ProcessID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("spIsDestinationDocumentUploadFileName_AlreadyExist(?,?,?,?,?,?)");
			cstm.setString(1, XML);
			cstm.setLong(2, GroupID);
			cstm.setString(3, FileName);
			cstm.setString(4, FilePath);
			cstm.setLong(5, CreatedBy);
			cstm.setLong(6, ProcessID);
	        long flag = cstm.executeUpdate();
	        return flag;
		}
		catch (Exception e) {
			  e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
		}
		return 0;
	}

	public long InsertDestinationDocument(String XML, long GroupID, String FileName, String FilePath, long CreatedBy, long ProcessID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("spInsertDestinationDocument(?,?,?,?,?,?)");
			cstm.setString(1, XML);
			cstm.setLong(2, GroupID);
			cstm.setString(3, FileName);
			cstm.setString(4, FilePath);
			cstm.setLong(5, CreatedBy);
			cstm.setLong(6, ProcessID);
	        long flag = cstm.executeUpdate();
	        return flag;
		}
		catch (Exception e) {
			  e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
		}
		return 0;
	}
	public long IsDocumentMappingAlreadyExist(long GroupId, long ProcessID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet               result              = null;
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("SpIsDocumentMapping_AlreadyExist(?,?)");
			cstm.setLong(1, GroupId);
			cstm.setLong(2, ProcessID);
			 cstm.registerOutParameter(5, OracleTypes.CURSOR);
   		     cstm.execute();
		     result = ((OracleCallableStatement)cstm).getCursor(4);
		   if(!result.isBeforeFirst())
		    {
		    	while(result.next()) {
		    		
		    		return result.getLong("");
		    	}
		    		
		    }
	       
		}
		catch (Exception e) {
			  e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;
		}
		return 0;
	}
	
	public long InsertDocumnetMapping(long GroupId, long DestinationFieldId, long SourceFieldId, long IsdefaultId, long isdefaultValue, long CreatedBy, Timestamp CreatedOn, short IsActive, long ProcessID) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet               result              = null;
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("SpsInsertDocumentMappingFields(?,?,?,?,?,?,?,?,?,?)");
			cstm.setLong(1, GroupId);
			cstm.setLong(2, DestinationFieldId);
			cstm.setLong(3, SourceFieldId);
			cstm.setLong(4, IsdefaultId);
			cstm.setLong(5, isdefaultValue);
			cstm.setLong(6, CreatedBy);
			cstm.setTimestamp(7, CreatedOn);
			cstm.setShort(8, IsActive);
			cstm.setLong(9, ProcessID);
			 cstm.registerOutParameter(10, OracleTypes.CURSOR);
			cstm.execute();
			 result = ((OracleCallableStatement)cstm).getCursor(10);
			   if(!result.isBeforeFirst())
			    {
			    	while(result.next()) {
			    		
			    		return result.getLong("");
			    	}
			    		
			    }
		}
		catch (Exception e) {
			     e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			  cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;	
		}
		return 0;
	}
  
	
	public String NBFilenameExist(long GroupId, long ProcessID, String FileName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		
		String result  ="false";
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("NBFilenameExist(?,?,?)");	
			cstm.setLong(1, GroupId);
			cstm.setLong(2, ProcessID);
			cstm.setString(3, FileName);
			long count = cstm.executeUpdate();
			if (count == 0)
			{
				result = "true";
			}
		   return result;
		}
		catch (Exception e) {
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
	    finally
	    {
	    	    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;		
	    }
		return result;
	}

	
	public List<DataUploadModal> GetSourceHeader(long ProcessID, long GroupID, String Type) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("spGetUploadHeaderFormat(?,?)");	
			cstm.setLong(1, ProcessID);
			cstm.setLong(2, GroupID);
			cstm.setString(3, Type);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.execute();
			 result = ((OracleCallableStatement)cstm).getCursor(4);
			   if(!result.isBeforeFirst())
			    {
				   dataUploadModalList = new ArrayList<DataUploadModal>();
			    	while(result.next()) {
			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
			    	}
			    		
			    }
		}
		catch (Exception e) {
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;		
		}
		return null;
	}
	
	public List<DataUploadModal> NBDataUpload(DataUploadModal dataModal) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			conn.setAutoCommit(false);
			cstm = conn.prepareCall("call spNBDataUpload(?,?,?,?,?,?,?)");	
			cstm.setString(1,dataModal.getFileName());
			cstm.setLong(2, dataModal.getGroupID());
			cstm.setLong(3, dataModal.getProcessID());
			cstm.setLong(4, dataModal.getMasterPolicyID());
			cstm.setLong(5, dataModal.getCreatedBy());
			cstm.setTimestamp(6, dataModal.getCreatedOn());
			cstm.registerOutParameter(7, OracleTypes.CURSOR);
			cstm.execute();
			conn.commit();
			 result = ((OracleCallableStatement)cstm).getCursor(7);
			   if(!result.isBeforeFirst())
			    {
				   dataUploadModalList = new ArrayList<DataUploadModal>();
			    	while(result.next()) {
			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
			    	}
			    		
			    }
		}
		catch (Exception e) {
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;		
		}
		return null;
	}
	
	public List<DataUploadModal> GetNBDataUploadStatusByFileName(DataUploadModal dataModal) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<DataUploadModal> dataUploadModalList   = null; 
		try
		{
			conn = ResourceManager.getConnection();
			conn.setAutoCommit(false);
			cstm = conn.prepareCall("call GetNBDataUploadStatus(?,?)");	
			cstm.setString(1,dataModal.getFileName());
			cstm.setLong(2, dataModal.getGroupID());
			cstm.setLong(3, dataModal.getProcessID());
			cstm.setLong(4, dataModal.getMasterPolicyID());
			cstm.setLong(5, dataModal.getCreatedBy());
			cstm.setTimestamp(6, dataModal.getCreatedOn());
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.execute();
			conn.commit();
			 result = ((OracleCallableStatement)cstm).getCursor(4);
			   if(!result.isBeforeFirst())
			    {
				   dataUploadModalList = new ArrayList<DataUploadModal>();
			    	while(result.next()) {
			    		dataUploadModalList = new ArrayList<DataUploadModal>();
  			    		
  			    		return dataUploadModalList;
			    	}
			    		
			    }
		}
		catch (Exception e) {
			    e.printStackTrace();
				logger.info(e.getMessage());	
		}
		finally
		{
			    cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;		
		}
		return null;
	}
	
	   public long InsertDocumentMapping(String XML, long GroupID, long ProcessID) throws Exception
	   {
		    CallableStatement		cstm				= null;
			Connection 				conn 				= null;
		   try
		   {
			    conn.setAutoCommit(false);
				cstm = conn.prepareCall("call GetNBDataUploadStatus(?,?,?,?)");
				cstm.setString(1, XML);
				cstm.setLong(2, GroupID);
				cstm.setLong(3, ProcessID);
				cstm.registerOutParameter(4, OracleTypes.CURSOR);
				cstm.execute();
		   }
		   catch (Exception e)
		   {
			   e.printStackTrace();
				logger.info(e.getMessage());	
		   }
		   finally
		   {
			   cstm.close();
				cstm			= null;
				ResourceManager.freeConnection(conn);
				conn			= null;	   
		   }
		  return 0;
	   }
	 
}

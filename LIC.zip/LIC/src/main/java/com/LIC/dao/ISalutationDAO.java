package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Salutation;

public interface ISalutationDAO {
	public void saveOrUpdate(Salutation obj) throws SQLException ;
	public void delete(Integer id) throws SQLException;
	public List<Salutation> getAll(Salutation filterObj) throws SQLException;
	public Salutation get(Integer id) throws SQLException;
}

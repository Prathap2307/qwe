package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.AccountType;

public interface IAccountTypeDAO {
	public void saveOrUpdate(AccountType obj) throws SQLException ;
	public void delete(Integer accountTypeID, Integer deleteBy) throws SQLException;
	public List<AccountType> getAll(AccountType filterObj) throws SQLException;
	public AccountType get(Integer accountTypeID) throws SQLException;
}

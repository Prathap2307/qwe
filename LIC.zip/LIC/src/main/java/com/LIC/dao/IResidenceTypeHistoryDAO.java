package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.ResidenceTypeHistory;

public interface IResidenceTypeHistoryDAO {
	
	public List<ResidenceTypeHistory> getAll(Integer accountTypeID) throws SQLException;
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.BenefitTypeHistory;

public interface IBenefitTypeHistoryDAO {

	public List<BenefitTypeHistory> getAll(Integer id) throws SQLException;


}

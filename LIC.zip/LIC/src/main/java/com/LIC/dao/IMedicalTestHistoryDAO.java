package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.MedicalTestHistory;

public interface IMedicalTestHistoryDAO {
	
	public List<MedicalTestHistory> getAll(Integer id) throws SQLException;
}

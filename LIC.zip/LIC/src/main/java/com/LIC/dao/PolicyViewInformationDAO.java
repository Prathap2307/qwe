package com.LIC.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.PolicyViewInformationModel;

@Repository
public class PolicyViewInformationDAO {
	@Autowired
	private EntityManager em;
	
	
	
	
@SuppressWarnings("unchecked")
	
	
	public List<PolicyViewInformationModel>GetAllGroupDetailsSearch(PolicyViewInformationModel model) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetMasterPolicyAgreementDetailsbyID")
               .registerStoredProcedureParameter("vLineOfBusiness",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vGroupID",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vMasterPolicyID",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vAgreementID",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vLineOfBusiness",model.getLobId())
        .setParameter("vGroupID",model.getGroupId())
        .setParameter("vMasterPolicyID",model.getMasterpolicyId())
        .setParameter("vAgreementID",model.getAgreementId());
         //return query.execute() ? query.getResultList() : null;
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<PolicyViewInformationModel> accList = list.stream().map(
        		  o -> new PolicyViewInformationModel((Number) o[0],(String) o[1],(String) o[2],(String) o[3],
        				  (Date) o[4],(String) o[5],(Number) o[6],(Number) o[7],(String) o[8])).collect(Collectors.toList());
        
       return accList;
       
	}






public List<PolicyViewInformationSearchModel>GetAllMemberDetailsSearch(PolicyViewInformationModel model) {
    StoredProcedureQuery query = em
           .createStoredProcedureQuery("spGetAllPolicyDetailsByMember")
           .registerStoredProcedureParameter("p_LineOfBusiness",Integer.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_ClientID",Integer.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_MasterPolicyID",Integer.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_AgreementID",Integer.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_FromDate",Date.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_Todate",Date.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_PloicyHolderName",String.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_EmployeeID",String.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_CertificateNumber",String.class, ParameterMode.IN)
           .registerStoredProcedureParameter("p_ContactID",String.class, ParameterMode.IN)
           .registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR)
                     .setParameter("p_LineOfBusiness",model.getLobId())
    .setParameter("p_ClientID",model.getClientId())
    .setParameter("p_MasterPolicyID",model.getMasterpolicyId())
    .setParameter("p_AgreementID",model.getAgreementId())
    .setParameter("p_FromDate",model.getFromDate())
.setParameter("p_Todate",model.getToDate())
.setParameter("p_PloicyHolderName",model.getPolicyHolderName())
.setParameter("p_EmployeeID",model.getEmployeeId())
    .setParameter("p_CertificateNumber",model.getCertificateNumber())
    .setParameter("p_ContactID",model.getContactId());
     //return query.execute() ? query.getResultList() : null;
    
    query.execute();
    List<Object[]> list  =  (List<Object[]>)query.getResultList();
    List<PolicyViewInformationSearchModel> accList = list.stream().map(
    		  o -> new PolicyViewInformationSearchModel((Number) o[0],(Number) o[1],(String) o[2],(String) o[3],(String) o[4],(String) o[5]
    				  ,(String) o[6],(String) o[7])).collect(Collectors.toList());
    
   return accList;
   
}


	

}






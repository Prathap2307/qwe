package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.CityHistory;

public interface ICityHistoryDAO {
	public List<CityHistory> getAll(Integer id) throws SQLException ;

}

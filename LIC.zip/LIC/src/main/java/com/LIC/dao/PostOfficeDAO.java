package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.PostOffice;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class PostOfficeDAO implements IPostOfficeDAO {
	
	static final Logger LOGGER = LogManager.getLogger(PostOfficeDAO.class);
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(PostOffice obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdatePostOffice(?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getDistrictId());
		  callableStatement.setInt(2, obj.getPostOfficeId());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setString(4, obj.getZipCode());
		  callableStatement.setInt(5, obj.getCreatedBy());
		  callableStatement.setString(6, obj.getRemarks());
		  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdatePostOffice executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdatePostOffice executed successfully.");
	}
	  
	@Override
	public void delete(Integer id, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeletePostOffice(?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeletePostOffice executed successfully.");
		  LOGGER.info("SP>spDeletePostOffice executed successfully.");
	} 
	
	@Override
	public List<PostOffice> getAll(PostOffice filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<PostOffice> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllPOSTOFFICE(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, filterObj.getDistrictId());
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  PostOffice obj = null;
			  list = new ArrayList<PostOffice>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("POSTOFFICEID")+" | "+rs.getString("Description")+" | "+rs.getString("ZipCode")); 
		        obj = new PostOffice();
		        obj.setPostOfficeId(rs.getInt("POSTOFFICEID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setZipCode(rs.getString("ZipCode"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllPOSTOFFICE executed successfully.");
			  LOGGER.info("SP>spGetAllPOSTOFFICE executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllPostOffices exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public PostOffice get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  PostOffice obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetPostOfficeByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		    	System.out.println(rs.getInt("PostOfficeID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("ZipCode")); 
		        obj = new PostOffice();
		        obj.setPostOfficeId(rs.getInt("PostOfficeID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setZipCode(rs.getString("ZipCode"));
		      }
			  System.out.println("SP>spGetPostOfficeByID executed successfully.");
			  LOGGER.info("SP>spGetPostOfficeByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetPostOfficeByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	}  
	 
}

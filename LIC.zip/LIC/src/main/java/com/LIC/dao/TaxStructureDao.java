package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.TaxStructureModal;
import com.LIC.model.Taxstructure;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.datetime.DateTimeUtility;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class TaxStructureDao implements ITaxstructureDAO {

    @Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(TaxStructureDao.class);
 
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	
	@Override
	public List<Taxstructure> getAll(Taxstructure filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Taxstructure> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllTaxstructure(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Taxstructure obj = null;
			  list = new ArrayList<Taxstructure>();
		      while (rs.next()) {
		        obj = new Taxstructure();
		        obj.setTaxStructureId(rs.getInt("TAXSTRUCTUREID"));
		        obj.setTaxStructureName(rs.getString("TAXSTRUCTURENAME"));
		        list.add(obj);
		      }
		      logger.info("SP>spGetAllTaxstructure executed successfully.");
		  }catch (Exception e) {
			  logger.error("SP>spGetAllTaxstructure exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	
	public long InsertOrUpdate(TaxStructureModal taxStructure,  List<TaxStructureModal> taxStructureModalList) throws Exception {
		
		Connection 				conn 				= null;
		long					taxStructureId		= 0;
		long 					flag				= 0;
		
		try {
			conn  = ResourceManager.getConnection();
			conn.setAutoCommit(false);
			if(taxStructure.getTaxStructureID() != 0) {
				DeleteTaxStructureDetails(taxStructure.getTaxStructureID(), conn);
			}
			
			taxStructureId	= InsertUpdateTaxStructure(taxStructure, conn);
			if(taxStructureModalList != null && taxStructureModalList.size() > 0) {
				for(TaxStructureModal obj : taxStructureModalList) {
					flag	= InsertUpdateTaxStructureDetails(taxStructureId, obj, conn);
				}
			}
			 
			if(flag > 0) {
				conn.rollback();
			}
			conn.commit();
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return taxStructureId;
	}
	
	public long InsertUpdateTaxStructure(TaxStructureModal taxStructure, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		ResultSet 				result 				= null;
		
		try {
			
			cstm  = conn.prepareCall("call spInsertOrUpdateTaxStructure(?,?,?,?,?,?,?,?,?,?,?,?)");
				
			cstm.setLong(1, 		taxStructure.getTaxStructureID());
			cstm.setString(2, 		taxStructure.getTaxStructureName());//Description
			cstm.setString(3,		taxStructure.getDescription());
			cstm.setTimestamp(4, 	taxStructure.getFromDate());
			cstm.setTimestamp(5, 	taxStructure.getToDate());
			cstm.setLong(6, 		taxStructure.getCreatedBy());
			cstm.setTimestamp(7, 	taxStructure.getCreatedOn());
			cstm.setLong(8, 		taxStructure.getModifiedBy());
			cstm.setTimestamp(9, 	taxStructure.getModifiedOn());
			cstm.setShort(10, 		taxStructure.getIsActive());
			cstm.setString(11, 		taxStructure.getExemptedInID());
			cstm.registerOutParameter(12, OracleTypes.CURSOR); //REF CURSOR
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(12);
			
			if(result != null) {
				if(result.next()) {
					return result.getLong("TaxStructureID");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
		return 0;
	}
	
	public long InsertUpdateTaxStructureDetails(long taxStructureID, TaxStructureModal obj, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			
			cstm  = conn.prepareCall("call spInsertTaxStructureDetails(?,?,?,?,?,?,?,?,?,?,?)");
			
			cstm.setLong(1, 		taxStructureID);
			cstm.setString(2,		obj.getTaxStructureDetailsName());
			cstm.setLong(3, 		obj.getParentTaxStructure());
			cstm.setLong(4,			obj.getModeID());
			cstm.setDouble(5, 		obj.getValue());
			cstm.setLong(6, 		obj.getHierarchyID());
			cstm.setString(7, 		obj.getParentTax());
			cstm.setLong(8, 		obj.getCreatedBy());
			cstm.setTimestamp(9, 	obj.getCreatedOn());
			cstm.setShort(10, 		obj.getIsActive());
			cstm.setLong(11, 		obj.getRowNumber());
				
			cstm.execute();
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return 1;
		} finally {
			cstm.close();
		}
		return 0;
	}
	
	 public void DeleteTaxStructureDetails(long taxStructureID, Connection conn)  throws Exception {
		 
		 CallableStatement		cstm				= null;
		 
		 try {
				conn  = ResourceManager.getConnection();
				cstm  = conn.prepareCall("call spDeleteTaxStructureDetails(?)");
				cstm.setLong(1, taxStructureID);
				cstm.executeUpdate();
				
			} catch(Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage(), e);
			} finally {
				cstm.close();
			}
     }
	 
	public String DeleteTaxStructure(long TaxStructureID, long deletedBy) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn  = ResourceManager.getConnection();
			cstm  = conn.prepareCall("call spDeleteTaxStructure(?,?,?)");
			cstm.setLong(1, TaxStructureID);
			cstm.setLong(2, deletedBy);
			cstm.registerOutParameter(3, OracleTypes.CURSOR); //REF CURSOR
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);
			
			if(result != null) {
				if(result.next()) {
					return result.getString("DeletedStatus");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
	}
	
	public String IsTaxStructureExist(TaxStructureModal taxStructure) throws Exception {


		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn  = ResourceManager.getConnection();
			cstm  = conn.prepareCall("call spIsTaxStructureExist(?,?,?,?,?)");
			
			
			cstm.setLong(1, taxStructure.getTaxStructureID());
			cstm.setString(2, taxStructure.getTaxStructureName());
			cstm.setTimestamp(3, taxStructure.getFromDate());
			cstm.setTimestamp(4, taxStructure.getToDate());
			cstm.registerOutParameter(5, OracleTypes.CURSOR); //REF CURSOR
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(5);
			
			if(result != null) {
				if(result.next()) {
					return result.getString("Result");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
	}
        
	public List<TaxStructureModal> GetAllTaxStructure() throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		TaxStructureModal 		taxStructureModal	= null;
		List<TaxStructureModal>	taxStructureList    = null;
		
		try {
			conn = ResourceManager.getConnection();
		    cstm = conn.prepareCall("call spGetAllTaxStructure(?)"); 
			
		    cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();	
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				taxStructureList = new ArrayList<TaxStructureModal>();
				
				while(result.next()) {
					
					taxStructureModal = new TaxStructureModal();
					taxStructureModal.setTaxStructureID(result.getLong("TaxStructureID"));
					taxStructureModal.setTaxStructureName(result.getString("TaxStructureName"));
					taxStructureModal.setDescription(result.getString("Description"));
					taxStructureModal.setFromDate(result.getTimestamp("FromDate"));
					taxStructureModal.setToDate(result.getTimestamp("ToDate"));
					if(taxStructureModal.getFromDate() != null)
					taxStructureModal.setFromDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getFromDate()));
					if(taxStructureModal.getToDate() != null)
					taxStructureModal.setToDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getToDate()));
					taxStructureModal.setExemptedInID(result.getString("ExemptedInID"));
					taxStructureList.add(taxStructureModal);
				}
			}
		} catch(Exception e) {
			 e.printStackTrace();
			logger.info(e.getMessage());
		} finally  {
			    cstm.close();
				cstm	= null;
				ResourceManager.freeConnection(conn);
				conn	= null;
		}
		
		return taxStructureList;
	}
	
	public List<TaxStructureModal> GetAllTaxStructureBasedonTaxName(String TaxStructureName) throws Exception {
	    
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		TaxStructureModal 		taxStructureModal	= null;
		List<TaxStructureModal>	taxStructureList	= null;
		
		try {
			conn = ResourceManager.getConnection();
		    cstm = conn.prepareCall("call spGetAllTaxStructureBasedonTaxName(?,?) ");
		    cstm.setString(1, TaxStructureName); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				taxStructureList = new ArrayList<TaxStructureModal>();
				while(result.next()) {
					
					taxStructureModal = new TaxStructureModal();
					taxStructureModal.setTaxStructureID(result.getLong("TaxStructureID"));
					taxStructureModal.setTaxStructureName(result.getString("TaxStructureName"));
					taxStructureModal.setDescription(result.getString("Description"));
					taxStructureModal.setFromDate(result.getTimestamp("FromDate"));
					taxStructureModal.setToDate(result.getTimestamp("ToDate"));
					taxStructureModal.setFromDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getFromDate()));
					taxStructureModal.setToDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getToDate()));
					taxStructureModal.setExemptedInID(result.getString("ExemptedInID"));
					taxStructureList.add(taxStructureModal);
				}
			}
			return taxStructureList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return null;
	}
	
	public List<TaxStructureModal> GetAllTaxStructureDetailsByTaxStructureID(long taxStructureID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		TaxStructureModal 		taxStructureModal	= null;
		List<TaxStructureModal>	taxStructureList    = null;
		
		try {
			conn = ResourceManager.getConnection();
		    cstm = conn.prepareCall("call spGetTaxStructureDetailsByID(?,?) ");
		    cstm.setLong(1, taxStructureID); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				taxStructureList = new ArrayList<TaxStructureModal>();
				
				while(result.next()){
					
					taxStructureModal = new TaxStructureModal();
					taxStructureModal.setTaxStructureDetailID(result.getLong("taxstructuredetailsid"));
					taxStructureModal.setTaxStructureID(result.getLong("taxstructureid"));
					taxStructureModal.setTaxStructureDetailsName(result.getString("taxstructuredetailsname"));
					taxStructureModal.setParentTaxStructure(result.getLong("parenttaxstructure"));
					taxStructureList.add(taxStructureModal);
				}
				
			}
		} catch(Exception e) {
			 e.printStackTrace();
		     logger.info(e.getMessage());
		} finally {
			    cstm.close();
				cstm	= null;
				ResourceManager.freeConnection(conn);
				conn	= null;
		}
		return taxStructureList;
	}
	
	public TaxStructureModal GetTaxStructureById(Long TaxStructureID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		TaxStructureModal 		taxStructureModal	= null;
		
		try {
			conn = ResourceManager.getConnection();
		    cstm = conn.prepareCall("call spGetTaxStructureByID(?,?)");
		    cstm.setLong(1, TaxStructureID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				
				if(result.next()) {
					
					taxStructureModal = new TaxStructureModal();
					taxStructureModal.setTaxStructureID(result.getLong("TaxStructureID"));
					taxStructureModal.setTaxStructureName(result.getString("TaxStructureName"));
					taxStructureModal.setDescription(result.getString("Description"));
					taxStructureModal.setFromDate(result.getTimestamp("FromDate"));
					taxStructureModal.setToDate(result.getTimestamp("ToDate"));
					taxStructureModal.setFromDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getFromDate()));
					taxStructureModal.setToDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getToDate()));
					//taxStructureModal.setExemptedInID(result.getLong("ExemptedInID"));
				}
			}
		} catch(Exception e) {
			 e.printStackTrace();
		     logger.info(e.getMessage());
		} finally {
		    cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return taxStructureModal;
	}
	
	public List<TaxStructureModal> GetAllTaxStructureDetails(long TaxStructureID) throws Exception {
	    
		CallableStatement		cstm						= null;
		Connection 				conn 						= null;
		ResultSet 				result 						= null;
		List<TaxStructureModal>	taxStructureList			= null;
		TaxStructureModal 		taxStructureModal 			= null;
	
		try {
	        conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetTaxStructureDetailsByID(?,?) ");
			
			cstm.setLong(1, TaxStructureID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();

			result = ((OracleCallableStatement)cstm).getCursor(2);
			if(result != null) {
				taxStructureList = new ArrayList<TaxStructureModal>();
				
				while(result.next()) {
					taxStructureModal = new TaxStructureModal();
					taxStructureModal.setTaxStructureDetailID(result.getLong("taxstructuredetailsid"));
					taxStructureModal.setTaxStructureID(result.getLong("taxstructureid"));
					taxStructureModal.setTaxStructureDetailsName(result.getString("taxstructuredetailsname"));
					taxStructureModal.setParentTaxStructure(result.getLong("parenttaxstructure"));
					taxStructureModal.setParentTax(result.getString("ParentTax"));
					taxStructureModal.setModeName(result.getString("modes"));
					taxStructureModal.setParentTaxStructureDetailsName(result.getString("parenttaxstructure"));
					
					taxStructureList.add(taxStructureModal);
					
					/*
					taxStructureModal.setFromDate(result.getTimestamp("FromDate"));
					taxStructureModal.setToDate(result.getTimestamp("ToDate"));
					taxStructureModal.setFromDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getFromDate()));
					taxStructureModal.setToDateStr(DateTimeUtility.getDateFromTimeStamp(taxStructureModal.getToDate()));
					taxStructureModal.setExemptedInID(result.getString("ExemptedInID"));*/
				}
			}
			
		} catch(Exception e) {
		    e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
            cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		return taxStructureList;
	}
	
}



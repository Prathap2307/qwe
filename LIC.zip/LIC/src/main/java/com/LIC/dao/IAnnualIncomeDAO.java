package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.AnnualIncome;

public interface IAnnualIncomeDAO {
	public void saveOrUpdate(AnnualIncome obj) throws SQLException ;
	public void delete(Integer AnnualIncomeID, Integer deleteBy) throws SQLException;
	public List<AnnualIncome> getAll(AnnualIncome filterObj) throws SQLException;
	public AnnualIncome get(Integer AnnualIncomeID) throws SQLException;
	
}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.model.PasswordPolicyModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
@Repository
public class PasswordPolicyDao { 
	
     @Autowired	JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(PasswordPolicyDao.class);
	
	
	public long InsertPasswordPolicy(PasswordPolicyModal passwordPolicy) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;

		try {
			
			if(passwordPolicy != null) {
			 
				conn   		= ResourceManager.getConnection();
				cstm 		= conn.prepareCall("call spInsertUpdatePasswordPolicy(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
				cstm.setLong(1, passwordPolicy.getOrgId());
				cstm.setLong(2, passwordPolicy.getPasswordPolicyId());
				cstm.setLong(3, passwordPolicy.getMinPasswordLength());
				cstm.setLong(4, passwordPolicy.getMaxPasswordLength());
				cstm.setLong(5, passwordPolicy.getNoOfAttempts());
				cstm.setLong(6, passwordPolicy.getPasswordHistoryCount());
				cstm.setLong(7, passwordPolicy.getPasswordAge());
				cstm.setLong(8, passwordPolicy.getAlertMsgDay());
				cstm.setLong(9, passwordPolicy.getIsDigitsReq());
				cstm.setLong(10,passwordPolicy.getIsCapitalletterReq());
				cstm.setLong(11,passwordPolicy.getIsSmallletterReq());
				cstm.setLong(12,passwordPolicy.getIsSpecialcharReq());
				cstm.setLong(13,passwordPolicy.getPasswordPolicyId());
				
				cstm.registerOutParameter(14, OracleTypes.CURSOR); //REF CURSOR
				cstm.execute();
				
				result = ((OracleCallableStatement)cstm).getCursor(14);
				
				if(result != null) {
					
					if(result.next()) {
						
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return 0;
	}
	
	public List<PasswordPolicyModal> GetPasswordPolicy(long organisationID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		PasswordPolicyModal     passwordPolicyModal = null;
		List<PasswordPolicyModal> passwordPolicyModallist = null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetPasswordPolicyByOraganisationID(?,?) ");
			cstm.setLong(1, organisationID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				
				passwordPolicyModallist = new ArrayList<PasswordPolicyModal>();
				
				while(result.next()) {
					passwordPolicyModal = new PasswordPolicyModal();
					passwordPolicyModal.setPasswordPolicyId(result.getLong("passwordPolicyID"));
					passwordPolicyModal.setOrgId(result.getLong("organisationID"));
					passwordPolicyModal.setMinPasswordLength(result.getInt("minPasswordLength"));
					passwordPolicyModal.setMaxPasswordLength(result.getInt("maxPasswordLength"));
					passwordPolicyModal.setNoOfAttempts(result.getInt("noOfAttempts"));
					passwordPolicyModal.setPasswordHistoryCount(result.getInt("passwordHistoryCount"));
					passwordPolicyModal.setPasswordAge(result.getInt("passwordAge"));
					passwordPolicyModal.setAlertMsgDay(result.getInt("alertMsgDay"));
					passwordPolicyModal.setIsDigitsReq(result.getShort("isDigitsReq"));
					passwordPolicyModal.setIsCapitalletterReq(result.getShort("isCapitalletterReq"));
					passwordPolicyModal.setIsSmallletterReq(result.getShort("isCapitalletterReq"));
					passwordPolicyModal.setIsSpecialcharReq(result.getShort("isSpecialcharReq"));
					passwordPolicyModal.setIsPasswordsameasUserID(result.getShort("isPasswordsameasUserID"));
					passwordPolicyModal.setIsActive(result.getShort("isActive"));
					passwordPolicyModallist.add(passwordPolicyModal);
				}
			}
			return passwordPolicyModallist;
		} catch(Exception ex) {
			ex.printStackTrace();
			logger.info(ex.getMessage());	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return passwordPolicyModallist;
	}
}

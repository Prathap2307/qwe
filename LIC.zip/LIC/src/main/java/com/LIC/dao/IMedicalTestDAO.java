package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.MedicalTest;

public interface IMedicalTestDAO {
	public void saveOrUpdate(MedicalTest obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<MedicalTest> getAll(MedicalTest filterObj) throws SQLException;
	public MedicalTest get(Integer id) throws SQLException;
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.PostOfficeHistory;

public interface IPostOfficeHistoryDAO {
	
	public List<PostOfficeHistory> getAll(Integer id) throws SQLException;
}

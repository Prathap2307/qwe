package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.BenefitRiders;
import com.LIC.model.VariantBenefitRider;

public interface IBenefitRidersDAO {
	public List<BenefitRiders> getAll(BenefitRiders filterObj) throws SQLException ;
	public List<VariantBenefitRider> getCoverageByProductID(Integer lineofBusinessId, Integer productId, Integer isSelectable, Integer isBaseCoverage) throws SQLException ;
	public BenefitRiders saveOrUpdateBenefitRider(BenefitRiders filterObj) throws SQLException ;
}

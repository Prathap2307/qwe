
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.PaymentFrequency;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class PaymentFrequencyDAO implements IPaymentFrequencyDAO {
	
	static final Logger LOGGER = LogManager.getLogger(AccountTypeDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(PaymentFrequency obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateFrequency(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getFrequencyId());
		  callableStatement.setString(2, obj.getShortDescription());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setInt(4, obj.getCreatedBy());
		  callableStatement.setString(5, obj.getRemarks());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateFrequency executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateFrequency executed successfully.");
	}
	
	@Override
	public void delete(Integer frequencyID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteFrequency(?,?,?); END;");
		  callableStatement.setInt(1, frequencyID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteFrequency executed successfully.");
		  LOGGER.info("SP>spDeleteFrequency executed successfully.");
	} 
	
	@Override
	public List<PaymentFrequency> getAll(PaymentFrequency filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<PaymentFrequency> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllFrequency(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  PaymentFrequency obj = null;
			  list = new ArrayList<PaymentFrequency>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")); 
		        obj = new PaymentFrequency();
		        obj.setFrequencyId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllFrequency executed successfully.");
			  LOGGER.info("SP>spGetAllFrequency executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllFrequency exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public PaymentFrequency get(Integer frequencyID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  PaymentFrequency obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetFrequency(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, frequencyID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")); 
		        obj = new PaymentFrequency();
		        obj.setFrequencyId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		      }
			  System.out.println("SP>spGetFrequency executed successfully.");
			  LOGGER.info("SP>spGetFrequency executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetFrequency exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.MaritalStatus;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class MaritalStatusDAO implements IMaritalStatusDAO {
	
	static final Logger LOGGER = LogManager.getLogger(MaritalStatusDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(MaritalStatus obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateMaritalStatus(?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getMaritalStatusId());
		  callableStatement.setString(2, obj.getDescription());
		  callableStatement.setInt(3, obj.getCreatedBy());
		  callableStatement.setString(4, obj.getRemarks());
		  callableStatement.registerOutParameter(5, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  LOGGER.info("SP>spInsertOrUpdateMaritalStatus executed successfully.");
	}
	
	@Override
	public void delete(Integer maritalStatusID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteMaritalStatus(?,?,?); END;");
		  callableStatement.setInt(1, maritalStatusID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteMaritalStatus executed successfully.");
		  LOGGER.info("SP>spDeleteMaritalStatus executed successfully.");
	} 
	
	@Override
	public List<MaritalStatus> getAll(MaritalStatus filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<MaritalStatus> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllMaritalStatus(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  MaritalStatus obj = null;
			  list = new ArrayList<MaritalStatus>();
		      while (rs.next()) {
		        obj = new MaritalStatus();
		        obj.setMaritalStatusId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllMaritalStatus executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllMaritalStatus exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public MaritalStatus get(Integer maritalStatusID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  MaritalStatus obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetMaritalStatus(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, maritalStatusID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new MaritalStatus();
		        obj.setMaritalStatusId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		      }
			  LOGGER.info("SP>spGetAllMaritalStatus executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllMaritalStatus exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

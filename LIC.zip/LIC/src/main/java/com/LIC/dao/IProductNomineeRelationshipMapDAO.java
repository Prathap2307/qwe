package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.LIC.model.ProductNomineeRelationshipMap;

public interface IProductNomineeRelationshipMapDAO {
	public void saveOrUpdate(Connection connection,ProductNomineeRelationshipMap obj) throws SQLException ;
	public List<Integer> get(Connection connection,Integer id) throws SQLException ;
	public void delete(Connection connection,Integer productID) throws SQLException ;
}


package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.PremiumPaymentFrequency;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class PremiumPaymentFrequencyDAO implements IPremiumPaymentFrequencyDAO {
	
	static final Logger LOGGER = LogManager.getLogger(PremiumPaymentFrequencyDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(PremiumPaymentFrequency obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertUpdatePaymentFrequencyDetails(?,?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getId());
		  callableStatement.setInt(2, obj.getPlanID());
		  callableStatement.setInt(3, obj.getPremPaymentFrequencyID());
		  callableStatement.setDouble(4, obj.getModalFactor());
		  callableStatement.setInt(5, obj.getGracePeriod());
		  callableStatement.setInt(6, obj.getNoticePeriod());
		  callableStatement.setInt(7, obj.getCreatedBy());
		  callableStatement.registerOutParameter(8, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  LOGGER.info("SP>spInsertOrUpdatePremiumPaymentFrequency executed successfully.");
	}
	
	@Override
	public void delete(Integer premiumPaymentFrequencyID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeletePaymentFrequencyDetails(?,?,?); END;");
		  callableStatement.setInt(1, premiumPaymentFrequencyID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeletePaymentFrequencyDetails executed successfully.");
		  LOGGER.info("SP>spDeletePaymentFrequencyDetails executed successfully.");
	} 
	
	@Override
	public List<PremiumPaymentFrequency> getAll(PremiumPaymentFrequency filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<PremiumPaymentFrequency> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllPaymentFrequencyDetails(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  PremiumPaymentFrequency obj = null;
			  list = new ArrayList<PremiumPaymentFrequency>();
		      while (rs.next()) {
			        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("PPFDESCRIPTION")); 

		        obj = new PremiumPaymentFrequency();

		        obj.setId(rs.getInt("ID"));
		        obj.setPlanID(rs.getInt("PLANID"));
		        obj.setPremPaymentFrequencyID(rs.getInt("PremPaymentFrequencyID"));
		        obj.setDispPlanName(rs.getString("DESCRIPTION"));
		        obj.setDispPaymentFrequencyName(rs.getString("PPFDESCRIPTION"));
		        obj.setModalFactor(rs.getDouble("MODALFACTOR"));
		        obj.setGracePeriod(rs.getInt("GRACEPERIOD"));
		        obj.setNoticePeriod(rs.getInt("NOTICEPERIOD"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllPaymentFrequencyDetails executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllPaymentFrequencyDetails exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public PremiumPaymentFrequency get(Integer PremiumPaymentFrequencyID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  PremiumPaymentFrequency obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetPaymentFrequencyDetails(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, PremiumPaymentFrequencyID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new PremiumPaymentFrequency();
		        obj.setId(rs.getInt("ID"));
		        obj.setPlanID(rs.getInt("PlanID"));
		        obj.setPremPaymentFrequencyID(rs.getInt("PREMPAYMENTFREQUENCYID"));
		        obj.setModalFactor(rs.getDouble("MODALFACTOR"));
		        obj.setGracePeriod(rs.getInt("GRACEPERIOD"));
		        obj.setNoticePeriod(rs.getInt("NOTICEPERIOD"));
		      }
			  LOGGER.info("SP>spGetPaymentFrequencyDetails executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetPaymentFrequencyDetails exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.BankCityHistory;

public interface IBankCityHistoryDAO {
	public List<BankCityHistory> getAll(Integer id) throws SQLException ;

}

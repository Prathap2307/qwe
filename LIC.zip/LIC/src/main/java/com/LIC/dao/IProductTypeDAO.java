package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.ProductType;

public interface IProductTypeDAO {
	public List<ProductType> getAll(ProductType filterObj) throws SQLException ;

}

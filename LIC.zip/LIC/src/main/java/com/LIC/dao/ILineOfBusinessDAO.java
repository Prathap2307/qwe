package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.LineOfBusiness;

public interface ILineOfBusinessDAO {
	public List<LineOfBusiness> getAll(LineOfBusiness filterObj) throws SQLException ;

}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.DocumentCategory;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class DocumentCategoryDAO implements IDocumentCategoryDAO {
	
	static final Logger LOGGER = LogManager.getLogger(DocumentCategoryDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(DocumentCategory obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateDocumentCatery(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getDocumentCategoryId());
		  callableStatement.setString(2, obj.getShortDescription());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setInt(4, obj.getCreatedBy());
		  callableStatement.setString(5, obj.getRemarks());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  LOGGER.info("SP>spInsertOrUpdateDocumentCatery executed successfully.");
	}
	
	@Override
	public void delete(Integer documentCategoryID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteDocumentCatery(?,?,?); END;");
		  callableStatement.setInt(1, documentCategoryID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteDocumentCategory executed successfully.");
		  LOGGER.info("SP>spDeleteDocumentCategory executed successfully.");
	} 
	
	@Override
	public List<DocumentCategory> getAll(DocumentCategory filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<DocumentCategory> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllDocumentCatery(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  DocumentCategory obj = null;
			  list = new ArrayList<DocumentCategory>();
		      while (rs.next()) {
		        obj = new DocumentCategory();
		        obj.setDocumentCategoryId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllDocumentCatery executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllDocumentCatery exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public DocumentCategory get(Integer documentCategoryID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  DocumentCategory obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetDocumentCatery(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, documentCategoryID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")); 
		        obj = new DocumentCategory();
		        obj.setDocumentCategoryId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		      }
			  LOGGER.info("SP>spGetAllDocumentCatery executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllDocumentCatery exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			   
		  }
		  return obj;
	} 
	 
}

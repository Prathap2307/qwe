package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.District;

public interface IDistrictDAO {
	public void saveOrUpdate(District obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<District> getAll(District filterObj) throws SQLException;
	public District get(Integer id) throws SQLException;
}

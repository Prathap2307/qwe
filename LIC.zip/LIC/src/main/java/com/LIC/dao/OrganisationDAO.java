package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.GetOrganisationModel;
import com.LIC.model.OrganisationModel;

@Repository
public class OrganisationDAO {
	
	
	@Autowired
	private EntityManager em;
	
	
	public void postOrganisation(OrganisationModel model){
    	 StoredProcedureQuery query = em
                .createNamedStoredProcedureQuery("createOrUpdateOrganisation");
               
               query .setParameter("vOrganisationID",model.getOrganisationId());
               query .setParameter("vShortName", model.getShortName());
               query.setParameter("vOrganisationName",model.getOrganisationName());
               query.setParameter("vPasswordExpiry", model.getPasswordExpiry());
               query .setParameter("vNoOfDays",model.getNoOfDays());
               query.setParameter("vAddress1",model.getAddress1());   
               query .setParameter("vAddress2", model.getAddress2());
               query.setParameter("vAddress3",model.getAddress3());
               query.setParameter("vCountryID", model.getCountryId());
               query .setParameter("vStateID",model.getStateId());
               query.setParameter("vDistrictID",model.getDistrictId());   
               query .setParameter("vTalukID", model.getTalukId());
               query.setParameter("vZipCode",model.getZipCode());
               query.setParameter("vPhoneNo", model.getPhoneNo());
               query .setParameter("vMobileNo",model.getMobileNo());
               query.setParameter("vConferenceNo",model.getConferenceNo());   
               query .setParameter("vFaxNo", model.getFaxNo());
               query.setParameter("vEmail",model.getEmail());
               query.setParameter("vIsActive",model.getIsActive());
               query.setParameter("vGSTNo", model.getGstNo());
               query .setParameter("vPANNo",model.getPanNo());
               query .setParameter("vSACCode", model.getSacCode());
               query .setParameter("vCreatedBy", model.getCreatedBy());
               query .setParameter("vCreatedOn", model.getCreatedOn());
              // query.setParameter("vIsActive",model.getIsActive());   
               query.getParameter("vResult");
               query.execute() ;
           
    	        
	}
	
	
	public List<GetOrganisationModel>GetAllOrganisations() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllOrganisations")
               .registerStoredProcedureParameter("oOrg", Class.class, ParameterMode.REF_CURSOR);
                    

        
         // return query.execute() ? query.getResultList() : null;
      
        
       query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetOrganisationModel> accList = list.stream().map(
        		  o -> new GetOrganisationModel((Number) o[0],(String) o[1],(String) o[2],(Number)o[3],
        				  
        				  (Number) o[4],(Number) o[5],
        				  (String) o[6],(Number) o[7],
        				  
        				  
        				  
        				  (String) o[8],(String) o[9],
        				  (String) o[10],(String) o[11],(String) o[12],(String) o[13],
(String) o[14],(String) o[15],(String) o[16],(String) o[17],
        				  
        				  
        				  
        				  
        				  (String) o[18])).collect(Collectors.toList());
        
       return accList;
       
         
       }

	
	
	
	
	
	public List<GetOrganisationModel>GetAllCountryNames() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllCountries")
               .registerStoredProcedureParameter("p_recordset", Class.class, ParameterMode.REF_CURSOR);
                    

        
          //return query.execute() ? query.getResultList() : null;
      
        
       query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetOrganisationModel> accList = list.stream().map(
        		  o -> new GetOrganisationModel((Number) o[0],(String) o[1],(String) o[2],(String) o[3],(Number) o[4])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	
	
	
	public List<GetOrganisationModel>GetAllStateNames(Number countryId) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllStates")
               .registerStoredProcedureParameter("p_CountryID",Long.class, ParameterMode.IN)
               .registerStoredProcedureParameter("cur", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("p_CountryID",countryId);

        
        //return query.execute() ? query.getResultList() : null;
      
        
       query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetOrganisationModel> accList = list.stream().map(
        		  o -> new GetOrganisationModel((Number) o[0],(String) o[1],(Number) o[2])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	
	
	public List<GetOrganisationModel>GetAllDistrictsNames(Number stateId) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllDistricts")
               .registerStoredProcedureParameter("p_StateID",Long.class, ParameterMode.IN)
               .registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("p_StateID",stateId);

        
         //return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetOrganisationModel> accList = list.stream().map(
        		  o -> new GetOrganisationModel((String) o[0],(Number) o[1],(String) o[2])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	
	
	
	
	public List<GetOrganisationModel>GetAllPostOfficeNames(Number districtId) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllPOSTOFFICE")
               .registerStoredProcedureParameter("p_DistrictID",Long.class, ParameterMode.IN)
               .registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("p_DistrictID",districtId);

        
       //  return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetOrganisationModel> accList = list.stream().map(
        		  o -> new GetOrganisationModel((Number) o[0],(String) o[1],(String) o[2])).collect(Collectors.toList());
        
       return accList;
       
         
	}
	
	
	
    public List<GetOrganisationModel>GetAllDetailsBasedOnZipCode(String zipCode) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllDetailsByZipCode")
               .registerStoredProcedureParameter("PZipCode",String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oTALUK", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("PZipCode",zipCode);

        
        //return query.execute() ? query.getResultList() : null;
      
        
       query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetOrganisationModel> zipList = list.stream().map(
                       o -> new GetOrganisationModel((String) o[0],(String) o[1],(Number) o[2],(Number) o[3],(Number) o[4],(String) o[5],(Number) o[6],(String) o[7])).collect(Collectors.toList());
        
       return zipList;
       
         
       }

	
	
	
	
	
	
	
	
}

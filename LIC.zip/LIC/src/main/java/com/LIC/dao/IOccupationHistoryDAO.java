package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.OccupationHistory;

public interface IOccupationHistoryDAO {
	public List<OccupationHistory> getAll(Integer id) throws SQLException ;
}

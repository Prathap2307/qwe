package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.PaymentFrequency;

public interface IPaymentFrequencyDAO {
	public void saveOrUpdate(PaymentFrequency obj) throws SQLException ;
	public void delete(Integer frequencyID, Integer deleteBy) throws SQLException;
	public List<PaymentFrequency> getAll(PaymentFrequency filterObj) throws SQLException;
	public PaymentFrequency get(Integer frequencyID) throws SQLException;
}

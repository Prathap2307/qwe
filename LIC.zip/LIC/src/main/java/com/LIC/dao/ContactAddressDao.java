package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ContactAddressModal;

@Repository
@SuppressWarnings("unchecked")
public class ContactAddressDao {

	@Autowired
	private EntityManager em;
	
	public List<ContactAddressModal> GetAllDetailsByZipCode(String zipCode) {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllDetailsByZipCode")
               .registerStoredProcedureParameter("p_ZipCode", String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR)
               .setParameter("p_ZipCode", zipCode);
   	 query.execute();
		List<Object[]> list  =  (List<Object[]>)query.getResultList();
   	 List<ContactAddressModal> accList = list.stream().map(
                o -> new ContactAddressModal((Number) o[0], (String) o[1], (Number) o[2], (String) o[3], (Number) o[4], (String) o[5], (Number) o[6],
                		(String) o[7])).collect(Collectors.toList());
   	System.out.println("ZiaccListpCode >"+accList);
    	return accList;
	}
}

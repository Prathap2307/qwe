package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.RegionHistory;

public interface IRegionHistoryDAO {
	public List<RegionHistory> getAll(Integer id) throws SQLException ;

}

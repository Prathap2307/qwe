package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.CurrencyHistory;

public interface ICurrencyHistoryDAO {
	
	public List<CurrencyHistory> getAll(Integer id) throws SQLException;
}

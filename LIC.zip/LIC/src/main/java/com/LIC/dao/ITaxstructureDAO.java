package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.LIC.model.Taxstructure;
@Repository
public interface ITaxstructureDAO {
	public List<Taxstructure> getAll(Taxstructure filterObj) throws SQLException ;

}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.CountryHistory;

public interface ICountryHistoryDAO {
	
	public List<CountryHistory> getAll(Integer id) throws SQLException;
}

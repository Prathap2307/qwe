package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.PostOffice;

public interface IPostOfficeDAO {
	public void saveOrUpdate(PostOffice obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<PostOffice> getAll(PostOffice filterObj) throws SQLException;
	public PostOffice get(Integer id) throws SQLException;
}

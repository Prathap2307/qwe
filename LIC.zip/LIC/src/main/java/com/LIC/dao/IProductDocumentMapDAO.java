package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.LIC.model.ProductDocumentMap;

public interface IProductDocumentMapDAO {
	public Integer saveOrUpdate(Connection connection,ProductDocumentMap obj) throws SQLException ;

}

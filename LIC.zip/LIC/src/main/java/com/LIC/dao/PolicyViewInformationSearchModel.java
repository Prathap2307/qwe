package com.LIC.dao;

public class PolicyViewInformationSearchModel {
	
	private Number applicationId;
	private Number lobId;
	private String masterPolicyNumber;
	private String insurerMasterAgreementNo;
	private String policyNumber;
	private String policyHolderName;
	private String employeeId;
	private String contactId;
	
	
	

	 public Number getApplicationId() {
		return applicationId;
	}




	public void setApplicationId(Number applicationId) {
		this.applicationId = applicationId;
	}




	public Number getLobId() {
		return lobId;
	}




	public void setLobId(Number lobId) {
		this.lobId = lobId;
	}




	public String getMasterPolicyNumber() {
		return masterPolicyNumber;
	}




	public void setMasterPolicyNumber(String masterPolicyNumber) {
		this.masterPolicyNumber = masterPolicyNumber;
	}




	public String getInsurerMasterAgreementNo() {
		return insurerMasterAgreementNo;
	}




	public void setInsurerMasterAgreementNo(String insurerMasterAgreementNo) {
		this.insurerMasterAgreementNo = insurerMasterAgreementNo;
	}




	public String getPolicyNumber() {
		return policyNumber;
	}




	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}




	public String getPolicyHolderName() {
		return policyHolderName;
	}




	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}




	public String getEmployeeId() {
		return employeeId;
	}




	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}




	public String getContactId() {
		return contactId;
	}




	public void setContactId(String contactId) {
		this.contactId = contactId;
	}


public PolicyViewInformationSearchModel()
{
super();	
}

	public PolicyViewInformationSearchModel(Number applicationId, Number lobId, String masterPolicyNumber, 
				String insurerMasterAgreementNo,String policyNumber,String policyHolderName,String employeeId,String ContactId) {
			super();
			this.lobId = lobId;
			this.masterPolicyNumber = masterPolicyNumber;
			this.applicationId = applicationId;
			this.insurerMasterAgreementNo = insurerMasterAgreementNo;
			this.policyNumber=policyNumber;
			this.policyHolderName=policyHolderName;
			this.employeeId=employeeId;
			this.contactId=ContactId;
		}
	
}

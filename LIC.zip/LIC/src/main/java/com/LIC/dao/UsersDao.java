package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.LIC.constant.Constant;
import com.LIC.model.BranchModal;
import com.LIC.model.ContactAddressModal;
import com.LIC.model.CountryTimeZone;
import com.LIC.model.EmployeeModal;
import com.LIC.model.GetLOBUsers;
import com.LIC.model.GetUserEmployeeModel;
import com.LIC.model.LineOfBusiness;
import com.LIC.model.ReportingToModal;
import com.LIC.model.UnderWritingUserRuleLevelModel;
import com.LIC.model.UserModal;
import com.LIC.model.UserProfileModal;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
public class UsersDao {
	
    @Autowired	JdbcTemplate jdbcTemplate;
	private static final Logger logger = Logger.getLogger(UsersDao.class);
	
	public String IsUserEmployeeExist(UserModal usermodal, String employeeNo) throws Exception {
	    CallableStatement		cstm				= null;
		Connection 				conn 				= null;
	    ResultSet 				result 				= null;
	 
		try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call IsUserEmployeeExist(?,?,?,?,?,?)");
			 
			 cstm.setLong(1, 		usermodal.getOrganisationID());
			 cstm.setLong(2, 		usermodal.getBranchID());
			 cstm.setString(3, 		usermodal.getUserName());
			 cstm.setLong(4, 		usermodal.getEmployeeID());
			 cstm.setLong(5,        usermodal.getUserTypeID());
			 
			 cstm.registerOutParameter(6, OracleTypes.CURSOR);
			 cstm.execute();
			 
			 result = ((OracleCallableStatement)cstm).getCursor(6);
		    
			 if(result != null) {
		    	while(result.next()) {
		    		return result.getString("Description");
		    	}
		    		
		     }
		 } catch(Exception e) {
			 e.printStackTrace();
			 logger.error(e.getMessage(), e); 
	
		 } finally {
		    cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	 		 
		 }
		return ""; 
	 }
	
	public int IsPasswordExists(UserModal usermodal) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spIsPasswordExists(?,?,?)");
			
			cstm.setLong(1, 		usermodal.getUserID());
			cstm.setString(2, 		usermodal.getPassword());
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);
			
			if(result != null) {
				if(result.next()) {
					return result.getInt("UserRecords");
				}
				
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e); 
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	 		 
		}
		return 0; 
	}
	
	public ValueObject InsertUserAndEmployeeDetails(EmployeeModal employeemodal, List<ContactAddressModal> contactaddressmodallist, UserModal usermodal, 
			List<BranchModal> branchList, List<UnderWritingUserRuleLevelModel> underWritingLevelList) throws Exception {
		
		Connection 				conn 				= null;
		ValueObject 			valueOutObject 		= null;
		long 					empId 				= 0;
		long 					userID 				= 0;
  
		try {

			conn = ResourceManager.getConnection();
			conn.setAutoCommit(false);
			
			valueOutObject	= new ValueObject();
			
			if(employeemodal !=  null) {
				DeleteEmployeeAddressMap(employeemodal.getEmployeeID(), conn);
			
				System.out.println("prev empId >"+employeemodal.getEmployeeID());
				empId 	= InsertOrUpdateEmployee(employeemodal, conn);
				System.out.println("generated empId >>"+empId);
				valueOutObject.put("EmployeeId", empId);
				
				usermodal.setEmployeeID(empId);
				
				if(usermodal !=  null) {
					userID	= InsertOrUpdateUser(employeemodal, usermodal, conn);
					System.err.println("generated userID >>"+userID);
					valueOutObject.put("UserID", userID);
				}
				
				if (userID > 0) {
					int status = InsertEmployeeAttachedBranch(empId, userID, branchList, conn);
					System.out.println("EmployeeAttachedBranch status >>"+status);
					valueOutObject.put("EmployeeAttachedBranchStatus", status > 0 ? "Failed" : "Success");
				}
				
				DeleteLineofBusinessMap(userID, conn);
				InsertUserLobMap(usermodal, conn);
				DeleteUnderWritingUserRuleLevelID(userID, conn);
				InsertUnderWritingUserRuleLevelID(userID, underWritingLevelList, conn);
				
			}
			
			conn.commit();
		
		} catch(Exception e) {
			conn.rollback();
			e.printStackTrace();
			valueOutObject.put(Constant.ERROR, e.getLocalizedMessage());
			logger.error(e.getMessage(), e);
		} finally {
			
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return valueOutObject;
	}
	
	public long InsertOrUpdateEmployee(EmployeeModal employeemodal, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		ResultSet 				result 				= null;
		long 					empId 				= 0;
       
        try {
        	
        	if(conn == null)
        		conn = ResourceManager.getConnection();
        	
        	cstm = conn.prepareCall("call spInsertOrUpdateEmployee(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        	cstm.setLong(1, 		employeemodal.getEmployeeID());
        	cstm.setLong(2, 		employeemodal.getOrganisationID());
			cstm.setLong(3, 		employeemodal.getSalutationID());
			cstm.setString(4, 		employeemodal.getFirstName());
			cstm.setString(5, 		employeemodal.getLastName());
			cstm.setString(6, 		employeemodal.getInitial());
			cstm.setString(7, 		employeemodal.getEmployeeNo());
			cstm.setLong(8, 		employeemodal.getReportingTo());
			cstm.setLong(9, 		employeemodal.getDepartmentID());
			cstm.setLong(10, 		employeemodal.getDesignationID());
			cstm.setLong(11, 		employeemodal.getBranchID());
			cstm.setString(12, 		employeemodal.getEmail());
			cstm.setString(13, 		employeemodal.getPhotos());
			cstm.setLong(14, 		employeemodal.getCreatedBy());
			cstm.setTimestamp(15, 	employeemodal.getCreatedOn());
			cstm.setInt(16, 		employeemodal.getGender());
			cstm.setInt(17, 		employeemodal.getMaritalStatus());
			cstm.setTimestamp(18, 	employeemodal.getDateOfBirth());
			cstm.setTimestamp(19, 	employeemodal.getDateOfJoin());
			cstm.setLong(20, 		employeemodal.getEducationID());
			cstm.setString(21, 		employeemodal.getPhoneNo());
			cstm.setString(22, 		employeemodal.getMobileNo());
			cstm.setString(23, 		employeemodal.getConferenceNo());
			cstm.setString(24, 		employeemodal.getFaxNo());
			cstm.setLong(25, 		employeemodal.getLevelID());
			cstm.setLong(26, 		employeemodal.getModifiedBy());
			cstm.setTimestamp(27, 	employeemodal.getModifiedOn());
			cstm.setLong(28, 		employeemodal.getDeletedBy());
			cstm.setTimestamp(29, 	employeemodal.getDeletedOn());
			cstm.setLong(30, 		employeemodal.getIsActive());
			cstm.setLong(31, 		employeemodal.getGradeID());
			cstm.setLong(32, 		employeemodal.getSelectAllBranch());
			cstm.setString(33, 		employeemodal.getAddress());
			cstm.registerOutParameter(34, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(34);
			
			if(result != null) {
				while(result.next()) {
					System.err.println("sddd"+result.getLong("EmployeesID"));
					empId = result.getLong("EmployeesID");
				}
			}
			return empId;
        } catch(Exception e) {
        	conn.rollback();
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
        
		return 0;
	
	}
	
	public long InsertOrUpdateUser(EmployeeModal employeemodal, UserModal usermodal, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		ResultSet 				result 				= null;
		long 					userId 				= 0;
		
		try {
			
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			cstm = conn.prepareCall("call spInsertOrUpdateUser(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			cstm.setLong(1, 	employeemodal.getOrganisationID());
			cstm.setLong(2, 	employeemodal.getBranchID());
			cstm.setLong(3, 		usermodal.getEmployeeID());
			cstm.setLong(4, 		usermodal.getUserID());
			cstm.setString(5, 		usermodal.getUserName());
			cstm.setString(6, 		usermodal.getPassword());
			cstm.setShort(7, 		usermodal.getIsAdmin());
			cstm.setLong(8, 		usermodal.getIsSuperUser());
			cstm.setShort(9, 		usermodal.getIsUnderWriter());
			cstm.setLong(10, 		usermodal.getCreatedBy());
			cstm.setTimestamp(11, 	usermodal.getCreatedOn());
			cstm.setShort(12, 		usermodal.getIsActive());
			cstm.setLong(13, 		usermodal.getDefaultLineofBusiness());
			cstm.setShort(14, 		usermodal.getUserType());
			cstm.setLong(15, 		usermodal.getMainChannelID());
			cstm.setLong(16, 		usermodal.getSubChannelID());
			cstm.setLong(17, 		usermodal.getAgentID());
			cstm.setLong(18, 		usermodal.getUsageID());
			cstm.setLong(19, 		usermodal.getGroupID());
			cstm.setLong(20, 		usermodal.getTPAID());
			cstm.registerOutParameter(21, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(21);
			System.out.println("result >>"+result);
			if(result != null) {
				if(result.next()) {
					System.out.println("result.getLong(\"UserID\") >>"+result.getLong("UserID"));
					userId = result.getLong("UserID");
				}
			}
			return userId;
		} catch(Exception e) {
			conn.rollback();
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
		
		return 0;
		
	}
	
	public int InsertEmployeeAttachedBranch(long EmployeeID, long UserID, List<BranchModal> branchList, Connection conn) throws Exception {
		CallableStatement		cstm				= null;
		
		try {
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			System.out.println("branchList >>"+branchList);
			if(branchList != null) {
				
				String Status = DeleteEmployeeAttachedBranch(EmployeeID, conn);
				System.err.println("delete Status >>"+Status);
				
				for (BranchModal branchModal : branchList) {
					cstm = conn.prepareCall("call spInsertEmployeeAttachedBranch(?,?,?)");
					cstm.setLong(1, branchModal.getBranchId());
					cstm.setLong(2, EmployeeID);
					cstm.setLong(3, UserID);
                    cstm.executeUpdate();
				}
			}
		} catch(Exception e) {
			conn.rollback();
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return 1;
		} finally {
			if(cstm != null)
				cstm.close();
		}
		return 0;
	}
	
	public int InsertUserLobMap(UserModal usermodal, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			System.out.println("LineOfBusinessModel >>"+usermodal.getLineOfBusinessModelList());
			if(usermodal.getLineOfBusinessModelList() != null) {
				
				for (LineOfBusiness lineOfBusiness : usermodal.getLineOfBusinessModelList()) {
					
					cstm = conn.prepareCall("call spInsertUserLobMap(?,?,?,?)");
					cstm.setLong(1, 		usermodal.getUserID());
					cstm.setLong(2, 		lineOfBusiness.getLineOfBusinessId());
					cstm.setLong(3, 		lineOfBusiness.getCreatedBy());
					cstm.setTimestamp(4, 	DateTimeUtility.getTimeStamp(lineOfBusiness.getCreatedOn()+""));
					cstm.executeUpdate();
				}
			}
		} catch(Exception e) {
			conn.rollback();
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return 1;
		} finally {
			if(cstm != null)
				cstm.close();
		}
		return 0;
	}
	
	public void InsertUnderWritingUserRuleLevelID(long userId, List<UnderWritingUserRuleLevelModel> usermodalList, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			System.out.println("LineOfBusinessModel >>" + usermodalList);
			if(usermodalList != null) {
				
				for (UnderWritingUserRuleLevelModel usermodal : usermodalList) {
					
					cstm = conn.prepareCall("call spInsertUnderWritingUserRuleLevelID(?,?,?)");
					cstm.setLong(1, 		userId);
					cstm.setLong(2, 		usermodal.getUnderWritingLevelID());
					cstm.setShort(3, 		usermodal.getIsActive());
					cstm.executeUpdate();
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			if(cstm != null)
				cstm.close();
		}
	}
	
	public String DeleteEmployeeAttachedBranch(long EmployeeID, Connection conn)throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			cstm = conn.prepareCall("call spDeleteEmployeeAttachedBranch(?)");
			cstm.setLong(1, EmployeeID);
			
			cstm.executeUpdate();
			return "Success";
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
		}
		return "Errror";
	}
	
	public void DeleteEmployeeAddressMap(long employeeId, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			cstm = conn.prepareCall("call spDeleteEmployeeAddressMap(?)");
			cstm.setLong(1, employeeId);
			cstm.executeUpdate();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
	}
	
	public void DeleteUnderWritingUserRuleLevelID(long employeeId, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		
		try {
			
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			cstm = conn.prepareCall("call spDeleteUnderWritingUserRuleLevelID(?)");
			cstm.setLong(1, employeeId);
			cstm.executeUpdate();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
	}
	
	public void DeleteLineofBusinessMap(long UserId, Connection conn) throws Exception  {
		
		CallableStatement		cstm				= null;
		
		try {
			
			if(conn == null)
				conn = ResourceManager.getConnection();
			
			cstm = conn.prepareCall("call spDeleteLineofBusinessMap(?)");
			cstm.setLong(1, UserId);
			cstm.executeUpdate();
			System.out.println("call DeleteLineofBusinessMap");
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
    }
	
	public  UserProfileModal ValidateUserProfile(String userName, String password, String PasswordCheck) throws Exception {
	   CallableStatement		cstm				= null;
	   Connection 				conn 				= null; 
	   ResultSet 				result 				= null;
	   UserProfileModal 		userProfileModal 	= null;
	
	   try {
		   conn = ResourceManager.getConnection();
		   cstm = conn.prepareCall("call spValidateUserProfile(?,?,?,?)");
		   cstm.setString(1, userName);
		   cstm.setString(2, password);
		   cstm.setString(3, PasswordCheck);
		   cstm.registerOutParameter(4, OracleTypes.CURSOR);
		   cstm.execute();
		   
		   result = ((OracleCallableStatement)cstm).getCursor(4);
		  
		   if(result != null) {
			   
			   if(result.next()) {
				   userProfileModal = new UserProfileModal();
                   
                   userProfileModal.setUserProfileID(result.getLong("UserID"));
                   String name = result.getString("FirstName") != null ? result.getString("FirstName").trim() : ""  
                   + result.getString("LastName") != null ? result.getString("LastName").trim() : ""
                   + result.getString("middlename") != null ? result.getString("middlename").trim() : "";
                   
                   userProfileModal.setName(name);
                   userProfileModal.setFirstName(result.getString("FirstName"));
                   userProfileModal.setEmployeeNo(result.getString("EmployeeID"));
                   userProfileModal.setUserName(result.getString("UserName"));
                   userProfileModal.setBranchID(result.getLong("BranchID"));
                   userProfileModal.setEmail(result.getString("Email"));
                   userProfileModal.setPhoneNo(result.getString("PhoneNo"));
                   userProfileModal.setMobileNo(result.getString("MobileNo"));
                   userProfileModal.setPhoneNo(result.getString("Photos"));
			   }
		   }
		
		   return userProfileModal;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
	}
	
	public List<GetUserEmployeeModel> GetAllUsersBySearch(EmployeeModal employee, String loginName) throws Exception {
		CallableStatement				cstm					= null;
		Connection 						conn 					= null; 
		ResultSet 						result 					= null;
		GetUserEmployeeModel			getUserEmployeeModel 	= null;
		List<GetUserEmployeeModel>	 	employeeModalList 		= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllUsersBySearch(?,?,?,?,?,?,?,?,?,?,?)");
			cstm.setLong(1, 	employee.getOrganisationID());
			cstm.setLong(2, 	employee.getBranchID());
			cstm.setString(3, 	employee.getFirstName());
			cstm.setString(4, 	employee.getLastName());
			cstm.setString(5, 	loginName);
			cstm.setString(6, 	employee.getEmployeeNo());
			cstm.setLong(7, 	employee.getDepartmentID());
			cstm.setLong(8, 	employee.getDesignationID());
			cstm.setLong(9, 	employee.getBranchID());
			cstm.setLong(10, 	employee.getReportingTo());
			cstm.registerOutParameter(11, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(11);
			
			if(result != null) {
				employeeModalList 	= new ArrayList<GetUserEmployeeModel>();
				
				while(result.next()) {
					getUserEmployeeModel = new GetUserEmployeeModel();
					
					getUserEmployeeModel.setOrganisationID(result.getLong("OrganisationID"));
					getUserEmployeeModel.setEmployeeID(result.getLong("EmployeeID"));
					getUserEmployeeModel.setUserID(result.getLong("UserID"));
					getUserEmployeeModel.setName(result.getString("NAME"));
					getUserEmployeeModel.setFirstName(result.getString("FirstName"));
					getUserEmployeeModel.setLastName(result.getString("LastName"));
					getUserEmployeeModel.setInitial(result.getString("MIddlename"));
					getUserEmployeeModel.setDepartment(result.getString("DEPARTMENT"));
					getUserEmployeeModel.setDesignation(result.getString("DESIGNATION"));
					getUserEmployeeModel.setBranchName(result.getString("BRANCH"));
					getUserEmployeeModel.setUserName(result.getString("UserName"));
					getUserEmployeeModel.setIsAdmin(result.getShort("IsAdmin"));
					getUserEmployeeModel.setIsSuperUser(result.getShort("IsSuperUser"));
					getUserEmployeeModel.setEmployeeNo(result.getString("EmployeeNo"));
					getUserEmployeeModel.setReportingTo(result.getLong("ReportingTo"));
					getUserEmployeeModel.setEmployeeIsActive(result.getShort("EmployeeIsActive"));
					getUserEmployeeModel.setUserIsActive(result.getShort("UserIsActive"));
					getUserEmployeeModel.setReportingTo(result.getLong("ReportingTo"));
					employeeModalList.add(getUserEmployeeModel);
				}
			}
			
			return employeeModalList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
	}
	
	public List<GetUserEmployeeModel> GetSearchUser(EmployeeModal employee, UserModal user) throws Exception {
		CallableStatement				cstm					= null;
		Connection 						conn 					= null; 
		ResultSet 						result 					= null;
		GetUserEmployeeModel			getUserEmployeeModel 	= null;
		List<GetUserEmployeeModel>	 	employeeModalList 		= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetSearchUser(?,?,?,?,?,?,?,?,?,?)");
			cstm.setLong(1, 	user.getUserTypeID());
			cstm.setString(2, 	employee.getFirstName());
			cstm.setString(3, 	employee.getLastName());
			cstm.setString(4, 	employee.getInitial());
			cstm.setLong(5, 	user.getUserID());
			cstm.setLong(6, 	employee.getBranchID());
			cstm.setLong(7, 	employee.getReportingTo());
			cstm.setLong(8, 	employee.getEmployeeID());
			cstm.setString(9, 	user.getUserName());
			
			cstm.registerOutParameter(10, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(10);
			
			if(result != null) {
				employeeModalList 	= new ArrayList<GetUserEmployeeModel>();
				
				while(result.next()) {
					getUserEmployeeModel = new GetUserEmployeeModel();
					
					getUserEmployeeModel.setUserType(result.getShort("UserType"));
					getUserEmployeeModel.setSelected(result.getInt("Selected"));
					getUserEmployeeModel.setOrganisationID(result.getLong("ORGANISATIONID"));
					getUserEmployeeModel.setEmployeeID(result.getLong("EMPLOYEEID"));
					getUserEmployeeModel.setUserID(result.getLong("USERID"));
					getUserEmployeeModel.setUserName(result.getString("USERNAME"));
					getUserEmployeeModel.setPassword(result.getString("PASSWORD"));
					getUserEmployeeModel.setIsAdmin(result.getShort("IsAdmin"));
					getUserEmployeeModel.setIsSuperUser(result.getShort("IsSuperUser"));
					getUserEmployeeModel.setFirstName(result.getString("FIRSTNAME"));
					getUserEmployeeModel.setLastName(result.getString("LASTNAME"));
					getUserEmployeeModel.setInitial(result.getString("middlename"));
					getUserEmployeeModel.setGender(result.getString("GENDER"));
					getUserEmployeeModel.setMaritalStatus(result.getInt("MARITALSTATUSID"));
					getUserEmployeeModel.setReportingTo(result.getLong("REPORTINGTO"));
					getUserEmployeeModel.setDateOfBirth(result.getTimestamp("DATEOFBIRTH"));
					getUserEmployeeModel.setDateOfJoin(result.getTimestamp("DATEOFJOIN"));
					getUserEmployeeModel.setEducationID(result.getLong("EDUCATIONID"));
					getUserEmployeeModel.setPhoneNo(result.getString("PHONENO"));
					getUserEmployeeModel.setMobileNo(result.getString("MOBILENO"));
					getUserEmployeeModel.setConferenceNo(result.getString("CONFERENCENO"));
					getUserEmployeeModel.setFaxNo(result.getString("FAXNO"));
					getUserEmployeeModel.setEmail(result.getString("EMAIL"));
					getUserEmployeeModel.setBranchName(result.getString("BranchName"));
					getUserEmployeeModel.setEmployeeIsActive(result.getShort("EmployeeIsActive"));
					getUserEmployeeModel.setUserIsActive(result.getShort("UserIsActive"));
					
					employeeModalList.add(getUserEmployeeModel);
				}
			}
			
			return employeeModalList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
	}
	
	 public String CheckAdminLogin(String userName, String password) throws SQLException {
		 CallableStatement			cstm				= null;
		 Connection 				conn 				= null; 
		 ResultSet 					result 				= null;

	   try {
         
		   conn = ResourceManager.getConnection();
		   cstm = conn.prepareCall("call spCheckAdminUserLogin(?,?,?)");
		   
		   cstm.setString(1, userName);
		   cstm.setString(2, password);
		   cstm.registerOutParameter(3, OracleTypes.CURSOR);
		   cstm.execute();
		   
		   result = ((OracleCallableStatement)cstm).getCursor(3);
		  
		   if(result != null) {
			  if(result.next()) {
				  return result.getString("status");
			  }
		   }
	   } catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
     }

	 public GetUserEmployeeModel GetLastLogin(long userId) throws Exception {
		 
		 CallableStatement			cstm				= null;
		 Connection 				conn 				= null;
		 ResultSet 					result 				= null;
		 GetUserEmployeeModel      getUserEmployeeModel = null;
		 
		 try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call spGetLastLogin(?,?)");
			 cstm.setLong(1, userId);
			 cstm.registerOutParameter(2, OracleTypes.CURSOR);
			 cstm.execute();
			 result = ((OracleCallableStatement)cstm).getCursor(2);
			 
			 if(result != null) {
				 getUserEmployeeModel = new GetUserEmployeeModel();
				 while(result.next()) {
						
					 getUserEmployeeModel.setUserID(result.getLong("UserID"));
					 getUserEmployeeModel.setFirstName(result.getString("FirstName"));
					 getUserEmployeeModel.setLastName(result.getString("LastName"));
					 getUserEmployeeModel.setInitial(result.getString("MIDDLENAME"));
					 getUserEmployeeModel.setEmployeeID(result.getLong("EmployeeID"));
					 getUserEmployeeModel.setUserName(result.getString("UserName"));
					 getUserEmployeeModel.setCurrentLoginTime(result.getTimestamp("CURRENTLOGINTIME"));
					 getUserEmployeeModel.setCreatedOn(result.getTimestamp("CreatedOn"));
					 getUserEmployeeModel.setFirstLoginTime(result.getString("FirstLogin"));
					 getUserEmployeeModel.setBranchID(result.getLong("BranchID"));
					 getUserEmployeeModel.setEmail(result.getString("Email"));
					 getUserEmployeeModel.setPhoneNo(result.getString("PhoneNo"));
					 getUserEmployeeModel.setMobileNo(result.getString("MobileNo"));
					 getUserEmployeeModel.setLastLoginTime(result.getTimestamp("LASTLOGINTIME"));
					 getUserEmployeeModel.setLineofBusinessID(result.getLong("LineofBusinessID"));
					 getUserEmployeeModel.setOrganisationID(result.getLong("OrganisationID"));
					 getUserEmployeeModel.setIsSuperUser(result.getShort("IsSuperUser"));
					 getUserEmployeeModel.setIsAdmin(result.getShort("IsAdmin"));
					 getUserEmployeeModel.setIsUnderWriter(result.getShort("IsUnderWriter"));
					 getUserEmployeeModel.setPhotos(result.getString("Photos"));
					 getUserEmployeeModel.setPassword(result.getString("Password"));
					       
				 }
			 }
			 
		 } catch(Exception e) {
			 e.printStackTrace();
			 logger.error(e.getMessage(), e);	
		 } finally {
			 cstm.close();
			 cstm	= null;
			 ResourceManager.freeConnection(conn);
			 conn	= null;	
		 }
		 return getUserEmployeeModel;
	 }
	 
	 public UserModal GetAdminInvalidUser(String Name) throws Exception {
		    
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
	
		try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call spGetAdminInvalidUser(?,?)");
			 cstm.setString(1, Name);
			 cstm.registerOutParameter(2, OracleTypes.CURSOR);
			 cstm.execute();
			 result = ((OracleCallableStatement)cstm).getCursor(2);
		    
			 if(result != null) {
				 UserModal        userModal  = new UserModal();
		    	while(result.next()) {
		    		userModal.setUserID(result.getLong("UserID"));
		    		userModal.setUserName(result.getString("UserName"));
		    		userModal.setPassword(result.getString("Password"));
		    		userModal.setInvalidLoginCount(result.getInt("InvalidLoginCount"));
		    	}
		    	return userModal;
		    }
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
		   cstm.close();
		   cstm	= null;
		   ResourceManager.freeConnection(conn);
		   conn	= null;	
		}
		return null;
	 }
	 
	public String IsUserExist(long UserID, String UserName) throws Exception { 
	   CallableStatement		cstm				= null;
	   Connection 				conn 				= null; 
	   ResultSet 				result 				= null;
		
	   try {
		   conn = ResourceManager.getConnection();
		   cstm = conn.prepareCall("call spIsUserExist(?,?,?)");
		   cstm.setLong(1, UserID);
		   cstm.setString(2, UserName);
		   cstm.registerOutParameter(3, OracleTypes.CURSOR);
		   cstm.execute();
		   
		   result = ((OracleCallableStatement)cstm).getCursor(3);
		   
		   if(result != null) {
				if(result.next()) {
					return result.getInt("exist") > 0 ? "EXIST" : "NOTEXIST"; 
				}
			}
		  
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
		 
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return  null;
	}
	
	public int IsUserEmplyeeNoExist(long EmployeID, String EmployeNo) throws Exception { 
	   CallableStatement		cstm				= null;
	   Connection 				conn 				= null; 
	   ResultSet 				result 				= null;
		
	   try {
		   conn = ResourceManager.getConnection();
		   cstm = conn.prepareCall("call spIsUserEmplyeeNoExist(?,?,?)");
		   cstm.setLong(1, EmployeID);
		   cstm.setString(2, EmployeNo);
		   cstm.registerOutParameter(3, OracleTypes.CURSOR);
		   cstm.execute();
		   
		   result = ((OracleCallableStatement)cstm).getCursor(3);
		   
		   if(result != null) {
				if(result.next()) {
					return result.getInt("ExistCount"); 
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return  0;
	}
	
	 public int IsPasswordExists(long UserID, String NewPassword) throws Exception {
		    CallableStatement		cstm				= null;
			Connection 				conn 				= null;
		    ResultSet 				result 				= null;
		   
		 try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call spIsPasswordExists(?,?,?)");
			 cstm.setLong(1, UserID);
			 cstm.setString(2, NewPassword);
			 cstm.registerOutParameter(3, OracleTypes.CURSOR);
			 cstm.execute();
			 
			 result = ((OracleCallableStatement)cstm).getCursor(3);
		   
			 if(result != null)  {
		    	while(result.next()) {
		    		return result.getInt("UserRecords");
		    	}
		    		
		    }
		 } catch(Exception e) {
			 e.printStackTrace();
				logger.error(e.getMessage(), e); 
 
		 }  finally {
			    cstm.close();
				cstm	= null;
				ResourceManager.freeConnection(conn);
				conn	= null;	 		 
		 }
		return 0; 
	 }
	 
	 public String UpdatePassword(long UserID, String UserName, String NewPassword) throws Exception {
	    CallableStatement		cstm				= null;
		Connection 				conn 				= null;
	    
	    try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call spUpdatePassword(?,?,?)");
			 cstm.setLong(1, UserID);
			 cstm.setString(2, UserName);
			 cstm.setString(3, NewPassword);
			 cstm.executeUpdate();
			 
			 return "Password Successfully Updated.";
	    } catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e); 
		} finally {
		    cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		 }
		 return "Error";
	 }
	 
	 public String UpdateAdminIsLoggedOut(long UserID) throws Exception {
		 CallableStatement		cstm				= null;
		 Connection 				conn 				= null;
		 
		 try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call spUpdateAdminIsLoggedOutByUserID(?)");
			 cstm.setLong(1, UserID);
			 cstm.executeUpdate();
			 
			 return "Success";
			 
		 } catch (Exception e) {
			 e.printStackTrace();
			 logger.error(e.getMessage(), e);
		 } finally {
			 cstm.close();
			 cstm	= null;
			 ResourceManager.freeConnection(conn);
			 conn	= null;
		 }
		 return null;
	 }
	 
	public CountryTimeZone getTimeZoneByID(long TimeZoneID) throws Exception {
	
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
	    try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call spGetCountryTimeZoneByID(?,?)");
			 cstm.setLong(1, TimeZoneID);
			 cstm.registerOutParameter(2, OracleTypes.CURSOR);
			 cstm.executeUpdate();
			 result = ((OracleCallableStatement)cstm).getCursor(2);
			    
			 if(result != null) {
				 CountryTimeZone countryTimeZone  = new CountryTimeZone();
		    	if(result.next()) {
			    		countryTimeZone.setTimeZoneID(result.getLong("TimeZoneID"));
			    		countryTimeZone.setDescription(result.getString("Description"));
			    		countryTimeZone.setShortDescription(result.getString("ShortDescription"));
			    		//countryTimeZone.setIsActive(result.getShort("IsActive"));
		    	}
		    	return countryTimeZone;
		    }
			 
	    } catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
		    cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		 }
		 return null;
	}

	public List<GetLOBUsers> GetLOBUsersToSelectCheckBox(long OrganisationID, long GroupID, int Mode) throws Exception{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<GetLOBUsers> 		userModalList 		= null;
		GetLOBUsers 			userModal 			= null;
	    
		try {
			 conn = ResourceManager.getConnection();
			 cstm = conn.prepareCall("call spGetLOBUsersToSelectCheckBox(?,?,?,?)");
			 cstm.setLong(1, OrganisationID);
			 cstm.setLong(2, GroupID);
			 cstm.setLong(3, Mode);
			 cstm.registerOutParameter(4, OracleTypes.CURSOR);
			 cstm.executeUpdate();
			 result = ((OracleCallableStatement)cstm).getCursor(4);
			    
			 if(result != null) {
				 userModalList  = new ArrayList<GetLOBUsers>();
		    	
				 while(result.next()) {
		    		userModal	= new GetLOBUsers();
		    		userModal.setSelected(result.getShort("ORGANISATIONID"));
		    		userModal.setOrganisationID(result.getLong("ORGANISATIONID"));
		    		userModal.setEmployeeID(result.getLong("EMPLOYEEID"));
		    		userModal.setUserID(result.getLong("USERID"));
		    		userModal.setUserName(result.getString("USERNAME"));
		    		userModal.setPassword(result.getString("PASSWORD"));
		    		userModal.setFirstName(result.getString("FIRSTNAME"));
		    		userModal.setLastName(result.getString("LASTNAME"));
		    		userModal.setMiddleName(result.getString("middlename"));
		    		userModal.setReportingTo(result.getLong("REPORTINGTO"));
		    		userModal.setIsEmployeeActive(result.getShort("ISEMPLOYEEACTIVE"));
		    		userModal.setIsUserActive(result.getShort("ISUSERISACTIVE"));
		    		userModal.setGroupName(result.getString("GroupName"));
		    		userModalList.add(userModal);
		    	}
		    	
		    }
			 
	    } catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
		    cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		 }
		return userModalList;
    }
	
	public EmployeeModal GetEmployeeByID(long employeeId) throws Exception{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		EmployeeModal 			employeeModal 		= null;
		UserModal 				userModal 			= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetEmployeeByID(?,?)");
			cstm.setLong(1, employeeId);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				
				if(result.next()) {
					
					employeeModal	= new EmployeeModal();
					employeeModal.setOrganisationID(result.getLong("OrganisationID"));
					employeeModal.setBranchID(result.getLong("BranchID"));
					employeeModal.setDepartmentID(result.getLong("DepartmentID"));
					employeeModal.setDesignationID(result.getLong("DesignationID"));
					employeeModal.setGradeID(result.getLong("GradeID"));
					employeeModal.setEmployeeID(result.getLong("EmployeeID"));
					employeeModal.setEmployeeNo(result.getString("EmployeeNo"));
					employeeModal.setFirstName(result.getString("Firstname"));
					employeeModal.setLastName(result.getString("LastName"));
					employeeModal.setInitial(result.getString("middlename"));
					employeeModal.setSalutationID(result.getLong("SalutationID"));
					employeeModal.setGender(result.getShort("Gender"));
					employeeModal.setMaritalStatus(result.getShort("MaritalStatusID"));
					employeeModal.setLevelID(result.getShort("LevelID"));
					employeeModal.setDateOfBirth(result.getTimestamp("DateOfBirth"));
					employeeModal.setDateOfJoin(result.getTimestamp("DateOfJoin"));
					employeeModal.setEducationID(result.getLong("EducationID"));
					employeeModal.setPhoneNo(result.getString("PhoneNo"));
					employeeModal.setMobileNo(result.getString("MobileNo"));
					employeeModal.setConferenceNo(result.getString("ConferenceNo"));
					employeeModal.setFaxNo(result.getString("FaxNo"));
					employeeModal.setEmail(result.getString("Email"));
					employeeModal.setPhotos(result.getString("Photos"));
					employeeModal.setIsActive(result.getShort("IsActive"));
					employeeModal.setAddress(result.getString("Address"));
					employeeModal.setSelectAllBranch(result.getShort("SelectAllBranch"));
					
					userModal		= new UserModal();
					userModal.setUserID(result.getLong("UserID"));
					userModal.setUserName(result.getString("UserName"));
					userModal.setIsUnderWriter(result.getShort("IsUnderWriter"));
					userModal.setPassword(result.getString("Password"));
					userModal.setIsAdmin(result.getShort("IsAdmin"));
					userModal.setIsActive(result.getShort("IsActive"));
					userModal.setDefaultLineofBusiness(result.getShort("defaultlineofbusiness"));
					userModal.setUserType(result.getShort("UserType"));
					userModal.setGroupID(result.getLong("GroupID"));
					userModal.setMainChannelID(result.getLong("MainChannelID"));
					userModal.setSubChannelID(result.getLong("SubChannelID"));
					userModal.setAgentID(result.getLong("AgentID"));
					userModal.setUsageID(result.getLong("UsageID"));
					userModal.setChannelCode(result.getString("IntermediaryCode"));
					userModal.setSubChannelAgentType(result.getString("SubChannelAgentType"));
					userModal.setAgentName(result.getString("AgentName"));
					userModal.setMainChannelCodeName(result.getString("MainChannelCodeName"));
					userModal.setSubChannelCodeName(result.getString("SubChannelCodeName"));

					employeeModal.setUserModal(userModal);
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return employeeModal;
	}
	
	public List<LineOfBusiness> GetLineofBusinessMap(long employeeId) throws Exception{
		CallableStatement			cstm				= null;
		Connection 					conn 				= null;
		ResultSet 					result 				= null;
		LineOfBusiness 				lineOfBusiness 		= null;
		List<LineOfBusiness> 		lineOfBusinessList 	= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetLineofBusinessmap(?,?)");
			cstm.setLong(1, employeeId);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				lineOfBusinessList	= new ArrayList<LineOfBusiness>();
				
				while(result.next()) {
					
					lineOfBusiness	= new LineOfBusiness();
					
					lineOfBusiness.setLineOfBusinessId(result.getInt("lineofbusinessid"));
					
					lineOfBusinessList.add(lineOfBusiness);
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return lineOfBusinessList;
	}
	
	public List<BranchModal> GetEmployeeAttachedBranchMap(long employeeId) throws Exception{
		CallableStatement			cstm				= null;
		Connection 					conn 				= null;
		ResultSet 					result 				= null;
		BranchModal 				branchModal 		= null;
		List<BranchModal> 			branchModalList 	= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetEmployeeAttachedBranchMap(?,?)");
			cstm.setLong(1, employeeId);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				branchModalList	= new ArrayList<BranchModal>();
				
				while(result.next()) {
					
					branchModal	= new BranchModal();
					
					branchModal.setBranchId(result.getLong("BranchID"));
					
					branchModalList.add(branchModal);
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return branchModalList;
	}

	public List<ReportingToModal> getAllReportingTo() throws Exception{
		CallableStatement			cstm				= null;
		Connection 					conn 				= null;
		ResultSet 					result 				= null;
		ReportingToModal 			reportingTo 			= null;
		List<ReportingToModal> 		reportingToList		= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllReportingTo(?)");
			cstm.registerOutParameter(1, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				reportingToList	= new ArrayList<ReportingToModal>();
				
				while(result.next()) {
					
					reportingTo	= new ReportingToModal();
					
					reportingTo.setDescription(result.getString("description"));
					reportingTo.setID(result.getLong("ID"));
					
					reportingToList.add(reportingTo);
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return reportingToList;
	}
	
	
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.BusinessType;

public interface IBusinessTypeDAO {
	public void saveOrUpdate(BusinessType obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<BusinessType> getAll(BusinessType filterObj) throws SQLException;
	public BusinessType get(Integer id) throws SQLException;
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.RelationshipHistory;

public interface IRelationshipHistoryDAO {
	public List<RelationshipHistory> getAll(Integer id) throws SQLException ;

}

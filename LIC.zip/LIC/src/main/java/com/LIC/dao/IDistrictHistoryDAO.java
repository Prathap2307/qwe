package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.DistrictHistory;

public interface IDistrictHistoryDAO {
	
	public List<DistrictHistory> getAll(Integer id) throws SQLException;
}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.dao.IQuestionDAO;
import com.LIC.dao.JDBCConnection;
import com.LIC.dao.QuestionDAO;
import com.LIC.model.GetQuestionModel;
import com.LIC.model.Question;
import com.LIC.model.QuestionMapModel;
import com.LIC.model.QuestionModel;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class QuestionDAO implements IQuestionDAO{
	
	static final Logger LOGGER = LogManager.getLogger(QuestionDAO.class);
	
	@Autowired
	private EntityManager em;
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	
	@Override
	public List<Question> getAll(Question filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Question> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllQuestion(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Question obj = null;
			  list = new ArrayList<Question>();
		      while (rs.next()) {
		        obj = new Question();
		        obj.setQuestionId(rs.getInt("QUESTIONID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllQuestion executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllQuestion exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	
	
	public void createQuestionInfo(QuestionModel model) {

		StoredProcedureQuery addQuestionStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateQuestion");
		addQuestionStoredProcedure.setParameter("vQuestionID", model.getQuestionId());
		addQuestionStoredProcedure.setParameter("vDescription", model.getDescription());
		addQuestionStoredProcedure.setParameter("vLOB", model.getLobId());
		addQuestionStoredProcedure.setParameter("vWeightage", model.getWeightAge());
		addQuestionStoredProcedure.setParameter("vOrderID", model.getOrderId());
		addQuestionStoredProcedure.setParameter("vCreatedBy", model.getCreatedBy());
		addQuestionStoredProcedure.setParameter("vCreatedOn", model.getCreatedOn());
		addQuestionStoredProcedure.setParameter("vShortDescription", model.getShortDescription());
		addQuestionStoredProcedure.setParameter("vIsActive", model.getIsActive());
		addQuestionStoredProcedure.getParameter("vRESULT");
		addQuestionStoredProcedure.execute();
		
		
		
		

	

}
	
	
/*	public void createQuestionMapInfo(QuestionMapModel model) {

		StoredProcedureQuery addQuestionStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateQuestionMap");
		addQuestionStoredProcedure.setParameter("vID", model.getMapId());
		addQuestionStoredProcedure.setParameter("vQuestionID", model.getOptionId());
		addQuestionStoredProcedure.setParameter("vOptionID", model.getOptionId());
		addQuestionStoredProcedure.execute();
		
		
		
		

	

}*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public List<GetQuestionModel>GetAllQuestions(Number questionId,String description) {
	    StoredProcedureQuery query = em
	           .createStoredProcedureQuery("spGetAllQuestions")
	           .registerStoredProcedureParameter("vQuestionID",Long.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("vDescription",String.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("oQues", Class.class, ParameterMode.REF_CURSOR)
	                     .setParameter("vQuestionID",questionId)
	            .setParameter("vDescription",description);

	    
	     // return query.execute() ? query.getResultList() : null;
	  
	    
	    query.execute();
	    List<Object[]> list  =  (List<Object[]>)query.getResultList();
	    List<GetQuestionModel> accList = list.stream().map(
	    		  o -> new GetQuestionModel((Number) o[0], (String) o[1],(String) o[2],(Number) o[3],(Number) o[4],(Number) o[5])).collect(Collectors.toList());
	    
	   return accList;
	   
	     
	   }
	
	
	
	
	

	
	
	
	public List<GetQuestionModel>GetAll() {
	    StoredProcedureQuery query = em
	           .createStoredProcedureQuery("spGetAllQuestion")
	         
	           .registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR);
	                  

	    
	     // return query.execute() ? query.getResultList() : null;
	  
	    
	    query.execute();
	    List<Object[]> list  =  (List<Object[]>)query.getResultList();
	    List<GetQuestionModel> accList = list.stream().map(
	    		  o -> new GetQuestionModel((Number) o[0],(Number) o[1],(String) o[2],(String) o[3],(Number) o[4],(Number) o[5],(Number) o[6],(String) o[7])).collect(Collectors.toList());
	    
	   return accList;
	   
	     
	   }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	

	
	public List<GetQuestionModel>QuestionExistOrNot(Number questionId,String description,Number lob,String shortDescription) {
	    StoredProcedureQuery query = em
	           .createStoredProcedureQuery("spIsQuestionsExists")
	           .registerStoredProcedureParameter("vQuestionID",Long.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("vDescription",String.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("vLOB",Long.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("vShortDescription",String.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("paraout", Class.class, ParameterMode.REF_CURSOR)
	    .setParameter("vQuestionID",questionId)
	    .setParameter("vDescription",description)
	    .setParameter("vLOB",lob)
	    .setParameter("vShortDescription",shortDescription);
	     return query.execute() ? query.getResultList() : null;
	  
	    
	    /*query.execute();
	    List<Object[]> list  =  (List<Object[]>)query.getResultList();
	    List<GetQuestionModel> accList = list.stream().map(
	    		  o -> new GetQuestionModel((Number) o[0], (Number) o[1],(String) o[2],(String) o[3],(Number) o[4],(Number) o[5])).collect(Collectors.toList());
	    
	   return accList;*/
	   
	     
	   }
	
	
	
	public void deleteQuestions(QuestionModel model) {

		StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteQuestion");
		query.setParameter("vQuestionID",model.getQuestionId());
		
		query.setParameter("vDELETEDBY",model.getDeletedBy());
		query.getParameter("RESULT1");
        query.execute();
	}
	
	
	
	
	
	public void deleteQuestionsMap(QuestionMapModel model) {

		StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteQuestionMapId");
		query.setParameter("vQuestionID",model.getQuestionId());
        query.execute();
	}
	
	
	
	
	
	
	public List<GetQuestionModel>GetAllQuestionsByOrderId(Number questionId,Number lob,Number orderId) {
	    StoredProcedureQuery query = em
	           .createStoredProcedureQuery("spGetQuestionsByOrderID")
	           .registerStoredProcedureParameter("vQuestionID",Long.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("vLOB",Long.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("vOrderID",Long.class, ParameterMode.IN)
	           .registerStoredProcedureParameter("oQues", Class.class, ParameterMode.REF_CURSOR)
	    .setParameter("vQuestionID",lob)
	    .setParameter("vLOB",lob)
	    .setParameter("vOrderID",orderId);
	    
	     // return query.execute() ? query.getResultList() : null;
	  
	    
	  query.execute();
	    List<Object[]> list  =  (List<Object[]>)query.getResultList();
	    List<GetQuestionModel> accList = list.stream().map(
	    		  o -> new GetQuestionModel((Number) o[0],(Number) o[1],(String) o[2],(String) o[3],(Number) o[4],(Number) o[5])).collect(Collectors.toList());
	                  return accList;
	   
	   
	   
	     
	   }
	
	
	
	
	
	
	

}

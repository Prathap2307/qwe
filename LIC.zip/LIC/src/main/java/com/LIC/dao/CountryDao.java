package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.CountryModal;
import com.LIC.resource.ResourceManager;
import com.LIC.dao.ICountryDAO;
import com.LIC.dao.JDBCConnection;
import com.LIC.model.Country;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class CountryDao implements ICountryDAO {
	
	static final Logger LOGGER = LogManager.getLogger(CountryDao.class);
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	public List<CountryModal> getAllCountries() throws Exception {

		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		CountryModal			countryModal		= null;
		List<CountryModal>		countryList			= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			
			cstm 		= conn.prepareCall("call spGetAllCountries(?) ");
			
			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);

		    if(result != null) {
		    	
		    	countryList	= new ArrayList<CountryModal>();
		    	
		    	while (result.next ()) {
		    		countryModal = new CountryModal();
		    		
		    		countryModal.setCountryId(result.getLong("CountryID"));
		    		countryModal.setCountryCode(result.getString("countryCode"));
		    		countryModal.setDescription(result.getString("description"));
		    		countryModal.setIsDeclined(result.getShort("IsDeclined"));
		    		
		    		countryList.add(countryModal);
		    	}
		    }
		
		    return countryList;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return null;
	}
	
	@Override
	public void saveOrUpdate(Country obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateCountry(?,?,?,?,?,?, ?); END;");
		  callableStatement.setInt(1, obj.getCountryId());
		  callableStatement.setString(2, obj.getDescription());
		  callableStatement.setString(3, obj.getShortDescription());
		  callableStatement.setString(4, obj.getCountryCode());
		  callableStatement.setInt(5, obj.getCreatedBy());
		  callableStatement.setInt(6, obj.getIsDeclined());
		  callableStatement.setString(7, obj.getRemarks());
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateCountry executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateCountry executed successfully.");
	}
	
	@Override
	public void delete(Integer id, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteCountry(?,?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteCountry executed successfully.");
		  LOGGER.info("SP>spDeleteCountry executed successfully.");
	} 
	
	@Override
	public List<Country> getAll(Country filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<Country> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllCountries(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  Country obj = null;
			  list = new ArrayList<Country>();
		      while (rs.next()) {
		         
		        obj = new Country();
		        obj.setCountryId(rs.getInt("CountryID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setShortDescription(rs.getString("shortDescription"));
		        obj.setCountryCode(rs.getString("CountryCode"));
		        obj.setIsDeclined(rs.getInt("IsDeclined"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllCountries executed successfully.");
			  LOGGER.info("SP>spGetAllCountries executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllCountries exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public Country get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  Country obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetCountry(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		    	System.out.println(rs.getInt("COUNTRYID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")+" | "+rs.getString("COUNTRYCODE")+" | "+rs.getString("ISDECLINED")); 
		        obj = new Country();
		        obj.setCountryId(rs.getInt("COUNTRYID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		        obj.setCountryCode(rs.getString("COUNTRYCODE"));
		        obj.setIsDeclined(rs.getInt("ISDECLINED"));
		      }
			  System.out.println("SP>spGetCountry executed successfully.");
			  LOGGER.info("SP>spGetCountry executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetCountry exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

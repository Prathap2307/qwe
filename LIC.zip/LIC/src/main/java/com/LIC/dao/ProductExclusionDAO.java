
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.model.ProductExclusion;

import oracle.jdbc.OracleTypes;

	@Repository
	public class ProductExclusionDAO implements IProductExclusionDAO{
		
		static final Logger LOGGER = LogManager.getLogger(ProductExclusionDAO.class);
		
		@Override
		public void saveOrUpdate(Connection connection,ProductExclusion obj) throws SQLException {
		
			  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertProductExclusion(?,?,?,?); END;");
			  callableStatement.setInt(1, obj.getProductID());
			  callableStatement.setString(2, obj.getDescripition());
			  callableStatement.setInt(3, obj.getCreatedBy());
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  //callableStatement.registerOutParameter(3, Types.VARCHAR);
			  callableStatement.executeUpdate();
			  LOGGER.info("SP>spInsertProductExclusion executed successfully.");
		
		}
		@Override
		public void delete(Connection connection,Integer productID) throws SQLException {	
			CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteProductExclusionByID(?,?); END;");
			  callableStatement.setInt(1, productID);
			  callableStatement.registerOutParameter(2, Types.VARCHAR); 
			  callableStatement.executeUpdate();
			  System.out.println("SP>spDeleteProductExclusionByID executed successfully.");
			  LOGGER.info("SP>spDeleteProductExclusionByID executed successfully.");
		}
}

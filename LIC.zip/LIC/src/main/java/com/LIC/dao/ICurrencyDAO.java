package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Currency;

public interface ICurrencyDAO {
	public void saveOrUpdate(Currency obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<Currency> getAll(Currency filterObj) throws SQLException;
	public Currency get(Integer id) throws SQLException;
}

package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.ProfessionHistory;

public interface IProfessionHistoryDAO {
	
	public List<ProfessionHistory> getAll(Integer id) throws SQLException;
}

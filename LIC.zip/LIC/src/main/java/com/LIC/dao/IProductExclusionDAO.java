package com.LIC.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.LIC.model.ProductExclusion;

public interface IProductExclusionDAO {
	public void saveOrUpdate(Connection connection,ProductExclusion obj) throws SQLException;
	public void delete(Connection connection,Integer productID) throws SQLException ;

}

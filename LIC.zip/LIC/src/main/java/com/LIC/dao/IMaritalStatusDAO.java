package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.MaritalStatus;

public interface IMaritalStatusDAO {
	public void saveOrUpdate(MaritalStatus obj) throws SQLException ;
	public void delete(Integer maritalStatusID, Integer deleteBy) throws SQLException;
	public List<MaritalStatus> getAll(MaritalStatus filterObj) throws SQLException;
	public MaritalStatus get(Integer maritalStatusID) throws SQLException;
}

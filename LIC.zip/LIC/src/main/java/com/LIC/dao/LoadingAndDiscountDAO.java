package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.LoadingAndDiscount;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class LoadingAndDiscountDAO implements ILoadingAndDiscountDAO {
	
	static final Logger LOGGER = LogManager.getLogger(LoadingAndDiscountDAO.class);
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	  
	@Override
	public void saveOrUpdate(LoadingAndDiscount obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertUpdateLoadingAndDiscount(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getId());
		  callableStatement.setInt(2, obj.getLineOfBusinessId());
		  callableStatement.setInt(3, obj.getProductId());
		  callableStatement.setInt(4, obj.getQuestionId());
		  callableStatement.setString(5, obj.getDescription());
		  callableStatement.setInt(6, obj.getCategoryValueId());
		  callableStatement.setInt(7, obj.getValueSpecificId());
		  callableStatement.setInt(8, obj.getTypeId());
		  callableStatement.setDouble(9, obj.getValue());
		  callableStatement.setInt(10, obj.getAppliedOn());
		  callableStatement.setDouble(11, obj.getMaximumLimit());
		  callableStatement.setDouble(12, obj.getRangeFrom());
		  callableStatement.setDouble(13, obj.getRangeTo());
		  callableStatement.setInt(14, obj.getCreatedBy());
		  callableStatement.registerOutParameter(15, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertUpdateLoadingAndDiscount executed successfully.");
		  LOGGER.info("SP>spInsertUpdateLoadingAndDiscount executed successfully.");
	}
	  
	@Override
	public void delete(Integer id, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteLoadingAndDiscount(?,?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, OracleTypes.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteLoadingAndDiscount executed successfully.");
		  LOGGER.info("SP>spDeleteLoadingAndDiscount executed successfully.");
	} 
	
	@Override
	public List<LoadingAndDiscount> getAll(LoadingAndDiscount filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<LoadingAndDiscount> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllLoadingAndDiscount(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  LoadingAndDiscount obj = null;
			  list = new ArrayList<LoadingAndDiscount>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("LOADINGDISCOUNTDESCRIPTION")+" | "+rs.getInt("CATEGORYVALUEID")+" | "+rs.getInt("TYPEID")); 
		        obj = new LoadingAndDiscount();
		        obj.setId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("LOADINGDISCOUNTDESCRIPTION"));
		        obj.setProductName(rs.getString("DESCRIPTION"));
		        obj.setCategoryValueId(rs.getInt("CATEGORYVALUEID"));
		        obj.setValueSpecificId(rs.getInt("VALUESPECIFIEDID"));
		        obj.setTypeId(rs.getInt("TYPEID"));
		        obj.setValue(rs.getDouble("VALUE"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllLoadingAndDiscount executed successfully.");
			  LOGGER.info("SP>spGetAllLoadingAndDiscount executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllLoadingAndDiscount exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public LoadingAndDiscount get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  LoadingAndDiscount obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetLoadingAndDiscount(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
			        System.out.println(rs.getInt("ID")+" | "+rs.getString("LOADINGDISCOUNTDESCRIPTION")+" | "+rs.getInt("CATEGORYVALUEID")+" | "+rs.getInt("TYPEID")); 
			        obj = new LoadingAndDiscount();
			        obj.setId(rs.getInt("ID"));
			        obj.setProductId(rs.getInt("PRODUCTID"));
			        obj.setQuestionId(rs.getInt("QUESTIONID"));
			        obj.setValueSpecificId(rs.getInt("VALUESPECIFIEDID"));
			        obj.setRangeFrom(rs.getDouble("RANGEFROM"));
			        obj.setRangeTo(rs.getDouble("RANGETO"));
			        obj.setDescription(rs.getString("LOADINGDISCOUNTDESCRIPTION"));
			        obj.setCategoryValueId(rs.getInt("CATEGORYVALUEID"));
			        obj.setTypeId(rs.getInt("TYPEID"));
			        obj.setValue(rs.getDouble("VALUE"));
			      }
			  System.out.println("SP>spGetLoadingAndDiscount executed successfully.");
			  LOGGER.info("SP>spGetLoadingAndDiscount executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetLoadingAndDiscount exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	}  
	 
}

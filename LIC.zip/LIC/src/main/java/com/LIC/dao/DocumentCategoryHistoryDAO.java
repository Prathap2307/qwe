package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.DocumentCategoryHistory;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class DocumentCategoryHistoryDAO implements IDocumentCategoryHistoryDAO {

	static final Logger LOGGER = LogManager.getLogger(DocumentCategoryHistoryDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	 
	@Override
	public List<DocumentCategoryHistory> getAll(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<DocumentCategoryHistory> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllDocumentCateryHistory(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  DocumentCategoryHistory obj = null;
			  list = new ArrayList<DocumentCategoryHistory>();
		      while (rs.next()) {
		        System.out.println(rs.getInt("ID")+" | "+rs.getString("DESCRIPTION")+" | "+rs.getString("SHORTDESCRIPTION")); 
		        obj = new DocumentCategoryHistory();
		        obj.setHistoryId(rs.getInt("HISTORYID"));
		        obj.setDocumentCategoryId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		         
		        obj.setCreatedBy(rs.getInt("CREATEDBY"));
		        if(null != rs.getString("CREATEDON") && !rs.getString("CREATEDON").isEmpty()) {
		        	obj.setCreatedOnStr(rs.getString("CREATEDON"));
		        }
		        
		        obj.setModifiedBy(rs.getInt("MODIFIEDBY"));
		        if(null != rs.getString("MODIFIEDON") && !rs.getString("MODIFIEDON").isEmpty()) {
		        	obj.setModifiedOnStr(rs.getString("MODIFIEDON"));
		        }
		        
		        obj.setDeletedBy(rs.getInt("DELETEDBY"));
		        if(null != rs.getString("DELETEDON") && !rs.getString("DELETEDON").isEmpty()) {
		        	obj.setDeletedOnStr(rs.getString("DELETEDON"));
		        }
		        obj.setIsActive(rs.getInt("ISACTIVE"));
		        obj.setRemarks(rs.getString("REMARKS"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllDocumentCateryHistory executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllDocumentCateryHistory exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	}
	
}

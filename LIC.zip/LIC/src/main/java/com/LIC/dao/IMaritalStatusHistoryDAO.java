package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.MaritalStatusHistory;
public interface IMaritalStatusHistoryDAO {
	public List<MaritalStatusHistory> getAll(Integer id) throws SQLException ;


}

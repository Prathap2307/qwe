package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Lookup;

public interface ILookupDAO {
	public List<Lookup> getAll(Lookup filterObj) throws SQLException ;

}

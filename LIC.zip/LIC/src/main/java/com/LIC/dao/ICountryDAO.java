package com.LIC.dao;

import java.sql.SQLException;
import java.util.List;

import com.LIC.model.Country;

public interface ICountryDAO {
	public void saveOrUpdate(Country obj) throws SQLException ;
	public void delete(Integer id, Integer deleteBy) throws SQLException;
	public List<Country> getAll(Country filterObj) throws SQLException;
	public Country get(Integer id) throws SQLException;
}

package com.LIC.resource;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
public class ResourceManager {

	public static final String JDBC_DRIVER_CLASS_NAME			= "spring.datasource.driver-class-name";
	
	public static final String JDBC_URL							= "spring.datasource.url";
	
	public static final String JDBC_USER_NAME					= "spring.datasource.username";
	
	public static final String JDBC_PASSWORD					= "spring.datasource.password";

	private static final String JDBC							= "application.properties";
	
	public static Connection getConnection() throws Exception {
		return getConnection(JDBC);
	}
	
	public static Connection getConnection(String fileName) throws Exception {
		Properties	properties	= null;
		
		try {
			properties = new Properties();
			properties.load(ResourceManager.class.getClassLoader().getResourceAsStream(fileName));
			Class.forName(properties.getProperty(JDBC_DRIVER_CLASS_NAME));
			
			return DriverManager.getConnection(properties.getProperty(JDBC_URL), 
					properties.getProperty(JDBC_USER_NAME), properties.getProperty(JDBC_PASSWORD));
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e);
			throw e;
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		} finally {
			properties	= null;
		}
	}	

	/**
	 * To close and existing connection.
	 * 
	 * @param conn - connection object which has to be closed
	 * @throws SQLException
	 */
	public static void freeConnection(Connection conn) throws SQLException {
		if(conn!= null && !conn.isClosed()) conn.close();
	}
	
	//Convert result set to list
	public static List resultSetToArrayList(ResultSet rs) throws SQLException{
		  ResultSetMetaData md = rs.getMetaData();
		  int columns = md.getColumnCount();
		  ArrayList list = new ArrayList(50);
		  while (rs.next()){
		     HashMap row = new HashMap(columns);
		     for(int i=1; i<=columns; ++i){           
		      row.put(md.getColumnName(i),rs.getObject(i));
		     }
		      list.add(row);
		  }

		 return list;
		}
}

package com.LIC.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PremiumRateUploadModel  implements Serializable{
	
	/**
	 * Premium Rate Upload
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String fileName;
	
	private String filePath;
	
	private String variant;
	
	private String baseBenefitAdditionalRiders;
	  
	private String ruleSetName;
     
	private String influencingFactor;
	
	private String influencingFactorType;
	
	private float minValue;
	
	private float minValue1;
	
	private float maxValue;
	
	private float maxValue1;
	
	private String spectifiedAs;
	
	private float rate;
	
	private int dataUploadId;
	
	private int isMigrated;
	
	private char status;
	
	private String errorDetails;
	
	private int headerId;
	
	private int coverageID;
	
	private int influencingFactorID;
	
	private int specifiedAsID;
	
	private int specificValuesID;
	
	private int amountTypeID;
	
	private int expressedAsID;
	
	private char coefficientType;
	
	
	
	

	public PremiumRateUploadModel(String variant, String baseBenefitAdditionalRiders, String ruleSetName,
			String influencingFactor, String influencingFactorType, float minValue, float minValue1, float maxValue,
			float maxValue1, String spectifiedAs, float rate) {
		super();
		this.variant = variant;
		this.baseBenefitAdditionalRiders = baseBenefitAdditionalRiders;
		this.ruleSetName = ruleSetName;
		this.influencingFactor = influencingFactor;
		this.influencingFactorType = influencingFactorType;
		this.minValue = minValue;
		this.minValue1 = minValue1;
		this.maxValue = maxValue;
		this.maxValue1 = maxValue1;
		this.spectifiedAs = spectifiedAs;
		this.rate = rate;
	}



	public PremiumRateUploadModel() {
		super();
		// TODO Auto-generated constructor stub
	}



	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public String getVariant() {
		return variant;
	}



	public void setVariant(String variant) {
		this.variant = variant;
	}



	public String getBaseBenefitAdditionalRiders() {
		return baseBenefitAdditionalRiders;
	}



	public void setBaseBenefitAdditionalRiders(String baseBenefitAdditionalRiders) {
		this.baseBenefitAdditionalRiders = baseBenefitAdditionalRiders;
	}



	public String getRuleSetName() {
		return ruleSetName;
	}



	public void setRuleSetName(String ruleSetName) {
		this.ruleSetName = ruleSetName;
	}



	public String getInfluencingFactor() {
		return influencingFactor;
	}



	public void setInfluencingFactor(String influencingFactor) {
		this.influencingFactor = influencingFactor;
	}



	public String getInfluencingFactorType() {
		return influencingFactorType;
	}



	public void setInfluencingFactorType(String influencingFactorType) {
		this.influencingFactorType = influencingFactorType;
	}



	public float getMinValue() {
		return minValue;
	}



	public void setMinValue(float minValue) {
		this.minValue = minValue;
	}



	public float getMinValue1() {
		return minValue1;
	}



	public void setMinValue1(float minValue1) {
		this.minValue1 = minValue1;
	}



	public float getMaxValue() {
		return maxValue;
	}



	public void setMaxValue(float maxValue) {
		this.maxValue = maxValue;
	}



	public float getMaxValue1() {
		return maxValue1;
	}



	public void setMaxValue1(float maxValue1) {
		this.maxValue1 = maxValue1;
	}



	public String getSpectifiedAs() {
		return spectifiedAs;
	}



	public void setSpecifiedAs(String SpectifiedAs) {
		spectifiedAs = spectifiedAs;
	}



	public float getRate() {
		return rate;
	}



	public void setRate(float rate) {
		this.rate = rate;
	}



	public int getDataUploadId() {
		return dataUploadId;
	}



	public void setDataUploadId(int dataUploadId) {
		this.dataUploadId = dataUploadId;
	}



	public int getIsMigrated() {
		return isMigrated;
	}



	public void setIsMigrated(int isMigrated) {
		this.isMigrated = isMigrated;
	}



	public char getStatus() {
		return status;
	}



	public void setStatus(char status) {
		this.status = status;
	}



	public String getErrorDetails() {
		return errorDetails;
	}



	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}



	public int getHeaderId() {
		return headerId;
	}



	public void setHeaderId(int headerId) {
		this.headerId = headerId;
	}



	public int getCoverageID() {
		return coverageID;
	}



	public void setCoverageID(int coverageID) {
		this.coverageID = coverageID;
	}



	public int getInfluencingFactorID() {
		return influencingFactorID;
	}



	public void setInfluencingFactorID(int influencingFactorID) {
		this.influencingFactorID = influencingFactorID;
	}



	public int getSpecifiedAsID() {
		return specifiedAsID;
	}



	public void setSpecifiedAsID(int specifiedAsID) {
		this.specifiedAsID = specifiedAsID;
	}



	public int getSpecificValuesID() {
		return specificValuesID;
	}



	public void setSpecificValuesID(int specificValuesID) {
		this.specificValuesID = specificValuesID;
	}



	public int getAmountTypeID() {
		return amountTypeID;
	}



	public void setAmountTypeID(int amountTypeID) {
		this.amountTypeID = amountTypeID;
	}



	public int getExpressedAsID() {
		return expressedAsID;
	}



	public void setExpressedAsID(int expressedAsID) {
		this.expressedAsID = expressedAsID;
	}



	public char getCoefficientType() {
		return coefficientType;
	}



	public void setCoefficientType(char coefficientType) {
		this.coefficientType = coefficientType;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	 @Override
	 public String toString() { 
		 return this.baseBenefitAdditionalRiders + ",Variant:"+ this.variant;
	}
	 
	 
	
	
	public String getFilePath() {
		return filePath;
	}



	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}



	public void setSpectifiedAs(String spectifiedAs) {
		this.spectifiedAs = spectifiedAs;
	}



	public static List<String> getColumnList() {
		List<String> list= new ArrayList<String>();
		list.add("variant");		
		list.add("baseBenefitAdditionalRiders");
		list.add("ruleSetName");
		list.add("influencingFactor");
		list.add("influencingFactorType");	
		list.add("MinimumValue");
		list.add("MinimumValue1");
		list.add("MaximumValue");
		list.add("MaximumValue1");
		list.add("SpectifiedAs");
		list.add("rate");
		return list;
		
	}
      

}


package com.LIC.model;

import java.io.Serializable;


public class Coefficient extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer coefficientId;
	private String description; 
	
	
	public Integer getCoefficientId() {
		return coefficientId;
	}
	public void setCoefficientId(Integer coefficientId) {
		this.coefficientId = coefficientId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
}

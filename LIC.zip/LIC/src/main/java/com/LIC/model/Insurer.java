			
package com.LIC.model;

import java.io.Serializable;
import java.sql.Date;
 
public class Insurer extends RecordModifier  implements Serializable {
	private static final long serialVersionUID = 1L;

			private Integer insurerID;
			private String insurerName;
			private Integer lineOfBusinessID;
			private Date dateOfCommencement;
			private String geographicalPresence;
			private Integer distributionID;
			private String logo;
			private Integer addressID;
			private String collectionGLCode;
			private String paymentGLCode;
			private String freshGLCode;
			private String aPOnlineGLCode;
			private String lICPremiumPaymentGLCode;
			private String revivalGLCode;
			private String medicalGLCode;
			private String claimGLCode;
			private Double triggerLimitforStampDuty;
			private String intimationEmailaddressforStampDuty;
			private String intimationMobileNumberforStampDuty;
			private String pANNo;
			private String gSTNo;
			
			public Integer getInsurerID() {
				return insurerID;
			}
			public void setInsurerID(Integer insurerID) {
				this.insurerID = insurerID;
			}
			public String getInsurerName() {
				return insurerName;
			}
			public void setInsurerName(String insurerName) {
				this.insurerName = insurerName;
			}
			public Integer getLineOfBusinessID() {
				return lineOfBusinessID;
			}
			public void setLineOfBusinessID(Integer lineOfBusinessID) {
				this.lineOfBusinessID = lineOfBusinessID;
			}
			public Date getDateOfCommencement() {
				return dateOfCommencement;
			}
			public void setDateOfCommencement(Date dateOfCommencement) {
				this.dateOfCommencement = dateOfCommencement;
			}
			public String getGeographicalPresence() {
				return geographicalPresence;
			}
			public void setGeographicalPresence(String geographicalPresence) {
				this.geographicalPresence = geographicalPresence;
			}
			public Integer getDistributionID() {
				return distributionID;
			}
			public void setDistributionID(Integer distributionID) {
				this.distributionID = distributionID;
			}
			public String getLogo() {
				return logo;
			}
			public void setLogo(String logo) {
				this.logo = logo;
			}
			public Integer getAddressID() {
				return addressID;
			}
			public void setAddressID(Integer addressID) {
				this.addressID = addressID;
			}
			public String getCollectionGLCode() {
				return collectionGLCode;
			}
			public void setCollectionGLCode(String collectionGLCode) {
				this.collectionGLCode = collectionGLCode;
			}
			public String getPaymentGLCode() {
				return paymentGLCode;
			}
			public void setPaymentGLCode(String paymentGLCode) {
				this.paymentGLCode = paymentGLCode;
			}
			public String getFreshGLCode() {
				return freshGLCode;
			}
			public void setFreshGLCode(String freshGLCode) {
				this.freshGLCode = freshGLCode;
			}
			public String getaPOnlineGLCode() {
				return aPOnlineGLCode;
			}
			public void setaPOnlineGLCode(String aPOnlineGLCode) {
				this.aPOnlineGLCode = aPOnlineGLCode;
			}
			public String getlICPremiumPaymentGLCode() {
				return lICPremiumPaymentGLCode;
			}
			public void setlICPremiumPaymentGLCode(String lICPremiumPaymentGLCode) {
				this.lICPremiumPaymentGLCode = lICPremiumPaymentGLCode;
			}
			public String getRevivalGLCode() {
				return revivalGLCode;
			}
			public void setRevivalGLCode(String revivalGLCode) {
				this.revivalGLCode = revivalGLCode;
			}
			public String getMedicalGLCode() {
				return medicalGLCode;
			}
			public void setMedicalGLCode(String medicalGLCode) {
				this.medicalGLCode = medicalGLCode;
			}
			public String getClaimGLCode() {
				return claimGLCode;
			}
			public void setClaimGLCode(String claimGLCode) {
				this.claimGLCode = claimGLCode;
			}
			public Double getTriggerLimitforStampDuty() {
				return triggerLimitforStampDuty;
			}
			public void setTriggerLimitforStampDuty(Double triggerLimitforStampDuty) {
				this.triggerLimitforStampDuty = triggerLimitforStampDuty;
			}
			public String getIntimationEmailaddressforStampDuty() {
				return intimationEmailaddressforStampDuty;
			}
			public void setIntimationEmailaddressforStampDuty(String intimationEmailaddressforStampDuty) {
				this.intimationEmailaddressforStampDuty = intimationEmailaddressforStampDuty;
			}
			public String getIntimationMobileNumberforStampDuty() {
				return intimationMobileNumberforStampDuty;
			}
			public void setIntimationMobileNumberforStampDuty(String intimationMobileNumberforStampDuty) {
				this.intimationMobileNumberforStampDuty = intimationMobileNumberforStampDuty;
			}
			public String getpANNo() {
				return pANNo;
			}
			public void setpANNo(String pANNo) {
				this.pANNo = pANNo;
			}
			public String getgSTNo() {
				return gSTNo;
			}
			public void setgSTNo(String gSTNo) {
				this.gSTNo = gSTNo;
			}
			}
package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DashBoard {
	 @Id 
	 private Number id;
	private Number totalClientCreated;
	private Number totalPoliciesCreated;
	private Number totalSumAssured;
	private Number totalPremiumAmount;
	private Number claimIntimated;
	private Number claimSettled;
	
	
	

	public Number getTotalPoliciesCreated() {
		return totalPoliciesCreated;
	}

	public void setTotalPoliciesCreated(Number totalPoliciesCreated) {
		this.totalPoliciesCreated = totalPoliciesCreated;
	}

	public Number getTotalSumAssured() {
		return totalSumAssured;
	}

	public void setTotalSumAssured(Number totalSumAssured) {
		this.totalSumAssured = totalSumAssured;
	}

	public Number getTotalPremiumAmount() {
		return totalPremiumAmount;
	}

	public void setTotalPremiumAmount(Number totalPremiumAmount) {
		this.totalPremiumAmount = totalPremiumAmount;
	}

	public Number getClaimIntimated() {
		return claimIntimated;
	}

	public void setClaimIntimated(Number claimIntimated) {
		this.claimIntimated = claimIntimated;
	}

	public Number getClaimSettled() {
		return claimSettled;
	}

	public void setClaimSettled(Number claimSettled) {
		this.claimSettled = claimSettled;
	}

	public Number getTotalClientCreated() {
		return totalClientCreated;
	}

	public void setTotalClientCreated(Number totalClientCreated) {
		this.totalClientCreated = totalClientCreated;
	}

	public DashBoard(Number totalClientCreated) {
		super();
		this.totalClientCreated = totalClientCreated;
	}
	
	
	
	
	
	public DashBoard(Number totalPoliciesCreated, Number totalSumAssured, Number totalPremiumAmount,
			Number claimIntimated, Number claimSettled) {
		super();
		this.totalPoliciesCreated = totalPoliciesCreated;
		this.totalSumAssured = totalSumAssured;
		this.totalPremiumAmount = totalPremiumAmount;
		this.claimIntimated = claimIntimated;
		this.claimSettled = claimSettled;
	}

	public DashBoard() {}
	
	
	
}

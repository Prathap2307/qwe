package com.LIC.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class QuotationModel implements Serializable{
	
	/**
	 * Sales Hierarchy Details
	 */
	private static final long serialVersionUID = 1L;
	
	private int lineOfBusinessID;
	private int branchID;
	private int quotationID ;
	private Date quotationDate;
	private String quotationNo = "";
	private int salesHierarchyID;
	private int subChannelID;
	private int mainChannelID;
	private String salesType ;
	private int quotationPartyMapID;
	private int productID;
	private int planID=0;
	private int sumInsured;
	private Date policyStartDate;
	private Date policyEndDate;
	private Date policyIssueDate;
	private int premiumPaymentTerm;
	private int policyTerm ;
	private int premiumPaymentFrequencyID;
	private int basePremium;
	private int netPremium;
	private int netPayableAmount;
	private int discretionaryPercentage;
	private String discretionaryDiscountLoading;
	private int discretionaryAmount;
	private int isServiceTax ;
	private String loanID;
	private int outstandingLoanAmt;
	private int rateOfInterest;
	private int eMITypeID;
	private int loanTenture;
	private int loanTypeID;
	private int eMI;
	private int statusID;
    private int createdBy  ;    
	private Date createdOn;
	private int isActive;
	private int typeID;
	private int totalMembers ;
	private int totalSumInsured ;
	private String fileName;
	private int fileHeaderID	;
	private String remarks;
	private int quotationVersion;

	
	

	public QuotationModel() {
		super();
		
	}




	public int getLineOfBusinessID() {
		return lineOfBusinessID;
	}




	public void setLineOfBusinessID(int lineOfBusinessID) {
		this.lineOfBusinessID = lineOfBusinessID;
	}




	public int getBranchID() {
		return branchID;
	}




	public void setBranchID(int branchID) {
		this.branchID = branchID;
	}




	public int getQuotationID() {
		return quotationID;
	}




	public void setQuotationID(int quotationID) {
		this.quotationID = quotationID;
	}




	public Date getQuotationDate() {
		return quotationDate;
	}




	public void setQuotationDate(Date quotationDate) {
		this.quotationDate = quotationDate;
	}




	public String getQuotationNo() {
		return quotationNo;
	}




	public void setQuotationNo(String quotationNo) {
		this.quotationNo = quotationNo;
	}




	public int getSalesHierarchyID() {
		return salesHierarchyID;
	}




	public void setSalesHierarchyID(int salesHierarchyID) {
		this.salesHierarchyID = salesHierarchyID;
	}




	public int getSubChannelID() {
		return subChannelID;
	}




	public void setSubChannelID(int subChannelID) {
		this.subChannelID = subChannelID;
	}




	public int getMainChannelID() {
		return mainChannelID;
	}




	public void setMainChannelID(int mainChannelID) {
		this.mainChannelID = mainChannelID;
	}




	public String getSalesType() {
		return salesType;
	}




	public void setSalesType(String salesType) {
		this.salesType = salesType;
	}




	public int getQuotationPartyMapID() {
		return quotationPartyMapID;
	}




	public void setQuotationPartyMapID(int quotationPartyMapID) {
		this.quotationPartyMapID = quotationPartyMapID;
	}




	public int getProductID() {
		return productID;
	}




	public void setProductID(int productID) {
		this.productID = productID;
	}




	public int getPlanID() {
		return planID;
	}




	public void setPlanID(int planID) {
		this.planID = planID;
	}




	public int getSumInsured() {
		return sumInsured;
	}




	public void setSumInsured(int sumInsured) {
		this.sumInsured = sumInsured;
	}




	public Date getPolicyStartDate() {
		return policyStartDate;
	}




	public void setPolicyStartDate(Date policyStartDate) {
		this.policyStartDate = policyStartDate;
	}




	public Date getPolicyEndDate() {
		return policyEndDate;
	}




	public void setPolicyEndDate(Date policyEndDate) {
		this.policyEndDate = policyEndDate;
	}




	public Date getPolicyIssueDate() {
		return policyIssueDate;
	}




	public void setPolicyIssueDate(Date policyIssueDate) {
		this.policyIssueDate = policyIssueDate;
	}




	public int getPremiumPaymentTerm() {
		return premiumPaymentTerm;
	}




	public void setPremiumPaymentTerm(int premiumPaymentTerm) {
		this.premiumPaymentTerm = premiumPaymentTerm;
	}




	public int getPolicyTerm() {
		return policyTerm;
	}




	public void setPolicyTerm(int policyTerm) {
		this.policyTerm = policyTerm;
	}




	public int getPremiumPaymentFrequencyID() {
		return premiumPaymentFrequencyID;
	}




	public void setPremiumPaymentFrequencyID(int premiumPaymentFrequencyID) {
		this.premiumPaymentFrequencyID = premiumPaymentFrequencyID;
	}




	public int getBasePremium() {
		return basePremium;
	}




	public void setBasePremium(int basePremium) {
		this.basePremium = basePremium;
	}




	public int getNetPremium() {
		return netPremium;
	}




	public void setNetPremium(int netPremium) {
		this.netPremium = netPremium;
	}




	public int getNetPayableAmount() {
		return netPayableAmount;
	}




	public void setNetPayableAmount(int netPayableAmount) {
		this.netPayableAmount = netPayableAmount;
	}




	public int getDiscretionaryPercentage() {
		return discretionaryPercentage;
	}




	public void setDiscretionaryPercentage(int discretionaryPercentage) {
		this.discretionaryPercentage = discretionaryPercentage;
	}




	public String getDiscretionaryDiscountLoading() {
		return discretionaryDiscountLoading;
	}




	public void setDiscretionaryDiscountLoading(String discretionaryDiscountLoading) {
		this.discretionaryDiscountLoading = discretionaryDiscountLoading;
	}




	public int getDiscretionaryAmount() {
		return discretionaryAmount;
	}




	public void setDiscretionaryAmount(int discretionaryAmount) {
		this.discretionaryAmount = discretionaryAmount;
	}




	public int getIsServiceTax() {
		return isServiceTax;
	}




	public void setIsServiceTax(int isServiceTax) {
		this.isServiceTax = isServiceTax;
	}




	public String getLoanID() {
		return loanID;
	}




	public void setLoanID(String loanID) {
		this.loanID = loanID;
	}




	public int getOutstandingLoanAmt() {
		return outstandingLoanAmt;
	}




	public void setOutstandingLoanAmt(int outstandingLoanAmt) {
		this.outstandingLoanAmt = outstandingLoanAmt;
	}




	public int getRateOfInterest() {
		return rateOfInterest;
	}




	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}




	public int geteMITypeID() {
		return eMITypeID;
	}




	public void seteMITypeID(int eMITypeID) {
		this.eMITypeID = eMITypeID;
	}




	public int getLoanTenture() {
		return loanTenture;
	}




	public void setLoanTenture(int loanTenture) {
		this.loanTenture = loanTenture;
	}




	public int getLoanTypeID() {
		return loanTypeID;
	}




	public void setLoanTypeID(int loanTypeID) {
		this.loanTypeID = loanTypeID;
	}




	public int geteMI() {
		return eMI;
	}




	public void seteMI(int eMI) {
		this.eMI = eMI;
	}




	public int getStatusID() {
		return statusID;
	}




	public void setStatusID(int statusID) {
		this.statusID = statusID;
	}




	public int getCreatedBy() {
		return createdBy;
	}




	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}




	public Date getCreatedOn() {
		return createdOn;
	}




	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}




	public int getIsActive() {
		return isActive;
	}




	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}




	public int getTypeID() {
		return typeID;
	}




	public void setTypeID(int typeID) {
		this.typeID = typeID;
	}




	public int getTotalMembers() {
		return totalMembers;
	}




	public void setTotalMembers(int totalMembers) {
		this.totalMembers = totalMembers;
	}




	public int getTotalSumInsured() {
		return totalSumInsured;
	}




	public void setTotalSumInsured(int totalSumInsured) {
		this.totalSumInsured = totalSumInsured;
	}




	public String getFileName() {
		return fileName;
	}




	public void setFileName(String fileName) {
		this.fileName = fileName;
	}




	public int getFileHeaderID() {
		return fileHeaderID;
	}




	public void setFileHeaderID(int fileHeaderID) {
		this.fileHeaderID = fileHeaderID;
	}




	public String getRemarks() {
		return remarks;
	}




	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}




	public int getQuotationVersion() {
		return quotationVersion;
	}




	public void setQuotationVersion(int quotationVersion) {
		this.quotationVersion = quotationVersion;
	}

	
	public static List<String> getMemberUploadColumnList() {
		List<String> list = new ArrayList<String>();
		list.add("Type");
		list.add("SchemeNo");
		list.add("EmployeeNo");
		list.add("UniqueID");
		list.add("Title");
		list.add("FirstName");
		list.add("MiddleName");
		list.add("LastName");
		list.add("DateOfBirth");
		list.add("DateOfJoining");
		list.add("SchemeJoiningDate");
		list.add("NBIntimationDate");
		list.add("Age");
		list.add("BasicSalary");
		list.add("Gender");
		list.add("EmailID");
		list.add("AddressType");
		list.add("Address1");
		list.add("Address2");
		list.add("Address3");
		list.add("PinCode");
		list.add("City");
		list.add("State");
		list.add("Country");
		list.add("PhoneNumber");
		list.add("MobileNumber");
		list.add("PanNo");
		list.add("BenefitOption");
		list.add("GPSSumAssured");
		list.add("GPSRiderAD");
		list.add("GPSRiderADD");
		list.add("GPSRiderTPD");
		list.add("GPSRiderAT");
		list.add("GPSRiderCI4");
		list.add("GPSRiderCIRC");
		list.add("GPSRiderCIP");		
		list.add("GPSRiderCIA");
		list.add("GPSRiderTIP");
		list.add("GPSRiderATIR");
		list.add("SIngleJointLife");
		list.add("BenefitTerm");
		list.add("TenureOfTheLoan");
		list.add("PremiumTerm");
		list.add("NomineeEffectiveDate");
		list.add("NomineeName1");
		list.add("NomineeRelationship1");
		list.add("NomineePercentage1");
		list.add("NomineeName2");
		list.add("NomineeRelationship2");
		list.add("NomineePercentage2");
		list.add("NomineeName3");
		list.add("NomineeRelationship3");
		list.add("NomineePercentage3");
		list.add("NomineeName4");
		list.add("NomineeRelationship4");
		list.add("NomineePercentage4");
		list.add("BranchCodeOfBank");
		list.add("PremiumReceived");
		list.add("DateOfDisbursementOfLoan");
		list.add("UnderwritingDocumentType");
		list.add("HDFDate");
		list.add("TypeOfLoan");
		list.add("OccupationName");
		list.add("Location");
		list.add("IsWindowPeriodApplicable");
		list.add("Grade");
		list.add("TypeOfClaim");
		list.add("ClaimPayOutOption");
		list.add("OccupationRisk");
		list.add("PaymentFrequency");

		return list;

	}

}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
public class PrivilegesModal implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public String toString() {
		return "PrivilegesModal [userRoleID=" + userRoleID + ", groupRoleID=" + groupRoleID + ", moduleID=" + moduleID
				+ ", featureID=" + featureID + ", userID=" + userID + ", departmentID=" + departmentID
				+ ", designationID=" + designationID + ", groupID=" + groupID + ", privilegesID=" + privilegesID
				+ ", userRoles=" + userRoles + ", groupRoles=" + groupRoles + ", type=" + type + ", createdBy="
				+ createdBy + ", createdOn=" + createdOn + "]";
	}
	private long       userRoleID;
	private long       groupRoleID;
	private long       moduleID;
	private long       featureID;
	private long       userID;
	private long       departmentID;
	private long       designationID;
	private long       groupID;
	private long       privilegesID;
	private String     userRoles;
    private String     groupRoles;
	private long       type;
	private long       createdBy;
	private Timestamp  createdOn;
	private long  		lineOfBusinessID;
	
	public long getUserRoleID() {
		return userRoleID;
	}
	public long getGroupRoleID() {
		return groupRoleID;
	}
	public long getModuleID() {
		return moduleID;
	}
	public long getFeatureID() {
		return featureID;
	}
	public long getUserID() {
		return userID;
	}
	public long getDepartmentID() {
		return departmentID;
	}
	public long getDesignationID() {
		return designationID;
	}
	public long getGroupID() {
		return groupID;
	}
	public long getPrivilegesID() {
		return privilegesID;
	}
	public String getUserRoles() {
		return userRoles;
	}
	public String getGroupRoles() {
		return groupRoles;
	}
	public long getType() {
		return type;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public void setUserRoleID(long userRoleID) {
		this.userRoleID = userRoleID;
	}
	public void setGroupRoleID(long groupRoleID) {
		this.groupRoleID = groupRoleID;
	}
	public void setModuleID(long moduleID) {
		this.moduleID = moduleID;
	}
	public void setFeatureID(long featureID) {
		this.featureID = featureID;
	}
	public void setUserID(long userID) {
		this.userID = userID;
	}
	public void setDepartmentID(long departmentID) {
		this.departmentID = departmentID;
	}
	public void setDesignationID(long designationID) {
		this.designationID = designationID;
	}
	public void setGroupID(long groupID) {
		this.groupID = groupID;
	}
	public void setPrivilegesID(long privilegesID) {
		this.privilegesID = privilegesID;
	}
	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}
	public void setGroupRoles(String groupRoles) {
		this.groupRoles = groupRoles;
	}
	public void setType(long type) {
		this.type = type;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public long getLineOfBusinessID() {
		return lineOfBusinessID;
	}
	public void setLineOfBusinessID(long lineOfBusinessID) {
		this.lineOfBusinessID = lineOfBusinessID;
	}
	
}

package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetGroupDetailsModel {
	@Id
	private Number partyID;
	private String firstName;
	private Number groupID;
	private String groupName;
	private String customerGroupID;
	private String coreBusiness;
	private Number salutationID;
	private String contactFirstName;
	private String contactMiddleName;
	private String contactLastName;
	private String contactNumber;
	private Number masterPolicyAgreement;
	private String agreementStartDate;
	private String agreementEndDate;
	private Number branchID;
	private Number parentGroupID;
	private Number hierarchyID;
	private String panNo;
	private String gstNo;
	private Number userID;
	
	
	public GetGroupDetailsModel()
	{}
	
	public GetGroupDetailsModel(Number partyID, String firstName, Number groupID, String groupName,
			String customerGroupID, String coreBusiness, Number salutationID, String contactFirstName,
			String contactMiddleName, String contactLastName, String contactNumber, Number masterPolicyAgreement,
			String agreementStartDate, String agreementEndDate, Number branchID, Number parentGroupID,
			Number hierarchyID, String panNo, String gstNo) {
		super();
		this.partyID = partyID;
		this.firstName = firstName;
		this.groupID = groupID;
		this.groupName = groupName;
		this.customerGroupID = customerGroupID;
		this.coreBusiness = coreBusiness;
		this.salutationID = salutationID;
		this.contactFirstName = contactFirstName;
		this.contactMiddleName = contactMiddleName;
		this.contactLastName = contactLastName;
		this.contactNumber = contactNumber;
		this.masterPolicyAgreement = masterPolicyAgreement;
		this.agreementStartDate = agreementStartDate;
		this.agreementEndDate = agreementEndDate;
		this.branchID = branchID;
		this.parentGroupID = parentGroupID;
		this.hierarchyID = hierarchyID;
		this.panNo = panNo;
		this.gstNo = gstNo;
	}
	
	public Number getUserID() {
		return userID;
	}
	public void setUserID(Number userID) {
		this.userID = userID;
	}
	public Number getPartyID() {
		return partyID;
	}
	public void setPartyID(Number partyID) {
		this.partyID = partyID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Number getGroupID() {
		return groupID;
	}
	public void setGroupID(Number groupID) {
		this.groupID = groupID;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCustomerGroupID() {
		return customerGroupID;
	}
	public void setCustomerGroupID(String customerGroupID) {
		this.customerGroupID = customerGroupID;
	}
	public String getCoreBusiness() {
		return coreBusiness;
	}
	public void setCoreBusiness(String coreBusiness) {
		this.coreBusiness = coreBusiness;
	}
	public Number getSalutationID() {
		return salutationID;
	}
	public void setSalutationID(Number salutationID) {
		this.salutationID = salutationID;
	}
	public String getContactFirstName() {
		return contactFirstName;
	}
	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}
	public String getContactMiddleName() {
		return contactMiddleName;
	}
	public void setContactMiddleName(String contactMiddleName) {
		this.contactMiddleName = contactMiddleName;
	}
	public String getContactLastName() {
		return contactLastName;
	}
	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Number getMasterPolicyAgreement() {
		return masterPolicyAgreement;
	}
	public void setMasterPolicyAgreement(Number masterPolicyAgreement) {
		this.masterPolicyAgreement = masterPolicyAgreement;
	}
	public String getAgreementStartDate() {
		return agreementStartDate;
	}
	public void setAgreementStartDate(String agreementStartDate) {
		this.agreementStartDate = agreementStartDate;
	}
	public String getAgreementEndDate() {
		return agreementEndDate;
	}
	public void setAgreementEndDate(String agreementEndDate) {
		this.agreementEndDate = agreementEndDate;
	}
	public Number getBranchID() {
		return branchID;
	}
	public void setBranchID(Number branchID) {
		this.branchID = branchID;
	}
	public Number getParentGroupID() {
		return parentGroupID;
	}
	public void setParentGroupID(Number parentGroupID) {
		this.parentGroupID = parentGroupID;
	}
	public Number getHierarchyID() {
		return hierarchyID;
	}
	public void setHierarchyID(Number hierarchyID) {
		this.hierarchyID = hierarchyID;
	}
	public String getpANNo() {
		return panNo;
	}
	public void setpANNo(String pANNo) {
		this.panNo = pANNo;
	}
	public String getGstNo() {
		return gstNo;
	}
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}
	
}

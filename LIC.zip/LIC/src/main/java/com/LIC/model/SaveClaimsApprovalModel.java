package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

/*
 * @Author = "671621"
 */
@Entity
public class SaveClaimsApprovalModel {
	
	@Id
	private String vClaimID;
	private int vIsDeductible;
	private float vDeductibleAmount;
	private float vAccountBalance;
	private float vAmountDeducted;
	private float vAmountAdded;
	private float vTotalApprovedAmount;
	private float vTotalAmountPayable;
	private float vPreviousBalanceAmount;
	private float vProfessionalCharges;
	private float vProfessionalServiceTax;
	private float vTotalProfessionalCharges;
	private float vSurveyorIncidentalCharges;
	
	private int vCoveargeID; 
	private int vBenefitID;
	private float vEligibleAmount;
	private String vLimitType;
	private float vActualExpenses;
	private float vApprovedAmount;
	private float vTotApprovedAmmount;
	private int vCreatedBy;
	private Date vCreatedOn;
	private int vIsActive;
	
	private int vTransactionID;
	private int vLineOfBusinessID;
	private int vPartyID;
	private int vApplicationID;
	private int vProductID;
	private int vCoverageID;
	private int vBenefitsID;
	private float vLmitPerYear;
	private float vClaimedamount;
	private float vPreviousClaimedamount;
	private float vPreviousApprovedAmount;
	private float vBalanceAmount;
	
	public String getvClaimID() {
		return vClaimID;
	}
	public void setvClaimID(String vClaimID) {
		this.vClaimID = vClaimID;
	}
	public int getvIsDeductible() {
		return vIsDeductible;
	}
	public void setvIsDeductible(int vIsDeductible) {
		this.vIsDeductible = vIsDeductible;
	}
	public float getvDeductibleAmount() {
		return vDeductibleAmount;
	}
	public void setvDeductibleAmount(float vDeductibleAmount) {
		this.vDeductibleAmount = vDeductibleAmount;
	}
	public float getvAccountBalance() {
		return vAccountBalance;
	}
	public void setvAccountBalance(float vAccountBalance) {
		this.vAccountBalance = vAccountBalance;
	}
	public float getvAmountDeducted() {
		return vAmountDeducted;
	}
	public void setvAmountDeducted(float vAmountDeducted) {
		this.vAmountDeducted = vAmountDeducted;
	}
	public float getvAmountAdded() {
		return vAmountAdded;
	}
	public void setvAmountAdded(float vAmountAdded) {
		this.vAmountAdded = vAmountAdded;
	}
	public float getvTotalApprovedAmount() {
		return vTotalApprovedAmount;
	}
	public void setvTotalApprovedAmount(float vTotalApprovedAmount) {
		this.vTotalApprovedAmount = vTotalApprovedAmount;
	}
	public float getvTotalAmountPayable() {
		return vTotalAmountPayable;
	}
	public void setvTotalAmountPayable(float vTotalAmountPayable) {
		this.vTotalAmountPayable = vTotalAmountPayable;
	}
	public float getvPreviousBalanceAmount() {
		return vPreviousBalanceAmount;
	}
	public void setvPreviousBalanceAmount(float vPreviousBalanceAmount) {
		this.vPreviousBalanceAmount = vPreviousBalanceAmount;
	}
	public float getvProfessionalCharges() {
		return vProfessionalCharges;
	}
	public void setvProfessionalCharges(float vProfessionalCharges) {
		this.vProfessionalCharges = vProfessionalCharges;
	}
	public float getvProfessionalServiceTax() {
		return vProfessionalServiceTax;
	}
	public void setvProfessionalServiceTax(float vProfessionalServiceTax) {
		this.vProfessionalServiceTax = vProfessionalServiceTax;
	}
	public float getvTotalProfessionalCharges() {
		return vTotalProfessionalCharges;
	}
	public void setvTotalProfessionalCharges(float vTotalProfessionalCharges) {
		this.vTotalProfessionalCharges = vTotalProfessionalCharges;
	}
	public float getvSurveyorIncidentalCharges() {
		return vSurveyorIncidentalCharges;
	}
	public void setvSurveyorIncidentalCharges(float vSurveyorIncidentalCharges) {
		this.vSurveyorIncidentalCharges = vSurveyorIncidentalCharges;
	}
	public int getvCoveargeID() {
		return vCoveargeID;
	}
	public void setvCoveargeID(int vCoveargeID) {
		this.vCoveargeID = vCoveargeID;
	}
	public int getvBenefitID() {
		return vBenefitID;
	}
	public void setvBenefitID(int vBenefitID) {
		this.vBenefitID = vBenefitID;
	}
	public float getvEligibleAmount() {
		return vEligibleAmount;
	}
	public void setvEligibleAmount(float vEligibleAmount) {
		this.vEligibleAmount = vEligibleAmount;
	}
	public String getvLimitType() {
		return vLimitType;
	}
	public void setvLimitType(String vLimitType) {
		this.vLimitType = vLimitType;
	}
	public float getvActualExpenses() {
		return vActualExpenses;
	}
	public void setvActualExpenses(float vActualExpenses) {
		this.vActualExpenses = vActualExpenses;
	}
	public float getvApprovedAmount() {
		return vApprovedAmount;
	}
	public void setvApprovedAmount(float vApprovedAmount) {
		this.vApprovedAmount = vApprovedAmount;
	}
	public float getvTotApprovedAmmount() {
		return vTotApprovedAmmount;
	}
	public void setvTotApprovedAmmount(float vTotApprovedAmmount) {
		this.vTotApprovedAmmount = vTotApprovedAmmount;
	}
	public int getvCreatedBy() {
		return vCreatedBy;
	}
	public void setvCreatedBy(int vCreatedBy) {
		this.vCreatedBy = vCreatedBy;
	}
	public Date getvCreatedOn() {
		return vCreatedOn;
	}
	public void setvCreatedOn(Date vCreatedOn) {
		this.vCreatedOn = vCreatedOn;
	}
	public int getvIsActive() {
		return vIsActive;
	}
	public void setvIsActive(int vIsActive) {
		this.vIsActive = vIsActive;
	}
	public int getvTransactionID() {
		return vTransactionID;
	}
	public void setvTransactionID(int vTransactionID) {
		this.vTransactionID = vTransactionID;
	}
	public int getvLineOfBusinessID() {
		return vLineOfBusinessID;
	}
	public void setvLineOfBusinessID(int vLineOfBusinessID) {
		this.vLineOfBusinessID = vLineOfBusinessID;
	}
	public int getvPartyID() {
		return vPartyID;
	}
	public void setvPartyID(int vPartyID) {
		this.vPartyID = vPartyID;
	}
	public int getvApplicationID() {
		return vApplicationID;
	}
	public void setvApplicationID(int vApplicationID) {
		this.vApplicationID = vApplicationID;
	}
	public int getvProductID() {
		return vProductID;
	}
	public void setvProductID(int vProductID) {
		this.vProductID = vProductID;
	}
	public int getvCoverageID() {
		return vCoverageID;
	}
	public void setvCoverageID(int vCoverageID) {
		this.vCoverageID = vCoverageID;
	}
	public int getvBenefitsID() {
		return vBenefitsID;
	}
	public void setvBenefitsID(int vBenefitsID) {
		this.vBenefitsID = vBenefitsID;
	}
	public float getvLmitPerYear() {
		return vLmitPerYear;
	}
	public void setvLmitPerYear(float vLmitPerYear) {
		this.vLmitPerYear = vLmitPerYear;
	}
	public float getvClaimedamount() {
		return vClaimedamount;
	}
	public void setvClaimedamount(float vClaimedamount) {
		this.vClaimedamount = vClaimedamount;
	}
	public float getvPreviousClaimedamount() {
		return vPreviousClaimedamount;
	}
	public void setvPreviousClaimedamount(float vPreviousClaimedamount) {
		this.vPreviousClaimedamount = vPreviousClaimedamount;
	}
	public float getvPreviousApprovedAmount() {
		return vPreviousApprovedAmount;
	}
	public void setvPreviousApprovedAmount(float vPreviousApprovedAmount) {
		this.vPreviousApprovedAmount = vPreviousApprovedAmount;
	}
	public float getvBalanceAmount() {
		return vBalanceAmount;
	}
	public void setvBalanceAmount(float vBalanceAmount) {
		this.vBalanceAmount = vBalanceAmount;
	}

}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class UserProfileModal implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private long        userProfileID;
    private long        customerTypeID;
    private long        organisationID;
    private long       	branchID;
    private long 		parentBranchID;
    private String 		employeeNo;
    private String 		name;
    private String 		userName;
    private String 		firstName;
    private String 		email;
    private String 		phoneNo;
    private String 		mobileNo;
    private long 		lOB;
    private long 		isFirstLogin;
    private String 		password;
    private long 		overviewCompleted;
    private long 		isRiskProfileCompleted;
    private long 		isSuperUser;
    private long 		isAdmin;
    private long 		isUnderWriter;
    private Timestamp 	lastLogin;
    private long 		lineOfBusiness;
    private String 		lineOfBusinessDescription;
    private long 		groupID;
    private long 		isPANVerified;
    private long 		isMobileVerified;
    private String 		uniqueMemberId;
    private String 		pANNo;
    private String 		photos;
    private long 		levelID;
    private long 		reportingTo;
    private long 		subChannelID;
    private long 		mainChannelID;
    private long  		agentID;
    private long 		usageID;
    private long 		userType;
    private String 		intermediaryCode;
    private String 		groupName;
    private BranchModal branch;
    private long        moduleID;
    private long        featureID;
    
    
    //private OrganisationInfo _Organisation;
    
	public long getModuleID() {
		return moduleID;
	}
	public long getFeatureID() {
		return featureID;
	}
	public void setModuleID(long moduleID) {
		this.moduleID = moduleID;
	}
	public void setFeatureID(long featureID) {
		this.featureID = featureID;
	}
	public long getUserProfileID() {
		return userProfileID;
	}
	public BranchModal getBranch() {
		return branch;
	}
	public void setBranch(BranchModal branch) {
		this.branch = branch;
	}
	public long getCustomerTypeID() {
		return customerTypeID;
	}
	public long getOrganisationID() {
		return organisationID;
	}
	public long getBranchID() {
		return branchID;
	}
	public long getParentBranchID() {
		return parentBranchID;
	}
	public String getEmployeeNo() {
		return employeeNo;
	}
	public String getName() {
		return name;
	}
	public String getUserName() {
		return userName;
	}
	public String getEmail() {
		return email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public long getlOB() {
		return lOB;
	}
	public long getIsFirstLogin() {
		return isFirstLogin;
	}
	public String getPassword() {
		return password;
	}
	public long getOverviewCompleted() {
		return overviewCompleted;
	}
	public long getIsRiskProfileCompleted() {
		return isRiskProfileCompleted;
	}
	public long getIsSuperUser() {
		return isSuperUser;
	}
	public long getIsAdmin() {
		return isAdmin;
	}
	public long getIsUnderWriter() {
		return isUnderWriter;
	}
	public Timestamp getLastLogin() {
		return lastLogin;
	}
	public long getLineOfBusiness() {
		return lineOfBusiness;
	}
	public String getLineOfBusinessDescription() {
		return lineOfBusinessDescription;
	}
	public long getGroupID() {
		return groupID;
	}
	public long getIsPANVerified() {
		return isPANVerified;
	}
	public long getIsMobileVerified() {
		return isMobileVerified;
	}
	public String getUniqueMemberId() {
		return uniqueMemberId;
	}
	public String getpANNo() {
		return pANNo;
	}
	public String getPhotos() {
		return photos;
	}
	public long getLevelID() {
		return levelID;
	}
	public long getReportingTo() {
		return reportingTo;
	}
	public long getSubChannelID() {
		return subChannelID;
	}
	public long getMainChannelID() {
		return mainChannelID;
	}
	public long getAgentID() {
		return agentID;
	}
	public long getUsageID() {
		return usageID;
	}
	public long getUserType() {
		return userType;
	}
	public String getIntermediaryCode() {
		return intermediaryCode;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setUserProfileID(long userProfileID) {
		this.userProfileID = userProfileID;
	}
	public void setCustomerTypeID(long customerTypeID) {
		this.customerTypeID = customerTypeID;
	}
	public void setOrganisationID(long organisationID) {
		this.organisationID = organisationID;
	}
	public void setBranchID(long branchID) {
		this.branchID = branchID;
	}
	public void setParentBranchID(long parentBranchID) {
		this.parentBranchID = parentBranchID;
	}
	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public void setlOB(long lOB) {
		this.lOB = lOB;
	}
	public void setIsFirstLogin(long isFirstLogin) {
		this.isFirstLogin = isFirstLogin;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setOverviewCompleted(long overviewCompleted) {
		this.overviewCompleted = overviewCompleted;
	}
	public void setIsRiskProfileCompleted(long isRiskProfileCompleted) {
		this.isRiskProfileCompleted = isRiskProfileCompleted;
	}
	public void setIsSuperUser(long isSuperUser) {
		this.isSuperUser = isSuperUser;
	}
	public void setIsAdmin(long isAdmin) {
		this.isAdmin = isAdmin;
	}
	public void setIsUnderWriter(long isUnderWriter) {
		this.isUnderWriter = isUnderWriter;
	}
	public void setLastLogin(Timestamp lastLogin) {
		this.lastLogin = lastLogin;
	}
	public void setLineOfBusiness(long lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	public void setLineOfBusinessDescription(String lineOfBusinessDescription) {
		this.lineOfBusinessDescription = lineOfBusinessDescription;
	}
	public void setGroupID(long groupID) {
		this.groupID = groupID;
	}
	public void setIsPANVerified(long isPANVerified) {
		this.isPANVerified = isPANVerified;
	}
	public void setIsMobileVerified(long isMobileVerified) {
		this.isMobileVerified = isMobileVerified;
	}
	public void setUniqueMemberId(String uniqueMemberId) {
		this.uniqueMemberId = uniqueMemberId;
	}
	public void setpANNo(String pANNo) {
		this.pANNo = pANNo;
	}
	public void setPhotos(String photos) {
		this.photos = photos;
	}
	public void setLevelID(long levelID) {
		this.levelID = levelID;
	}
	public void setReportingTo(long reportingTo) {
		this.reportingTo = reportingTo;
	}
	public void setSubChannelID(long subChannelID) {
		this.subChannelID = subChannelID;
	}
	public void setMainChannelID(long mainChannelID) {
		this.mainChannelID = mainChannelID;
	}
	public void setAgentID(long agentID) {
		this.agentID = agentID;
	}
	public void setUsageID(long usageID) {
		this.usageID = usageID;
	}
	public void setUserType(long userType) {
		this.userType = userType;
	}
	public void setIntermediaryCode(String intermediaryCode) {
		this.intermediaryCode = intermediaryCode;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	} 
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class BranchModal  implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	    @Override
	public String toString() {
		return "BranchModal [branchId=" + branchId + ", organisationId=" + organisationId + ", shortName=" + shortName
				+ ", branchName=" + branchName + ", workingDate=" + workingDate + ", parentBranchId=" + parentBranchId
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", isActive=" + isActive + ", address1="
				+ address1 + ", address2=" + address2 + ", address3=" + address3 + ", address4=" + address4
				+ ", countryID=" + countryID + ", stateID=" + stateID + ", districtID=" + districtID + ", talukID="
				+ talukID + ", zipCode=" + zipCode + ", phoneNo=" + phoneNo + ", mobileNo=" + mobileNo
				+ ", conferenceNo=" + conferenceNo + ", faxNo=" + faxNo + ", email=" + email + ", pageTypeID="
				+ pageTypeID + ", regionalID=" + regionalID + ", zoneID=" + zoneID + ", divisionID=" + divisionID
				+ ", gstNo=" + gstNo + ", panNo=" + panNo + ", lutNo=" + lutNo + ", branchTypeId=" + branchTypeId
				+ ", countryName=" + countryName + ", stateName=" + stateName + ", districtName=" + districtName
				+ ", parentBranch=" + parentBranch + ", addressId=" + addressId + ", TalukaName=" + TalukaName + "]";
	}
		private long 		branchId;
		private long 		organisationId;
	    private String 		shortName;
	    private String 		branchName;
	    private Timestamp 	workingDate;
	    private long 		parentBranchId;
	    private long 		createdBy;
	    private Timestamp 	createdOn; 
	    private Short 		isActive;
	    private String 		address1;
	    private String 		address2;
	    private String 		address3;
	    private String 		address4;
	    private long 		countryID;
	    private long 		stateID;
	    private long 		districtID;
	    private long 		talukID;
	    private String 		zipCode;
	    private String 		phoneNo ;
	    private String 		mobileNo;
	    private String 		conferenceNo ;
	    private String 		faxNo;
	    private String 		email;
	    private long 		pageTypeID;
	    private long 		regionalID;
	    private long 		zoneID;
	    private long 		divisionID;
	    private String 		gstNo;
	    private String 		panNo;
	    private String 		lutNo;
	    private short       branchTypeId;
	    private String 		countryName;
		private String 		stateName;
	    private String 		districtName;
	    private String 		parentBranch;
	    private long        addressId;
	
	    
	    public short getBranchTypeId() {
			return branchTypeId;
		}
		public void setBranchTypeId(short branchTypeId) {
			this.branchTypeId = branchTypeId;
		}
		public String getTalukaName() {
			return TalukaName;
		}
		public String getCountryName() {
			return countryName;
		}
		public String getStateName() {
			return stateName;
		}
		public String getDistrictName() {
			return districtName;
		}
		public String getParentBranch() {
			return parentBranch;
		}
		public void setCountryName(String countryName) {
			this.countryName = countryName;
		}
		public void setStateName(String stateName) {
			this.stateName = stateName;
		}
		public void setDistrictName(String districtName) {
			this.districtName = districtName;
		}
		public void setParentBranch(String parentBranch) {
			this.parentBranch = parentBranch;
		}
		public void setTalukaName(String talukaName) {
			TalukaName = talukaName;
		}
		private String TalukaName;
	    
	    
		public long getBranchId() {
			return branchId;
		}
		public long getOrganisationId() {
			return organisationId;
		}
		public String getShortName() {
			return shortName;
		}
		public String getBranchName() {
			return branchName;
		}
		public Timestamp getWorkingDate() {
			return workingDate;
		}
		public long getParentBranchId() {
			return parentBranchId;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public Short getIsActive() {
			return isActive;
		}
		public String getAddress1() {
			return address1;
		}
		public String getAddress2() {
			return address2;
		}
		public String getAddress3() {
			return address3;
		}
		public String getAddress4() {
			return address4;
		}
		public long getCountryID() {
			return countryID;
		}
		public long getStateID() {
			return stateID;
		}
		public long getDistrictID() {
			return districtID;
		}
		public long getTalukID() {
			return talukID;
		}
		public String getZipCode() {
			return zipCode;
		}
		public String getPhoneNo() {
			return phoneNo;
		}
		public String getMobileNo() {
			return mobileNo;
		}
		public String getConferenceNo() {
			return conferenceNo;
		}
		public String getFaxNo() {
			return faxNo;
		}
		public String getEmail() {
			return email;
		}
		public long getPageTypeID() {
			return pageTypeID;
		}
		public long getRegionalID() {
			return regionalID;
		}
		public long getZoneID() {
			return zoneID;
		}
		public long getDivisionID() {
			return divisionID;
		}
		public String getGstNo() {
			return gstNo;
		}
		public String getPanNo() {
			return panNo;
		}
		public String getLutNo() {
			return lutNo;
		}
		public void setBranchId(long branchId) {
			this.branchId = branchId;
		}
		public void setOrganisationId(long organisationID) {
			this.organisationId = organisationID;
		}
		public void setShortName(String shortName) {
			this.shortName = shortName;
		}
		public void setBranchName(String branchName) {
			this.branchName = branchName;
		}
		public void setWorkingDate(Timestamp workingDate) {
			this.workingDate = workingDate;
		}
		public void setParentBranchId(long parentBranchID) {
			this.parentBranchId = parentBranchID;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setIsActive(Short isActive) {
			this.isActive = isActive;
		}
		public void setAddress1(String address1) {
			this.address1 = address1;
		}
		public void setAddress2(String address2) {
			this.address2 = address2;
		}
		public void setAddress3(String address3) {
			this.address3 = address3;
		}
		public void setAddress4(String address4) {
			this.address4 = address4;
		}
		public void setCountryID(long countryID) {
			this.countryID = countryID;
		}
		public void setStateID(long stateID) {
			this.stateID = stateID;
		}
		public void setDistrictID(long districtID) {
			this.districtID = districtID;
		}
		public void setTalukID(long talukID) {
			this.talukID = talukID;
		}
		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}
		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}
		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}
		public void setConferenceNo(String conferenceNo) {
			this.conferenceNo = conferenceNo;
		}
		public void setFaxNo(String faxNo) {
			this.faxNo = faxNo;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public void setPageTypeID(long pageTypeID) {
			this.pageTypeID = pageTypeID;
		}
		public void setRegionalID(long regionalID) {
			this.regionalID = regionalID;
		}
		public void setZoneID(long zoneID) {
			this.zoneID = zoneID;
		}
		public void setDivisionID(long divisionID) {
			this.divisionID = divisionID;
		}
		public void setGstNo(String gstNo) {
			this.gstNo = gstNo;
		}
		public void setPanNo(String panNo) {
			this.panNo = panNo;
		}
		public void setLutNo(String lutNo) {
			this.lutNo = lutNo;
		}
		public long getAddressId() {
			return addressId;
		}
		public void setAddressId(long addressId) {
			this.addressId = addressId;
		}
	   
}

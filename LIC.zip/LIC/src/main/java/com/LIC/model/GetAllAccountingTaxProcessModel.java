package com.LIC.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetAllAccountingTaxProcessModel {
@Id
private Number processID ;
private String code;
private String processName;
private Number createdBy;
private String createdOn;
private Number modifiedBy;
private String modifiedOn;
private Number isActive;
private Number isGSTApplicable;
private Number isTaxApplicable;
private Number gstTypeID;


public GetAllAccountingTaxProcessModel()
{
}

public GetAllAccountingTaxProcessModel(Number processID, String code, String processName, Number createdBy,
		String createdOn, Number modifiedBy, String modifiedOn, Number isActive, Number isGSTApplicable,
		Number isTaxApplicable, Number gstTypeID) {
	super();
	this.processID = processID;
	this.code = code;
	this.processName = processName;
	this.createdBy = createdBy;
	this.createdOn = createdOn;
	this.modifiedBy = modifiedBy;
	this.modifiedOn = modifiedOn;
	this.isActive = isActive;
	this.isGSTApplicable = isGSTApplicable;
	this.isTaxApplicable = isTaxApplicable;
	this.gstTypeID = gstTypeID;
}


public Number getProcessID() {
	return processID;
}
public void setProcessID(Number processID) {
	this.processID = processID;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getProcessName() {
	return processName;
}
public void setProcessName(String processName) {
	this.processName = processName;
}
public Number getCreatedBy() {
	return createdBy;
}
public void setCreatedBy(Number createdBy) {
	this.createdBy = createdBy;
}
public String getCreatedOn() {
	return createdOn;
}
public void setCreatedOn(String createdOn) {
	this.createdOn = createdOn;
}
public Number getModifiedBy() {
	return modifiedBy;
}
public void setModifiedBy(Number modifiedBy) {
	this.modifiedBy = modifiedBy;
}
public String getModifiedOn() {
	return modifiedOn;
}
public void setModifiedOn(String modifiedOn) {
	this.modifiedOn = modifiedOn;
}
public Number getIsActive() {
	return isActive;
}
public void setIsActive(Number isActive) {
	this.isActive = isActive;
}
public Number getIsGSTApplicable() {
	return isGSTApplicable;
}
public void setIsGSTApplicable(Number isGSTApplicable) {
	this.isGSTApplicable = isGSTApplicable;
}
public Number getIsTaxApplicable() {
	return isTaxApplicable;
}
public void setIsTaxApplicable(Number isTaxApplicable) {
	this.isTaxApplicable = isTaxApplicable;
}
public Number getGstTypeID() {
	return gstTypeID;
}
public void setGstTypeID(Number gstTypeID) {
	this.gstTypeID = gstTypeID;
}

}

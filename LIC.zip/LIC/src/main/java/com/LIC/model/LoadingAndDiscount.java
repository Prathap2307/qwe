package com.LIC.model;

import java.io.Serializable;
import java.util.Date;

public class LoadingAndDiscount extends RecordModifier implements Serializable {
		
    private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer productId;
	private Integer lineOfBusinessId;
	private Integer loadingTypeId;
	private Integer questionId;
	private Integer sumInsuredId;
	private String description;
	private Integer categoryValueId;
	private Integer valueSpecificId;
	private Double value;
	private Integer typeId;
	private Integer appliedOn;
	private Double maximumLimit;
	private Double rangeFrom;
	private Double rangeTo;
	private Integer ver;
	private Date effectiveStartDate;
	private Date effectiveEndDate;
	private String productName;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getLineOfBusinessId() {
		return lineOfBusinessId;
	}
	public void setLineOfBusinessId(Integer lineOfBusinessId) {
		this.lineOfBusinessId = lineOfBusinessId;
	}
	public Integer getLoadingTypeId() {
		return loadingTypeId;
	}
	public void setLoadingTypeId(Integer loadingTypeId) {
		this.loadingTypeId = loadingTypeId;
	}
	public Integer getQuestionId() {
		if(null == questionId) {
			questionId = 0;
		}
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public Integer getSumInsuredId() {
		return sumInsuredId;
	}
	public void setSumInsuredId(Integer sumInsuredId) {
		this.sumInsuredId = sumInsuredId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getCategoryValueId() {
		return categoryValueId;
	}
	public void setCategoryValueId(Integer categoryValueId) {
		this.categoryValueId = categoryValueId;
	}
	public Integer getValueSpecificId() {
		return valueSpecificId;
	}
	public void setValueSpecificId(Integer valueSpecificId) {
		this.valueSpecificId = valueSpecificId;
	}
	public Double getValue() {
		if(null == valueSpecificId || valueSpecificId == 0) {
			value = 0.0;
		}
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public Integer getTypeId() {
		if(null == valueSpecificId || valueSpecificId == 0) {
			typeId = 0;
		}
		return typeId;
	}
	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}
	public Integer getAppliedOn() {
		if(null == appliedOn) {
			appliedOn = 0;
		}
		return appliedOn;
	}
	public void setAppliedOn(Integer appliedOn) {
		this.appliedOn = appliedOn;
	}
	public Double getMaximumLimit() {
		if(null == maximumLimit) {
			maximumLimit = 0.0;
		}
		return maximumLimit;
	}
	public void setMaximumLimit(Double maximumLimit) {
		this.maximumLimit = maximumLimit;
	}
	public Double getRangeFrom() {
		return rangeFrom;
	}
	public void setRangeFrom(Double rangeFrom) {
		this.rangeFrom = rangeFrom;
	}
	public Double getRangeTo() {
		return rangeTo;
	}
	public void setRangeTo(Double rangeTo) {
		this.rangeTo = rangeTo;
	}
	public Integer getVer() {
		return ver;
	}
	public void setVer(Integer ver) {
		this.ver = ver;
	}
	public Date getEffectiveStartDate() {
		return effectiveStartDate;
	}
	public void setEffectiveStartDate(Date effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}
	public Date getEffectiveEndDate() {
		return effectiveEndDate;
	}
	public void setEffectiveEndDate(Date effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
}

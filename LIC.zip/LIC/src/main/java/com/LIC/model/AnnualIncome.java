package com.LIC.model;


import java.io.Serializable;

public class AnnualIncome extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer annualIncomeID;
	private String description; 
	private String shortDescription; 
	private String remarks;
	 
	
	public Integer getAnnualIncomeID() {
		return annualIncomeID;
	}
	public void setAnnualIncomeID(Integer annualIncomeID) {
		this.annualIncomeID = annualIncomeID;
	}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	 
	
}

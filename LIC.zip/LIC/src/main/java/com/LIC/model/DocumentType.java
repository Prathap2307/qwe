
package com.LIC.model;

import java.io.Serializable;


public class DocumentType extends RecordModifier  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer documentTypeId;
	private String description;
	private String remarks;

	public Integer getDocumentTypeId() {
		return documentTypeId;
	}

	public void setDocumentTypeId(Integer documentTypeId) {
		this.documentTypeId = documentTypeId;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "DocumentType [documentTypeId=" + documentTypeId + ", description=" + description + ", remarks="
				+ remarks + "]";
	}
	
}

package com.LIC.model;

import java.sql.Date;

public class MasterOccupation {

	private String description;
	private String createdBy;
	private Date createdOn;
	private Integer isActive;
}

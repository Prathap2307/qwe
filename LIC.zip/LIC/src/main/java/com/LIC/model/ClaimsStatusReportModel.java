/*package com.lic.claim.claimsstatusreport.model;*/
package com.LIC.model;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ClaimsStatusReportModel {
	@Id
	private Number pApplicationID;
	private Number pProductID;
	private Number pID;
	private Number pClaimID;
	private Number pLineOfBusinessID;
	private Number pPageTYpeID;
	private String pClaimNumber;
	private String pFirstName;
	private String pLastName;
	private String pPolicyNumber;
	private String pContactID;
	private Number pStatusID;

	public ClaimsStatusReportModel(Number number, Number number2, Number number3, Number number4, Number number5) {
		// TODO Auto-generated constructor stub
	}

	public Number getpApplicationID() {
		return pApplicationID;
	}

	public void setpApplicationID(Number pApplicationID) {
		this.pApplicationID = pApplicationID;
	}

	public Number getpProductID() {
		return pProductID;
	}

	public void setpProductID(Number pProductID) {
		this.pProductID = pProductID;
	}

	public Number getpID() {
		return pID;
	}

	public void setpID(Number pID) {
		this.pID = pID;
	}

	public Number getpClaimID() {
		return pClaimID;
	}

	public void setpClaimID(Number pClaimID) {
		this.pClaimID = pClaimID;
	}

	public Number getpLineOfBusinessID() {
		return pLineOfBusinessID;
	}

	public void setpLineOfBusinessID(Number pLineOfBusinessID) {
		this.pLineOfBusinessID = pLineOfBusinessID;
	}

	public Number getpPageTYpeID() {
		return pPageTYpeID;
	}

	public void setpPageTYpeID(Number pPageTYpeID) {
		this.pPageTYpeID = pPageTYpeID;
	}

	public String getpClaimNumber() {
		return pClaimNumber;
	}

	public void setpClaimNumber(String pClaimNumber) {
		this.pClaimNumber = pClaimNumber;
	}

	public String getpFirstName() {
		return pFirstName;
	}

	public void setpFirstName(String pFirstName) {
		this.pFirstName = pFirstName;
	}

	public String getpLastName() {
		return pLastName;
	}

	public void setpLastName(String pLastName) {
		this.pLastName = pLastName;
	}

	public String getpPolicyNumber() {
		return pPolicyNumber;
	}

	public void setpPolicyNumber(String pPolicyNumber) {
		this.pPolicyNumber = pPolicyNumber;
	}

	public String getpContactID() {
		return pContactID;
	}

	public void setpContactID(String pContactID) {
		this.pContactID = pContactID;
	}

	public Number getpStatusID() {
		return pStatusID;
	}

	public void setpStatusID(Number pStatusID) {
		this.pStatusID = pStatusID;
	}

}

package com.LIC.model;

import javax.persistence.Id;

public class AccountingGroupInfoModel {

	@Id
	private Number accountGroupID;
	private String code;
	private String groupName;
	private Number isActive;
	private Number createdBy;
	private String createdOn;
	private Number modifiedBy;
	private String modifiedOn;
	private Number deletedBy;
	private String deletedOn;
	
	
	
	
	public Number getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(Number deletedBy) {
		this.deletedBy = deletedBy;
	}
	public String getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(String deletedOn) {
		this.deletedOn = deletedOn;
	}
	public Number getAccountGroupID() {
		return accountGroupID;
	}
	public void setAccountGroupID(Number accountGroupID) {
		this.accountGroupID = accountGroupID;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public Number getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Number modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public AccountingGroupInfoModel(Number accountGroupID, String code, String groupName, Number isActive,
			Number createdBy, String createdOn, Number modifiedBy, String modifiedOn, Number deletedBy,
			String deletedOn) {
		super();
		this.accountGroupID = accountGroupID;
		this.code = code;
		this.groupName = groupName;
		this.isActive = isActive;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
		this.deletedBy = deletedBy;
		this.deletedOn = deletedOn;
	}


	
}

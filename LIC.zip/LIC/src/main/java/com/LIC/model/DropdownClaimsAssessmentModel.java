package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/*
 * @Author = "671621"
 */
@Entity
public class DropdownClaimsAssessmentModel {

	@Id
	private int pClaimID;
	
	private String pCoverageName;
	private int pCoverageID;
	
	private int pDocumentTypeID;
	private String pDescription;
	private String pAdditionalDocument;
	
	public DropdownClaimsAssessmentModel() {
		
	}

	public DropdownClaimsAssessmentModel(int pClaimID) {
		this.pClaimID = pClaimID;
	}
	
	public DropdownClaimsAssessmentModel(String pCoverageName, int pCoverageID) {
		this.pCoverageName = pCoverageName;
		this.pCoverageID = pCoverageID;
	}
	
	public DropdownClaimsAssessmentModel(int pDocumentTypeID, String pDescription, String pAdditionalDocument) {
		this.pDocumentTypeID = pDocumentTypeID;
		this.pDescription = pDescription;
		this.pAdditionalDocument = pAdditionalDocument;
	}

	public int getpClaimID() {
		return pClaimID;
	}

	public void setpClaimID(int pClaimID) {
		this.pClaimID = pClaimID;
	}

	public String getpCoverageName() {
		return pCoverageName;
	}

	public void setpCoverageName(String pCoverageName) {
		this.pCoverageName = pCoverageName;
	}

	public int getpCoverageID() {
		return pCoverageID;
	}

	public void setpCoverageID(int pCoverageID) {
		this.pCoverageID = pCoverageID;
	}

	public int getpDocumentTypeID() {
		return pDocumentTypeID;
	}

	public void setpDocumentTypeID(int pDocumentTypeID) {
		this.pDocumentTypeID = pDocumentTypeID;
	}

	public String getpDescription() {
		return pDescription;
	}

	public void setpDescription(String pDescription) {
		this.pDescription = pDescription;
	}

	public String getpAdditionalDocument() {
		return pAdditionalDocument;
	}

	public void setpAdditionalDocument(String pAdditionalDocument) {
		this.pAdditionalDocument = pAdditionalDocument;
	}

}

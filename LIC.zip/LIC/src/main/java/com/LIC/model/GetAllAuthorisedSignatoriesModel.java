package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetAllAuthorisedSignatoriesModel {
@Id

private Number id;
private String description;



public GetAllAuthorisedSignatoriesModel()
{}

public GetAllAuthorisedSignatoriesModel(Number id, String description) {
	super();
	this.id = id;
	this.description = description;
}

public Number getId() {
	return id;
}
public void setId(Number id) {
	this.id = id;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}



}

package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MemberDeletionModel {
	@Id
private int headerId;
private String filePath;
private String fileName;



public int getHeaderId() {
	return headerId;
}

public void setHeaderId(int headerId) {
	this.headerId = headerId;
}

public String getFilePath() {
	return filePath;
}

public void setFilePath(String filePath) {
	this.filePath = filePath;
}

public String getFileName() {
	return fileName;
}

public void setFileName(String fileName) {
	this.fileName = fileName;
}

public MemberDeletionModel(int headerId, String filePath, String fileName) {
	this.headerId = headerId;
	this.filePath = filePath;
	this.fileName = fileName;
}

public MemberDeletionModel() {
}


}

package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;


@NamedStoredProcedureQuery(name = "createOrUpdateQuestion", procedureName = "spInsertOrUpdateQuestions", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vQuestionID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDescription", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vLOB", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vWeightage", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vOrderID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedOn", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vShortDescription", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vIsActive", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "vRESULT", type = Integer.class)} ,resultClasses = QuestionModel.class)
		





@NamedStoredProcedureQuery(name = "deleteQuestion", procedureName = "spDeleteQuestions", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vQuestionID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDELETEDBY", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "RESULT1", type = String.class)}, resultClasses = QuestionModel.class)










@Entity
@Table(name="MASTER_QUESTIONS")
public class QuestionModel {
	@Id
	
	
	private int questionId;
	private int lobId;
	private String description;
	private String shortDescription;
	private int orderId;
	private int weightAge;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	private int deletedBy;
	private Date deletedOn;
	private int isActive;
	
	public int getLobId() {
		return lobId;
	}
	public void setLobId(int lobId) {
		this.lobId = lobId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getWeightAge() {
		return weightAge;
	}
	public void setWeightAge(int weightAge) {
		this.weightAge = weightAge;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	
	
	
	

}

package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AccountingHeadModel {
	@Id
	private Number accountHeadId;
	private Number accountClassificationID;
	private Number accountGroupID;
	private Number accountTypeID;
	private String code;
	private String accountHeadName;
	private Number isControlAC;
	private Number isManualVoucher;
	private Number createdBy;
	private Number isactive;
	private String classification;
	private String groupName;
	private Number isPostedAC;
	
	
	public AccountingHeadModel()
	{
	}
		
	public AccountingHeadModel(Number accountHeadId, String code, String accountHeadName) {
		super();
		this.accountHeadId = accountHeadId;
		this.code = code;
		this.accountHeadName = accountHeadName;
	}
	
	public AccountingHeadModel(Number accountHeadId, String code, String accountHeadName
			, Number accountClassificationID, String classification, String groupName, Number accountGroupID,
			Number accountTypeID, Number isControlAC, Number isPostedAC,Number isactive, Number isManualVoucher) {
		super();
		this.accountHeadId = accountHeadId;
		this.code = code;
		this.accountHeadName = accountHeadName;
		this.accountClassificationID = accountClassificationID;
		this.classification = classification;
		this.groupName = groupName;
		this.accountGroupID = accountGroupID;
		this.accountTypeID = accountTypeID;
		this.isControlAC = isControlAC;
		this.isPostedAC = isPostedAC;
		this.isactive = isactive;
		this.isManualVoucher = isManualVoucher;
	
	}
	
	
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Number getIsPostedAC() {
		return isPostedAC;
	}
	public void setIsPostedAC(Number isPostedAC) {
		this.isPostedAC = isPostedAC;
	}
	public Number getAccountClassificationID() {
		return accountClassificationID;
	}
	public void setAccountClassificationID(Number accountClassificationID) {
		this.accountClassificationID = accountClassificationID;
	}
	public Number getAccountGroupID() {
		return accountGroupID;
	}
	public void setAccountGroupID(Number accountGroupID) {
		this.accountGroupID = accountGroupID;
	}
	public Number getAccountTypeID() {
		return accountTypeID;
	}
	public void setAccountTypeID(Number accountTypeID) {
		this.accountTypeID = accountTypeID;
	}
	public Number getIsControlAC() {
		return isControlAC;
	}
	public void setIsControlAC(Number isControlAC) {
		this.isControlAC = isControlAC;
	}
	public Number getIsManualVoucher() {
		return isManualVoucher;
	}
	public void setIsManualVoucher(Number isManualVoucher) {
		this.isManualVoucher = isManualVoucher;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public Number getIsactive() {
		return isactive;
	}
	public void setIsactive(Number isactive) {
		this.isactive = isactive;
	}
	public Number getAccountHeadId() {
		return accountHeadId;
	}
	public void setAccountHeadId(Number accountHeadId) {
		this.accountHeadId = accountHeadId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getAccountHeadName() {
		return accountHeadName;
	}
	public void setAccountHeadName(String accountHeadName) {
		this.accountHeadName = accountHeadName;
	}
	

}

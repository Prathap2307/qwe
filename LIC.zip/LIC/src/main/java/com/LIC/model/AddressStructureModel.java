package com.LIC.model;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

@NamedStoredProcedureQuery(name = "createOrUpdateAddressStructure", procedureName = "spInsertOrUpdateAddressStructure", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vStructureID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDescription", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedBy", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedOn", type = Date.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "visActive", type = Integer.class),}, resultClasses = AddressStructureModel.class)



		
@NamedStoredProcedureQuery(name = "deleteAddress", procedureName = "spDeleteAddressStructure", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vStructureID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDeletedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDeletedOn", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "RESULT1", type = String.class)}, resultClasses = AddressStructureModel.class)





@Entity
@Table(name="Master_AddressStructure")
public class AddressStructureModel {
	
	@Id
	private Number structureId;
	private String description;
	private Number createdBy;
	private Date createdOn;
	private Number modifiedBy;
	private Date modifiedOn;
	private Number deletedBy;
	private Date deletedOn;
	private Number isActive;
	public Number getStructureId() {
		return structureId;
	}
	public void setStructureId(int structureId) {
		this.structureId = structureId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Number getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public Number getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	
	
	

	
	

}

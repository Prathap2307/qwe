package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class HealthsClaimsModel implements Serializable
{
	private static final long serialVersionUID = 1L;
	public static final String HEALTHS_CLAIMS_MODEL  = "HealthsClaimsModel";
	
	
		private long 			claimID;
	    private String 			status;
	    private long 			userName;
		private long 			claimStatusID;
		private String          preStatus;
		private long 			previousStatusID;
		private double 			proffesionalCharges;
		private double 			serviceTax;
	    private double 			totalProffesional;
		private double 			incidentalCharges;
		private long 			surveyorID;
		private short 			isSurveyOrInternal;
		private long 			surveyOrType;;
		private double 			surveyOrExp;
		private long 			claimTypeID;
		private long 			telephoneNomber;
		private String 			nameOfHospital;
		private String 			addOfHospital;
		private String 			diseasDiscription;
		private String 			finalDiagnosis;
		private String 			bankName;
		private String 			branch;
		private String 			location;
		private String 			accountNo;
		private String 			acoountType;
		private String 			microCode;
		private String 			ifscCode;
		private String 			regNo;
		private short 			isInsured ;
		private short 			isAdditionalDoc ;
		private String 			otherInsurenceComName ;
		private String 			otherPolicyType ;
		private String 			otherPolicyNo;
		private double 			otherPolicySumInsured ;
		private double 			otherPolicySumInsuredPerDay ;
		private double 			amountIncurred;
		private String 			OtherPolicyDetailedNote;
		private String 			doctorName;
		private String 			doctorAddress;
		private String 			qualification;
		private short 			isCloseAClaim;
		private long 			claimCloseReasonID;
		private String 			rejectedReason;
		private long 			rejectedReasonID;
		private String 			closureReason;
		private Timestamp 		dateOfLss;
		private Timestamp 		dateOfAdmision;
		private Timestamp 		dateOfDischarge;
		private String 			address1;
		private String 			address2;
		private String 			address3;
		private String 			address4;
		private String 			insurerSalutation;
		private String 			insurerFirstName;
		private String 			employeeID;
		private String 			insurerLastName;
		private long 			stateID;
		private long 			districID;
		private long 			postOfficeID;
		private String 			zipCode;
		private long 			addressType;
		private String 			landLineNo;
		private String 			mobileNO;
		private String 			conferenceNO;
		private String 			faxNO;
		private String 			emailID;
		private String 			pEmailID;
		private double 			totalApproved;
		private double 			totalPayable;
		private long 			claimPlanID;
		private double 			totalCompulsary;
		private double 			totalvoluntory;
		private double 			preProductBalance;
		private double 			preCoverageBalanace;
		private double 			benefitBalance;
		private double 			preProductClaimAmt;
		private double 			preCoverageClaimAmt;
		private double 			preBenefitClaimAmt;
		private double 			preProductApproverAmt;
		private double 			preProductCovApprovedAmt;
		private double 			preBenefitApprovedtAmt;
		private double 			transactionID;
		private long 			lineOfBusinessID;
		private long 			insureTypeID;
		private long 			partyID;
		private long 			applicationID;
		private double 			plansumInsured;
		private double 			planBalanceAmt;
		private double 			coverageBalanceAmt;
		private double 			coverageLimit;
		private double 			benefitLimit;
		private String 			toSentMail;
		private String 			mailFrom;
		private String 			mailBody;
		private String 			mailSub;
		private long 			templetID;
	    
	    
	
		public long getClaimID() {
			return claimID;
		}
		public String getStatus() {
			return status;
		}
		public long getUserName() {
			return userName;
		}
		public long getClaimStatusID() {
			return claimStatusID;
		}
		public String getPreStatus() {
			return preStatus;
		}
		public long getPreviousStatusID() {
			return previousStatusID;
		}
		public double getProffesionalCharges() {
			return proffesionalCharges;
		}
		public double getServiceTax() {
			return serviceTax;
		}
		public double getTotalProffesional() {
			return totalProffesional;
		}
		public double getIncidentalCharges() {
			return incidentalCharges;
		}
		public long getSurveyorID() {
			return surveyorID;
		}
		public short isSurveyOrInternal() {
			return isSurveyOrInternal;
		}
		public long getSurveyOrType() {
			return surveyOrType;
		}
		public double getSurveyOrExp() {
			return surveyOrExp;
		}
		public long getClaimTypeID() {
			return claimTypeID;
		}
		public long getTelephoneNomber() {
			return telephoneNomber;
		}
		public String getNameOfHospital() {
			return nameOfHospital;
		}
		public String getAddOfHospital() {
			return addOfHospital;
		}
		public String getDiseasDiscription() {
			return diseasDiscription;
		}
		public String getFinalDiagnosis() {
			return finalDiagnosis;
		}
		public String getBankName() {
			return bankName;
		}
		public String getBranch() {
			return branch;
		}
		public String getLocation() {
			return location;
		}
		public String getAccountNo() {
			return accountNo;
		}
		public String getAcoountType() {
			return acoountType;
		}
		public String getMicroCode() {
			return microCode;
		}
		public String getIfscCode() {
			return ifscCode;
		}
		public String getRegNo() {
			return regNo;
		}
		public short isInsured() {
			return isInsured;
		}
		public short isAdditionalDoc() {
			return isAdditionalDoc;
		}
		public String getOtherInsurenceComName() {
			return otherInsurenceComName;
		}
		public String getOtherPolicyType() {
			return otherPolicyType;
		}
		public String getOtherPolicyNo() {
			return otherPolicyNo;
		}
		public double getOtherPolicySumInsured() {
			return otherPolicySumInsured;
		}
		public double getOtherPolicySumInsuredPerDay() {
			return otherPolicySumInsuredPerDay;
		}
		public double getAmountIncurred() {
			return amountIncurred;
		}
		public String getOtherPolicyDetailedNote() {
			return OtherPolicyDetailedNote;
		}
		public String getDoctorName() {
			return doctorName;
		}
		public String getDoctorAddress() {
			return doctorAddress;
		}
		public String getQualification() {
			return qualification;
		}
		public short isCloseAClaim() {
			return isCloseAClaim;
		}
		public long getClaimCloseReasonID() {
			return claimCloseReasonID;
		}
		public String getRejectedReason() {
			return rejectedReason;
		}
		public long getRejectedReasonID() {
			return rejectedReasonID;
		}
		public String getClosureReason() {
			return closureReason;
		}
		public Timestamp getDateOfLss() {
			return dateOfLss;
		}
		public Timestamp getDateOfAdmision() {
			return dateOfAdmision;
		}
		public Timestamp getDateOfDischarge() {
			return dateOfDischarge;
		}
		public String getAddress1() {
			return address1;
		}
		public String getAddress2() {
			return address2;
		}
		public String getAddress3() {
			return address3;
		}
		public String getAddress4() {
			return address4;
		}
		public String getInsurerSalutation() {
			return insurerSalutation;
		}
		public String getInsurerFirstName() {
			return insurerFirstName;
		}
		public String getEmployeeID() {
			return employeeID;
		}
		public String getInsurerLastName() {
			return insurerLastName;
		}
		public long getStateID() {
			return stateID;
		}
		public long getDistricID() {
			return districID;
		}
		public long getPostOfficeID() {
			return postOfficeID;
		}
		public String getZipCode() {
			return zipCode;
		}
		public long getAddressType() {
			return addressType;
		}
		public String getLandLineNo() {
			return landLineNo;
		}
		public String getMobileNO() {
			return mobileNO;
		}
		public String getConferenceNO() {
			return conferenceNO;
		}
		public String getFaxNO() {
			return faxNO;
		}
		public String getEmailID() {
			return emailID;
		}
		public String getpEmailID() {
			return pEmailID;
		}
		public double getTotalApproved() {
			return totalApproved;
		}
		public double getTotalPayable() {
			return totalPayable;
		}
		public long getClaimPlanID() {
			return claimPlanID;
		}
		public double getTotalCompulsary() {
			return totalCompulsary;
		}
		public double getTotalvoluntory() {
			return totalvoluntory;
		}
		public double getPreProductBalance() {
			return preProductBalance;
		}
		public double getPreCoverageBalanace() {
			return preCoverageBalanace;
		}
		public double getBenefitBalance() {
			return benefitBalance;
		}
		public double getPreProductClaimAmt() {
			return preProductClaimAmt;
		}
		public double getPreCoverageClaimAmt() {
			return preCoverageClaimAmt;
		}
		public double getPreBenefitClaimAmt() {
			return preBenefitClaimAmt;
		}
		public double getPreProductApproverAmt() {
			return preProductApproverAmt;
		}
		public double getPreProductCovApprovedAmt() {
			return preProductCovApprovedAmt;
		}
		public double getPreBenefitApprovedtAmt() {
			return preBenefitApprovedtAmt;
		}
		public double getTransactionID() {
			return transactionID;
		}
		public long getLineOfBusinessID() {
			return lineOfBusinessID;
		}
		public long getInsureTypeID() {
			return insureTypeID;
		}
		public long getPartyID() {
			return partyID;
		}
		public long getApplicationID() {
			return applicationID;
		}
		public double getPlansumInsured() {
			return plansumInsured;
		}
		public double getPlanBalanceAmt() {
			return planBalanceAmt;
		}
		public double getCoverageBalanceAmt() {
			return coverageBalanceAmt;
		}
		public double getCoverageLimit() {
			return coverageLimit;
		}
		public double getBenefitLimit() {
			return benefitLimit;
		}
		public String getToSentMail() {
			return toSentMail;
		}
		public String getMailFrom() {
			return mailFrom;
		}
		public String getMailBody() {
			return mailBody;
		}
		public String getMailSub() {
			return mailSub;
		}
		public long getTempletID() {
			return templetID;
		}
		
		public void setClaimID(long claimID) {
			this.claimID = claimID;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public void setUserName(long userName) {
			this.userName = userName;
		}
		public void setClaimStatusID(long claimStatusID) {
			this.claimStatusID = claimStatusID;
		}
		public void setPreStatus(String preStatus) {
			this.preStatus = preStatus;
		}
		public void setPreviousStatusID(long previousStatusID) {
			this.previousStatusID = previousStatusID;
		}
		public void setProffesionalCharges(double proffesionalCharges) {
			this.proffesionalCharges = proffesionalCharges;
		}
		public void setServiceTax(double serviceTax) {
			this.serviceTax = serviceTax;
		}
		public void setTotalProffesional(double totalProffesional) {
			this.totalProffesional = totalProffesional;
		}
		public void setIncidentalCharges(double incidentalCharges) {
			this.incidentalCharges = incidentalCharges;
		}
		public void setSurveyorID(long surveyorID) {
			this.surveyorID = surveyorID;
		}
		public void setSurveyOrInternal(short isSurveyOrInternal) {
			this.isSurveyOrInternal = isSurveyOrInternal;
		}
		public void setSurveyOrType(long surveyOrType) {
			this.surveyOrType = surveyOrType;
		}
		public void setSurveyOrExp(double surveyOrExp) {
			this.surveyOrExp = surveyOrExp;
		}
		public void setClaimTypeID(long claimTypeID) {
			this.claimTypeID = claimTypeID;
		}
		public void setTelephoneNomber(long telephoneNomber) {
			this.telephoneNomber = telephoneNomber;
		}
		public void setNameOfHospital(String nameOfHospital) {
			this.nameOfHospital = nameOfHospital;
		}
		public void setAddOfHospital(String addOfHospital) {
			this.addOfHospital = addOfHospital;
		}
		public void setDiseasDiscription(String diseasDiscription) {
			this.diseasDiscription = diseasDiscription;
		}
		public void setFinalDiagnosis(String finalDiagnosis) {
			this.finalDiagnosis = finalDiagnosis;
		}
		public void setBankName(String bankName) {
			this.bankName = bankName;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}
		public void setAcoountType(String acoountType) {
			this.acoountType = acoountType;
		}
		public void setMicroCode(String microCode) {
			this.microCode = microCode;
		}
		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}
		public void setRegNo(String regNo) {
			this.regNo = regNo;
		}
		public void setInsured(short isInsured) {
			this.isInsured = isInsured;
		}
		public void setAdditionalDoc(short isAdditionalDoc) {
			this.isAdditionalDoc = isAdditionalDoc;
		}
		public void setOtherInsurenceComName(String otherInsurenceComName) {
			this.otherInsurenceComName = otherInsurenceComName;
		}
		public void setOtherPolicyType(String otherPolicyType) {
			this.otherPolicyType = otherPolicyType;
		}
		public void setOtherPolicyNo(String otherPolicyNo) {
			this.otherPolicyNo = otherPolicyNo;
		}
		public void setOtherPolicySumInsured(double otherPolicySumInsured) {
			this.otherPolicySumInsured = otherPolicySumInsured;
		}
		public void setOtherPolicySumInsuredPerDay(double otherPolicySumInsuredPerDay) {
			this.otherPolicySumInsuredPerDay = otherPolicySumInsuredPerDay;
		}
		public void setAmountIncurred(double amountIncurred) {
			this.amountIncurred = amountIncurred;
		}
		public void setOtherPolicyDetailedNote(String otherPolicyDetailedNote) {
			OtherPolicyDetailedNote = otherPolicyDetailedNote;
		}
		public void setDoctorName(String doctorName) {
			this.doctorName = doctorName;
		}
		public void setDoctorAddress(String doctorAddress) {
			this.doctorAddress = doctorAddress;
		}
		public void setQualification(String qualification) {
			this.qualification = qualification;
		}
		public void setCloseAClaim(short isCloseAClaim) {
			this.isCloseAClaim = isCloseAClaim;
		}
		public void setClaimCloseReasonID(long claimCloseReasonID) {
			this.claimCloseReasonID = claimCloseReasonID;
		}
		public void setRejectedReason(String rejectedReason) {
			this.rejectedReason = rejectedReason;
		}
		public void setRejectedReasonID(long rejectedReasonID) {
			this.rejectedReasonID = rejectedReasonID;
		}
		public void setClosureReason(String closureReason) {
			this.closureReason = closureReason;
		}
		public void setDateOfLss(Timestamp dateOfLss) {
			this.dateOfLss = dateOfLss;
		}
		public void setDateOfAdmision(Timestamp dateOfAdmision) {
			this.dateOfAdmision = dateOfAdmision;
		}
		public void setDateOfDischarge(Timestamp dateOfDischarge) {
			this.dateOfDischarge = dateOfDischarge;
		}
		public void setAddress1(String address1) {
			this.address1 = address1;
		}
		public void setAddress2(String address2) {
			this.address2 = address2;
		}
		public void setAddress3(String address3) {
			this.address3 = address3;
		}
		public void setAddress4(String address4) {
			this.address4 = address4;
		}
		public void setInsurerSalutation(String insurerSalutation) {
			this.insurerSalutation = insurerSalutation;
		}
		public void setInsurerFirstName(String insurerFirstName) {
			this.insurerFirstName = insurerFirstName;
		}
		public void setEmployeeID(String employeeID) {
			this.employeeID = employeeID;
		}
		public void setInsurerLastName(String insurerLastName) {
			this.insurerLastName = insurerLastName;
		}
		public void setStateID(long stateID) {
			this.stateID = stateID;
		}
		public void setDistricID(long districID) {
			this.districID = districID;
		}
		public void setPostOfficeID(long postOfficeID) {
			this.postOfficeID = postOfficeID;
		}
		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}
		public void setAddressType(long addressType) {
			this.addressType = addressType;
		}
		public void setLandLineNo(String landLineNo) {
			this.landLineNo = landLineNo;
		}
		public void setMobileNO(String mobileNO) {
			this.mobileNO = mobileNO;
		}
		public void setConferenceNO(String conferenceNO) {
			this.conferenceNO = conferenceNO;
		}
		public void setFaxNO(String faxNO) {
			this.faxNO = faxNO;
		}
		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}
		public void setpEmailID(String pEmailID) {
			this.pEmailID = pEmailID;
		}
		public void setTotalApproved(double totalApproved) {
			this.totalApproved = totalApproved;
		}
		public void setTotalPayable(double totalPayable) {
			this.totalPayable = totalPayable;
		}
		public void setClaimPlanID(long claimPlanID) {
			this.claimPlanID = claimPlanID;
		}
		public void setTotalCompulsary(double totalCompulsary) {
			this.totalCompulsary = totalCompulsary;
		}
		public void setTotalvoluntory(double totalvoluntory) {
			this.totalvoluntory = totalvoluntory;
		}
		public void setPreProductBalance(double preProductBalance) {
			this.preProductBalance = preProductBalance;
		}
		public void setPreCoverageBalanace(double preCoverageBalanace) {
			this.preCoverageBalanace = preCoverageBalanace;
		}
		public void setBenefitBalance(double benefitBalance) {
			this.benefitBalance = benefitBalance;
		}
		public void setPreProductClaimAmt(double preProductClaimAmt) {
			this.preProductClaimAmt = preProductClaimAmt;
		}
		public void setPreCoverageClaimAmt(double preCoverageClaimAmt) {
			this.preCoverageClaimAmt = preCoverageClaimAmt;
		}
		public void setPreBenefitClaimAmt(double preBenefitClaimAmt) {
			this.preBenefitClaimAmt = preBenefitClaimAmt;
		}
		public void setPreProductApproverAmt(double preProductApproverAmt) {
			this.preProductApproverAmt = preProductApproverAmt;
		}
		public void setPreProductCovApprovedAmt(double preProductCovApprovedAmt) {
			this.preProductCovApprovedAmt = preProductCovApprovedAmt;
		}
		public void setPreBenefitApprovedtAmt(double preBenefitApprovedtAmt) {
			this.preBenefitApprovedtAmt = preBenefitApprovedtAmt;
		}
		public void setTransactionID(double transactionID) {
			this.transactionID = transactionID;
		}
		public void setLineOfBusinessID(long lineOfBusinessID) {
			this.lineOfBusinessID = lineOfBusinessID;
		}
		public void setInsureTypeID(long insureTypeID) {
			this.insureTypeID = insureTypeID;
		}
		public void setPartyID(long partyID) {
			this.partyID = partyID;
		}
		public void setApplicationID(long applicationID) {
			this.applicationID = applicationID;
		}
		public void setPlansumInsured(double plansumInsured) {
			this.plansumInsured = plansumInsured;
		}
		public void setPlanBalanceAmt(double planBalanceAmt) {
			this.planBalanceAmt = planBalanceAmt;
		}
		public void setCoverageBalanceAmt(double coverageBalanceAmt) {
			this.coverageBalanceAmt = coverageBalanceAmt;
		}
		public void setCoverageLimit(double coverageLimit) {
			this.coverageLimit = coverageLimit;
		}
		public void setBenefitLimit(double benefitLimit) {
			this.benefitLimit = benefitLimit;
		}
		public void setToSentMail(String toSentMail) {
			this.toSentMail = toSentMail;
		}
		public void setMailFrom(String mailFrom) {
			this.mailFrom = mailFrom;
		}
		public void setMailBody(String mailBody) {
			this.mailBody = mailBody;
		}
		public void setMailSub(String mailSub) {
			this.mailSub = mailSub;
		}
		public void setTempletID(long templetID) {
			this.templetID = templetID;
		}
		
		
		
		
	}

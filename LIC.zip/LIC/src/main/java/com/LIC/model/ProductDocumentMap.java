package com.LIC.model;

import java.io.Serializable;
public class ProductDocumentMap extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer id;
	private Integer productID;
	private Integer DocumentTypeId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public Integer getDocumentTypeId() {
		return DocumentTypeId;
	}
	public void setDocumentTypeId(Integer documentTypeId) {
		DocumentTypeId = documentTypeId;
	}

	
}

package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;




@NamedStoredProcedureQuery(name = "createOrUpdateQuestionMap", procedureName = "spInsertQuestionsOptionsMap", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vQuestionID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vOptionID", type = Integer.class),} ,resultClasses = QuestionMapModel.class)
		




@NamedStoredProcedureQuery(name = "deleteQuestionMapId", procedureName = "spDeleteQuestionsOptionsMap", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vQuestionID", type = Integer.class),}, resultClasses = QuestionModel.class)





@Entity
@Table(name="QuestionsOptionsMap")
public class QuestionMapModel {
	@Id
	private int mapId;
	private int questionId;
	private int optionId;
	public int getMapId() {
		return mapId;
	}
	public void setMapId(int mapId) {
		this.mapId = mapId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public int getOptionId() {
		return optionId;
	}
	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}
	
	

}

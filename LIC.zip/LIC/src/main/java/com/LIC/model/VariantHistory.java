package com.LIC.model;

import java.io.Serializable;

public class VariantHistory  extends RecordModifier implements  Serializable {
	private static final long serialVersionUID = 1L;
	
	 private Integer historyId  ;    	
	 private Integer productID  ;   
	 private Integer planId  ;    	
	 private String description ;    
	 private String lobDescription ;    
	 private  Integer lineOfBusinessID ;    
	 private  String remarks ;
	 
	public Integer getHistoryId() {
		return historyId;
	}
	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	
	public Integer getLineOfBusinessID() {
		return lineOfBusinessID;
	}
	public void setLineOfBusinessID(Integer lineOfBusinessID) {
		this.lineOfBusinessID = lineOfBusinessID;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLobDescription() {
		return lobDescription;
	}
	public void setLobDescription(String lobDescription) {
		this.lobDescription = lobDescription;
	}
	
     
}

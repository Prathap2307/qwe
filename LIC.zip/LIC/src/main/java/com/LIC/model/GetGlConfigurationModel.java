package com.LIC.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class GetGlConfigurationModel {
	@Id
	private Number processId;
	private Number id;
	public GetGlConfigurationModel(Number id, String description,String code) {
		super();
		this.id = id;
		this.description = description;
		this.code = code;
		
	}
	public Number getId() {
		return id;
	}
	public void setId(Number id) {
		this.id = id;
	}
	private String processName;
	private String code;
	private Number isGstApplicaable;
	private Number paymentModeId;
	private String description;
	private Number insurerProductTypeId;
	private Number productTypeId;
	private String productType;
	private Number insurerId;
	private String insurer;
	private String productVersion;
	private String planCategoryId;
	private String insurerType;
	private Number glConfigurationId;
	private String productName;
	private Number productId;
	private Number paymentCode;
	private String paymentMode;
	private String bankName;
	private Number creditGlcode;
	private Number debitGlCode;
	private String creditGlName;
	private String debitGlName;
	private String debitNarration;
	private String creditNarration;
	private Number createdBy;
	private String createdOn;
	private Number modifiedBy;
	private String modifiedOn;
	private Number isActive;
	private String remark;
	private Number countryId;
	private Number stateId;
	
	private String countryCode;
	private String shortDescription;
	
	private Number isDeclined;
	
	
	
	
	
	
	
	
	public Number getInsurerProductTypeId() {
		return insurerProductTypeId;
	}
	public void setInsurerProductTypeId(Number insurerProductTypeId) {
		this.insurerProductTypeId = insurerProductTypeId;
	}
	public Number getProductTypeId() {
		return productTypeId;
	}
	public void setProductTypeId(Number productTypeId) {
		this.productTypeId = productTypeId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public Number getInsurerId() {
		return insurerId;
	}
	public void setInsurerId(Number insurerId) {
		this.insurerId = insurerId;
	}
	public String getInsurer() {
		return insurer;
	}
	public void setInsurer(String insurer) {
		this.insurer = insurer;
	}
	public String getProductVersion() {
		return productVersion;
	}
	public void setProductVersion(String productVersion) {
		this.productVersion = productVersion;
	}
	public String getPlanCategory() {
		return planCategoryId;
	}
	public void setPlanCategory(String planCategory) {
		this.planCategoryId = planCategory;
	}
	public String getInsurerType() {
		return insurerType;
	}
	public void setInsurerType(String insurerType) {
		this.insurerType = insurerType;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public Number getIsDeclined() {
		return isDeclined;
	}
	public void setIsDeclined(Number isDeclined) {
		this.isDeclined = isDeclined;
	}
	public void setCountryId(Number countryId) {
		this.countryId = countryId;
	}
	public GetGlConfigurationModel(Number countryId, String countryCode, String description,String shortDescription, Number isDeclined) {
		this.countryId = countryId;
		this.countryCode = countryCode;
		this.description=description;
		this.shortDescription = shortDescription;
		this.isDeclined = isDeclined;
	}
	
	
	public GetGlConfigurationModel( Number countryId,String description,Number stateId
			) {
		
		this.countryId = countryId;
		this.description = description;
		this.stateId = stateId;
	}

	
	
	
	public GetGlConfigurationModel( Number productId,String description, Number insurerProductTypeId, Number productTypeId,
			String productType, Number insurerId,String insurer, String productVersion, String planCategoryId,
			String insurerType) {
	
		
		this.productId = productId;
		this.description = description;
		this.insurerProductTypeId = insurerProductTypeId;
		this.productTypeId = productTypeId;
		this.insurerId = insurerId;
		this.productType = productType;
		this.insurer = insurer;
		this.productVersion = productVersion;
		this.planCategoryId = planCategoryId;
		this.insurerType = insurerType;
	}
	public GetGlConfigurationModel(Number glConfigurationId, Number productId, String productName,Number paymentCode, String paymentMode,String bankName,Number processId, String processName,Number creditGlcode, Number debitGlCode,  String creditGlName, String debitGlName,
		String creditNarration,String debitNarration,  Number createdBy, String createdOn, Number modifiedBy,
		String modifiedOn, Number isActive, String remark,Number isGstApplicaable, Number countryId, Number stateId) {
		

		this.glConfigurationId = glConfigurationId;
		this.productId = productId;
		this.productName = productName;
		this.paymentCode = paymentCode;
		this.paymentMode = paymentMode;
		this.bankName = bankName;
		this.processId = processId;
		this.processName = processName;
		this.creditGlcode = creditGlcode;
		this.debitGlCode = debitGlCode;
		this.creditGlName = creditGlName;
		this.debitGlName = debitGlName;
		this.creditNarration = creditNarration;
		this.debitNarration = debitNarration;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
		this.isActive = isActive;
		this.remark = remark;
		this.isGstApplicaable = isGstApplicaable;
		this.countryId = countryId;
		this.stateId = stateId;
	}
	public Number getGlConfigurationId() {
		return glConfigurationId;
	}
	public void setGlConfigurationId(Number glConfigurationId) {
		this.glConfigurationId = glConfigurationId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Number getProductId() {
		return productId;
	}
	public void setProductId(Number productId) {
		this.productId = productId;
	}
	public Number getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(Number paymentCode) {
		this.paymentCode = paymentCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Number getCreditGlcode() {
		return creditGlcode;
	}
	public void setCreditGlcode(Number creditGlcode) {
		this.creditGlcode = creditGlcode;
	}
	public Number getDebitGlCode() {
		return debitGlCode;
	}
	public void setDebitGlCode(Number debitGlCode) {
		this.debitGlCode = debitGlCode;
	}
	public String getCreditGlName() {
		return creditGlName;
	}
	public void setCreditGlName(String creditGlName) {
		this.creditGlName = creditGlName;
	}
	public String getDebitGlName() {
		return debitGlName;
	}
	public void setDebitGlName(String debitGlName) {
		this.debitGlName = debitGlName;
	}
	public String getDebitNarration() {
		return debitNarration;
	}
	public void setDebitNarration(String debitNarration) {
		this.debitNarration = debitNarration;
	}
	public String getCreditNarration() {
		return creditNarration;
	}
	public void setCreditNarration(String creditNarration) {
		this.creditNarration = creditNarration;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public Number getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Number modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public Number getCountryId() {
		return countryId;
	}
	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	public Number getStateId() {
		return stateId;
	}
	public void setStateId(Number stateId) {
		this.stateId = stateId;
	}
	
	
	
	public GetGlConfigurationModel(Number paymentModeId, String description) {
		super();
		this.paymentModeId = paymentModeId;
		this.description = description;
	}
	public Number getPaymentModeId() {
		return paymentModeId;
	}
	public void setPaymentModeId(Number paymentModeId) {
		this.paymentModeId = paymentModeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public GetGlConfigurationModel() {
		super();
	}
	public GetGlConfigurationModel(Number processId,String code, String processName,Number isGstApplicaable) {
		super();
		this.processId = processId;
		
		this.code = code;
		this.processName = processName;
		this.isGstApplicaable = isGstApplicaable;
	}
	public Number getProcessId() {
		return processId;
	}
	public void setProcessId(Number processId) {
		this.processId = processId;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Number getIsGstApplicaable() {
		return isGstApplicaable;
	}
	public void setIsGstApplicaable(Number isGstApplicaable) {
		this.isGstApplicaable = isGstApplicaable;
	}
	
	
	

}

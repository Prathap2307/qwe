package com.LIC.model;

public class SearchClaimDetailsModel {
	private Number pContactTypeID;
	private Number pTypeID;
	private String pMasterPolicyNo;
	private String pCertificateNo;
	private String pFirstName;
	private String pEmployeeID;
	private String pMemberID;

	public SearchClaimDetailsModel() {

	}

	public SearchClaimDetailsModel(Number pContactTypeID, Number pTypeID, String pMasterPolicyNo, String pCertificateNo,
			String pFirstName, String pEmployeeID, String pMemberID) {
		super();
		this.pContactTypeID = pContactTypeID;
		this.pTypeID = pTypeID;
		this.pMasterPolicyNo = pMasterPolicyNo;
		this.pCertificateNo = pCertificateNo;
		this.pFirstName = pFirstName;
		this.pEmployeeID = pEmployeeID;
		this.pMemberID = pMemberID;
	}

	public Number getpContactTypeID() {
		return pContactTypeID;
	}

	public void setpContactTypeID(Integer pContactTypeID) {
		this.pContactTypeID = pContactTypeID;
	}

	public Number getpTypeID() {
		return pTypeID;
	}

	public void setpTypeID(Integer pTypeID) {
		this.pTypeID = pTypeID;
	}

	public String getpMasterPolicyNo() {
		return pMasterPolicyNo;
	}

	public void setpMasterPolicyNo(String pMasterPolicyNo) {
		this.pMasterPolicyNo = pMasterPolicyNo;
	}

	public String getpCertificateNo() {
		return pCertificateNo;
	}

	public void setpCertificateNo(String pCertificateNo) {
		this.pCertificateNo = pCertificateNo;
	}

	public String getpFirstName() {
		return pFirstName;
	}

	public void setpFirstName(String pFirstName) {
		this.pFirstName = pFirstName;
	}

	public String getpEmployeeID() {
		return pEmployeeID;
	}

	public void setpEmployeeID(String pEmployeeID) {
		this.pEmployeeID = pEmployeeID;
	}

	public String getpMemberID() {
		return pMemberID;
	}

	public void setpMemberID(String pMemberID) {
		this.pMemberID = pMemberID;
	}

}

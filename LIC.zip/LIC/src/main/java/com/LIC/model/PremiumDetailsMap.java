package com.LIC.model;

import java.io.Serializable;

public class PremiumDetailsMap implements Serializable {
		
    private static final long serialVersionUID = 1L;
	
	private Integer premiumDetailsId;
	private Integer premiumId;
	private Integer expressAsID;
	private Integer influencingFactorID;
	private Integer specificValuesID;
	private Integer minimumValue;
	private Integer maximumValue;
	private Integer minimumValueMonth;
	private Integer maximumValueMonth;
	
	
	public Integer getPremiumDetailsId() {
		return premiumDetailsId;
	}
	public void setPremiumDetailsId(Integer premiumDetailsId) {
		this.premiumDetailsId = premiumDetailsId;
	}
	public Integer getPremiumId() {
		return premiumId;
	}
	public void setPremiumId(Integer premiumId) {
		this.premiumId = premiumId;
	}
	public Integer getInfluencingFactorID() {
		return influencingFactorID;
	}
	public void setInfluencingFactorID(Integer influencingFactorID) {
		this.influencingFactorID = influencingFactorID;
	}
	public Integer getSpecificValuesID() {
		return specificValuesID;
	}
	public void setSpecificValuesID(Integer specificValuesID) {
		this.specificValuesID = specificValuesID;
	}
	public Integer getMinimumValue() {
		return minimumValue;
	}
	public void setMinimumValue(Integer minimumValue) {
		this.minimumValue = minimumValue;
	}
	public Integer getMaximumValue() {
		return maximumValue;
	}
	public void setMaximumValue(Integer maximumValue) {
		this.maximumValue = maximumValue;
	}
	public Integer getMinimumValueMonth() {
		return minimumValueMonth;
	}
	public void setMinimumValueMonth(Integer minimumValueMonth) {
		this.minimumValueMonth = minimumValueMonth;
	}
	public Integer getMaximumValueMonth() {
		return maximumValueMonth;
	}
	public void setMaximumValueMonth(Integer maximumValueMonth) {
		this.maximumValueMonth = maximumValueMonth;
	}
	public Integer getExpressAsID() {
		return expressAsID;
	}
	public void setExpressAsID(Integer expressAsID) {
		this.expressAsID = expressAsID;
	}
	
	 
}

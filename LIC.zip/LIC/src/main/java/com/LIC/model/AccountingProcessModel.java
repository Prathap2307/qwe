package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity

@Table(name="M_Process")
@Getter
@Setter
public class AccountingProcessModel {
	
	
	@Id
	private Number processID;
	private String code;
	private String description;
	private Number createdBy;
	private Date createdOn;
	private Number isActive;
	private Number isGSTApplicable;
	private Number isTaxApplicable;
	private Number gstTypeID;
	private Number dupID;
	private String processName;
	private Number accountProcessID;
	private Number groupName;
	private Number modifiedBy;
	private Date modifiedOn;
	
	
	  public AccountingProcessModel(Number processID, String code,String processName, Number createdBy, Date
	  createdOn,  Number modifiedBy, Date modifiedOn, Number isActive, Number isGSTApplicable, Number isTaxApplicable, Number
	  gstTypeID) {
	 
	  this.processID = processID; 
	  this.code = code;
	  this.processName = processName;
	  this.createdBy = createdBy;
	  this.createdOn = createdOn; 
	  this.modifiedBy = modifiedBy;
	  this.modifiedOn = modifiedOn;
	  this.isActive = isActive; 
	  this.isGSTApplicable =isGSTApplicable; 
	  this.isTaxApplicable = isTaxApplicable;
	  this.gstTypeID =gstTypeID;
	 
	  }
	 
	
	public AccountingProcessModel()
	{
		
	}
	

	

	public AccountingProcessModel(Number processID, String code, String processName, Number isGSTApplicable) {
		super();
		this.processID = processID;
		this.code = code;
		this.isGSTApplicable = isGSTApplicable;
		this.processName = processName;
	}


	public Number getProcessID() {
		return processID;
	}
	public void setProcessID(Number processID) {
		this.processID = processID;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public Number getIsGSTApplicable() {
		return isGSTApplicable;
	}
	public void setIsGSTApplicable(Number isGSTApplicable) {
		this.isGSTApplicable = isGSTApplicable;
	}
	public Number getIsTaxApplicable() {
		return isTaxApplicable;
	}
	public void setIsTaxApplicable(Number isTaxApplicable) {
		this.isTaxApplicable = isTaxApplicable;
	}
	public Number getgstTypeID() {
		return gstTypeID;
	}
	public void setgstTypeID(Number gstTypeID) {
		this.gstTypeID = gstTypeID;
	}
	public Number getDupID() {
		return dupID;
	}
	public void setDupID(Number dupID) {
		this.dupID = dupID;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public Number getAccountProcessID() {
		return accountProcessID;
	}
	public void setAccountProcessID(Number accountProcessID) {
		this.accountProcessID = accountProcessID;
	}
	public Number getGroupName() {
		return groupName;
	}
	public void setGroupName(Number groupName) {
		this.groupName = groupName;
	}
	public Number getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Number modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
	


}

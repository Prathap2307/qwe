package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class SubChannelModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	    	
	    private long 		 	SubChannelID;
	    private long 		 	MainChannelID;
	    private String 		 	Description;
	    private String      	shortDescription;
	    private String       	ChannelName;
	    private String       	MainChannelName;
	    private String       	ChannelCode;
        private long     		CategroyID;
	    private long 		 	CreatedBy;
	    private Timestamp 	 	CreatedOn; 
	    private long 			ModifiedBy;
	    private Timestamp 	 	ModifiedOn;
	    private short 		 	IsActive;
	    private long       		DeletedBy;
	    private Timestamp   	DeletedOn;
	    private String 			MobileNo;
 	    private String 			Email;
 	    private String 			PolicyHolderCode;
 	    private long 		 	BranchID;
	    private short 		 	IsCDAccount;
	    private short 		 	IsPhysicalEntry;
	    private double 			TriggerLimit;
	    private short 			IsBlanket;
		private short 			IsChildrenAccess;
		private long 		 	ChannelID;
		private String 			SubChannelNameWithCode;
		private List<BranchModal> branchModalList;
	    
		public long getSubChannelID() {
			return SubChannelID;
		}
		public void setSubChannelID(long subChannelID) {
			SubChannelID = subChannelID;
		}

		public long getMainChannelID() {
			return MainChannelID;
		}

		public void setMainChannelID(long mainChannelID) {
			MainChannelID = mainChannelID;
		}

		public String getDescription() {
			return Description;
		}

		public void setDescription(String description) {
			Description = description;
		}

		public String getshortDescription() {
			return shortDescription;
		}
		public void setshortDescription(String shortDescription) {
			this.shortDescription = shortDescription;
		}
		public String getChannelName() {
			return ChannelName;
		}

		public void setChannelName(String channelName) {
			ChannelName = channelName;
		}
		public String getChannelCode() {
			return ChannelCode;
		}

		public void setChannelCode(String channelCode) {
			ChannelCode = channelCode;
		}

		public long getCategroyID() {
			return CategroyID;
		}

		public void setCategroyID(long categroyID) {
			CategroyID = categroyID;
		}

		public long getCreatedBy() {
			return CreatedBy;
		}

		public void setCreatedBy(long createdBy) {
			CreatedBy = createdBy;
		}

		public Timestamp getCreatedOn() {
			return CreatedOn;
		}

		public void setCreatedOn(Timestamp createdOn) {
			CreatedOn = createdOn;
		}

		public long getModifiedBy() {
			return ModifiedBy;
		}

		public void setModifiedBy(long modifiedBy) {
			ModifiedBy = modifiedBy;
		}

		public Timestamp getModifiedOn() {
			return ModifiedOn;
		}

		public void setModifiedOn(Timestamp modifiedOn) {
			ModifiedOn = modifiedOn;
		}

		public short getIsActive() {
			return IsActive;
		}

		public void setIsActive(short isActive) {
			IsActive = isActive;
		}

		public long getDeletedBy() {
			return DeletedBy;
		}

		public void setDeletedBy(long deletedBy) {
			DeletedBy = deletedBy;
		}

		public Timestamp getDeletedOn() {
			return DeletedOn;
		}

		public void setDeletedOn(Timestamp deletedOn) {
			DeletedOn = deletedOn;
		}

		public String getMobileNo() {
			return MobileNo;
		}

		public void setMobileNo(String mobileNo) {
			MobileNo = mobileNo;
		}

		public String getEmail() {
			return Email;
		}

		public void setEmail(String email) {
			Email = email;
		}

		public String getPolicyHolderCode() {
			return PolicyHolderCode;
		}

		public void setPolicyHolderCode(String policyHolderCode) {
			PolicyHolderCode = policyHolderCode;
		}

		public long getBranchID() {
			return BranchID;
		}

		public void setBranchID(long branchID) {
			BranchID = branchID;
		}

		public short getIsCDAccount() {
			return IsCDAccount;
		}

		public void setIsCDAccount(short isCDAccount) {
			IsCDAccount = isCDAccount;
		}

		public short getIsPhysicalEntry() {
			return IsPhysicalEntry;
		}

		public void setIsPhysicalEntry(short isPhysicalEntry) {
			IsPhysicalEntry = isPhysicalEntry;
		}

		public double getTriggerLimit() {
			return TriggerLimit;
		}

		public void setTriggerLimit(double triggerLimit) {
			TriggerLimit = triggerLimit;
		}

		public short getIsBlanket() {
			return IsBlanket;
		}

		public void setIsBlanket(short isBlanket) {
			IsBlanket = isBlanket;
		}

		public short getIsChildrenAccess() {
			return IsChildrenAccess;
		}

		public void setIsChildrenAccess(short isChildrenAccess) {
			IsChildrenAccess = isChildrenAccess;
		}
		public String getMainChannelName() {
			return MainChannelName;
		}
		public void setMainChannelName(String mainChannelName) {
			MainChannelName = mainChannelName;
		}
		public long getChannelID() {
			return ChannelID;
		}
		public void setChannelID(long channelID) {
			ChannelID = channelID;
		}
		public String getSubChannelNameWithCode() {
			return SubChannelNameWithCode;
		}
		public void setSubChannelNameWithCode(String subChannelNameWithCode) {
			SubChannelNameWithCode = subChannelNameWithCode;
		}
		public List<BranchModal> getBranchModalList() {
			return branchModalList;
		}
		public void setBranchModalList(List<BranchModal> branchModalList) {
			this.branchModalList = branchModalList;
		}

		

		
	
	   

	   
		
		
	
	    

	   
}

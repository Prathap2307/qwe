package com.LIC.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

public class MasterGroupDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int 	groupId;
	private String 	groupName;
	private String 	customerGroupId;
	private String 	coreBusiness;
	private int 	salutationId;
	private String 	contactFirstName;
	private String 	contactMiddleName;
	private String	contactLastName;
	private String 	contact;
	private int 	masterPolicyAgreement;
	private Date 	agreementStartDate;
	private Date 	agreementEndDate;
	private int 	branchId;
	private String 	email;
	private String 	employeeURLKey;
	private String 	password;
	private String 	logo;
	private int 	createdBy;
	private Date 	createdOn;
	private short 	isActive;
	private short 	isSms;
	private short 	isEmail;
	private String 	shortName;
	private int 	riskCategoryId;
	private int 	turnOver;
	private int 	salesHierarchyId;
	private int 	isParentGroup;
	private int 	parentGroupId;
	private int 	hierarchyId;
	private String 	panNo;
	private String 	gstNo;
	private int 	clientTypeId;
	private int 	gstTypeId;
	private String 	sacCode;
	private int 	resultout;
	private long 	userId;
	private List<ClientAddressDetails> clientAddressDetails;
	private List<MasterGrade> masterGrades;
	
	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public int getGroupId() {
		return groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public String getCustomerGroupId() {
		return customerGroupId;
	}
	public String getCoreBusiness() {
		return coreBusiness;
	}
	public int getSalutationId() {
		return salutationId;
	}
	public String getContactFirstName() {
		return contactFirstName;
	}
	public String getContactMiddleName() {
		return contactMiddleName;
	}
	public String getContactLastName() {
		return contactLastName;
	}
	public String getContact() {
		return contact;
	}
	public int getMasterPolicyAgreement() {
		return masterPolicyAgreement;
	}
	public Date getAgreementStartDate() {
		return agreementStartDate;
	}
	public Date getAgreementEndDate() {
		return agreementEndDate;
	}
	public int getBranchId() {
		return branchId;
	}
	public String getEmail() {
		return email;
	}
	public String getEmployeeURLKey() {
		return employeeURLKey;
	}
	public String getPassword() {
		return password;
	}
	public String getLogo() {
		return logo;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public short getIsSms() {
		return isSms;
	}
	public short getIsEmail() {
		return isEmail;
	}
	public String getShortName() {
		return shortName;
	}
	public int getRiskCategoryId() {
		return riskCategoryId;
	}
	public int getTurnOver() {
		return turnOver;
	}
	public int getSalesHierarchyId() {
		return salesHierarchyId;
	}
	public int getIsParentGroup() {
		return isParentGroup;
	}
	public int getParentGroupId() {
		return parentGroupId;
	}
	public int getHierarchyId() {
		return hierarchyId;
	}
	public String getPanNo() {
		return panNo;
	}
	public String getGstNo() {
		return gstNo;
	}
	public int getClientTypeId() {
		return clientTypeId;
	}
	public int getGstTypeId() {
		return gstTypeId;
	}
	public String getSacCode() {
		return sacCode;
	}
	public int getResultout() {
		return resultout;
	}
	public List<ClientAddressDetails> getClientAddressDetails() {
		return clientAddressDetails;
	}
	public List<MasterGrade> getMasterGrades() {
		return masterGrades;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public void setCustomerGroupId(String customerGroupId) {
		this.customerGroupId = customerGroupId;
	}
	public void setCoreBusiness(String coreBusiness) {
		this.coreBusiness = coreBusiness;
	}
	public void setSalutationId(int salutationId) {
		this.salutationId = salutationId;
	}
	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}
	public void setContactMiddleName(String contactMiddleName) {
		this.contactMiddleName = contactMiddleName;
	}
	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public void setMasterPolicyAgreement(int masterPolicyAgreement) {
		this.masterPolicyAgreement = masterPolicyAgreement;
	}
	public void setAgreementStartDate(Date agreementStartDate) {
		this.agreementStartDate = agreementStartDate;
	}
	public void setAgreementEndDate(Date agreementEndDate) {
		this.agreementEndDate = agreementEndDate;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setEmployeeURLKey(String employeeURLKey) {
		this.employeeURLKey = employeeURLKey;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	public void setIsSms(short isSms) {
		this.isSms = isSms;
	}
	public void setIsEmail(short isEmail) {
		this.isEmail = isEmail;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public void setRiskCategoryId(int riskCategoryId) {
		this.riskCategoryId = riskCategoryId;
	}
	public void setTurnOver(int turnOver) {
		this.turnOver = turnOver;
	}
	public void setSalesHierarchyId(int salesHierarchyId) {
		this.salesHierarchyId = salesHierarchyId;
	}
	public void setIsParentGroup(int isParentGroup) {
		this.isParentGroup = isParentGroup;
	}
	public void setParentGroupId(int parentGroupId) {
		this.parentGroupId = parentGroupId;
	}
	public void setHierarchyId(int hierarchyId) {
		this.hierarchyId = hierarchyId;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}
	public void setClientTypeId(int clientTypeId) {
		this.clientTypeId = clientTypeId;
	}
	public void setGstTypeId(int gstTypeId) {
		this.gstTypeId = gstTypeId;
	}
	public void setSacCode(String sacCode) {
		this.sacCode = sacCode;
	}
	public void setResultout(int resultout) {
		this.resultout = resultout;
	}
	public void setClientAddressDetails(List<ClientAddressDetails> clientAddressDetails) {
		this.clientAddressDetails = clientAddressDetails;
	}
	public void setMasterGrades(List<MasterGrade> masterGrades) {
		this.masterGrades = masterGrades;
	}
	@Override
	public String toString() {
		return "MasterGroupDetails [groupId=" + groupId + ", groupName=" + groupName + ", customerGroupId="
				+ customerGroupId + ", coreBusiness=" + coreBusiness + ", salutationId=" + salutationId
				+ ", contactFirstName=" + contactFirstName + ", contactMiddleName=" + contactMiddleName
				+ ", contactLastName=" + contactLastName + ", contact=" + contact + ", masterPolicyAgreement="
				+ masterPolicyAgreement + ", agreementStartDate=" + agreementStartDate + ", agreementEndDate="
				+ agreementEndDate + ", branchId=" + branchId + ", email=" + email + ", employeeURLKey="
				+ employeeURLKey + ", password=" + password + ", logo=" + logo + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", isActive=" + isActive + ", isSms=" + isSms + ", isEmail=" + isEmail
				+ ", shortName=" + shortName + ", riskCategoryId=" + riskCategoryId + ", turnOver=" + turnOver
				+ ", salesHierarchyId=" + salesHierarchyId + ", isParentGroup=" + isParentGroup + ", parentGroupId="
				+ parentGroupId + ", hierarchyId=" + hierarchyId + ", panNo=" + panNo + ", gstNo=" + gstNo
				+ ", clientTypeId=" + clientTypeId + ", gstTypeId=" + gstTypeId + ", sacCode=" + sacCode
				+ ", resultout=" + resultout + ", userId=" + userId + ", clientAddressDetails=" + clientAddressDetails
				+ ", masterGrades=" + masterGrades + "]";
	}
	
	
}



package com.LIC.model;

import java.io.Serializable;
public class ProductExclusion extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer exclusionId;
	private Integer productID;
	private String descripition;
	
	public Integer getExclusionId() {
		return exclusionId;
	}
	public void setExclusionId(Integer exclusionId) {
		this.exclusionId = exclusionId;
	}
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public String getDescripition() {
		return descripition;
	}
	public void setDescripition(String descripition) {
		this.descripition = descripition;
	}


	
	
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class InsurerModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	 
	    private long 		insurerID;
	    private long 		lineOfBusinessID;
	    private long 		distributionID;
	    private Timestamp	dateOfCommencement;
	    private String		geographicalPresence;
	    private String 		insurerName;
	    private String		logo;
	    private long		addressId;
	    private long 		createdBy;
		private Timestamp 	createdOn;
		private long 		modifiedBy;
		private Timestamp 	modifiedOn;
		private long 		deletedBy;
		private Timestamp 	deletedOn;
		private long 		isActive;
		private String		collectionGLCode;
		private String		paymentGLCode;
		private String		freshGLCode;
		private String		apOnlineGLCode;
		private String		licPremiumPaymentGLCode;
		private String		revivalGLCode;
		private String		medicalGLCode;
		private String		claimGLCode;
		private long		triggerLimitforStampDuty;
		private String		intimationEmailaddressforStampDuty;
		private String		intimationMobileNumberforStampDuty;
		private String		panNo;
		private String		gstNo;
		private String      description;
		
		private List<LineOfBusinessInsurerModel>	lineOfBusinessInsurerList;
		private List<ContactAddressModal>			contactAddressModalList;
		private ContactAddressModal contactAddressModal;
		
			//ContactAddressModal
		    private long   			addressTypeID ;
		    private long 			countryID  ;
		    private long 			stateID    ;
		    private long 			districtID ;
		    private long 			talukID    ;
		    private String 			address1   ;
		    private String 			address2   ;
		    private String 			address3   ;
		    private String 			address4   ;
		    private String 			address5  ;
		    private String 			zipcode    ;
		    private String 			phoneNumber ;
		    private String 			mobilNumber       ;
		    private String 			conferenceNumber   ;
		    private String 			faxNumber ;
		    private String 			email ;
		    private String   		tehsil ;
		    
		    
		
		
		public long getAddressTypeID() {
				return addressTypeID;
			}
			public void setAddressTypeID(long addressTypeID) {
				this.addressTypeID = addressTypeID;
			}
			public long getCountryID() {
				return countryID;
			}
			public void setCountryID(long countryID) {
				this.countryID = countryID;
			}
			public long getStateID() {
				return stateID;
			}
			public void setStateID(long stateID) {
				this.stateID = stateID;
			}
			public long getDistrictID() {
				return districtID;
			}
			public void setDistrictID(long districtID) {
				this.districtID = districtID;
			}
			public long getTalukID() {
				return talukID;
			}
			public void setTalukID(long talukID) {
				this.talukID = talukID;
			}
			public String getAddress1() {
				return address1;
			}
			public void setAddress1(String address1) {
				this.address1 = address1;
			}
			public String getAddress2() {
				return address2;
			}
			public void setAddress2(String address2) {
				this.address2 = address2;
			}
			public String getAddress3() {
				return address3;
			}
			public void setAddress3(String address3) {
				this.address3 = address3;
			}
			public String getAddress4() {
				return address4;
			}
			public void setAddress4(String address4) {
				this.address4 = address4;
			}
			public String getAddress5() {
				return address5;
			}
			public void setAddress5(String address5) {
				this.address5 = address5;
			}
			public String getZipcode() {
				return zipcode;
			}
			public void setZipcode(String zipcode) {
				this.zipcode = zipcode;
			}
			public String getPhoneNumber() {
				return phoneNumber;
			}
			public void setPhoneNumber(String phoneNumber) {
				this.phoneNumber = phoneNumber;
			}
			public String getMobilNumber() {
				return mobilNumber;
			}
			public void setMobilNumber(String mobilNumber) {
				this.mobilNumber = mobilNumber;
			}
			public String getConferenceNumber() {
				return conferenceNumber;
			}
			public void setConferenceNumber(String conferenceNumber) {
				this.conferenceNumber = conferenceNumber;
			}
			public String getFaxNumber() {
				return faxNumber;
			}
			public void setFaxNumber(String faxNumber) {
				this.faxNumber = faxNumber;
			}
			public String getEmail() {
				return email;
			}
			public void setEmail(String email) {
				this.email = email;
			}
			public String getTehsil() {
				return tehsil;
			}
			public void setTehsil(String tehsil) {
				this.tehsil = tehsil;
			}
		public ContactAddressModal getContactAddressModal() {
			return contactAddressModal;
		}
		public void setContactAddressModal(ContactAddressModal contactAddressModal) {
			this.contactAddressModal = contactAddressModal;
		}
		public List<ContactAddressModal> getContactAddressModalList() {
			return contactAddressModalList;
		}
		public void setContactAddressModalList(List<ContactAddressModal> contactAddressModalList) {
			this.contactAddressModalList = contactAddressModalList;
		}
		public long getInsurerID() {
			return insurerID;
		}
		public void setInsurerID(long insurerID) {
			this.insurerID = insurerID;
		}
		public long getLineOfBusinessID() {
			return lineOfBusinessID;
		}
		public void setLineOfBusinessID(long lineOfBusinessID) {
			this.lineOfBusinessID = lineOfBusinessID;
		}
		public long getDistributionID() {
			return distributionID;
		}
		public void setDistributionID(long distributionID) {
			this.distributionID = distributionID;
		}
		public Timestamp getDateOfCommencement() {
			return dateOfCommencement;
		}
		public void setDateOfCommencement(Timestamp dateOfCommencement) {
			this.dateOfCommencement = dateOfCommencement;
		}
		public String getGeographicalPresence() {
			return geographicalPresence;
		}
		public void setGeographicalPresence(String geographicalPresence) {
			this.geographicalPresence = geographicalPresence;
		}
		public String getInsurerName() {
			return insurerName;
		}
		public void setInsurerName(String insurerName) {
			this.insurerName = insurerName;
		}
		public String getLogo() {
			return logo;
		}
		public void setLogo(String logo) {
			this.logo = logo;
		}
		public long getAddressId() {
			return addressId;
		}
		public void setAddressId(long addressId) {
			this.addressId = addressId;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public long getIsActive() {
			return isActive;
		}
		public void setIsActive(long isActive) {
			this.isActive = isActive;
		}
		public String getCollectionGLCode() {
			return collectionGLCode;
		}
		public void setCollectionGLCode(String collectionGLCode) {
			this.collectionGLCode = collectionGLCode;
		}
		public String getPaymentGLCode() {
			return paymentGLCode;
		}
		public void setPaymentGLCode(String paymentGLCode) {
			this.paymentGLCode = paymentGLCode;
		}
		public String getFreshGLCode() {
			return freshGLCode;
		}
		public void setFreshGLCode(String freshGLCode) {
			this.freshGLCode = freshGLCode;
		}
		public String getApOnlineGLCode() {
			return apOnlineGLCode;
		}
		public void setApOnlineGLCode(String apOnlineGLCode) {
			this.apOnlineGLCode = apOnlineGLCode;
		}
		public String getLicPremiumPaymentGLCode() {
			return licPremiumPaymentGLCode;
		}
		public void setLicPremiumPaymentGLCode(String licPremiumPaymentGLCode) {
			this.licPremiumPaymentGLCode = licPremiumPaymentGLCode;
		}
		public String getRevivalGLCode() {
			return revivalGLCode;
		}
		public void setRevivalGLCode(String revivalGLCode) {
			this.revivalGLCode = revivalGLCode;
		}
		public String getMedicalGLCode() {
			return medicalGLCode;
		}
		public void setMedicalGLCode(String medicalGLCode) {
			this.medicalGLCode = medicalGLCode;
		}
		public String getClaimGLCode() {
			return claimGLCode;
		}
		public void setClaimGLCode(String claimGLCode) {
			this.claimGLCode = claimGLCode;
		}
		public long getTriggerLimitforStampDuty() {
			return triggerLimitforStampDuty;
		}
		public void setTriggerLimitforStampDuty(long triggerLimitforStampDuty) {
			this.triggerLimitforStampDuty = triggerLimitforStampDuty;
		}
		public String getIntimationEmailaddressforStampDuty() {
			return intimationEmailaddressforStampDuty;
		}
		public void setIntimationEmailaddressforStampDuty(String intimationEmailaddressforStampDuty) {
			this.intimationEmailaddressforStampDuty = intimationEmailaddressforStampDuty;
		}
		public String getIntimationMobileNumberforStampDuty() {
			return intimationMobileNumberforStampDuty;
		}
		public void setIntimationMobileNumberforStampDuty(String intimationMobileNumberforStampDuty) {
			this.intimationMobileNumberforStampDuty = intimationMobileNumberforStampDuty;
		}
		public String getPanNo() {
			return panNo;
		}
		public void setPanNo(String panNo) {
			this.panNo = panNo;
		}
		public String getGstNo() {
			return gstNo;
		}
		public void setGstNo(String gstNo) {
			this.gstNo = gstNo;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public List<LineOfBusinessInsurerModel> getLineOfBusinessInsurerList() {
			return lineOfBusinessInsurerList;
		}
		public void setLineOfBusinessInsurerList(List<LineOfBusinessInsurerModel> lineOfBusinessInsurerList) {
			this.lineOfBusinessInsurerList = lineOfBusinessInsurerList;
		}
		@Override
		public String toString() {
			return "InsurerModal [insurerID=" + insurerID + ", lineOfBusinessID=" + lineOfBusinessID
					+ ", distributionID=" + distributionID + ", dateOfCommencement=" + dateOfCommencement
					+ ", geographicalPresence=" + geographicalPresence + ", insurerName=" + insurerName + ", logo="
					+ logo + ", addressId=" + addressId + ", createdBy=" + createdBy + ", createdOn=" + createdOn
					+ ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + ", deletedBy=" + deletedBy
					+ ", deletedOn=" + deletedOn + ", isActive=" + isActive + ", collectionGLCode=" + collectionGLCode
					+ ", paymentGLCode=" + paymentGLCode + ", freshGLCode=" + freshGLCode + ", apOnlineGLCode="
					+ apOnlineGLCode + ", licPremiumPaymentGLCode=" + licPremiumPaymentGLCode + ", revivalGLCode="
					+ revivalGLCode + ", medicalGLCode=" + medicalGLCode + ", claimGLCode=" + claimGLCode
					+ ", triggerLimitforStampDuty=" + triggerLimitforStampDuty + ", intimationEmailaddressforStampDuty="
					+ intimationEmailaddressforStampDuty + ", intimationMobileNumberforStampDuty="
					+ intimationMobileNumberforStampDuty + ", panNo=" + panNo + ", gstNo=" + gstNo + ", description="
					+ description + ", lineOfBusinessInsurerList=" + lineOfBusinessInsurerList
					+ ", contactAddressModalList=" + contactAddressModalList + ", contactAddressModal="
					+ contactAddressModal + ", addressTypeID=" + addressTypeID + ", countryID=" + countryID
					+ ", stateID=" + stateID + ", districtID=" + districtID + ", talukID=" + talukID + ", address1="
					+ address1 + ", address2=" + address2 + ", address3=" + address3 + ", address4=" + address4
					+ ", address5=" + address5 + ", zipcode=" + zipcode + ", phoneNumber=" + phoneNumber
					+ ", mobilNumber=" + mobilNumber + ", conferenceNumber=" + conferenceNumber + ", faxNumber="
					+ faxNumber + ", email=" + email + ", tehsil=" + tehsil + "]";
		}
		
		
}


package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetAllAccountProcessTaxMapModeModel {
	@Id
	private Number modeId;
	private String Mode;
	
		
	public GetAllAccountProcessTaxMapModeModel(Number modeId, String mode) {
		super();
		this.modeId = modeId;
		Mode = mode;
	}
	
	public Number getModeId() {
		return modeId;
	}
	public void setModeId(Number modeId) {
		this.modeId = modeId;
	}
	public String getMode() {
		return Mode;
	}
	public void setMode(String mode) {
		Mode = mode;
	}
	
	
}

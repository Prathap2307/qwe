package com.LIC.model;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.Timestamp;


public class AuthorisedSignatoryModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;

		private long 		AuthorisedSignatoryID ;
		private long  		ModuleID;
		private String  	ModuleName;
		private String 		Name ;
		private String 		Designation ;
		private String 		Email ;
		private String 		ContactMobileNo ;
		private String 		Signature ;
		private Blob 		imgSignature;
		private long  		CreatedBy ;
		private Timestamp	CreatedOn ;
		private long  		ModifiedBy ;
		private  Timestamp 	ModifiedOn ;
		private long  		DeletedBy ;
		private  Timestamp 	DeletedOn ;
		private short  		IsActive;
		
		
		public long getAuthorisedSignatoryID() {
			return AuthorisedSignatoryID;
		}
		public void setAuthorisedSignatoryID(long authorisedSignatoryID) {
			AuthorisedSignatoryID = authorisedSignatoryID;
		}
		public long getModuleID() {
			return ModuleID;
		}
		public void setModuleID(long moduleID) {
			ModuleID = moduleID;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getDesignation() {
			return Designation;
		}
		public void setDesignation(String designation) {
			Designation = designation;
		}
		public String getEmail() {
			return Email;
		}
		public void setEmail(String email) {
			Email = email;
		}
		public String getContactMobileNo() {
			return ContactMobileNo;
		}
		public void setContactMobileNo(String contactMobileNo) {
			ContactMobileNo = contactMobileNo;
		}
		public String getSignature() {
			return Signature;
		}
		public void setSignature(String signature) {
			Signature = signature;
		}
		public long getCreatedBy() {
			return CreatedBy;
		}
		public void setCreatedBy(long createdBy) {
			CreatedBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return CreatedOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			CreatedOn = createdOn;
		}
		public long getModifiedBy() {
			return ModifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			ModifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return ModifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			ModifiedOn = modifiedOn;
		}
		public long getDeletedBy() {
			return DeletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			DeletedBy = deletedBy;
		}
		public Timestamp getDeletedOn() {
			return DeletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			DeletedOn = deletedOn;
		}
		public short getIsActive() {
			return IsActive;
		}
		public void setIsActive(short isActive) {
			IsActive = isActive;
		}
		public Blob getImgSignature() {
			return imgSignature;
		}
		public void setImgSignature(Blob image) {
			this.imgSignature = image;
		}
		public String getModuleName() {
			return ModuleName;
		}
		public void setModuleName(String moduleName) {
			ModuleName = moduleName;
		}

}

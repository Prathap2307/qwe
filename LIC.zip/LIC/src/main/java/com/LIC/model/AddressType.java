package com.LIC.model;

import java.io.Serializable;

public class AddressType extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer addressTypeID;
	private String description; 
	private String remarks;
	 

	
	public Integer getAddressTypeID() {
		return addressTypeID;
	}
	public void setAddressTypeID(Integer addressTypeID) {
		this.addressTypeID = addressTypeID;
	}
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	 
	
}

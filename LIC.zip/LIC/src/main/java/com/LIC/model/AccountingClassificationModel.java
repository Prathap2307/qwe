package com.LIC.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name="master_accountclassification")
@Getter
@Setter
public class AccountingClassificationModel {
	@Id
	private int accountClassificationID;
	private String code;
	private String description;
	private int createdBy;
	private int isactive;

	public int getAccountClassificationID() {
		return accountClassificationID;
	}
	public void setAccountClassificationID(int accountClassificationID) {
		this.accountClassificationID = accountClassificationID;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public int getIsactive() {
		return isactive;
	}
	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}
	
}

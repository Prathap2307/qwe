package com.LIC.model;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="master_accountclassification")
@Getter
@Setter
public class GetAccountingClassificationModel {
	@Id
	private Number accountClassificationID;
	private String code;
	private String description;
	private Number createdBy;
	private Number isactive;
	private String createdOn;
	private Number modifiedBy;
	private String modifiedOn;
	
 
	public GetAccountingClassificationModel()
    {
     super();
    }
   
  	public GetAccountingClassificationModel(Number accountClassificationID, String code,String description,Number isactive,Number createdBy,String createdOn
			,Number modifiedBy,String modifiedOn) {
		super();
		this.accountClassificationID=accountClassificationID;
		this.code=code;
		this.description=description;
		this.isactive=isactive;
		this.createdBy=createdBy;
		this.createdOn=createdOn;
		this.modifiedBy=modifiedBy;
		this.modifiedOn=modifiedOn;
	}

	public GetAccountingClassificationModel(Number accountClassificationID, String code,String description,Number createdBy,Number isactive) {
		super();
		this.accountClassificationID=accountClassificationID;
		this.code=code;
		this.description=description;
		this.createdBy=createdBy;
		this.isactive=isactive;
		
	}
	

	public Number getAccountClassificationID() {
		return accountClassificationID;
	}

	public void setAccountClassificationID(Number accountClassificationID) {
		this.accountClassificationID = accountClassificationID;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Number getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}

	public Number getIsactive() {
		return isactive;
	}

	public void setIsactive(Number isactive) {
		this.isactive = isactive;
	}
	

	public String getCreatedOn() {
		return createdOn;
	}



	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}



	public Number getModifiedBy() {
		return modifiedBy;
	}



	public void setModifiedBy(Number modifiedBy) {
		this.modifiedBy = modifiedBy;
	}



	public String getModifiedOn() {
		return modifiedOn;
	}



	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}


	
}


package com.LIC.model;

import java.io.Serializable;


public class DocumentCategory extends RecordModifier  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer documentCategoryId;
	private String description;
	private String shortDescription; 
	private String remarks;
	
	public Integer getDocumentCategoryId() {
		return documentCategoryId;
	}

	public void setDocumentCategoryId(Integer documentCategoryId) {
		this.documentCategoryId = documentCategoryId;
	}
	
	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	
	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}

package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

/*
 * @Author = "671621"
 */
@Entity
public class OnSelectionOfGridClaimsAssessmentModel {

	@Id
	private int pClaimID;

	private int pApplicationID;
	private int pProductID;

	private int pID;

	private int pTransactionID;
	private int pBalanceAmount;
	private int pClaimedAmount;
	private int pApprovedAmount;
	private int pSumInsured;

	private int pSURVEYORHISTORYID;
	private String pClaimNUMBER;
	private int pSurveyorID;
	private int pSurveyorExpenses;
	private int pCreatedBy;
	private Date pCreatedOn;
	private int pModifiedSurveyorExpenses;
	private int pSurveyorBranchID;
	private int pSurveyorCityID;
	private String pDESCRIPTION;
	private String pSurveyorFirstName;
	private String pSurveyorLastName;
	private String pFIRSTNAME;
	private String pLASTNAME;
	private String pAssessmentRemarks;

	public OnSelectionOfGridClaimsAssessmentModel() {
		
	}

	public OnSelectionOfGridClaimsAssessmentModel(int pClaimID) {
		this.pClaimID = pClaimID;
	}

	public OnSelectionOfGridClaimsAssessmentModel(int pApplicationID, int pProductID) {
		this.pApplicationID = pApplicationID;
		this.pProductID = pProductID;
	}

	public OnSelectionOfGridClaimsAssessmentModel(int pTransactionID, int pBalanceAmount, int pClaimedAmount,
			int pApprovedAmount, int pSumInsured) {
		this.pTransactionID = pTransactionID;
		this.pBalanceAmount = pBalanceAmount;
		this.pClaimedAmount = pClaimedAmount;
		this.pApprovedAmount = pApprovedAmount;
		this.pSumInsured = pSumInsured;
	}

	public OnSelectionOfGridClaimsAssessmentModel(int pSURVEYORHISTORYID, int pClaimID, String pClaimNUMBER,
			int pSurveyorID, int pSurveyorExpenses, int pCreatedBy, Date pCreatedOn, int pModifiedSurveyorExpenses,
			int pSurveyorBranchID, int pSurveyorCityID, String pDESCRIPTION, String pSurveyorFirstName,
			String pSurveyorLastName, String pFIRSTNAME, String pLASTNAME, String pAssessmentRemarks) {
		this.pSURVEYORHISTORYID = pSURVEYORHISTORYID;
		this.pClaimID = pClaimID;
		this.pClaimNUMBER = pClaimNUMBER;
		this.pSurveyorID = pSurveyorID;
		this.pSurveyorExpenses = pSurveyorExpenses;
		this.pCreatedBy = pCreatedBy;
		this.pCreatedOn = pCreatedOn;
		this.pModifiedSurveyorExpenses = pModifiedSurveyorExpenses;
		this.pSurveyorBranchID = pSurveyorBranchID;
		this.pSurveyorCityID = pSurveyorCityID;
		this.pDESCRIPTION = pDESCRIPTION;
		this.pSurveyorFirstName = pSurveyorFirstName;
		this.pSurveyorLastName = pSurveyorLastName;
		this.pFIRSTNAME = pFIRSTNAME;
		this.pLASTNAME = pLASTNAME;
		this.pAssessmentRemarks = pAssessmentRemarks;
	}

	public int getpClaimID() {
		return pClaimID;
	}

	public void setpClaimID(int pClaimID) {
		this.pClaimID = pClaimID;
	}

	public int getpApplicationID() {
		return pApplicationID;
	}

	public void setpApplicationID(int pApplicationID) {
		this.pApplicationID = pApplicationID;
	}

	public int getpProductID() {
		return pProductID;
	}

	public void setpProductID(int pProductID) {
		this.pProductID = pProductID;
	}

	public int getpID() {
		return pID;
	}

	public void setpID(int pID) {
		this.pID = pID;
	}

	public int getpTransactionID() {
		return pTransactionID;
	}

	public void setpTransactionID(int pTransactionID) {
		this.pTransactionID = pTransactionID;
	}

	public int getpBalanceAmount() {
		return pBalanceAmount;
	}

	public void setpBalanceAmount(int pBalanceAmount) {
		this.pBalanceAmount = pBalanceAmount;
	}

	public int getpClaimedAmount() {
		return pClaimedAmount;
	}

	public void setpClaimedAmount(int pClaimedAmount) {
		this.pClaimedAmount = pClaimedAmount;
	}

	public int getpApprovedAmount() {
		return pApprovedAmount;
	}

	public void setpApprovedAmount(int pApprovedAmount) {
		this.pApprovedAmount = pApprovedAmount;
	}

	public int getpSumInsured() {
		return pSumInsured;
	}

	public void setpSumInsured(int pSumInsured) {
		this.pSumInsured = pSumInsured;
	}

	public int getpSURVEYORHISTORYID() {
		return pSURVEYORHISTORYID;
	}

	public void setpSURVEYORHISTORYID(int pSURVEYORHISTORYID) {
		this.pSURVEYORHISTORYID = pSURVEYORHISTORYID;
	}

	public String getpClaimNUMBER() {
		return pClaimNUMBER;
	}

	public void setpClaimNUMBER(String pClaimNUMBER) {
		this.pClaimNUMBER = pClaimNUMBER;
	}

	public int getpSurveyorID() {
		return pSurveyorID;
	}

	public void setpSurveyorID(int pSurveyorID) {
		this.pSurveyorID = pSurveyorID;
	}

	public int getpSurveyorExpenses() {
		return pSurveyorExpenses;
	}

	public void setpSurveyorExpenses(int pSurveyorExpenses) {
		this.pSurveyorExpenses = pSurveyorExpenses;
	}

	public int getpCreatedBy() {
		return pCreatedBy;
	}

	public void setpCreatedBy(int pCreatedBy) {
		this.pCreatedBy = pCreatedBy;
	}

	public Date getpCreatedOn() {
		return pCreatedOn;
	}

	public void setpCreatedOn(Date pCreatedOn) {
		this.pCreatedOn = pCreatedOn;
	}

	public int getpModifiedSurveyorExpenses() {
		return pModifiedSurveyorExpenses;
	}

	public void setpModifiedSurveyorExpenses(int pModifiedSurveyorExpenses) {
		this.pModifiedSurveyorExpenses = pModifiedSurveyorExpenses;
	}

	public int getpSurveyorBranchID() {
		return pSurveyorBranchID;
	}

	public void setpSurveyorBranchID(int pSurveyorBranchID) {
		this.pSurveyorBranchID = pSurveyorBranchID;
	}

	public int getpSurveyorCityID() {
		return pSurveyorCityID;
	}

	public void setpSurveyorCityID(int pSurveyorCityID) {
		this.pSurveyorCityID = pSurveyorCityID;
	}

	public String getpDESCRIPTION() {
		return pDESCRIPTION;
	}

	public void setpDESCRIPTION(String pDESCRIPTION) {
		this.pDESCRIPTION = pDESCRIPTION;
	}

	public String getpSurveyorFirstName() {
		return pSurveyorFirstName;
	}

	public void setpSurveyorFirstName(String pSurveyorFirstName) {
		this.pSurveyorFirstName = pSurveyorFirstName;
	}

	public String getpSurveyorLastName() {
		return pSurveyorLastName;
	}

	public void setpSurveyorLastName(String pSurveyorLastName) {
		this.pSurveyorLastName = pSurveyorLastName;
	}

	public String getpFIRSTNAME() {
		return pFIRSTNAME;
	}

	public void setpFIRSTNAME(String pFIRSTNAME) {
		this.pFIRSTNAME = pFIRSTNAME;
	}

	public String getpLASTNAME() {
		return pLASTNAME;
	}

	public void setpLASTNAME(String pLASTNAME) {
		this.pLASTNAME = pLASTNAME;
	}

	public String getpAssessmentRemarks() {
		return pAssessmentRemarks;
	}

	public void setpAssessmentRemarks(String pAssessmentRemarks) {
		this.pAssessmentRemarks = pAssessmentRemarks;
	}

}

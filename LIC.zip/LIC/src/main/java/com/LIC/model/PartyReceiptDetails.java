package com.LIC.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class PartyReceiptDetails {

	private String certificateId;
	
	private long lineOfBusinessId;
	
	private long partyId;
	
	private String receiptNo;
	List<ApplicationPremiumDetails> applicationDetails = new ArrayList<ApplicationPremiumDetails>();
	
	public String getCertificateId() {
		return certificateId;
	}

	public List<ApplicationPremiumDetails> getApplicationDetails() {
		return applicationDetails;
	}

	public void setApplicationDetails(List<ApplicationPremiumDetails> applicationDetails) {
		this.applicationDetails = applicationDetails;
	}

	public void setCertificateId(String certificateId) {
		this.certificateId = certificateId;
	}

	public long getLineOfBusinessId() {
		return lineOfBusinessId;
	}

	public void setLineOfBusinessId(long lineOfBusinessId) {
		this.lineOfBusinessId = lineOfBusinessId;
	}

	public long getPartyId() {
		return partyId;
	}

	public void setPartyId(long partyId) {
		this.partyId = partyId;
	}

	public String getReceiptNo() {
		return receiptNo;
	}

	public void setReceiptNo(String receiptNo) {
		this.receiptNo = receiptNo;
	}

	public long getTypeId() {
		return typeId;
	}

	public void setTypeId(long typeId) {
		this.typeId = typeId;
	}

	public long getIsMasterPolicy() {
		return isMasterPolicy;
	}

	public void setIsMasterPolicy(long isMasterPolicy) {
		this.isMasterPolicy = isMasterPolicy;
	}

	public long getMasterGroupId() {
		return masterGroupId;
	}

	public void setMasterGroupId(long masterGroupId) {
		this.masterGroupId = masterGroupId;
	}

	public long getMasterPolicyId() {
		return masterPolicyId;
	}

	public void setMasterPolicyId(long masterPolicyId) {
		this.masterPolicyId = masterPolicyId;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	private long receiptId;

	public long getReceiptId() {
		return receiptId;
	}

	public void setReceiptId(long receiptId) {
		this.receiptId = receiptId;
	}

	private long typeId;
	
	private long isMasterPolicy;
	
	private long masterGroupId;
	
	private long masterPolicyId;
	
	private long createdBy;
	
	private Date createdOn;
}

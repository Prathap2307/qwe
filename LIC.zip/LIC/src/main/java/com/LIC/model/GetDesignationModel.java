package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_DESIGNATION")
public class GetDesignationModel {
	@Id
	private Number designationId;
	private String shortName;
	private String description;
	private Number departmentId;
	private String department;
	
	public Number getDesignationId() {
		return designationId;
	}
	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public Number getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Number departmentId) {
		this.departmentId = departmentId;
	}
	
	
	
	
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public void setDesignationId(Number designationId) {
		this.designationId = designationId;
	}
	public GetDesignationModel(Number designationId, String shortName, String description, Number departmentId,String department) {
		super();
		this.designationId = designationId;
		this.shortName = shortName;
		this.description = description;
		this.departmentId = departmentId;
		this.department = department;
		
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class GroupDetailsModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	 
	    private Long groupID ;
	    private String groupName ;
	    private String shortName ;
	    private String customerGroupID ;
	    private String coreBusiness ;
		 private Long	SalutationID ;
		 private String contactFirstName ;
		 private String ContactMiddleName ;
		 private String ContactLastName ;
		 private String ContactNumber ;
		 private Long masterPolicyAgreement ;
		 private Timestamp agreementStartDate ;
		private Timestamp agreementEndDate ;
		 private Long branchID ;
		 private Long createdBy ;
		 private Timestamp createdOn ;
		 private Long modifiedBy ;
		private Timestamp ModifiedOn ;
		 private Long deletedBy ;
		private Timestamp DeletedOn ;
		 private Long isActive ;
		 private Long dayClose ;
		 private Long	status ;
		private Timestamp SystemDate ;
		 private Long isSmsApplicable ;
		 private Long isEmailApplicable ;
	private String  Logo ;
		private String email ;
		private String password ;
		private String employeeURLKey; 
		 private Long riskCateryID ;
		 private Long salesHierarchyID ;
		 private Long parentGroupID ;
		 private Long hierarchyID ;
		 private String panNo ;
		 private String gstNo ;
		 private Long clientTypeID ;
		 private Long gstTypeID ;
		 private Long turnOver ;
		 private Long isParentGroup ;
		 private String sacCode ;
		public Long getGroupID() {
			return groupID;
		}
		public void setGroupID(Long groupID) {
			this.groupID = groupID;
		}
		public String getGroupName() {
			return groupName;
		}
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}
		public String getShortName() {
			return shortName;
		}
		public void setShortName(String shortName) {
			this.shortName = shortName;
		}
		public String getCustomerGroupID() {
			return customerGroupID;
		}
		public void setCustomerGroupID(String customerGroupID) {
			this.customerGroupID = customerGroupID;
		}
		public String getCoreBusiness() {
			return coreBusiness;
		}
		public void setCoreBusiness(String coreBusiness) {
			this.coreBusiness = coreBusiness;
		}
		public Long getSalutationID() {
			return SalutationID;
		}
		public void setSalutationID(Long salutationID) {
			SalutationID = salutationID;
		}
		public String getContactFirstName() {
			return contactFirstName;
		}
		public void setContactFirstName(String contactFirstName) {
			this.contactFirstName = contactFirstName;
		}
		public String getContactMiddleName() {
			return ContactMiddleName;
		}
		public void setContactMiddleName(String contactMiddleName) {
			ContactMiddleName = contactMiddleName;
		}
		public String getContactLastName() {
			return ContactLastName;
		}
		public void setContactLastName(String contactLastName) {
			ContactLastName = contactLastName;
		}
		public String getContactNumber() {
			return ContactNumber;
		}
		public void setContactNumber(String contactNumber) {
			ContactNumber = contactNumber;
		}
		public Long getMasterPolicyAgreement() {
			return masterPolicyAgreement;
		}
		public void setMasterPolicyAgreement(Long masterPolicyAgreement) {
			this.masterPolicyAgreement = masterPolicyAgreement;
		}
		public Timestamp getAgreementStartDate() {
			return agreementStartDate;
		}
		public void setAgreementStartDate(Timestamp agreementStartDate) {
			this.agreementStartDate = agreementStartDate;
		}
		public Timestamp getAgreementEndDate() {
			return agreementEndDate;
		}
		public void setAgreementEndDate(Timestamp agreementEndDate) {
			this.agreementEndDate = agreementEndDate;
		}
		public Long getBranchID() {
			return branchID;
		}
		public void setBranchID(Long branchID) {
			this.branchID = branchID;
		}
		public Long getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(Long createdBy) {
			this.createdBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public Long getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(Long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return ModifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			ModifiedOn = modifiedOn;
		}
		public Long getDeletedBy() {
			return deletedBy;
		}
		public void setDeletedBy(Long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public Timestamp getDeletedOn() {
			return DeletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			DeletedOn = deletedOn;
		}
		public Long getIsActive() {
			return isActive;
		}
		public void setIsActive(Long isActive) {
			this.isActive = isActive;
		}
		public Long getDayClose() {
			return dayClose;
		}
		public void setDayClose(Long dayClose) {
			this.dayClose = dayClose;
		}
		public Long getStatus() {
			return status;
		}
		public void setStatus(Long status) {
			this.status = status;
		}
		public Timestamp getSystemDate() {
			return SystemDate;
		}
		public void setSystemDate(Timestamp systemDate) {
			SystemDate = systemDate;
		}
		public Long getIsSmsApplicable() {
			return isSmsApplicable;
		}
		public void setIsSmsApplicable(Long isSmsApplicable) {
			this.isSmsApplicable = isSmsApplicable;
		}
		public Long getIsEmailApplicable() {
			return isEmailApplicable;
		}
		public void setIsEmailApplicable(Long isEmailApplicable) {
			this.isEmailApplicable = isEmailApplicable;
		}
		public String getLogo() {
			return Logo;
		}
		public void setLogo(String logo) {
			Logo = logo;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getEmployeeURLKey() {
			return employeeURLKey;
		}
		public void setEmployeeURLKey(String employeeURLKey) {
			this.employeeURLKey = employeeURLKey;
		}
		public Long getRiskCateryID() {
			return riskCateryID;
		}
		public void setRiskCateryID(Long riskCateryID) {
			this.riskCateryID = riskCateryID;
		}
		public Long getSalesHierarchyID() {
			return salesHierarchyID;
		}
		public void setSalesHierarchyID(Long salesHierarchyID) {
			this.salesHierarchyID = salesHierarchyID;
		}
		public Long getParentGroupID() {
			return parentGroupID;
		}
		public void setParentGroupID(Long parentGroupID) {
			this.parentGroupID = parentGroupID;
		}
		public Long getHierarchyID() {
			return hierarchyID;
		}
		public void setHierarchyID(Long hierarchyID) {
			this.hierarchyID = hierarchyID;
		}
		public String getPanNo() {
			return panNo;
		}
		public void setPanNo(String panNo) {
			this.panNo = panNo;
		}
		public String getGstNo() {
			return gstNo;
		}
		public void setGstNo(String gstNo) {
			this.gstNo = gstNo;
		}
		public Long getClientTypeID() {
			return clientTypeID;
		}
		public void setClientTypeID(Long clientTypeID) {
			this.clientTypeID = clientTypeID;
		}
		public Long getGstTypeID() {
			return gstTypeID;
		}
		public void setGstTypeID(Long gstTypeID) {
			this.gstTypeID = gstTypeID;
		}
		public Long getTurnOver() {
			return turnOver;
		}
		public void setTurnOver(Long turnOver) {
			this.turnOver = turnOver;
		}
		public Long getIsParentGroup() {
			return isParentGroup;
		}
		public void setIsParentGroup(Long isParentGroup) {
			this.isParentGroup = isParentGroup;
		}
		public String getSacCode() {
			return sacCode;
		}
		public void setSacCode(String sacCode) {
			this.sacCode = sacCode;
		}
		
	   
		
	   
}

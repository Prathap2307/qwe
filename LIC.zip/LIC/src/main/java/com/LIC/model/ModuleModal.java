package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class ModuleModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	 
	    private long 		ModuleId;
	    private long 		divisionID;
	    private String 		Description;
		private long  		CreatedBy ;
		private Timestamp 	CreatedOn ;
		private long  		ModifiedBy ;
		private Timestamp 	ModifiedOn ;
		private long  		DeletedBy ;
		private Timestamp 	DeletedOn ;
		private long  		IsActive ;
		
		public long getModuleId() {
			return ModuleId;
		}
		public void setModuleId(long moduleId) {
			this.ModuleId = moduleId;
		}
		public long getDivisionID() {
			return divisionID;
		}
		public void setDivisionID(long divisionID) {
			this.divisionID = divisionID;
		}
		public String getDescription() {
			return Description;
		}
		public void setDescription(String description) {
			Description = description;
		}
		public long getCreatedBy() {
			return CreatedBy;
		}
		public void setCreatedBy(long createdBy) {
			CreatedBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return CreatedOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			CreatedOn = createdOn;
		}
		public long getModifiedBy() {
			return ModifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			ModifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return ModifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			ModifiedOn = modifiedOn;
		}
		public long getDeletedBy() {
			return DeletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			DeletedBy = deletedBy;
		}
		public Timestamp getDeletedOn() {
			return DeletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			DeletedOn = deletedOn;
		}
		public long getIsActive() {
			return IsActive;
		}
		public void setIsActive(long isActive) {
			IsActive = isActive;
		}
	   
}

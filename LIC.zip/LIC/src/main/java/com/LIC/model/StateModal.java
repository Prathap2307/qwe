package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class StateModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	 
	    private long 		 stateID;
		private long 	     countryID;
	    private String 		 description;
	    private long 		 createdBy;
	    private Timestamp 	 createdOn; 
	    private short 		 isActive;
	    private Timestamp    deletedOn;
	    private long         deletedBy;
	    private long 		 excludeTax;
	    private String 		 tinNumber;
	    
		public long getStateID() {
			return stateID;
		}
		public void setStateID(long stateID) {
			this.stateID = stateID;
		}
		public long getCountryID() {
			return countryID;
		}
		public void setCountryID(long countryID) {
			this.countryID = countryID;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public long getExcludeTax() {
			return excludeTax;
		}
		public void setExcludeTax(long excludeTax) {
			this.excludeTax = excludeTax;
		}
		public String getTinNumber() {
		
			return tinNumber;
		}
		public void setTinNumber(String tinNumber) {
			this.tinNumber = tinNumber;
		}
		
}

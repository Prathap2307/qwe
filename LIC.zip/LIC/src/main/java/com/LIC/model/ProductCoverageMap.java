package com.LIC.model;

import java.io.Serializable;

public class ProductCoverageMap extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer productId;
	private Integer coverageId;
	private Integer isBaseCoverage;
	private Integer isSelectable;
	private Double maxCoverageSumAssured;
	private Integer typeofCoverID;
	private Integer calculationID ;
	private Integer packageID;
	private Double packageRate;
	private Integer isStampDutyApplicable;
	private Integer stampDutyType;
	private Double stampDutyRate;
	private String effectFromDate; //dd/MM/yyyy
	private String effectToDate; //dd/MM/yyyy
	private String coverageNameStr;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getCoverageId() {
		return coverageId;
	}
	public void setCoverageId(Integer coverageId) {
		this.coverageId = coverageId;
	}
	public Integer getIsBaseCoverage() {
		return isBaseCoverage;
	}
	public void setIsBaseCoverage(Integer isBaseCoverage) {
		this.isBaseCoverage = isBaseCoverage;
	}
	public Integer getIsSelectable() {
		return isSelectable;
	}
	public void setIsSelectable(Integer isSelectable) {
		this.isSelectable = isSelectable;
	}
	public Double getMaxCoverageSumAssured() {
		return maxCoverageSumAssured;
	}
	public void setMaxCoverageSumAssured(Double maxCoverageSumAssured) {
		this.maxCoverageSumAssured = maxCoverageSumAssured;
	}
	public Integer getTypeofCoverID() {
		return typeofCoverID;
	}
	public void setTypeofCoverID(Integer typeofCoverID) {
		this.typeofCoverID = typeofCoverID;
	}
	public Integer getCalculationID() {
		return calculationID;
	}
	public void setCalculationID(Integer calculationID) {
		this.calculationID = calculationID;
	}
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public Double getPackageRate() {
		return packageRate;
	}
	public void setPackageRate(Double packageRate) {
		this.packageRate = packageRate;
	}
	public Integer getIsStampDutyApplicable() {
		return isStampDutyApplicable;
	}
	public void setIsStampDutyApplicable(Integer isStampDutyApplicable) {
		this.isStampDutyApplicable = isStampDutyApplicable;
	}
	public Integer getStampDutyType() {
		if(null == stampDutyType) {
			stampDutyType = 0;
		}
		return stampDutyType;
	}
	public void setStampDutyType(Integer stampDutyType) {
		this.stampDutyType = stampDutyType;
	}
	public Double getStampDutyRate() {
		if(null == stampDutyRate) {
			stampDutyRate = 0.0;
		}
		return stampDutyRate;
	}
	public void setStampDutyRate(Double stampDutyRate) {
		this.stampDutyRate = stampDutyRate;
	}
	public String getEffectFromDate() {
		return effectFromDate;
	}
	public void setEffectFromDate(String effectFromDate) {
		this.effectFromDate = effectFromDate;
	}
	public String getEffectToDate() {
		return effectToDate;
	}
	public void setEffectToDate(String effectToDate) {
		this.effectToDate = effectToDate;
	}
	public String getCoverageNameStr() {
		return coverageNameStr;
	}
	public void setCoverageNameStr(String coverageNameStr) {
		this.coverageNameStr = coverageNameStr;
	}
	
	
}

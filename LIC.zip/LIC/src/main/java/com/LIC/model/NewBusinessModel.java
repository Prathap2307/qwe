package com.LIC.model;
import java.util.Date;
import java.security.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class NewBusinessModel {
	@Id
private int headerId;
private String filePath;
private String fileName;

private int groupID;
private int masterPolicyID;
private int createdBy;
private Date createdOn; 
private String type;
private int authorisedSignatoryID;


public int getHeaderId() {
	return headerId;
}

public void setHeaderId(int headerId) {
	this.headerId = headerId;
}

public String getFilePath() {
	return filePath;
}

public void setFilePath(String filePath) {
	this.filePath = filePath;
}

public String getFileName() {
	return fileName;
}

public void setFileName(String fileName) {
	this.fileName = fileName;
}

public int getGroupID() {
	return groupID;
}

public void setGroupID(int groupID) {
	this.groupID = groupID;
}

public int getMasterPolicyID() {
	return masterPolicyID;
}

public void setMasterPolicyID(int masterPolicyID) {
	this.masterPolicyID = masterPolicyID;
}

public int getCreatedBy() {
	return createdBy;
}

public void setCreatedBy(int createdBy) {
	this.createdBy = createdBy;
}

public Date getCreatedOn() {
	return createdOn;
}

public void setCreatedOn(Date createdOn) {
	this.createdOn = createdOn;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public int getAuthorisedSignatoryID() {
	return authorisedSignatoryID;
}

public void setAuthorisedSignatoryID(int authorisedSignatoryID) {
	this.authorisedSignatoryID = authorisedSignatoryID;
}

public NewBusinessModel()
{
super();	
}



}

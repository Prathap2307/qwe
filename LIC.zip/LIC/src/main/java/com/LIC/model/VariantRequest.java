package com.LIC.model;

import java.io.Serializable;
import java.util.List;
 
public class VariantRequest implements  Serializable {
	private static final long serialVersionUID = 1L;
	
	private Variant variant;
	private List<ProductAgeProofDocument> ageProofDocumentList;
	private List<ProductCoverageMap> productCoverageList;
	private List<Integer> variantQuestionIdList;
	private List<Integer> variantTaxStructureIdlist;
	
	private List<Integer> frequencyIds;
	private List<Integer> coEfficientIds;
	private List<Integer> relationShipIds;
	private List<Integer> nomineeRelationShipIds;
	
	private String exclusion;
	private String verbiage;
	
	public Variant getVariant() {
		return variant;
	}
	public void setVariant(Variant variant) {
		this.variant = variant;
	}
	public List<ProductAgeProofDocument> getAgeProofDocumentList() {
		return ageProofDocumentList;
	}
	public void setAgeProofDocumentList(List<ProductAgeProofDocument> ageProofDocumentList) {
		this.ageProofDocumentList = ageProofDocumentList;
	}
	public List<ProductCoverageMap> getProductCoverageList() {
		return productCoverageList;
	}
	public void setProductCoverageList(List<ProductCoverageMap> productCoverageList) {
		this.productCoverageList = productCoverageList;
	}
	public String getExclusion() {
		return exclusion;
	}
	public void setExclusion(String exclusion) {
		this.exclusion = exclusion;
	}
	public String getVerbiage() {
		return verbiage;
	}
	public void setVerbiage(String verbiage) {
		this.verbiage = verbiage;
	}
	public List<Integer> getVariantQuestionIdList() {
		return variantQuestionIdList;
	}
	public void setVariantQuestionIdList(List<Integer> variantQuestionIdList) {
		this.variantQuestionIdList = variantQuestionIdList;
	}
	public List<Integer> getVariantTaxStructureIdlist() {
		return variantTaxStructureIdlist;
	}
	public void setVariantTaxStructureIdlist(List<Integer> variantTaxStructureIdlist) {
		this.variantTaxStructureIdlist = variantTaxStructureIdlist;
	}
	public List<Integer> getFrequencyIds() {
		return frequencyIds;
	}
	public void setFrequencyIds(List<Integer> frequencyIds) {
		this.frequencyIds = frequencyIds;
	}
	public List<Integer> getCoEfficientIds() {
		return coEfficientIds;
	}
	public void setCoEfficientIds(List<Integer> coEfficientIds) {
		this.coEfficientIds = coEfficientIds;
	}
	public List<Integer> getRelationShipIds() {
		return relationShipIds;
	}
	public void setRelationShipIds(List<Integer> relationShipIds) {
		this.relationShipIds = relationShipIds;
	}
	public List<Integer> getNomineeRelationShipIds() {
		return nomineeRelationShipIds;
	}
	public void setNomineeRelationShipIds(List<Integer> nomineeRelationShipIds) {
		this.nomineeRelationShipIds = nomineeRelationShipIds;
	}
	 
}

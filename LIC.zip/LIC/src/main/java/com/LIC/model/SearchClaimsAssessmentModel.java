package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/*
 * @Author = "671621"
 */
@Entity
public class SearchClaimsAssessmentModel {
	
	@Id
	private int pApplicationID;
	private int pCertificateNo;
	
	public SearchClaimsAssessmentModel() {

	}

	public SearchClaimsAssessmentModel(int pApplicationID, int pCertificateNo) {
		this.pApplicationID = pApplicationID;
		this.pCertificateNo = pCertificateNo;
	}

	public int getpApplicationID() {
		return pApplicationID;
	}

	public void setpApplicationID(int pApplicationID) {
		this.pApplicationID = pApplicationID;
	}

	public int getpCertificateNo() {
		return pCertificateNo;
	}

	public void setpCertificateNo(int pCertificateNo) {
		this.pCertificateNo = pCertificateNo;
	}	
	
}

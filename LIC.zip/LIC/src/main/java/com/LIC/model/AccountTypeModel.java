package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AccountTypeModel {
	@Id
	private Number AccountTypeId;
	private String AccountType;

	public AccountTypeModel(Number accountTypeId, String accountType) {
		super();
		AccountTypeId = accountTypeId;
		AccountType = accountType;
	}

	public Number getAccountTypeId() {
		return AccountTypeId;
	}
	
	public void setAccountTypeId(Number accountTypeId) {
		AccountTypeId = accountTypeId;
	}
	public String getAccountType() {
		return AccountType;
	}
	public void setAccountType(String accountType) {
		AccountType = accountType;
	}
	
	
	
}

package com.LIC.model;

import java.sql.Date;
import java.util.List;

public class MasterPolicyNo {

	private int 	lineofbusinessid;
	private int 	insurerid;
	private int 	productid; 
	private int 	plancategoryid;
	private int 	typeid;
	private int		affinitytypeid;
	private String 	masterpolicyno;
	private int 	groupid;
	private Date 	agreementstartdate;
	private Date 	agreementenddate;
	private int 	totalmembers;
	private String 	specialcondition;
	private int 	suminsured;
	private int 	saleshierarchyid;
	private String 	saleshierarcycode;
	private int 	branchid;
	private int 	isfloter;
	private int 	isddloading;
	private int 	ddloadingvalue;
	private int 	mainchannelid;
	private int 	subchannelid;
	private int 	isadvancedeposit;
	private String 	subchannelsalestype;
	private String 	relationshipids;
	private String 	nomineerelationshipids;
	private String 	coefficientids;
	private String 	insurermasteragreementno;
	private int 	gradeid;
	private int 	tpaid;
	private String  tpapolicynumber;
	private int 	createdby;
	private Date 	createdOn;
	private int 	isactive;
	private String 	description ;
	private int 	agreementtypeid;
	private int 	calculationtypeid;
	private int 	totallives;
	private int 	totalpremiumamount;
	private int 	familysizeid;
	private int 	quotationid;
	private int 	masterpolicyid;
	private int		datauploadheaderid ;
	private int 	benefittypeid ;
	private int 	isemployee;
	private int 	iscorporate;
	private int 	statusid;
	private String 	remarks;
	private String 	contactnumber;
	private String 	emailId;
	private int 	addressdifferfromclientorg;
	private String 	clientnameunit;
	private String	contactpersonfirstname ;
	private String 	contactpersonmiddlename; 
	private String 	contactpersonlastname;
	private String 	panno; 
	private int 	typeofclient;
	private int 	gsttype;
	private String 	gstin ;
	private int 	windowperiod;
	private int		 normalretirementage;
	private int 	isnriletterreceived;
	private Date 	nriletterreceiveddate;
	private int 	paymentfrequencyid;
	private int 	modalfactors;
	private int 	ispsuflag;
	private int 	zoneid;
	private int		 salutationid;
	private String	 groupName;
	private String 	receiptNo;
	private String 	shortName;
	private short 	issfq;
	private String 	declaration; 
	private int 	addressStatus;
	private String 	activelyatworkclauseremarks;
	private String 	quotationdesc;
	private int		isdeclaration;
	private int 	activelyatworkclause;
	private String masterPolicyAgreement;
	private String coreBusiness;
	private String agreementNo;

	private List<BenefitRiders> 			benefitRiders;
	private List<MasterPolicyUnitAddress> 	masterPolicyUnitAddresses;
	private int age;
	private double sumInsuredAmount;
	private String customerGroupId ;
	private int gstTypeId;
	private int clientTypeId;
	private String code;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCustomerGroupId() {
		return customerGroupId;
	}

	public void setCustomerGroupId(String customerGroupId) {
		this.customerGroupId = customerGroupId;
	}

	public int getGstTypeId() {
		return gstTypeId;
	}

	public void setGstTypeId(int gstTypeId) {
		this.gstTypeId = gstTypeId;
	}

	public int getClientTypeId() {
		return clientTypeId;
	}

	public void setClientTypeId(int clientTypeId) {
		this.clientTypeId = clientTypeId;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCoreBusiness() {
		return coreBusiness;
	}

	public void setCoreBusiness(String coreBusiness) {
		this.coreBusiness = coreBusiness;
	}

	public String getMasterPolicyAgreement() {
		return masterPolicyAgreement;
	}

	public void setMasterPolicyAgreement(String masterPolicyAgreement) {
		this.masterPolicyAgreement = masterPolicyAgreement;
	}

	public int getLineofbusinessid() {
		return lineofbusinessid;
	}

	public void setLineofbusinessid(int lineofbusinessid) {
		this.lineofbusinessid = lineofbusinessid;
	}
	public String getReceiptNo() {
		return receiptNo;
	}

	public void setReceiptNo(String receiptNo) {
		this.receiptNo = receiptNo;
	}

	public int getActivelyatworkclause() {
		return activelyatworkclause;
	}

	public void setActivelyatworkclause(int activelyatworkclause) {
		this.activelyatworkclause = activelyatworkclause;
	}


	public int getInsurerid() {
		return insurerid;
	}

	public void setInsurerid(int insurerid) {
		this.insurerid = insurerid;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public int getPlancategoryid() {
		return plancategoryid;
	}

	public void setPlancategoryid(int plancategoryid) {
		this.plancategoryid = plancategoryid;
	}

	public int getTypeid() {
		return typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public int getAffinitytypeid() {
		return affinitytypeid;
	}

	public void setAffinitytypeid(int affinitytypeid) {
		this.affinitytypeid = affinitytypeid;
	}

	public String getMasterpolicyno() {
		return masterpolicyno;
	}

	public void setMasterpolicyno(String masterpolicyno) {
		this.masterpolicyno = masterpolicyno;
	}

	public int getGroupid() {
		return groupid;
	}

	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}

	public Date getAgreementstartdate() {
		return agreementstartdate;
	}

	public void setAgreementstartdate(Date agreementstartdate) {
		this.agreementstartdate = agreementstartdate;
	}

	public Date getAgreementenddate() {
		return agreementenddate;
	}

	public void setAgreementenddate(Date agreementenddate) {
		this.agreementenddate = agreementenddate;
	}

	public int getTotalmembers() {
		return totalmembers;
	}

	public void setTotalmembers(int totalmembers) {
		this.totalmembers = totalmembers;
	}

	public String getSpecialcondition() {
		return specialcondition;
	}

	public void setSpecialcondition(String specialcondition) {
		this.specialcondition = specialcondition;
	}

	public int getSuminsured() {
		return suminsured;
	}

	public void setSuminsured(int suminsured) {
		this.suminsured = suminsured;
	}

	public int getSaleshierarchyid() {
		return saleshierarchyid;
	}

	public void setSaleshierarchyid(int saleshierarchyid) {
		this.saleshierarchyid = saleshierarchyid;
	}

	public String getSaleshierarcycode() {
		return saleshierarcycode;
	}

	public void setSaleshierarcycode(String saleshierarcycode) {
		this.saleshierarcycode = saleshierarcycode;
	}

	public int getBranchid() {
		return branchid;
	}

	public void setBranchid(int branchid) {
		this.branchid = branchid;
	}

	public int getIsfloter() {
		return isfloter;
	}

	public void setIsfloter(int isfloter) {
		this.isfloter = isfloter;
	}

	public int getIsddloading() {
		return isddloading;
	}

	public void setIsddloading(int isddloading) {
		this.isddloading = isddloading;
	}

	public int getDdloadingvalue() {
		return ddloadingvalue;
	}

	public void setDdloadingvalue(int ddloadingvalue) {
		this.ddloadingvalue = ddloadingvalue;
	}

	public int getMainchannelid() {
		return mainchannelid;
	}

	public void setMainchannelid(int mainchannelid) {
		this.mainchannelid = mainchannelid;
	}

	public int getSubchannelid() {
		return subchannelid;
	}

	public void setSubchannelid(int subchannelid) {
		this.subchannelid = subchannelid;
	}

	public int getIsadvancedeposit() {
		return isadvancedeposit;
	}

	public void setIsadvancedeposit(int isadvancedeposit) {
		this.isadvancedeposit = isadvancedeposit;
	}

	public String getSubchannelsalestype() {
		return subchannelsalestype;
	}

	public void setSubchannelsalestype(String subchannelsalestype) {
		this.subchannelsalestype = subchannelsalestype;
	}

	public String getRelationshipids() {
		return relationshipids;
	}

	public void setRelationshipids(String relationshipids) {
		this.relationshipids = relationshipids;
	}

	public String getNomineerelationshipids() {
		return nomineerelationshipids;
	}

	public void setNomineerelationshipids(String nomineerelationshipids) {
		this.nomineerelationshipids = nomineerelationshipids;
	}

	public String getCoefficientids() {
		return coefficientids;
	}

	public void setCoefficientids(String coefficientids) {
		this.coefficientids = coefficientids;
	}

	public String getInsurermasteragreementno() {
		return insurermasteragreementno;
	}

	public void setInsurermasteragreementno(String insurermasteragreementno) {
		this.insurermasteragreementno = insurermasteragreementno;
	}

	public int getGradeid() {
		return gradeid;
	}

	public void setGradeid(int gradeid) {
		this.gradeid = gradeid;
	}

	public int getTpaid() {
		return tpaid;
	}

	public void setTpaid(int tpaid) {
		this.tpaid = tpaid;
	}

	public String getTpapolicynumber() {
		return tpapolicynumber;
	}

	public void setTpapolicynumber(String tpapolicynumber) {
		this.tpapolicynumber = tpapolicynumber;
	}

	public int getCreatedby() {
		return createdby;
	}

	public void setCreatedby(int createdby) {
		this.createdby = createdby;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public int getIsactive() {
		return isactive;
	}

	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getAgreementtypeid() {
		return agreementtypeid;
	}

	public void setAgreementtypeid(int agreementtypeid) {
		this.agreementtypeid = agreementtypeid;
	}

	public int getCalculationtypeid() {
		return calculationtypeid;
	}

	public void setCalculationtypeid(int calculationtypeid) {
		this.calculationtypeid = calculationtypeid;
	}

	public int getTotallives() {
		return totallives;
	}

	public void setTotallives(int totallives) {
		this.totallives = totallives;
	}

	public int getTotalpremiumamount() {
		return totalpremiumamount;
	}

	public void setTotalpremiumamount(int totalpremiumamount) {
		this.totalpremiumamount = totalpremiumamount;
	}

	public int getFamilysizeid() {
		return familysizeid;
	}

	public void setFamilysizeid(int familysizeid) {
		this.familysizeid = familysizeid;
	}

	public int getQuotationid() {
		return quotationid;
	}

	public void setQuotationid(int quotationid) {
		this.quotationid = quotationid;
	}

	public int getMasterpolicyid() {
		return masterpolicyid;
	}

	public void setMasterpolicyid(int masterpolicyid) {
		this.masterpolicyid = masterpolicyid;
	}

	public int getDatauploadheaderid() {
		return datauploadheaderid;
	}

	public void setDatauploadheaderid(int datauploadheaderid) {
		this.datauploadheaderid = datauploadheaderid;
	}

	public int getBenefittypeid() {
		return benefittypeid;
	}

	public void setBenefittypeid(int benefittypeid) {
		this.benefittypeid = benefittypeid;
	}

	public int getIsemployee() {
		return isemployee;
	}

	public void setIsemployee(int isemployee) {
		this.isemployee = isemployee;
	}

	public int getIscorporate() {
		return iscorporate;
	}

	public void setIscorporate(int iscorporate) {
		this.iscorporate = iscorporate;
	}

	public int getStatusid() {
		return statusid;
	}

	public void setStatusid(int statusid) {
		this.statusid = statusid;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getAddressdifferfromclientorg() {
		return addressdifferfromclientorg;
	}

	public void setAddressdifferfromclientorg(int addressdifferfromclientorg) {
		this.addressdifferfromclientorg = addressdifferfromclientorg;
	}

	public String getClientnameunit() {
		return clientnameunit;
	}

	public void setClientnameunit(String clientnameunit) {
		this.clientnameunit = clientnameunit;
	}

	public String getContactpersonfirstname() {
		return contactpersonfirstname;
	}

	public void setContactpersonfirstname(String contactpersonfirstname) {
		this.contactpersonfirstname = contactpersonfirstname;
	}

	public String getContactpersonmiddlename() {
		return contactpersonmiddlename;
	}

	public void setContactpersonmiddlename(String contactpersonmiddlename) {
		this.contactpersonmiddlename = contactpersonmiddlename;
	}

	public String getContactpersonlastname() {
		return contactpersonlastname;
	}

	public void setContactpersonlastname(String contactpersonlastname) {
		this.contactpersonlastname = contactpersonlastname;
	}

	public String getPanno() {
		return panno;
	}

	public void setPanno(String panno) {
		this.panno = panno;
	}

	public int getTypeofclient() {
		return typeofclient;
	}

	public void setTypeofclient(int typeofclient) {
		this.typeofclient = typeofclient;
	}

	public int getGsttype() {
		return gsttype;
	}

	public void setGsttype(int gsttype) {
		this.gsttype = gsttype;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public int getWindowperiod() {
		return windowperiod;
	}

	public void setWindowperiod(int windowperiod) {
		this.windowperiod = windowperiod;
	}

	public int getNormalretirementage() {
		return normalretirementage;
	}

	public void setNormalretirementage(int normalretirementage) {
		this.normalretirementage = normalretirementage;
	}

	public int getIsnriletterreceived() {
		return isnriletterreceived;
	}

	public void setIsnriletterreceived(int isnriletterreceived) {
		this.isnriletterreceived = isnriletterreceived;
	}

	public Date getNriletterreceiveddate() {
		return nriletterreceiveddate;
	}

	public void setNriletterreceiveddate(Date nriletterreceiveddate) {
		this.nriletterreceiveddate = nriletterreceiveddate;
	}

	public int getPaymentfrequencyid() {
		return paymentfrequencyid;
	}

	public void setPaymentfrequencyid(int paymentfrequencyid) {
		this.paymentfrequencyid = paymentfrequencyid;
	}

	public int getModalfactors() {
		return modalfactors;
	}

	public void setModalfactors(int modalfactors) {
		this.modalfactors = modalfactors;
	}

	public int getIspsuflag() {
		return ispsuflag;
	}

	public void setIspsuflag(int ispsuflag) {
		this.ispsuflag = ispsuflag;
	}

	public int getZoneid() {
		return zoneid;
	}

	public void setZoneid(int zoneid) {
		this.zoneid = zoneid;
	}

	public int getSalutationid() {
		return salutationid;
	}

	public void setSalutationid(int salutationid) {
		this.salutationid = salutationid;
	}

	public String getActivelyatworkclauseremarks() {
		return activelyatworkclauseremarks;
	}

	public void setActivelyatworkclauseremarks(String activelyatworkclauseremarks) {
		this.activelyatworkclauseremarks = activelyatworkclauseremarks;
	}

	public String getQuotationdesc() {
		return quotationdesc;
	}

	public void setQuotationdesc(String quotationdesc) {
		this.quotationdesc = quotationdesc;
	}

	public int getIsdeclaration() {
		return isdeclaration;
	}

	public void setIsdeclaration(int isdeclaration) {
		this.isdeclaration = isdeclaration;
	}

	public int getIssfq() {
		return issfq;
	}

	public void setIssfq(short issfq) {
		this.issfq = issfq;
	}

	public String getDeclaration() {
		return declaration;
	}

	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public List<MasterPolicyUnitAddress> getMasterPolicyUnitAddresses() {
		return masterPolicyUnitAddresses;
	}

	public void setMasterPolicyUnitAddresses(
			List<MasterPolicyUnitAddress> masterPolicyUnitAddresses) {
		this.masterPolicyUnitAddresses = masterPolicyUnitAddresses;
	}

	public int getAddressStatus() {
		return addressStatus;
	}

	public void setAddressStatus(int addressStatus) {
		this.addressStatus = addressStatus;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}



	public List<BenefitRiders> getBenefitRiders() {
		return benefitRiders;
	}

	public void setBenefitRiders(List<BenefitRiders> benefitRiders) {
		this.benefitRiders = benefitRiders;
	}

	public String getAgreementNo() {
		return agreementNo;
	}

	public void setAgreementNo(String agreementNo) {
		this.agreementNo = agreementNo;
	}

	@Override
	public String toString() {
		return "MasterPolicyNo [lineofbusinessid=" + lineofbusinessid + ", insurerid=" + insurerid + ", productid="
				+ productid + ", plancategoryid=" + plancategoryid + ", typeid=" + typeid + ", affinitytypeid="
				+ affinitytypeid + ", masterpolicyno=" + masterpolicyno + ", groupid=" + groupid
				+ ", agreementstartdate=" + agreementstartdate + ", agreementenddate=" + agreementenddate
				+ ", totalmembers=" + totalmembers + ", specialcondition=" + specialcondition + ", suminsured="
				+ suminsured + ", saleshierarchyid=" + saleshierarchyid + ", saleshierarcycode=" + saleshierarcycode
				+ ", branchid=" + branchid + ", isfloter=" + isfloter + ", isddloading=" + isddloading
				+ ", ddloadingvalue=" + ddloadingvalue + ", mainchannelid=" + mainchannelid + ", subchannelid="
				+ subchannelid + ", isadvancedeposit=" + isadvancedeposit + ", subchannelsalestype="
				+ subchannelsalestype + ", relationshipids=" + relationshipids + ", nomineerelationshipids="
				+ nomineerelationshipids + ", coefficientids=" + coefficientids + ", insurermasteragreementno="
				+ insurermasteragreementno + ", gradeid=" + gradeid + ", tpaid=" + tpaid + ", tpapolicynumber="
				+ tpapolicynumber + ", createdby=" + createdby + ", createdOn=" + createdOn + ", isactive=" + isactive
				+ ", description=" + description + ", agreementtypeid=" + agreementtypeid + ", calculationtypeid="
				+ calculationtypeid + ", totallives=" + totallives + ", totalpremiumamount=" + totalpremiumamount
				+ ", familysizeid=" + familysizeid + ", quotationid=" + quotationid + ", masterpolicyid="
				+ masterpolicyid + ", datauploadheaderid=" + datauploadheaderid + ", benefittypeid=" + benefittypeid
				+ ", isemployee=" + isemployee + ", iscorporate=" + iscorporate + ", statusid=" + statusid
				+ ", remarks=" + remarks + ", contactnumber=" + contactnumber + ", emailId=" + emailId
				+ ", addressdifferfromclientorg=" + addressdifferfromclientorg + ", clientnameunit=" + clientnameunit
				+ ", contactpersonfirstname=" + contactpersonfirstname + ", contactpersonmiddlename="
				+ contactpersonmiddlename + ", contactpersonlastname=" + contactpersonlastname + ", panno=" + panno
				+ ", typeofclient=" + typeofclient + ", gsttype=" + gsttype + ", gstin=" + gstin + ", windowperiod="
				+ windowperiod + ", normalretirementage=" + normalretirementage + ", isnriletterreceived="
				+ isnriletterreceived + ", nriletterreceiveddate=" + nriletterreceiveddate + ", paymentfrequencyid="
				+ paymentfrequencyid + ", modalfactors=" + modalfactors + ", ispsuflag=" + ispsuflag + ", zoneid="
				+ zoneid + ", salutationid=" + salutationid + ", groupName=" + groupName + ", receiptNo=" + receiptNo
				+ ", shortName=" + shortName + ", issfq=" + issfq + ", declaration=" + declaration + ", addressStatus="
				+ addressStatus + ", activelyatworkclauseremarks=" + activelyatworkclauseremarks + ", quotationdesc="
				+ quotationdesc + ", isdeclaration=" + isdeclaration + ", activelyatworkclause=" + activelyatworkclause
				+ ", masterPolicyAgreement=" + masterPolicyAgreement + ", coreBusiness=" + coreBusiness
				+ ", agreementNo=" + agreementNo + ", benefitRiders=" + benefitRiders + ", masterPolicyUnitAddresses="
				+ masterPolicyUnitAddresses + ", age=" + age + "]";
	}

	public double getSumInsuredAmount() {
		return sumInsuredAmount;
	}

	public void setSumInsuredAmount(double sumInsuredAmount) {
		this.sumInsuredAmount = sumInsuredAmount;
	}

	
	
	


}

package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

@NamedStoredProcedureQuery(
		name 			= "createOrUpdateProduct", 
		procedureName 	= "InsertorUpdatePlanDetails",
		resultClasses 	= {ProductModel.class},
		parameters 		= {

							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vOrganisationID", type = Integer.class),
							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPlanID", type = Integer.class),
							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPlanName", type = String.class),
							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vShortName", type = String.class),
							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCategory", type = Integer.class),
							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedBy", type = Integer.class),
							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedOn", type = Date.class),
							@StoredProcedureParameter(mode = ParameterMode.IN, name = "vIsActive", type = Integer.class),
							@StoredProcedureParameter(mode = ParameterMode.OUT, name = "vResult", type = Long.class)
						}
		)
		



@NamedStoredProcedureQuery(
		name 				= "deleteProduct", 
		procedureName 		= "spDeletePlan",
		resultClasses 		= {ProductModel.class},
		parameters 			= {
								@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPlanID", type = Integer.class),
								@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDeletedBy", type = Integer.class),
								@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDeletedOn", type = Date.class),
								@StoredProcedureParameter(mode = ParameterMode.OUT, name = "RESULT1", type = String.class)
							}
)










@Entity
@Table(name="MASTER_PLAN")
public class ProductModel {
	@Id
	private int planId;
	private int organisationId;
	private String planName;
	private String shortName;
	private int productTypeId;
	private int category;
	private int isActive;
	private int createdBy;
	private Date createdOn;
	private int deletedBy;
	private Date deletedOn;
	private int modifiedBy;
	private Date modifiedOn;
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public int getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(int organisationId) {
		this.organisationId = organisationId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public int getProductTypeId() {
		return productTypeId;
	}
	public void setProductTypeId(int productTypeId) {
		this.productTypeId = productTypeId;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	@Override
	public String toString() {
		return "ProductModel [planId=" + planId + ", organisationId=" + organisationId + ", planName=" + planName
				+ ", shortName=" + shortName + ", productTypeId=" + productTypeId + ", category=" + category
				+ ", isActive=" + isActive + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", deletedBy="
				+ deletedBy + ", deletedOn=" + deletedOn + ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn
				+ "]";
	}
	
	
	
	
	
	
	
	
}       

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class AddressTypeModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	 
	    private long 			addressTypeId ; 
	    private long 	     	countryID;
	    private String 		 	description;
	    private long 		 	createdBy;
	    private Timestamp 	 	createdOn; 
	    private long 			modifiedBy;
	    private Timestamp 		modifiedOn;
	    private short 		 	isActive;
	    private Timestamp   	deletedOn;
	    
	    
		public long getAddressTypeId() {
			return addressTypeId;
		}
		public long getCountryID() {
			return countryID;
		}
		public String getDescription() {
			return description;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setAddressTypeId(long addressTypeId) {
			this.addressTypeId = addressTypeId;
		}
		public void setCountryID(long countryID) {
			this.countryID = countryID;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
	   
}

package com.LIC.model;

import java.io.Serializable;

public class DeDupeFieldsModel extends RecordModifier implements Serializable {

	
	private Integer deDupeFieldsID;
	private String description;
	private String shortDescription;
	private String descriptionColumnName;
	private String shortDescriptionColumnName;
	
	
	public Integer getDeDupeFieldsID() {
		return deDupeFieldsID;
	}
	public String getDescription() {
		return description;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public String getDescriptionColumnName() {
		return descriptionColumnName;
	}
	public String getShortDescriptionColumnName() {
		return shortDescriptionColumnName;
	}
	public void setDeDupeFieldsID(Integer deDupeFieldsID) {
		this.deDupeFieldsID = deDupeFieldsID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public void setDescriptionColumnName(String descriptionColumnName) {
		this.descriptionColumnName = descriptionColumnName;
	}
	public void setShortDescriptionColumnName(String shortDescriptionColumnName) {
		this.shortDescriptionColumnName = shortDescriptionColumnName;
	}
	@Override
	public String toString() {
		return "DeDupeFieldsModel [deDupeFieldsID=" + deDupeFieldsID + ", description=" + description
				+ ", shortDescription=" + shortDescription + ", descriptionColumnName=" + descriptionColumnName
				+ ", shortDescriptionColumnName=" + shortDescriptionColumnName + "]";
	}
	
	
}

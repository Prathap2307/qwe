package com.LIC.model;



import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class NewBusinessOutputModel {
@Id
private Number headerId;
private Number totalRecords;
private Number successRecords;
private Number failureRecords;
private String fileName;
private String uploadDate;


public Number getHeaderId() {
	return headerId;
}
public void setHeaderId(Number headerId) {
	this.headerId = headerId;
}
public Number getTotalRecords() {
	return totalRecords;
}
public void setTotalRecords(Number totalRecords) {
	this.totalRecords = totalRecords;
}
public Number getSuccessRecords() {
	return successRecords;
}
public void setSuccessRecords(Number successRecords) {
	this.successRecords = successRecords;
}
public Number getFailureRecords() {
	return failureRecords;
}
public void setFailureRecords(Number failureRecords) {
	this.failureRecords = failureRecords;
}
public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}
public String getUploadDate() {
	return uploadDate;
}
public void setUploadDate(String uploadDate) {
	this.uploadDate = uploadDate;
}

public NewBusinessOutputModel()
{
	super();
}

public NewBusinessOutputModel(Number totalRecords, Number successRecords, Number failureRecords,Number headerId,
		String fileName) {
	super();
	this.headerId = headerId;
	this.totalRecords = totalRecords;
	this.successRecords = successRecords;
	this.failureRecords = failureRecords;
	this.fileName = fileName;
	
}



}

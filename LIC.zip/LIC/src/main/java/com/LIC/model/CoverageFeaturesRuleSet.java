package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class CoverageFeaturesRuleSet implements Serializable
{
	private static final long serialVersionUID = 1L;
	public static final String COVERAGE_FEATURES_RULESET  = "CoverageFeaturesRuleSet";
	
	private long 		rulesetID; 
	private long 		productID; 
	private long 		coverageID; 
	private String 		ruleSetName; 
	private long 		processID; 
	private String 		documentTypeIds; 
	private long 		createdBy; 
	private Timestamp 	createdOn; 
	private long 		modifiedBy; 
	private Timestamp	modifiedOn; 
	private long 		deletedBy; 
	private Timestamp	deletedOn; 
	private short 		isActive;
	
	
	public long getRulesetID() {
		return rulesetID;
	}
	public void setRulesetID(long rulesetID) {
		this.rulesetID = rulesetID;
	}
	public long getProductID() {
		return productID;
	}
	public void setProductID(long productID) {
		this.productID = productID;
	}
	public long getCoverageID() {
		return coverageID;
	}
	public void setCoverageID(long coverageID) {
		this.coverageID = coverageID;
	}
	public String getRuleSetName() {
		return ruleSetName;
	}
	public void setRuleSetName(String ruleSetName) {
		this.ruleSetName = ruleSetName;
	}
	public long getProcessID() {
		return processID;
	}
	public void setProcessID(long processID) {
		this.processID = processID;
	}
	public String getDocumentTypeIds() {
		return documentTypeIds;
	}
	public void setDocumentTypeIds(String documentTypeIds) {
		this.documentTypeIds = documentTypeIds;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public long getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(long deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Timestamp getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}
	public short getIsActive() {
		return isActive;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	
	
	
	
		
		
		
}

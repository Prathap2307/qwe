package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class GetLOBUsers implements Serializable {

	private static final long serialVersionUID = 1L;
	 
		private long 		userID;
	    private long 		organisationID;
	    private long 		branchID;
	    private long 		employeeID;
	    private long 		reportingTo;
		private String 		userName;
		private String 		password;
		private String 		firstName;
		private String 		lastName;
		private String 		middleName;
		private short 		isAdmin;
		private short 		isSuperUser;
		private long 		createdBy;
		private Timestamp 	createdOn;
		private short 		isUserActive;
		private short 		isEmployeeActive;
		private short 		modeID;
		private String 		modeName;
		private String 		groupName;
		private short 		selected;
		
		
		public long getReportingTo() {
			return reportingTo;
		}
		public String getFirstName() {
			return firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public String getMiddleName() {
			return middleName;
		}
		public short getIsUserActive() {
			return isUserActive;
		}
		public short getIsEmployeeActive() {
			return isEmployeeActive;
		}
		public void setReportingTo(long reportingTo) {
			this.reportingTo = reportingTo;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}
		public void setIsUserActive(short isUserActive) {
			this.isUserActive = isUserActive;
		}
		public void setIsEmployeeActive(short isEmployeeActive) {
			this.isEmployeeActive = isEmployeeActive;
		}
		public long getUserID() {
			return userID;
		}
		public long getOrganisationID() {
			return organisationID;
		}
		public long getBranchID() {
			return branchID;
		}
		public long getEmployeeID() {
			return employeeID;
		}
		public String getUserName() {
			return userName;
		}
		public String getPassword() {
			return password;
		}
		public short getIsAdmin() {
			return isAdmin;
		}
		public short getIsSuperUser() {
			return isSuperUser;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public short getModeID() {
			return modeID;
		}
		public String getModeName() {
			return modeName;
		}
		public void setUserID(long userID) {
			this.userID = userID;
		}
		public void setOrganisationID(long organisationID) {
			this.organisationID = organisationID;
		}
		public void setBranchID(long branchID) {
			this.branchID = branchID;
		}
		public void setEmployeeID(long employeeID) {
			this.employeeID = employeeID;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public void setIsAdmin(short isAdmin) {
			this.isAdmin = isAdmin;
		}
		public void setIsSuperUser(short isSuperUser) {
			this.isSuperUser = isSuperUser;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setModeID(short modeID) {
			this.modeID = modeID;
		}
		public void setModeName(String modeName) {
			this.modeName = modeName;
		}
		public short getSelected() {
			return selected;
		}
		public void setSelected(short selected) {
			this.selected = selected;
		}
		public String getGroupName() {
			return groupName;
		}
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}
}
		

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class ClaimGroupCoverageMap implements Serializable
{
	private static final long serialVersionUID = 1L;
	public static final String CLAIM_GROUP_COVERAGEMAP  = "ClaimGroupCoverageMap";
	
	
	private long 		claimCoverageMapID;
	private long 		claimID; 
	private long 		coverageID;
	
	
	public long getClaimCoverageMapID() {
		return claimCoverageMapID;
	}
	public void setClaimCoverageMapID(long claimCoverageMapID) {
		this.claimCoverageMapID = claimCoverageMapID;
	}
	public long getClaimID() {
		return claimID;
	}
	public void setClaimID(long claimID) {
		this.claimID = claimID;
	}
	public long getCoverageID() {
		return coverageID;
	}
	public void setCoverageID(long coverageID) {
		this.coverageID = coverageID;
	}
	
	
		
		
		
		}

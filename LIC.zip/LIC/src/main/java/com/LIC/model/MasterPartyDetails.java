package com.LIC.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class MasterPartyDetails {

	private int partyId;   
	 private int typeId;   
	 private int organisationId;   
	 private int salutationId;   
	 private String firstName ;  
	 private String initial ;  
	 private String lastname ;  
	 private String contactId; ;  
	 private Date dateOfBirth;  
	 private long masterGroupId;
	 List<ApplicationPremiumDetails> applicationDetails = new ArrayList<ApplicationPremiumDetails>();
	public List<ApplicationPremiumDetails> getApplicationDetails() {
		return applicationDetails;
	}
	public void setApplicationDetails(List<ApplicationPremiumDetails> applicationDetails) {
		this.applicationDetails = applicationDetails;
	}
	private long isMasterPolicy;
		
		public long getIsMasterPolicy() {
		return isMasterPolicy;
	}
	public void setIsMasterPolicy(long isMasterPolicy) {
		this.isMasterPolicy = isMasterPolicy;
	}
		private long masterPolicyId;
	 public long getMasterGroupId() {
			return masterGroupId;
		}
		public void setMasterGroupId(long masterGroupId) {
			this.masterGroupId = masterGroupId;
		}
		public long getMasterPolicyId() {
			return masterPolicyId;
		}
		public void setMasterPolicyId(long masterPolicyId) {
			this.masterPolicyId = masterPolicyId;
		}
	public int getPartyId() {
		return partyId;
	}
	public void setPartyId(int partyId) {
		this.partyId = partyId;
	}
	public int getTypeId() {
		return typeId;
	}
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}
	public int getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(int organisationId) {
		this.organisationId = organisationId;
	}
	public int getSalutationId() {
		return salutationId;
	}
	public void setSalutationId(int salutationId) {
		this.salutationId = salutationId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getInitial() {
		return initial;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getdOE() {
		return dOE;
	}
	public void setdOE(Date dOE) {
		this.dOE = dOE;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getMonths() {
		return months;
	}
	public void setMonths(int months) {
		this.months = months;
	}
	public int getGender() {
		return gender;
	}
	public void setGender(int gender) {
		this.gender = gender;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getgSTINNumber() {
		return gSTINNumber;
	}
	public void setgSTINNumber(String gSTINNumber) {
		this.gSTINNumber = gSTINNumber;
	}
	public String getMembershipNumber() {
		return membershipNumber;
	}
	public void setMembershipNumber(String membershipNumber) {
		this.membershipNumber = membershipNumber;
	}
	public String getDetailsOfWork() {
		return detailsOfWork;
	}
	public void setDetailsOfWork(String detailsOfWork) {
		this.detailsOfWork = detailsOfWork;
	}
	public int getOccupationId() {
		return occupationId;
	}
	public void setOccupationId(int occupationId) {
		this.occupationId = occupationId;
	}
	public String getOtherProfession() {
		return otherProfession;
	}
	public void setOtherProfession(String otherProfession) {
		this.otherProfession = otherProfession;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	public int getBusinessAddress() {
		return businessAddress;
	}
	public void setBusinessAddress(int businessAddress) {
		this.businessAddress = businessAddress;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getTypeofIndustry() {
		return typeofIndustry;
	}
	public void setTypeofIndustry(int typeofIndustry) {
		this.typeofIndustry = typeofIndustry;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getIsDubaiResId() {
		return isDubaiResId;
	}
	public void setIsDubaiResId(int isDubaiResId) {
		this.isDubaiResId = isDubaiResId;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public int getIsbothAddressSame() {
		return isbothAddressSame;
	}
	public void setIsbothAddressSame(int isbothAddressSame) {
		this.isbothAddressSame = isbothAddressSame;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public int getHaveanyOverseasBranch() {
		return haveanyOverseasBranch;
	}
	public void setHaveanyOverseasBranch(int haveanyOverseasBranch) {
		this.haveanyOverseasBranch = haveanyOverseasBranch;
	}
	public String getOverseasBranchDetails() {
		return overseasBranchDetails;
	}
	public void setOverseasBranchDetails(String overseasBranchDetails) {
		this.overseasBranchDetails = overseasBranchDetails;
	}
	public int getHaveanyClientsinUSA() {
		return haveanyClientsinUSA;
	}
	public void setHaveanyClientsinUSA(int haveanyClientsinUSA) {
		this.haveanyClientsinUSA = haveanyClientsinUSA;
	}
	public String getuSAClientDetails() {
		return uSAClientDetails;
	}
	public void setuSAClientDetails(String uSAClientDetails) {
		this.uSAClientDetails = uSAClientDetails;
	}
	public int getCityId() {
		return cityId;
	}
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public Date getDateOfJoiningScheme() {
		return dateOfJoiningScheme;
	}
	public void setDateOfJoiningScheme(Date dateOfJoiningScheme) {
		this.dateOfJoiningScheme = dateOfJoiningScheme;
	}
	public Date getRiskCommencementDate() {
		return riskCommencementDate;
	}
	public void setRiskCommencementDate(Date riskCommencementDate) {
		this.riskCommencementDate = riskCommencementDate;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	private Date dOE; 
	 private int age;   
	 private int months;   
	 private int gender;   
	 private String panNo ;  
	 private String gSTINNumber;
	 private String membershipNumber ;  
	 private String detailsOfWork ;  
	 private int occupationId;   
	 private String otherProfession ;  
	 private String registrationNumber;  
	 private Date registrationDate ;
	 private int businessAddress ;
	 private int createdBy;   
	 private Date createdOn;  
	 private int modifiedBy;   
	 private Date modifiedOn;  
	 private int isActive;   
	 private int categoryId;  
	 private int typeofIndustry;
	 private int mobileNo;
	 private String email;
	 private int isDubaiResId;
	 private String aadharNo;
	 private int isbothAddressSame; 
	 private String firmName;    
	 private int haveanyOverseasBranch ;
	 private String overseasBranchDetails ;  
	 private int haveanyClientsinUSA; 
	 private String uSAClientDetails;  
	 private int cityId;
	 private int stateId;  
	 private String pincode;
	    private Date dateOfJoiningScheme ;
	 private Date riskCommencementDate ;
	 private int basicSalary; 
	 private String employeeId; 
}

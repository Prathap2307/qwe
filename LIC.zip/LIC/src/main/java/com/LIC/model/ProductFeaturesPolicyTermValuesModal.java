package com.LIC.model;

import java.io.Serializable;
import java.text.DecimalFormat;


public class ProductFeaturesPolicyTermValuesModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	
		 private long PolicyTermID ;
		 private long  ProductFeatureID ;
		 private DecimalFormat PolicyTermValue ;
		 
		public long getPolicyTermID() {
			return PolicyTermID;
		}
		public long getProductFeatureID() {
			return ProductFeatureID;
		}
		public DecimalFormat getPolicyTermValue() {
			return PolicyTermValue;
		}
		public void setPolicyTermID(long policyTermID) {
			PolicyTermID = policyTermID;
		}
		public void setProductFeatureID(long productFeatureID) {
			ProductFeatureID = productFeatureID;
		}
		public void setPolicyTermValue(DecimalFormat policyTermValue) {
			PolicyTermValue = policyTermValue;
		}
		
			
}

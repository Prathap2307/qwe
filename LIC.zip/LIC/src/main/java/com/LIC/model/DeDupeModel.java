package com.LIC.model;

import java.io.Serializable;

public class DeDupeModel extends RecordModifier implements Serializable {
	
	private Integer dedupeclubbingID;
	private Integer typeID;
	private String description;
	private String criteria;
	private String query;
	private Integer moduleID;
	private	String groupByQuery;
	private String whereQuery;																					
	private String groupByQueryUpload;														
	private String whereQueryUpload;                                                        
	private String columnsQuery;                                                        
	private String columnsQueryUpload;                                                      
	private String whereColumnsQuery;                                                      
	private String whereColumnsQueryUpload;
	private Integer priority;
	private Integer status;
	public Integer getDedupeclubbingID() {
		return dedupeclubbingID;
	}
	public Integer getTypeID() {
		return typeID;
	}
	public String getDescription() {
		return description;
	}
	public String getCriteria() {
		return criteria;
	}
	public String getQuery() {
		return query;
	}
	public Integer getModuleID() {
		return moduleID;
	}
	public String getGroupByQuery() {
		return groupByQuery;
	}
	public String getWhereQuery() {
		return whereQuery;
	}
	public String getGroupByQueryUpload() {
		return groupByQueryUpload;
	}
	public String getWhereQueryUpload() {
		return whereQueryUpload;
	}
	public String getColumnsQuery() {
		return columnsQuery;
	}
	public String getColumnsQueryUpload() {
		return columnsQueryUpload;
	}
	public String getWhereColumnsQuery() {
		return whereColumnsQuery;
	}
	public String getWhereColumnsQueryUpload() {
		return whereColumnsQueryUpload;
	}
	public Integer getPriority() {
		return priority;
	}
	public Integer getStatus() {
		return status;
	}
	public void setDedupeclubbingID(Integer dedupeclubbingID) {
		this.dedupeclubbingID = dedupeclubbingID;
	}
	public void setTypeID(Integer typeID) {
		this.typeID = typeID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public void setModuleID(Integer moduleID) {
		this.moduleID = moduleID;
	}
	public void setGroupByQuery(String groupByQuery) {
		this.groupByQuery = groupByQuery;
	}
	public void setWhereQuery(String whereQuery) {
		this.whereQuery = whereQuery;
	}
	public void setGroupByQueryUpload(String groupByQueryUpload) {
		this.groupByQueryUpload = groupByQueryUpload;
	}
	public void setWhereQueryUpload(String whereQueryUpload) {
		this.whereQueryUpload = whereQueryUpload;
	}
	public void setColumnsQuery(String columnsQuery) {
		this.columnsQuery = columnsQuery;
	}
	public void setColumnsQueryUpload(String columnsQueryUpload) {
		this.columnsQueryUpload = columnsQueryUpload;
	}
	public void setWhereColumnsQuery(String whereColumnsQuery) {
		this.whereColumnsQuery = whereColumnsQuery;
	}
	public void setWhereColumnsQueryUpload(String whereColumnsQueryUpload) {
		this.whereColumnsQueryUpload = whereColumnsQueryUpload;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "DeDupeModel [dedupeclubbingID=" + dedupeclubbingID + ", typeID=" + typeID + ", description="
				+ description + ", criteria=" + criteria + ", query=" + query + ", moduleID=" + moduleID
				+ ", groupByQuery=" + groupByQuery + ", whereQuery=" + whereQuery + ", groupByQueryUpload="
				+ groupByQueryUpload + ", whereQueryUpload=" + whereQueryUpload + ", columnsQuery=" + columnsQuery
				+ ", columnsQueryUpload=" + columnsQueryUpload + ", whereColumnsQuery=" + whereColumnsQuery
				+ ", whereColumnsQueryUpload=" + whereColumnsQueryUpload + ", priority=" + priority + ", status="
				+ status + "]";
	}
	                                                        
	                                                    
	
	
	
	
	
	
}

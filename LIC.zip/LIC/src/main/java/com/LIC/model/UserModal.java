package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class UserModal implements Serializable {

	private static final long serialVersionUID = 1L;
	 
		private long 		userID;
	    private long 		organisationID;
	    private long 		branchID;
	    private long 		employeeID;
		private String 		userName;
		private String 		password;
		private short 		isAdmin;
		private short 		isSuperUser;
		private short 		isUnderWriter;
	    private Timestamp	pWDModifiedOn;
		private long 		defaultLineofBusiness;
		private long 		userTypeID;
		private long 		salesHierarchyID;
		private Timestamp	currentLoginTime;
		private Timestamp   lastLoginTime;
		private long        createdBy;
		private Timestamp 	createdOn;
		private long 		modifiedBy;
		private Timestamp 	modifiedOn;
		private long 		deletedBy;
		private Timestamp 	deletedOn;
		private short 		isActive;
		private short 		userType;
		private long 		mainChannelID;
		private long 		subChannelID;
		private long 		agentID;
		private long 		usageID;
		private long 		groupID;
		private long 		tPAId;
		private short 		isLoggedIn;
		private int 		invalidLoginCount;
		private long 		moduleID;
		private long 		featureID;
		private long 		role;
		private String 		channelCode;
		private String 		subChannelAgentType;
		private String 		agentName;
		private String 		mainChannelCodeName;
		private String 		subChannelCodeName;
		private short 		selectAllBranch;
		
		
		private List<LineOfBusiness> lineOfBusinessModelList;
		
		public List<LineOfBusiness> getLineOfBusinessModelList() {
			return lineOfBusinessModelList;
		}
		public void setLineOfBusinessModelList(List<LineOfBusiness> lineOfBusinessModelList) {
			this.lineOfBusinessModelList = lineOfBusinessModelList;
		}
		
		public String getAgentName() {
			return agentName;
		}
		public String getMainChannelCodeName() {
			return mainChannelCodeName;
		}
		public String getSubChannelCodeName() {
			return subChannelCodeName;
		}
		public short getSelectAllBranch() {
			return selectAllBranch;
		}
		public void setAgentName(String agentName) {
			this.agentName = agentName;
		}
		public void setMainChannelCodeName(String mainChannelCodeName) {
			this.mainChannelCodeName = mainChannelCodeName;
		}
		public void setSubChannelCodeName(String subChannelCodeName) {
			this.subChannelCodeName = subChannelCodeName;
		}
		public void setSelectAllBranch(short selectAllBranch) {
			this.selectAllBranch = selectAllBranch;
		}
		public long getUserID() {
			return userID;
		}
		public long getOrganisationID() {
			return organisationID;
		}
		public long getBranchID() {
			return branchID;
		}
		public long getEmployeeID() {
			return employeeID;
		}
		public String getUserName() {
			return userName;
		}
		public String getPassword() {
			return password;
		}
		public short getIsAdmin() {
			return isAdmin;
		}
		public short getIsSuperUser() {
			return isSuperUser;
		}
		public short getIsUnderWriter() {
			return isUnderWriter;
		}
		public Timestamp getpWDModifiedOn() {
			return pWDModifiedOn;
		}
		public long getDefaultLineofBusiness() {
			return defaultLineofBusiness;
		}
		public long getUserTypeID() {
			return userTypeID;
		}
		public long getSalesHierarchyID() {
			return salesHierarchyID;
		}
		public Timestamp getCurrentLoginTime() {
			return currentLoginTime;
		}
		public Timestamp getLastLoginTime() {
			return lastLoginTime;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public short getUserType() {
			return userType;
		}
		public long getMainChannelID() {
			return mainChannelID;
		}
		public long getSubChannelID() {
			return subChannelID;
		}
		public long getAgentID() {
			return agentID;
		}
		public long getUsageID() {
			return usageID;
		}
		public long getGroupID() {
			return groupID;
		}
		public long getTPAID() {
			return tPAId;
		}
		public short getIsLoggedIn() {
			return isLoggedIn;
		}
		public int getInvalidLoginCount() {
			return invalidLoginCount;
		}
		public long getModuleID() {
			return moduleID;
		}
		public long getFeatureID() {
			return featureID;
		}
		public long getRole() {
			return role;
		}
		public void setUserID(long userID) {
			this.userID = userID;
		}
		public void setOrganisationID(long organisationID) {
			this.organisationID = organisationID;
		}
		public void setBranchID(long branchID) {
			this.branchID = branchID;
		}
		public void setEmployeeID(long employeeID) {
			this.employeeID = employeeID;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public void setIsAdmin(short isAdmin) {
			this.isAdmin = isAdmin;
		}
		public void setIsSuperUser(short isSuperUser) {
			this.isSuperUser = isSuperUser;
		}
		public void setIsUnderWriter(short isUnderWriter) {
			this.isUnderWriter = isUnderWriter;
		}
		public void setpWDModifiedOn(Timestamp pWDModifiedOn) {
			this.pWDModifiedOn = pWDModifiedOn;
		}
		public void setDefaultLineofBusiness(long defaultLineofBusiness) {
			this.defaultLineofBusiness = defaultLineofBusiness;
		}
		public void setUserTypeID(long userTypeID) {
			this.userTypeID = userTypeID;
		}
		public void setSalesHierarchyID(long salesHierarchyID) {
			this.salesHierarchyID = salesHierarchyID;
		}
		public void setCurrentLoginTime(Timestamp currentLoginTime) {
			this.currentLoginTime = currentLoginTime;
		}
		public void setLastLoginTime(Timestamp lastLoginTime) {
			this.lastLoginTime = lastLoginTime;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public void setUserType(short userType) {
			this.userType = userType;
		}
		public void setMainChannelID(long channelID) {
			this.mainChannelID = channelID;
		}
		public void setSubChannelID(long subChannelID) {
			this.subChannelID = subChannelID;
		}
		public void setAgentID(long agentID) {
			this.agentID = agentID;
		}
		public void setUsageID(long usageID) {
			this.usageID = usageID;
		}
		public void setGroupID(long groupID) {
			this.groupID = groupID;
		}
		public void setTPAID(long tPAId) {
			this.tPAId = tPAId;
		}
		public void setIsLoggedIn(short isLoggedIn) {
			this.isLoggedIn = isLoggedIn;
		}
		public void setInvalidLoginCount(int invalidLoginCount) {
			this.invalidLoginCount = invalidLoginCount;
		}
		public void setModuleID(long moduleID) {
			this.moduleID = moduleID;
		}
		public void setFeatureID(long featureID) {
			this.featureID = featureID;
		}
		public void setRole(long role) {
			this.role = role;
		}
		public String getChannelCode() {
			return channelCode;
		}
		public void setChannelCode(String channelCode) {
			this.channelCode = channelCode;
		}
		public String getSubChannelAgentType() {
			return subChannelAgentType;
		}
		public void setSubChannelAgentType(String subChannelAgentType) {
			this.subChannelAgentType = subChannelAgentType;
		}
}

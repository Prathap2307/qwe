package com.LIC.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PolicyViewInformationModel {
	
	
	private Number lobId;
	private Number typeId;

	private Number policyType;
	private Number groupId;
	private Number agreementId;
	private Number headerId;
	private Number clientId;
	private Date fromDate;
	private Date toDate;
	private String policyHolderName;

	private String certificateNumber;
	private String contactId;
	private String clientName;
	private String masterPolicyNumber;
	private String fileName;
	private Date uploadedDate;
	public Date getPolicyIssuedDate() {
		return policyIssuedDate;
	}
	public void setPolicyIssuedDate(Date policyIssuedDate) {
		this.policyIssuedDate = policyIssuedDate;
	}
	public Number getBenifitTypeId() {
		return benifitTypeId;
	}
	public void setBenifitTypeId(Number benifitTypeId) {
		this.benifitTypeId = benifitTypeId;
	}
	public String getBenifitType() {
		return benifitType;
	}
	public void setBenifitType(String benifitType) {
		this.benifitType = benifitType;
	}
	public String getClientOrgAdress1() {
		return clientOrgAdress1;
	}
	public void setClientOrgAdress1(String clientOrgAdress1) {
		this.clientOrgAdress1 = clientOrgAdress1;
	}
	public String getClientOrgAdress2() {
		return clientOrgAdress2;
	}
	public void setClientOrgAdress2(String clientOrgAdress2) {
		this.clientOrgAdress2 = clientOrgAdress2;
	}




	private String agreementFileName;
	private Number masterpolicyId;
	private Date policyIssuedDate;
	private Number benifitTypeId;
	private String benifitType;
	private String clientOrgAdress1;
	private String clientOrgAdress2;


		



	public Number getPolicyType() {
		return policyType;
	}
	public void setPolicyType(Number policyType) {
		this.policyType = policyType;
	}
	public PolicyViewInformationModel(String policyHolderName,Number groupId,Number lobId, Number typeId ) {
		super();
		
		this.policyHolderName = policyHolderName;
		this.groupId = groupId;
		this.lobId = lobId;
		this.typeId = typeId;
		
	}
	public Number getTypeId() {
		return typeId;
	}
	public void setTypeId(Number typeId) {
		this.typeId = typeId;
	}

	public Number getClientId() {
		return clientId;
	}
	public void setClientId(Number clientId) {
		this.clientId = clientId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}









	public String getPolicyHolderName() {
		return policyHolderName;
	}
	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}

	public String getCertificateNumber() {
		return certificateNumber;
	}
	public void setCertificateNumber(String certificateNumber) {
		this.certificateNumber = certificateNumber;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public Number getGroupId() {
		return groupId;
	}
	public void setGroupId(Number groupId) {
		this.groupId = groupId;
	}
	public Number getLobId() {
		return lobId;
	}
	public void setLobId(Number lobId) {
		this.lobId = lobId;
	}

	public Number getAgreementId() {
		return agreementId;
	}
	public void setAgreementId(Number agreementId) {
		this.agreementId = agreementId;
	}
	public Number getHeaderId() {
		return headerId;
	}
	public void setHeaderId(Number headerId) {
		this.headerId = headerId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getMasterPolicyNumber() {
		return masterPolicyNumber;
	}
	public void setMasterPolicyNumber(String masterPolicyNumber) {
		this.masterPolicyNumber = masterPolicyNumber;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Date getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(Date uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getAgreementFileName() {
		return agreementFileName;
	}
	public void setAgreementFileName(String agreementFileName) {
		this.agreementFileName = agreementFileName;
	}
	public Number getMasterpolicyId() {
		return masterpolicyId;
	}
	public void setMasterpolicyId(Number masterpolicyId) {
		this.masterpolicyId = masterpolicyId;
	}

	public PolicyViewInformationModel( Number headerId, String clientName, String masterPolicyNumber,
			String fileName, Date uploadedDate, String agreementFileName, Number masterpolicyId,Number groupId,
			String insurerMasterAgreementNo) {
		super();
		
		this.headerId = headerId;
		this.clientName = clientName;
		this.masterPolicyNumber = masterPolicyNumber;
		this.fileName = fileName;
		this.uploadedDate = uploadedDate;
		this.agreementFileName = agreementFileName;
		this.masterpolicyId = masterpolicyId;
		this.groupId = groupId;
		this.insurerMasterAgreementNo = insurerMasterAgreementNo;
	}

    @Id
     private Number applicationId;
     private String partyId;
     private String certNo;
     private String policyIssueDate;
     private String clientOrgName;
     private Number benefitTypeId;
     private String benefitType;
     private String clientOrgAddress1;
     private String clientOrgAddress2;
     private String state;
     private String groupPolicyNo;
     private String certificateNo;
     private String groupPolicyHolder;
     private String groupPolicyHolderName;
     private String fullName;
     private String gender;
	 private String emailId;
	 private String dateOfBirth;
	 private Number employeeNo;
	 private String answer;
	 private String answer1;
	 private String answer2;
	 private String answer3;
	 private String answer4;
	 private String answer5;
	 private String answer6;
	 private String memberInsuredName;
	 private String employeeId;
	 private String nomineeName;
	 private String appointeeName;
	 private String thirdNomineeName;
	 private String relationshipWithMemberInsured;
	 private String paymentTerm;
	 private String paymentFrequency;
	 private Number premiumAmount;
	 private Number totalAnnualAmount;
	 private Number sgstCgstAmount;
	 private Number igstAmount;
	 private Number esgstCgstAmount;
	 private Number eigstAmount;
	 private Number sumInsured;
	 private Number sumAssured;
	 private Number netPremiumAmount;
	 private String coverageEffectiveDate;
	 private String netPremiumDate;
	 private String dateOfFirstInceptionCover;
	 private String coverageExpiryDate;
	 private String dateOfFirstInception1;
	 private String nextRenewal;
	 private String eCoverageEffectiveDate;
	 private String eCoverageExpiryDate;
	 private String insurerMasterAgreementNo;
	 private String policyNumber;
	 
 
    public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public Number getApplicationId() {
           return applicationId;
    }
    public void setApplicationId(Number applicationId) {
           this.applicationId = applicationId;
    }
    public String getPartyId() {
           return partyId;
    }
    public void setPartyId(String partyId) {
           this.partyId = partyId;
    }
    public String getCertNo() {
           return certNo;
    }
    public void setCertNo(String certNo) {
           this.certNo = certNo;
    }
    public String getPolicyIssueDate() {
           return policyIssueDate;
    }
    public void setPolicyIssueDate(String policyIssueDate) {
           this.policyIssueDate = policyIssueDate;
    }
    public String getClientOrgName() {
           return clientOrgName;
    }
    public void setClientOrgName(String clientOrgName) {
           this.clientOrgName = clientOrgName;
    }
    public Number getBenefitTypeId() {
           return benefitTypeId;
    }
    public void setBenefitTypeId(Number benefitTypeId) {
           this.benefitTypeId = benefitTypeId;
    }
    public String getBenefitType() {
           return benefitType;
    }
    public void setBenefitType(String benefitType) {
           this.benefitType = benefitType;
    }
    public String getClientOrgAddress1() {
           return clientOrgAddress1;
    }
    public void setClientOrgAddress1(String clientOrgAddress1) {
           this.clientOrgAddress1 = clientOrgAddress1;
    }
    public String getClientOrgAddress2() {
           return clientOrgAddress2;
    }
    public void setClientOrgAddress2(String clientOrgAddress2) {
           this.clientOrgAddress2 = clientOrgAddress2;
    }
    public String getState() {
           return state;
    }
    public void setState(String state) {
           this.state = state;
    }
    public String getGroupPolicyNo() {
           return groupPolicyNo;
    }
    public void setGroupPolicyNo(String groupPolicyNo) {
           this.groupPolicyNo = groupPolicyNo;
    }
    public String getCertificateNo() {
           return certificateNo;
    }
    public void setCertificateNo(String certificateNo) {
           this.certificateNo = certificateNo;
    }
    public String getGroupPolicyHolder() {
           return groupPolicyHolder;
    }
    public void setGroupPolicyHolder(String groupPolicyHolder) {
           this.groupPolicyHolder = groupPolicyHolder;
    }
    public String getGroupPolicyHolderName() {
           return groupPolicyHolderName;
    }
    public void setGroupPolicyHolderName(String groupPolicyHolderName) {
           this.groupPolicyHolderName = groupPolicyHolderName;
    }
    public String getFullName() {
           return fullName;
    }
    public void setFullName(String fullName) {
           this.fullName = fullName;
    }
    public String getGender() {
           return gender;
    }
    public void setGender(String gender) {
           this.gender = gender;
    }
    public String getEmailId() {
           return emailId;
    }
    public void setEmailId(String emailId) {
           this.emailId = emailId;
    }
    public String getDateOfBirth() {
           return dateOfBirth;
    }
    public void setDateOfBirth(String dateOfBirth) {
           this.dateOfBirth = dateOfBirth;
    }
    public Number getEmployeeNo() {
           return employeeNo;
    }
    public void setEmployeeNo(Number employeeNo) {
           this.employeeNo = employeeNo;
    }
    public String getAnswer() {
           return answer;
    }
    public void setAnswer(String answer) {
           this.answer = answer;
    }
    public String getAnswer1() {
           return answer1;
    }
    public void setAnswer1(String answer1) {
           this.answer1 = answer1;
    }
    public String getAnswer2() {
           return answer2;
    }
    public void setAnswer2(String answer2) {
           this.answer2 = answer2;
    }
    public String getAnswer3() {
           return answer3;
    }
    public void setAnswer3(String answer3) {
           this.answer3 = answer3;
    }
    public String getAnswer4() {
           return answer4;
    }
    public void setAnswer4(String answer4) {
           this.answer4 = answer4;
    }
    public String getAnswer5() {
           return answer5;
    }
    public void setAnswer5(String answer5) {
           this.answer5 = answer5;
    }
    public String getAnswer6() {
           return answer6;
    }
    public void setAnswer6(String answer6) {
           this.answer6 = answer6;
    }
    public String getMemberInsuredName() {
           return memberInsuredName;
    }
    public void setMemberInsuredName(String memberInsuredName) {
           this.memberInsuredName = memberInsuredName;
    }
    public String getEmployeeId() {
           return employeeId;
    }
    public void setEmployeeId(String employeeId) {
           this.employeeId = employeeId;
    }
    public String getNomineeName() {
           return nomineeName;
    }
    public void setNomineeName(String nomineeName) {
           this.nomineeName = nomineeName;
    }
    public String getAppointeeName() {
           return appointeeName;
    }
    public void setAppointeeName(String appointeeName) {
           this.appointeeName = appointeeName;
    }
    public String getThirdNomineeName() {
           return thirdNomineeName;
    }
    public void setThirdNomineeName(String thirdNomineeName) {
           this.thirdNomineeName = thirdNomineeName;
    }
    public String getRelationshipWithMemberInsured() {
           return relationshipWithMemberInsured;
    }
    public void setRelationshipWithMemberInsured(String relationshipWithMemberInsured) {
           this.relationshipWithMemberInsured = relationshipWithMemberInsured;
    }
    public String getPaymentTerm() {
           return paymentTerm;
    }
    public void setPaymentTerm(String paymentTerm) {
           this.paymentTerm = paymentTerm;
    }
    public String getPaymentFrequency() {
           return paymentFrequency;
    }
    public void setPaymentFrequency(String paymentFrequency) {
           this.paymentFrequency = paymentFrequency;
    }
    public Number getPremiumAmount() {
           return premiumAmount;
    }
    public void setPremiumAmount(Number premiumAmount) {
           this.premiumAmount = premiumAmount;
    }
    public Number getTotalAnnualAmount() {
           return totalAnnualAmount;
    }
    public void setTotalAnnualAmount(Number totalAnnualAmount) {
           this.totalAnnualAmount = totalAnnualAmount;
    }
    public Number getSgstCgstAmount() {
           return sgstCgstAmount;
    }
    public void setSgstCgstAmount(Number sgstCgstAmount) {
           this.sgstCgstAmount = sgstCgstAmount;
    }
    public Number getIgstAmount() {
           return igstAmount;
    }
    public void setIgstAmount(Number igstAmount) {
           this.igstAmount = igstAmount;
    }
    public Number getEsgstCgstAmount() {
           return esgstCgstAmount;
    }
    public void setEsgstCgstAmount(Number esgstCgstAmount) {
           this.esgstCgstAmount = esgstCgstAmount;
    }
    public Number getEigstAmount() {
           return eigstAmount;
    }
    public void setEigstAmount(Number eigstAmount) {
           this.eigstAmount = eigstAmount;
    }
    public Number getSumInsured() {
           return sumInsured;
    }
    public void setSumInsured(Number sumInsured) {
           this.sumInsured = sumInsured;
    }
    public Number getSumAssured() {
           return sumAssured;
    }
    public void setSumAssured(Number sumAssured) {
           this.sumAssured = sumAssured;
    }
    public Number getNetPremiumAmount() {
           return netPremiumAmount;
    }
    public void setNetPremiumAmount(Number netPremiumAmount) {
           this.netPremiumAmount = netPremiumAmount;
    }
    public String getCoverageEffectiveDate() {
           return coverageEffectiveDate;
    }
    public void setCoverageEffectiveDate(String coverageEffectiveDate) {
           this.coverageEffectiveDate = coverageEffectiveDate;
    }
    public String getNetPremiumDate() {
           return netPremiumDate;
    }
    public void setNetPremiumDate(String netPremiumDate) {
           this.netPremiumDate = netPremiumDate;
    }
    public String getDateOfFirstInceptionCover() {
           return dateOfFirstInceptionCover;
    }
    public void setDateOfFirstInceptionCover(String dateOfFirstInceptionCover) {
           this.dateOfFirstInceptionCover = dateOfFirstInceptionCover;
    }
    public String getCoverageExpiryDate() {
           return coverageExpiryDate;
    }
    public void setCoverageExpiryDate(String coverageExpiryDate) {
           this.coverageExpiryDate = coverageExpiryDate;
    }
    public String getDateOfFirstInception1() {
           return dateOfFirstInception1;
    }
    public void setDateOfFirstInception1(String dateOfFirstInception1) {
           this.dateOfFirstInception1 = dateOfFirstInception1;
    }
    public String getNextRenewal() {
           return nextRenewal;
    }
    public void setNextRenewal(String nextRenewal) {
           this.nextRenewal = nextRenewal;
    }
    public String geteCoverageEffectiveDate() {
           return eCoverageEffectiveDate;
    }
    public void seteCoverageEffectiveDate(String eCoverageEffectiveDate) {
           this.eCoverageEffectiveDate = eCoverageEffectiveDate;
    }
    public String geteCoverageExpiryDate() {
           return eCoverageExpiryDate;
    }
    public void seteCoverageExpiryDate(String eCoverageExpiryDate) {
           this.eCoverageExpiryDate = eCoverageExpiryDate;
    }
    public String getInsurerMasterAgreementNo() {
           return insurerMasterAgreementNo;
    }
    public void setInsurerMasterAgreementNo(String insurerMasterAgreementNo) {
           this.insurerMasterAgreementNo = insurerMasterAgreementNo;
    }
    
    
    public PolicyViewInformationModel() {
    	super();
    }
    
    
    
    public PolicyViewInformationModel(Number applicationId, Number lobId, String masterPolicyNumber, 
			String insurerMasterAgreementNo,String policyNumber,String policyHolderName,String employeeId,String ContactId) {
		super();
		this.lobId = lobId;
		this.masterPolicyNumber = masterPolicyNumber;
		this.applicationId = applicationId;
		this.insurerMasterAgreementNo = insurerMasterAgreementNo;
		this.policyNumber=policyNumber;
		this.policyHolderName=policyHolderName;
		this.employeeId=employeeId;
		this.contactId=ContactId;
	}
	public PolicyViewInformationModel(Number applicationId, String partyId, String certNo, String policyIssueDate,
                  String clientOrgName, Number benefitTypeId, String benefitType, String clientOrgAddress1,
                  String clientOrgAddress2, String state, String groupPolicyNo, String certificateNo,
                  String groupPolicyHolder, String groupPolicyHolderName, String fullName, String gender, String emailId,
                  String dateOfBirth, Number employeeNo, String answer, String answer1, String answer2, String answer3,
                  String answer4, String answer5, String answer6, String memberInsuredName, String employeeId,
                  String nomineeName, String appointeeName, String thirdNomineeName, String relationshipWithMemberInsured,
                  String paymentTerm, String paymentFrequency, Number premiumAmount, Number totalAnnualAmount,
                  Number sgstCgstAmount, Number igstAmount, Number esgstCgstAmount, Number eigstAmount, Number sumInsured,
                  Number sumAssured, Number netPremiumAmount, String coverageEffectiveDate, String netPremiumDate,
                  String dateOfFirstInceptionCover, String coverageExpiryDate, String dateOfFirstInception1,
                  String nextRenewal, String eCoverageEffectiveDate, String eCoverageExpiryDate,
                  String insurerMasterAgreementNo) {
           this.applicationId = applicationId;
           this.partyId = partyId;
           this.certNo = certNo;
           this.policyIssueDate = policyIssueDate;
           this.clientOrgName = clientOrgName;
           this.benefitTypeId = benefitTypeId;
           this.benefitType = benefitType;
           this.clientOrgAddress1 = clientOrgAddress1;
           this.clientOrgAddress2 = clientOrgAddress2;
           this.state = state;
           this.groupPolicyNo = groupPolicyNo;
           this.certificateNo = certificateNo;
           this.groupPolicyHolder = groupPolicyHolder;
           this.groupPolicyHolderName = groupPolicyHolderName;
           this.fullName = fullName;
           this.gender = gender;
           this.emailId = emailId;
           this.dateOfBirth = dateOfBirth;
           this.employeeNo = employeeNo;
           this.answer = answer;
           this.answer1 = answer1;
           this.answer2 = answer2;
           this.answer3 = answer3;
           this.answer4 = answer4;
           this.answer5 = answer5;
           this.answer6 = answer6;
           this.memberInsuredName = memberInsuredName;
           this.employeeId = employeeId;
           this.nomineeName = nomineeName;
           this.appointeeName = appointeeName;
           this.thirdNomineeName = thirdNomineeName;
           this.relationshipWithMemberInsured = relationshipWithMemberInsured;
           this.paymentTerm = paymentTerm;
           this.paymentFrequency = paymentFrequency;
           this.premiumAmount = premiumAmount;
           this.totalAnnualAmount = totalAnnualAmount;
           this.sgstCgstAmount = sgstCgstAmount;
           this.igstAmount = igstAmount;
           this.esgstCgstAmount = esgstCgstAmount;
           this.eigstAmount = eigstAmount;
           this.sumInsured = sumInsured;
           this.sumAssured = sumAssured;
           this.netPremiumAmount = netPremiumAmount;
           this.coverageEffectiveDate = coverageEffectiveDate;
           this.netPremiumDate = netPremiumDate;
           this.dateOfFirstInceptionCover = dateOfFirstInceptionCover;
           this.coverageExpiryDate = coverageExpiryDate;
           this.dateOfFirstInception1 = dateOfFirstInception1;
           this.nextRenewal = nextRenewal;
           this.eCoverageEffectiveDate = eCoverageEffectiveDate;
           this.eCoverageExpiryDate = eCoverageExpiryDate;
           this.insurerMasterAgreementNo = insurerMasterAgreementNo;
    }
 

}

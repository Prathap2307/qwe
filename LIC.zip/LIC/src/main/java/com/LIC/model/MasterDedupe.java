package com.LIC.model;

import java.sql.Date;

public class MasterDedupe {

	public int getDedupeClubbingId() {
		return DedupeClubbingId;
	}
	public void setDedupeClubbingId(int dedupeClubbingId) {
		DedupeClubbingId = dedupeClubbingId;
	}
	public int getTypeId() {
		return typeId;
	}
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getModuleId() {
		return moduleId;
	}
	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}
	public String getGroupByQuery() {
		return groupByQuery;
	}
	public void setGroupByQuery(String groupByQuery) {
		this.groupByQuery = groupByQuery;
	}
	public String getWhereQuery() {
		return whereQuery;
	}
	public void setWhereQuery(String whereQuery) {
		this.whereQuery = whereQuery;
	}
	public String getGroupByQueryUpload() {
		return groupByQueryUpload;
	}
	public void setGroupByQueryUpload(String groupByQueryUpload) {
		this.groupByQueryUpload = groupByQueryUpload;
	}
	public String getWhereQueryUpload() {
		return whereQueryUpload;
	}
	public void setWhereQueryUpload(String whereQueryUpload) {
		this.whereQueryUpload = whereQueryUpload;
	}
	public String getColumnsQuery() {
		return columnsQuery;
	}
	public void setColumnsQuery(String columnsQuery) {
		this.columnsQuery = columnsQuery;
	}
	public String getColumnsQueryUpload() {
		return columnsQueryUpload;
	}
	public void setColumnsQueryUpload(String columnsQueryUpload) {
		this.columnsQueryUpload = columnsQueryUpload;
	}
	public String getWhereColumnsQuery() {
		return whereColumnsQuery;
	}
	public void setWhereColumnsQuery(String whereColumnsQuery) {
		this.whereColumnsQuery = whereColumnsQuery;
	}
	public String getWhereColumnsQueryUpload() {
		return whereColumnsQueryUpload;
	}
	public void setWhereColumnsQueryUpload(String whereColumnsQueryUpload) {
		this.whereColumnsQueryUpload = whereColumnsQueryUpload;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	private int DedupeClubbingId;
	private int typeId;
	private String description;
	private String criteria;
	private String query;
	private int priority;
	private int status;
	private int moduleId;
	private String groupByQuery;
	private String whereQuery;
	private String groupByQueryUpload;
	private String whereQueryUpload;
	private String columnsQuery;
	private String columnsQueryUpload;
	private String whereColumnsQuery;
	private String whereColumnsQueryUpload;
	private int createdBy;
	private Date createdOn;
	private int isActive;
}

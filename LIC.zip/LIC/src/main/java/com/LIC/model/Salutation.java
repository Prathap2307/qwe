package com.LIC.model;

import java.io.Serializable;
 
public class Salutation implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer salutationId;
	private String description;
	private Integer isActive;
	
	public Integer getSalutationId() {
		return salutationId;
	}
	public void setSalutationId(Integer salutationId) {
		this.salutationId = salutationId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getIsActive() {
		return isActive;
	}
	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	
	  
}

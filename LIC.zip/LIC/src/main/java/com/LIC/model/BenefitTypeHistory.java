
package com.LIC.model;

import java.io.Serializable;

public class BenefitTypeHistory extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer historyId;
	private Integer benefitTypeId;
	private String description;
	private String shortDescription;
	private String remarks;
	
	public Integer getHistoryId() {
		return historyId;
	}
	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}
	public Integer getBenefitTypeId() {
		return benefitTypeId;
	}
	public void setBenefitTypeId(Integer benefitTypeId) {
		this.benefitTypeId = benefitTypeId;
	}
	
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
 
}

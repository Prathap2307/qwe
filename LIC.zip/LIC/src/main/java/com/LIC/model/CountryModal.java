package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class CountryModal implements Serializable {
	
	private static final long serialVersionUID = 1L;
	 
    private long 		countryId;
	private String 		countryCode;
	private String 		description;
	private String 		shortDescription;
	private short 		isDeclined;
	private short		isActive;
    private long 		createdBy;
    private Timestamp 	createdOn; 
    private long 		modifiedBy;
    private Timestamp 	modifiedOn; 
    private long 		deletedBy;
    private Timestamp 	deletedOn;
    
    public long getCountryId() {
		return countryId;
	}
	public void setCountryId(long countryId) {
		this.countryId = countryId;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getshortDescription() {
		return shortDescription;
	}
	public void setshortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public short getIsDeclined() {
		return isDeclined;
	}
	public void setIsDeclined(short isDeclined) {
		this.isDeclined = isDeclined;
	}
	public short getIsActive() {
		return isActive;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public long getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(long deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Timestamp getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}

}

package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Master_AddressStructure")

public class GetAddressStructure {
	
	@Id
	private Number structureId;
	private String description;
	
	
	public GetAddressStructure(Number structureId, String description) {
		super();
		this.structureId = structureId;
		this.description = description;
	}


	public Number getStructureId() {
		return structureId;
	}


	public void setStructureId(int structureId) {
		this.structureId = structureId;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
	
	

}

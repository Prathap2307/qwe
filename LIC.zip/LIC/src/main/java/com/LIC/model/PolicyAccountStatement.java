package com.LIC.model;

import java.sql.Date;

public class PolicyAccountStatement {

	private long groupid;
	
	private long masterpolicyId;
	
	private Date fromDate;
	
	private Date toDate;
	
	private long agreementid;
	
	private String description;
	
	private long partyId;
	
	public long getPartyId() {
		return partyId;
	}

	public void setPartyId(long partyId) {
		this.partyId = partyId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	private long userId;
	
	private String groupName;

	public double getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(double totalamount) {
		this.totalamount = totalamount;
	}

	public double getBalanceamount() {
		return balanceamount;
	}

	public void setBalanceamount(double balanceamount) {
		this.balanceamount = balanceamount;
	}

	public double getApprovedamount() {
		return approvedamount;
	}

	public void setApprovedamount(double approvedamount) {
		this.approvedamount = approvedamount;
	}

	private double totalamount;
	private double balanceamount;
	private double approvedamount;
	public long getGroupId() {
		return groupid;
	}

	public void setGroupId(long groupId) {
		this.groupid = groupId;
	}

	public long getMasterpolicyId() {
		return masterpolicyId;
	}

	public void setMasterpolicyId(long masterpolicyId) {
		this.masterpolicyId = masterpolicyId;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public long getAgreementid() {
		return agreementid;
	}

	public void setAgreementid(long agreementid) {
		this.agreementid = agreementid;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
	
}

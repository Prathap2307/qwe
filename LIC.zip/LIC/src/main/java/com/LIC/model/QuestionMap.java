package com.LIC.model;

public class QuestionMap {

	private String rateType;
	
	private String questions;
	
	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	public String getQuestions() {
		return questions;
	}

	public void setQuestions(String questions) {
		this.questions = questions;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public int getMasterPolicyId() {
		return masterPolicyId;
	}

	public void setMasterPolicyId(int masterPolicyId) {
		this.masterPolicyId = masterPolicyId;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public int getIsDiscount() {
		return isDiscount;
	}

	public void setIsDiscount(int isDiscount) {
		this.isDiscount = isDiscount;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public int getIsActvie() {
		return isActvie;
	}

	public void setIsActvie(int isActvie) {
		this.isActvie = isActvie;
	}

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public int getQuestionMapId() {
		return questionMapId;
	}

	public void setQuestionMapId(int questionMapId) {
		this.questionMapId = questionMapId;
	}

	public int getSfqMapId() {
		return sfqMapId;
	}

	public void setSfqMapId(int sfqMapId) {
		this.sfqMapId = sfqMapId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	private long rate;
	
	private int masterPolicyId;
	
	private int questionId;
	
	private int isDiscount;
	
	private long amount;
	
	private long createdBy;
	
	private int groupId;
	
	private int isActvie;
	
	private int typeId;
	
	private int questionMapId;
	
	private int sfqMapId;
	
	private String description;
	
	
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class SalesHierarchyAddressModal  implements Serializable {

	private static final long serialVersionUID = 1L;

	
		private long 	addressID ;
	    private String  address1 ;
	    private String  address2 ;
	    private String  address3 ;
	    private String  address4 ;
		private long  	countryID ;
		private long  	stateID ;
		private String  tehsil ;
		private long 	districtID ;
		private long  	talukID ;
		private long  	modifiedBy ;
		private String  zipCode ;
		private long  	addressTypeID ;
		private String  phoneNo ;
		private String  mobileNo ;
		private String  conferenceNo ;
		private String  faxNo ;
		private String  email ;
		private long  	createdBy ;
		private Timestamp  createdOn ;
		private Timestamp  modifiedOn ;
		private long  deletedBy ;
		private Timestamp  deletedOn ;
		private short  isActive ;
		private String  vendorID ;
		private long 	salesHierArchyID ;
		private long 	villageID ;
		private String address5 ;
		private short  deleted;
		private long   addressTypeTypeID;
		private String  	countryName;
		private String  	stateName;
		private String  	districtName;
		private String  	talukName;
		private String  	villageName;
		private String  	addressType;
		private String  	personalEmailID;
		private String  	otherDistrict;
		private String  	otherTaluk;
		private String  	otherVillage;
		
		public String getPersonalEmailID() {
			return personalEmailID;
		}
		public String getOtherDistrict() {
			return otherDistrict;
		}
		public String getOtherTaluk() {
			return otherTaluk;
		}
		public String getOtherVillage() {
			return otherVillage;
		}
		public void setPersonalEmailID(String personalEmailID) {
			this.personalEmailID = personalEmailID;
		}
		public void setOtherDistrict(String otherDistrict) {
			this.otherDistrict = otherDistrict;
		}
		public void setOtherTaluk(String otherTaluk) {
			this.otherTaluk = otherTaluk;
		}
		public void setOtherVillage(String otherVillage) {
			this.otherVillage = otherVillage;
		}
		public String getCountryName() {
			return countryName;
		}
		public String getStateName() {
			return stateName;
		}
		public String getDistrictName() {
			return districtName;
		}
		public String getTalukName() {
			return talukName;
		}
		public void setCountryName(String countryName) {
			this.countryName = countryName;
		}
		public void setStateName(String stateName) {
			this.stateName = stateName;
		}
		public void setDistrictName(String districtName) {
			this.districtName = districtName;
		}
		public void setTalukName(String talukName) {
			this.talukName = talukName;
		}
		public long getAddressID() {
			return addressID;
		}
		public String getAddress1() {
			return address1;
		}
		public String getAddress2() {
			return address2;
		}
		public String getAddress3() {
			return address3;
		}
		public String getAddress4() {
			return address4;
		}
		public long getCountryID() {
			return countryID;
		}
		public long getStateID() {
			return stateID;
		}
		public String getTehsil() {
			return tehsil;
		}
		public long getDistrictID() {
			return districtID;
		}
		public long getTalukID() {
			return talukID;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public String getZipCode() {
			return zipCode;
		}
		public long getAddressTypeID() {
			return addressTypeID;
		}
		public String getPhoneNo() {
			return phoneNo;
		}
		public String getMobileNo() {
			return mobileNo;
		}
		public String getConferenceNo() {
			return conferenceNo;
		}
		public String getFaxNo() {
			return faxNo;
		}
		public String getEmail() {
			return email;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public String getVendorID() {
			return vendorID;
		}
		public long getSalesHierArchyID() {
			return salesHierArchyID;
		}
		public long getVillageID() {
			return villageID;
		}
		public String getAddress5() {
			return address5;
		}
		public short getDeleted() {
			return deleted;
		}
		public long getAddressTypeTypeID() {
			return addressTypeTypeID;
		}
		public void setAddressID(long addressID) {
			this.addressID = addressID;
		}
		public void setAddress1(String address1) {
			this.address1 = address1;
		}
		public void setAddress2(String address2) {
			this.address2 = address2;
		}
		public void setAddress3(String address3) {
			this.address3 = address3;
		}
		public void setAddress4(String address4) {
			this.address4 = address4;
		}
		public void setCountryID(long countryID) {
			this.countryID = countryID;
		}
		public void setStateID(long stateID) {
			this.stateID = stateID;
		}
		public void setTehsil(String tehsil) {
			this.tehsil = tehsil;
		}
		public void setDistrictID(long districtID) {
			this.districtID = districtID;
		}
		public void setTalukID(long talukID) {
			this.talukID = talukID;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}
		public void setAddressTypeID(long addressTypeID) {
			this.addressTypeID = addressTypeID;
		}
		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}
		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}
		public void setConferenceNo(String conferenceNo) {
			this.conferenceNo = conferenceNo;
		}
		public void setFaxNo(String faxNo) {
			this.faxNo = faxNo;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public void setVendorID(String vendorID) {
			this.vendorID = vendorID;
		}
		public void setSalesHierArchyID(long sSalesHierArchyID) {
			this.salesHierArchyID = sSalesHierArchyID;
		}
		public void setVillageID(long villageID) {
			this.villageID = villageID;
		}
		public void setAddress5(String address5) {
			this.address5 = address5;
		}
		public void setDeleted(short deleted) {
			this.deleted = deleted;
		}
		public void setAddressTypeTypeID(long addressTypeTypeID) {
			this.addressTypeTypeID = addressTypeTypeID;
		}
		@Override
		public String toString() {
			return "SalesHierarchyAddressModal [addressID=" + addressID + ", address1=" + address1 + ", address2="
					+ address2 + ", address3=" + address3 + ", address4=" + address4 + ", countryID=" + countryID
					+ ", stateID=" + stateID + ", tehsil=" + tehsil + ", districtID=" + districtID + ", talukID="
					+ talukID + ", modifiedBy=" + modifiedBy + ", zipCode=" + zipCode + ", addressTypeID="
					+ addressTypeID + ", phoneNo=" + phoneNo + ", mobileNo=" + mobileNo + ", conferenceNo="
					+ conferenceNo + ", faxNo=" + faxNo + ", email=" + email + ", createdBy=" + createdBy
					+ ", createdOn=" + createdOn + ", modifiedOn=" + modifiedOn + ", deletedBy=" + deletedBy
					+ ", deletedOn=" + deletedOn + ", isActive=" + isActive + ", vendorID=" + vendorID
					+ ", sSalesHierArchyID=" + salesHierArchyID + ", villageID=" + villageID + ", address5=" + address5
					+ ", deleted=" + deleted + ", addressTypeTypeID=" + addressTypeTypeID + "]";
		}
		public String getVillageName() {
			return villageName;
		}
		public void setVillageName(String villageName) {
			this.villageName = villageName;
		}
		public String getAddressType() {
			return addressType;
		}
		public void setAddressType(String addressType) {
			this.addressType = addressType;
		} 
		
		
		
		   
		
}

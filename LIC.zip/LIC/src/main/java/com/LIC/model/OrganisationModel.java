package com.LIC.model;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;







@NamedStoredProcedureQuery(name = "createOrUpdateOrganisation", procedureName = "spInsertOrUpdateOrganisation", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vOrganisationID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vShortName", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vOrganisationName", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPasswordExpiry", type =Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vNoOfDays", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vAddress1", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vAddress2", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vAddress3", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCountryID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vStateID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDistrictID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vTalukID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vZipCode", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPhoneNo", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vMobileNo", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vConferenceNo", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vFaxNo", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vEmail", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vIsActive", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vGSTNo", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPANNo", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vSACCode", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedOn", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "vResult", type = Integer.class)} ,resultClasses = OrganisationModel.class)
		















@Entity
@Table(name="ORGANISATION")

public class OrganisationModel{
	
	@Id
	private int organisationId;
	private String shortName;
	private String organisationName;
	private int smsTrigger;
	private int passwordExpiry;
	private String gstNo;
	private String panNo;
	private String address1;
	private String address2;
	private String address3;
	private int countryId;
	private int stateId;
	private int districtId;
	private int talukId;
	private String zipCode;
	private String phoneNo;
	private String mobileNo;
	private String conferenceNo;
	private String faxNo;
	private String email;
	private int noOfDays;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	private int deletedBy;
	private Date deletedOn;
	private int isActive;
	private String sacCode;
	
	
	
	
	
	public int getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(int organisationId) {
		this.organisationId = organisationId;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getOrganisationName() {
		return organisationName;
	}
	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}
	public int getSmsTrigger() {
		return smsTrigger;
	}
	public void setSmsTrigger(int smsTrigger) {
		this.smsTrigger = smsTrigger;
	}
	public int getPasswordExpiry() {
		return passwordExpiry;
	}
	public void setPasswordExpiry(int passwordExpiry) {
		this.passwordExpiry = passwordExpiry;
	}
	public String getGstNo() {
		return gstNo;
	}
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public int getCountryId() {
		return countryId;
	}
	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public int getDistrictId() {
		return districtId;
	}
	public void setDistrictId(int districtId) {
		this.districtId = districtId;
	}
	public int getTalukId() {
		return talukId;
	}
	public void setTalukId(int talukId) {
		this.talukId = talukId;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getConferenceNo() {
		return conferenceNo;
	}
	public void setConferenceNo(String conferenceNo) {
		this.conferenceNo = conferenceNo;
	}
	public String getFaxNo() {
		return faxNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	public String getSacCode() {
		return sacCode;
	}
	public void setSacCode(String sacCode) {
		this.sacCode = sacCode;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

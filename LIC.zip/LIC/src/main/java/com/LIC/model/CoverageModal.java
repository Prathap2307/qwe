package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class CoverageModal  implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	
    public CoverageModal()  {
    	
    }
 
    @Override
	public String toString() {
		return "CoverageModal [coverageID=" + coverageID + ", typeofCoverID=" + typeofCoverID + ", calculationID="
				+ calculationID + ", coverageName=" + coverageName + ", coverCode=" + coverCode + ", calculationName="
				+ calculationName + ", description=" + description + ", typeOfCover=" + typeOfCover
				+ ", isStampDutyApplicable=" + isStampDutyApplicable + ", isActive=" + isActive + ", createdBy="
				+ createdBy + ", createdOn=" + createdOn + ", stamDutyType=" + stamDutyType + ", stampDutyRate="
				+ stampDutyRate + ", effectFromDate=" + effectFromDate + ", effectToDate=" + effectToDate
				+ ", productId=" + productId + ", isBaseCoverage=" + isBaseCoverage + ", isSelectable=" + isSelectable
				+ ", coverageMaxSumAssured=" + coverageMaxSumAssured + ", houseHoldLimitPerYear="
				+ houseHoldLimitPerYear + ", packageID=" + packageID + ", packages=" + packages + ", packageRate="
				+ packageRate + ", sectionID=" + sectionID + ", type=" + type + ", amountPercentage=" + amountPercentage
				+ ", productTypeID=" + productTypeID + ", insurerID=" + insurerID + ", insurerName=" + insurerName
				+ ", lineOfBusinessID=" + lineOfBusinessID + ", coverageUINMapModalList=" + coverageUINMapModalList
				+ "]";
	}

	public CoverageModal(long coverageModalID) {
       this.coverageID	= coverageModalID;
    }

    public CoverageModal(long coverageModalID, String CoverageName, String Description) {
    	 this.coverageID	= coverageModalID;
    	 this.coverageName	= CoverageName;
    	 this.description	= Description;
    }

    public CoverageModal(long coverageModalID, String CoverageName, String Description, short IsBaseCoverage, short IsSelectable, long PackageID, double PackageRate)    {
    	
    	this.coverageID		= coverageModalID;
	   	this.coverageName	= CoverageName;
	   	this.description	= Description;
	   	this.isBaseCoverage	= IsBaseCoverage;
	   	this.isSelectable	= IsSelectable;
	   	this.packageID		= PackageID;
	   	this.packageRate	= PackageRate;
    }
    
    private long 		coverageID;
    private long 		typeofCoverID;
    private long 		calculationID;
    private String 		coverageName;
    private String 		coverCode;
    private String 		calculationName;
    private String 		description;
    private String 		typeOfCover;
    private short 		isStampDutyApplicable;
    private short 		isActive;
    private long 		createdBy;
    private Timestamp 	createdOn;
    private int 		stamDutyType;
    private double 		stampDutyRate;
    private Timestamp 	effectFromDate;
    private Timestamp 	effectToDate;
    private long 		productId;
    private short 		isBaseCoverage;
    private short 		isSelectable;
    private double 		coverageMaxSumAssured;
    private double 		houseHoldLimitPerYear;
    private double 		packageID;
    private String 		packages;
    private double 		packageRate;
    private long 		sectionID;
    private int 		type;
    private double 		amountPercentage;
    private long 		productTypeID;
    private long 		insurerID;
    private String 		insurerName;
    private long 		lineOfBusinessID;
    private String 		lineOfBusinessName;
    
    private List<CoverageUINMapModal>		coverageUINMapModalList;
    private List<CoverageExclusionNewModal>	coverageExclusionNewModalList;


	public long getCoverageID() {
		return coverageID;
	}

	public long getTypeofCoverID() {
		return typeofCoverID;
	}

	public long getCalculationID() {
		return calculationID;
	}

	public String getCoverageName() {
		return coverageName;
	}

	public String getCoverCode() {
		return coverCode;
	}

	public String getCalculationName() {
		return calculationName;
	}

	public String getDescription() {
		return description;
	}

	public String getTypeOfCover() {
		return typeOfCover;
	}

	public short getIsStampDutyApplicable() {
		return isStampDutyApplicable;
	}

	public short getIsActive() {
		return isActive;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public int getStamDutyType() {
		return stamDutyType;
	}

	public double getStampDutyRate() {
		return stampDutyRate;
	}

	public Timestamp getEffectFromDate() {
		return effectFromDate;
	}

	public Timestamp getEffectToDate() {
		return effectToDate;
	}

	public long getProductId() {
		return productId;
	}

	public short getIsBaseCoverage() {
		return isBaseCoverage;
	}

	public short getIsSelectable() {
		return isSelectable;
	}

	public double getCoverageMaxSumAssured() {
		return coverageMaxSumAssured;
	}

	public double getHouseHoldLimitPerYear() {
		return houseHoldLimitPerYear;
	}

	public double getPackageID() {
		return packageID;
	}

	public String getPackages() {
		return packages;
	}

	public double getPackageRate() {
		return packageRate;
	}

	public long getSectionID() {
		return sectionID;
	}

	public int getType() {
		return type;
	}

	public double getAmountPercentage() {
		return amountPercentage;
	}

	public long getProductTypeID() {
		return productTypeID;
	}

	public long getInsurerID() {
		return insurerID;
	}

	public String getInsurerName() {
		return insurerName;
	}

	public long getLineOfBusinessID() {
		return lineOfBusinessID;
	}

	public void setCoverageID(long coverageID) {
		this.coverageID = coverageID;
	}

	public void setTypeofCoverID(long typeofCoverID) {
		this.typeofCoverID = typeofCoverID;
	}

	public void setCalculationID(long calculationID) {
		this.calculationID = calculationID;
	}

	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	public void setCoverCode(String coverCode) {
		this.coverCode = coverCode;
	}

	public void setCalculationName(String calculationName) {
		this.calculationName = calculationName;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setTypeOfCover(String typeOfCover) {
		this.typeOfCover = typeOfCover;
	}

	public void setIsStampDutyApplicable(short isStampDutyApplicable) {
		this.isStampDutyApplicable = isStampDutyApplicable;
	}

	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public void setStamDutyType(int stamDutyType) {
		this.stamDutyType = stamDutyType;
	}

	public void setStampDutyRate(double stampDutyRate) {
		this.stampDutyRate = stampDutyRate;
	}

	public void setEffectFromDate(Timestamp effectFromDate) {
		this.effectFromDate = effectFromDate;
	}

	public void setEffectToDate(Timestamp effectToDate) {
		this.effectToDate = effectToDate;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public void setIsBaseCoverage(short isBaseCoverage) {
		this.isBaseCoverage = isBaseCoverage;
	}

	public void setIsSelectable(short isSelectable) {
		this.isSelectable = isSelectable;
	}

	public void setCoverageMaxSumAssured(double coverageMaxSumAssured) {
		this.coverageMaxSumAssured = coverageMaxSumAssured;
	}

	public void setHouseHoldLimitPerYear(double houseHoldLimitPerYear) {
		this.houseHoldLimitPerYear = houseHoldLimitPerYear;
	}

	public void setPackageID(double packageID) {
		this.packageID = packageID;
	}

	public void setPackages(String packages) {
		this.packages = packages;
	}

	public void setPackageRate(double packageRate) {
		this.packageRate = packageRate;
	}

	public void setSectionID(long sectionID) {
		this.sectionID = sectionID;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void setAmountPercentage(double amountPercentage) {
		this.amountPercentage = amountPercentage;
	}

	public void setProductTypeID(long productTypeID) {
		this.productTypeID = productTypeID;
	}

	public void setInsurerID(long insurerID) {
		this.insurerID = insurerID;
	}

	public void setInsurerName(String insurerName) {
		this.insurerName = insurerName;
	}

	public void setLineOfBusinessID(long lineOfBusinessID) {
		this.lineOfBusinessID = lineOfBusinessID;
	}

	public List<CoverageUINMapModal> getCoverageUINMapModalList() {
		return coverageUINMapModalList;
	}

	public void setCoverageUINMapModalList(List<CoverageUINMapModal> coverageUINMapModalList) {
		this.coverageUINMapModalList = coverageUINMapModalList;
	}

	public String getLineOfBusinessName() {
		return lineOfBusinessName;
	}

	public void setLineOfBusinessName(String lineOfBusinessName) {
		this.lineOfBusinessName = lineOfBusinessName;
	}

	public List<CoverageExclusionNewModal> getCoverageExclusionNewModalList() {
		return coverageExclusionNewModalList;
	}

	public void setCoverageExclusionNewModalList(List<CoverageExclusionNewModal> coverageExclusionNewModalList) {
		this.coverageExclusionNewModalList = coverageExclusionNewModalList;
	}
}

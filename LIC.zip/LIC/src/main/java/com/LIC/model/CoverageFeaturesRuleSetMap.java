package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class CoverageFeaturesRuleSetMap implements Serializable
{
	private static final long serialVersionUID = 1L;
	public static final String COVERAGE_FEATURES_RULESETMAP  = "CoverageFeaturesRuleSetMap";
	
	
	private long mapId; 
	private long ruleSetId;  
	private long documentTypeId;
	public long getMapId() {
		return mapId;
	}
	public void setMapId(long mapId) {
		mapId = mapId;
	}
	public long getRuleSetId() {
		return ruleSetId;
	}
	public void setRuleSetId(long ruleSetId) {
		ruleSetId = ruleSetId;
	}
	public long getDocumentTypeId() {
		return documentTypeId;
	}
	public void setDocumentTypeId(long documentTypeId) {
		documentTypeId = documentTypeId;
	}
	
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
}

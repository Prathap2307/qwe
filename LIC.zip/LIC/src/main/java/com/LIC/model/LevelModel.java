package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class LevelModel implements Serializable {

	private static final long serialVersionUID = 1L; 	
	
		private long 		levelID;
		private String		description;
		private String 		shortDescription;
		private long 		createdBy;
		private Timestamp 	createdOn;
		private long 		modifiedBy;
		private Timestamp 	modifiedOn;
		private long 		deletedBy;
		private Timestamp 	deletedOn;
		private long 		isActive;
	
		
			public long getLevelID() {
				return levelID;
			}
			public void setLevelID(long levelID) {
				this.levelID = levelID;
			}
			public String getDescription() {
				return description;
			}
			public void setDescription(String description) {
				this.description = description;
			}
			public String getShortDescription() {
				return shortDescription;
			}
			public void setShortDescription(String shortDescription) {
				this.shortDescription = shortDescription;
			}
			public long getCreatedBy() {
				return createdBy;
			}
			public void setCreatedBy(long createdBy) {
				this.createdBy = createdBy;
			}
			public Timestamp getCreatedOn() {
				return createdOn;
			}
			public void setCreatedOn(Timestamp createdOn) {
				this.createdOn = createdOn;
			}
			public long getModifiedBy() {
				return modifiedBy;
			}
			public void setModifiedBy(long modifiedBy) {
				this.modifiedBy = modifiedBy;
			}
			public Timestamp getModifiedOn() {
				return modifiedOn;
			}
			public void setModifiedOn(Timestamp modifiedOn) {
				this.modifiedOn = modifiedOn;
			}
			public long getDeletedBy() {
				return deletedBy;
			}
			public void setDeletedBy(long deletedBy) {
				this.deletedBy = deletedBy;
			}
			public Timestamp getDeletedOn() {
				return deletedOn;
			}
			public void setDeletedOn(Timestamp deletedOn) {
				this.deletedOn = deletedOn;
			}
			public long getIsActive() {
				return isActive;
			}
			public void setIsActive(long isActive) {
				this.isActive = isActive;
			}
	
	
	
	
}

package com.LIC.model;

import java.io.Serializable;

public class DistrictHistory extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer historyId;
	private Integer districtId;
	private Integer stateId;
	private String description;
	private String zipCode; 
	private String remarks;
	
	public Integer getHistoryId() {
		return historyId;
	}
	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}
	public Integer getDistrictId() {
		return districtId;
	}
	public void setDistrictId(Integer districtId) {
		this.districtId = districtId;
	}
	public Integer getStateId() {
		return stateId;
	}
	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	} 

 
}

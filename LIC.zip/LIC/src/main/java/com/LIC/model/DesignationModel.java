package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;


@NamedStoredProcedureQuery(name = "createOrUpdateDesig", procedureName = "spInsertOrUpdateDesignation", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDepartmentID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDesignationID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vShortName", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDescription", type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "pCreatedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pIsActive", type = Integer.class)} ,resultClasses = DesignationModel.class)
		
@NamedStoredProcedureQuery(name ="deleteDesig", procedureName = "spDeleteDesignation", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDesignationID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDELETEDBY", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDELETEDON", type = Date.class)
		}, resultClasses = DesignationModel.class)






@Entity
@Table(name="MASTER_DESIGNATION")
public class DesignationModel {
	@Id
	private int designationId;
	private int departmentId;
	private String shortName;
	private String description;
	private int gradeId;
	private int organisationId;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	private int deletedBy;
	private Date deletedOn;
	private int isActive;
	
	
	public int getDesignationId() {
		return designationId;
	}
	public void setDesignationId(int designationId) {
		this.designationId = designationId;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getGradeId() {
		return gradeId;
	}
	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}
	public int getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(int organisationId) {
		this.organisationId = organisationId;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	
	
	
	
	
	

}

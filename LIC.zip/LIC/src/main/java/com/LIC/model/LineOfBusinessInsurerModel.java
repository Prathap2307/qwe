package com.LIC.model;

import java.sql.Timestamp;

public class LineOfBusinessInsurerModel {

	private long       		lobID;
	private String       	description;
	private long       		createdBy;
	private Timestamp       createdOn;
	private long       		modifiedBy;
	private Timestamp       modifiedOn;
	private long       		deletedBy;
	private Timestamp       deletedOn;
	private short       	isActive;
	private long			insurerId;
	
	public long getLobID() {
		return lobID;
	}
	public String getDescription() {
		return description;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public long getModifiedBy() {
		return modifiedBy;
	}
	public Timestamp getModifiedOn() {
		return modifiedOn;
	}
	public long getDeletedBy() {
		return deletedBy;
	}
	public Timestamp getDeletedOn() {
		return deletedOn;
	}
	public short getIsActive() {
		return isActive;
	}
	public void setLobID(long lobID) {
		this.lobID = lobID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public void setDeletedBy(long deletedBy) {
		this.deletedBy = deletedBy;
	}
	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	public long getInsurerId() {
		return insurerId;
	}
	public void setInsurerId(long insurerId) {
		this.insurerId = insurerId;
	}
}

package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_PLAN")
public class GetProductModel{
	
	
	@Id
	private Number planId;
	private Number organisationId;
	private String shortName;
	private String planName;
	private Number isActive;
	private Number category;
	private Number productTypeId;
	private String description;
	private Number createdBy;
	private Date createdOn;
	private Number deletedBy;
	private Date deletedOn;
	private Number modifiedBy;
	private Date modifiedOn;
	
	

	
	
	
	
	



	

	public GetProductModel(Number planId, Number organisationId,String planName, String shortName , Number isActive,
			Number category, Number productTypeId) {
		super();
		this.planId = planId;
		this.organisationId = organisationId;
		this.planName = planName;
		this.shortName = shortName;
		this.isActive = isActive;
		this.category = category;
		this.productTypeId = productTypeId;
	}


	public Number getOrganisationId() {
		return organisationId;
	}


	public void setOrganisationId(Number organisationId) {
		this.organisationId = organisationId;
	}


	public Number getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public Number getDeletedBy() {
		return deletedBy;
	}


	public void setDeletedBy(Number deletedBy) {
		this.deletedBy = deletedBy;
	}


	public Date getDeletedOn() {
		return deletedOn;
	}


	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}


	public Number getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(Number modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifiedOn() {
		return modifiedOn;
	}


	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}



	public Number getPlanId() {
		return planId;
	}
	public void setPlanId(Number planId) {
		this.planId = planId;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public Number getCategory() {
		return category;
	}
	public void setCategory(Number category) {
		this.category = category;
	}
	public GetProductModel(Number planId, String shortName,String planName, Number isActive, Number category) {
		super();
		this.planId = planId;
		this.shortName = shortName;
		this.planName = planName;
		this.isActive = isActive;
		this.category = category;
	}
	
	public GetProductModel(Number productTypeId, String description) {
		super();
		this.productTypeId = productTypeId;
		this.description = description;
	}



	public Number getProductTypeId() {
		return productTypeId;
	}


	public void setProductTypeId(Number productTypeId) {
		this.productTypeId = productTypeId;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public GetProductModel(Number organisationId,String planName, String shortName , Number category ) {
		super();
		this.organisationId = organisationId;
		this.planName = planName;
		this.shortName = shortName;
		this.category = category;
	}
	
	
	
	
	

}

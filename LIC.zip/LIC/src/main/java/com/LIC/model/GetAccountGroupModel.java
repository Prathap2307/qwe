package com.LIC.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_ACCOUNTGROUP")
public class GetAccountGroupModel {
	
	@Id
	private Number accountingGroupId;
	private String code;
	private String groupName;
	private Number createdBy;
	private String createdOn;
	private  Number  modifiedBy;
	private String modifiedOn;
	private  Number  deletedBy;
	private Date deletedOn;
	private Number isActive;
	private Number dupid;
	
	public Number getDupid() {
		return dupid;
	}
	public void setDupid(Number dupid) {
		this.dupid = dupid;
	}
	public Number getAccountingGroupId() {
		return accountingGroupId;
	}
	public void setAccountingGroupId(Number accountingGroupId) {
		this.accountingGroupId = accountingGroupId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public Number getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Number modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public Number getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(Number deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	public GetAccountGroupModel(Number accountingGroupId, String code, String groupName, Number isActive, Number createdBy,
			String createdOn, Number modifiedBy, String modifiedOn) {
		super();
		this.accountingGroupId = accountingGroupId;
		this.code = code;
		this.groupName = groupName;
		this.isActive = isActive;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
		
	}
	public GetAccountGroupModel() {
		super();
	}
	public GetAccountGroupModel(Number accountingGroupId, String groupName, String code) {
		super();
		this.accountingGroupId = accountingGroupId;
		this.groupName = groupName;
		this.code = code;
	}
	
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_DISTRICT")
public class DistrictModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	 
	    @Id
	    @GeneratedValue
	    @Column(name="DISTRICTID")
	    private long 		 	districtId;
	    private String 		 	description;
	    private long 		 	createdBy;
	    private Timestamp 		createdOn; 
	    private long 			modifiedBy;
	    private Timestamp 		modifiedOn;
		private short 		 	isActive;
	    private Timestamp   	deletedOn;
		private long         	deletedBy;
	    private long 			excludeTax;
	    private long 			stateID;
	    private String 			zipCode;
	
	    public long getDistrictId() {
			return districtId;
		}
		public void setDistrictId(long districtId) {
			this.districtId = districtId;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public long getExcludeTax() {
			return excludeTax;
		}
		public void setExcludeTax(long excludeTax) {
			this.excludeTax = excludeTax;
		}
		public long getStateID() {
			return stateID;
		}
		public void setStateID(long stateID) {
			this.stateID = stateID;
		}
		public String getZipCode() {
			return zipCode;
		}
		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}
		@Override
		public String toString() {
			return "DistrictModal [districtId=" + districtId + ", description=" + description + ", createdBy="
					+ createdBy + ", createdOn=" + createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn="
					+ modifiedOn + ", isActive=" + isActive + ", deletedOn=" + deletedOn + ", deletedBy=" + deletedBy
					+ ", excludeTax=" + excludeTax + ", stateID=" + stateID + ", zipCode=" + zipCode + "]";
		}
	   
}

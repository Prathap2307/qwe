package com.LIC.model;

public class ClientOrganization {

	 private String clientName ;
	 private Integer clientId ;
	 private String contactpersonFirstName ;
	 private String contactpersonLastName ;
	 private String insurerServicingBranch ;
	 private String contactpersonMiddleName ;
	 private String triggerSmsEmail ;
	 private Integer contact ;
	 private String riskCategory ;
	 private Integer turnOver ;
	 public Integer getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(Integer turnOver) {
		this.turnOver = turnOver;
	}
	private String typeOfClient ;
	 private String gstType ;
	 private Integer pan ;
	 private String isSms;
	 private String isEmail;
	 public String getIsSms() {
		return isSms;
	}
	public void setIsSms(String isSms) {
		this.isSms = isSms;
	}
	public String getIsEmail() {
		return isEmail;
	}
	public void setIsEmail(String isEmail) {
		this.isEmail = isEmail;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	private String shortName;
private String emailId ;
private String servicingBranch ;
private String selectParent ;
private String parentCompany ;
private String marketingOfficeLocation ;
private String agentName ;
private String grade ;
public String getClientName() {
	return clientName;
}
public void setClientName(String clientName) {
	this.clientName = clientName;
}
public Integer getClientId() {
	return clientId;
}
public void setClientId(Integer clientId) {
	this.clientId = clientId;
}
public String getContactpersonFirstName() {
	return contactpersonFirstName;
}
public void setContactpersonFirstName(String contactpersonFirstName) {
	this.contactpersonFirstName = contactpersonFirstName;
}
public String getContactpersonLastName() {
	return contactpersonLastName;
}
public void setContactpersonLastName(String contactpersonLastName) {
	this.contactpersonLastName = contactpersonLastName;
}
public String getInsurerServicingBranch() {
	return insurerServicingBranch;
}
public void setInsurerServicingBranch(String insurerServicingBranch) {
	this.insurerServicingBranch = insurerServicingBranch;
}
public String getContactpersonMiddleName() {
	return contactpersonMiddleName;
}
public void setContactpersonMiddleName(String contactpersonMiddleName) {
	this.contactpersonMiddleName = contactpersonMiddleName;
}
public String getTriggerSmsEmail() {
	return triggerSmsEmail;
}
public void setTriggerSmsEmail(String triggerSmsEmail) {
	this.triggerSmsEmail = triggerSmsEmail;
}
public Integer getContact() {
	return contact;
}
public void setContact(Integer contact) {
	this.contact = contact;
}
public String getRiskCategory() {
	return riskCategory;
}
public void setRiskCategory(String riskCategory) {
	this.riskCategory = riskCategory;
}
public String getTypeOfClient() {
	return typeOfClient;
}
public void setTypeOfClient(String typeOfClient) {
	this.typeOfClient = typeOfClient;
}
public String getGstType() {
	return gstType;
}
public void setGstType(String gstType) {
	this.gstType = gstType;
}
public Integer getPan() {
	return pan;
}
public void setPan(Integer pan) {
	this.pan = pan;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getServicingBranch() {
	return servicingBranch;
}
public void setServicingBranch(String servicingBranch) {
	this.servicingBranch = servicingBranch;
}
public String getSelectParent() {
	return selectParent;
}
public void setSelectParent(String selectParent) {
	this.selectParent = selectParent;
}
public String getParentCompany() {
	return parentCompany;
}
public void setParentCompany(String parentCompany) {
	this.parentCompany = parentCompany;
}
public String getMarketingOfficeLocation() {
	return marketingOfficeLocation;
}
public void setMarketingOfficeLocation(String marketingOfficeLocation) {
	this.marketingOfficeLocation = marketingOfficeLocation;
}
public String getAgentName() {
	return agentName;
}
public void setAgentName(String agentName) {
	this.agentName = agentName;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public String getAddressOne() {
	return addressOne;
}
public void setAddressOne(String addressOne) {
	this.addressOne = addressOne;
}
public String getAddressTwo() {
	return addressTwo;
}
public void setAddressTwo(String addressTwo) {
	this.addressTwo = addressTwo;
}
public String getAddressThree() {
	return addressThree;
}
public void setAddressThree(String addressThree) {
	this.addressThree = addressThree;
}
public Integer getZipCode() {
	return zipCode;
}
public void setZipCode(Integer zipCode) {
	this.zipCode = zipCode;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getDistrict() {
	return district;
}
public void setDistrict(String district) {
	this.district = district;
}
public String getPostOffice() {
	return postOffice;
}
public void setPostOffice(String postOffice) {
	this.postOffice = postOffice;
}
public String getLandline() {
	return landline;
}
public void setLandline(String landline) {
	this.landline = landline;
}
public String getAddressType() {
	return addressType;
}
public void setAddressType(String addressType) {
	this.addressType = addressType;
}
private String addressOne ;
private String addressTwo ;
private String addressThree ;
private Integer zipCode ;
private String country ;
private String state ;
private String district ;
private String postOffice ;
private String landline ;
private String addressType ;
}


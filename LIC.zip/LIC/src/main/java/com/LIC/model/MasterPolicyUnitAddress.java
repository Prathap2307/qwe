package com.LIC.model;

import java.util.Date;

public class MasterPolicyUnitAddress implements Cloneable {

	private int addressId;
	
	private String address1;
	
	private String address2;
	
	private String address3;
	
	private String address4;
	
	private String address5;
	
	private int countryId;
	
	private int stateId;
	
	private int districtId;
	
	private String countryName;
	
	private String stateName;
	
	private String districtName;
	
	private int talukaId;
	
	private int zipCode;
	
	private int addressTypeId;
	
	private String addressTypeName;
	
	private long phoneNo;
	
	private long mobileNo;
	
	private long conferenceNo;
	
	private long faxNo;
	
	private String email;
	
	private String personalEmailId;
	
	private int createdBy;
	
	private Date createdOn;
	
	private int masterpolicyId;

	private String tehsil;
	
	private String gstNo;
	
	private String panNo;
	
	private String unitName;
	
	public String getTehsil() {
		return tehsil;
	}

	public void setTehsil(String tehsil) {
		this.tehsil = tehsil;
	}

	public String getGstNo() {
		return gstNo;
	}

	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getAddress5() {
		return address5;
	}

	public void setAddress5(String address5) {
		this.address5 = address5;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public int getDistrictId() {
		return districtId;
	}

	public void setDistrictId(int districtId) {
		this.districtId = districtId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public int getTalukaId() {
		return talukaId;
	}

	public void setTalukaId(int talukaId) {
		this.talukaId = talukaId;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public int getAddressTypeId() {
		return addressTypeId;
	}

	public void setAddressTypeId(int addressTypeId) {
		this.addressTypeId = addressTypeId;
	}

	public String getAddressTypeName() {
		return addressTypeName;
	}

	public void setAddressTypeName(String addressTypeName) {
		this.addressTypeName = addressTypeName;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public long getConferenceNo() {
		return conferenceNo;
	}

	public void setConferenceNo(long conferenceNo) {
		this.conferenceNo = conferenceNo;
	}

	public long getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(long faxNo) {
		this.faxNo = faxNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public int getMasterpolicyId() {
		return masterpolicyId;
	}

	public void setMasterpolicyId(int masterpolicyId) {
		this.masterpolicyId = masterpolicyId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	

	@Override
	public String toString() {
		return "MasterPolicyUnitAddress [addressId=" + addressId + ", address1=" + address1 + ", address2=" + address2
				+ ", address3=" + address3 + ", address4=" + address4 + ", address5=" + address5 + ", countryId="
				+ countryId + ", stateId=" + stateId + ", districtId=" + districtId + ", countryName=" + countryName
				+ ", stateName=" + stateName + ", districtName=" + districtName + ", talukaId=" + talukaId
				+ ", zipCode=" + zipCode + ", addressTypeId=" + addressTypeId + ", addressTypeName=" + addressTypeName
				+ ", phoneNo=" + phoneNo + ", mobileNo=" + mobileNo + ", conferenceNo=" + conferenceNo + ", faxNo="
				+ faxNo + ", email=" + email + ", personalEmailId=" + personalEmailId + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", masterpolicyId=" + masterpolicyId + ", tehsil=" + tehsil + ", gstNo="
				+ gstNo + ", panNo=" + panNo + ", unitName=" + unitName + "]";
	}
	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
}

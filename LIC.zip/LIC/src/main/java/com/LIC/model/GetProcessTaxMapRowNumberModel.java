package com.LIC.model;


public class GetProcessTaxMapRowNumberModel {

private	Number rowNumber;

public GetProcessTaxMapRowNumberModel(Number rowNumber) {
	super();
	this.rowNumber = rowNumber;
}

public Number getRowNumber() {
	return rowNumber;
}

public void setRowNumber(Number rowNumber) {
	this.rowNumber = rowNumber;
}




}


package com.LIC.model;

import java.io.Serializable;
 
public class Question extends RecordModifier  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer questionId;
	private Integer lob;
	private String description;
	private String shortDescription; 
	private Integer orderId;
	private Double weightId;
	
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public Integer getLob() {
		return lob;
	}
	public void setLob(Integer lob) {
		this.lob = lob;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Double getWeightId() {
		return weightId;
	}
	public void setWeightId(Double weightId) {
		this.weightId = weightId;
	}

	
	
}

package com.LIC.model;

public class ClaimIntimationCoverageModel {

	private Number coverageId;

	public ClaimIntimationCoverageModel(Number coverageId, String coverageName) {
		super();
		this.coverageId = coverageId;
		this.coverageName = coverageName;
	}

	public Number getCoverageId() {
		return coverageId;
	}

	public void setCoverageId(Number coverageId) {
		this.coverageId = coverageId;
	}

	public String getCoverageName() {
		return coverageName;
	}

	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	public Number getAmount() {
		return amount;
	}

	public void setAmount(Number amount) {
		this.amount = amount;
	}

	private String coverageName;
	private Number amount;

}

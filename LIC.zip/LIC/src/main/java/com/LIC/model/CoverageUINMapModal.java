package com.LIC.model;


import java.io.Serializable;
import java.sql.Timestamp;

public class CoverageUINMapModal  implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private long 		uinID;
	private long 		coverageID;
	private String  	uinNumber;
	private String 		versionNo;
	private String 		description;
	private long 		maximumMaturityAge;
	private int 		maximumMaturityAgeType;
	private Timestamp  	uinEffectiveFrom;
	private Timestamp 	uinEffectiveTo;
	private long 		minimumEntryAge;
	private int 		minimumEntryAgeType;
	private long 		maximumEntryAge;
	private int 		maximumEntryAgeType;
	private double  	minimumSumAssured;
	private int 		minimumSumAssuredType;
	private double 		maximumSumAssured;
	private int 		maximumSumAssuredType;
	private double 		minimumFreeCoverLimit;
	private double 		maximumFreeCoverLimit;
	private short 		isActive;
	
	public long getUinID() {
		return uinID;
	}
	public long getCoverageID() {
		return coverageID;
	}
	public String getUinNumber() {
		return uinNumber;
	}
	public String getVersionNo() {
		return versionNo;
	}
	public String getDescription() {
		return description;
	}
	public long getMaximumMaturityAge() {
		return maximumMaturityAge;
	}
	public int getMaximumMaturityAgeType() {
		return maximumMaturityAgeType;
	}
	public Timestamp getUinEffectiveFrom() {
		return uinEffectiveFrom;
	}
	public Timestamp getUinEffectiveTo() {
		return uinEffectiveTo;
	}
	public long getMinimumEntryAge() {
		return minimumEntryAge;
	}
	public int getMinimumEntryAgeType() {
		return minimumEntryAgeType;
	}
	public long getMaximumEntryAge() {
		return maximumEntryAge;
	}
	public int getMaximumEntryAgeType() {
		return maximumEntryAgeType;
	}
	public double getMinimumSumAssured() {
		return minimumSumAssured;
	}
	public int getMinimumSumAssuredType() {
		return minimumSumAssuredType;
	}
	public double getMaximumSumAssured() {
		return maximumSumAssured;
	}
	public int getMaximumSumAssuredType() {
		return maximumSumAssuredType;
	}
	public double getMinimumFreeCoverLimit() {
		return minimumFreeCoverLimit;
	}
	public double getMaximumFreeCoverLimit() {
		return maximumFreeCoverLimit;
	}
	public short getIsActive() {
		return isActive;
	}
	public void setUinID(long uinID) {
		this.uinID = uinID;
	}
	public void setCoverageID(long coverageID) {
		this.coverageID = coverageID;
	}
	public void setUinNumber(String uinNumber) {
		this.uinNumber = uinNumber;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setMaximumMaturityAge(long maximumMaturityAge) {
		this.maximumMaturityAge = maximumMaturityAge;
	}
	public void setMaximumMaturityAgeType(int maximumMaturityAgeType) {
		this.maximumMaturityAgeType = maximumMaturityAgeType;
	}
	public void setUinEffectiveFrom(Timestamp uinEffectiveFrom) {
		this.uinEffectiveFrom = uinEffectiveFrom;
	}
	public void setUinEffectiveTo(Timestamp uinEffectiveTo) {
		this.uinEffectiveTo = uinEffectiveTo;
	}
	public void setMinimumEntryAge(long minimumEntryAge) {
		this.minimumEntryAge = minimumEntryAge;
	}
	public void setMinimumEntryAgeType(int minimumEntryAgeType) {
		this.minimumEntryAgeType = minimumEntryAgeType;
	}
	public void setMaximumEntryAge(long maximumEntryAge) {
		this.maximumEntryAge = maximumEntryAge;
	}
	public void setMaximumEntryAgeType(int maximumEntryAgeType) {
		this.maximumEntryAgeType = maximumEntryAgeType;
	}
	public void setMinimumSumAssured(double minimumSumAssured) {
		this.minimumSumAssured = minimumSumAssured;
	}
	public void setMinimumSumAssuredType(int minimumSumAssuredType) {
		this.minimumSumAssuredType = minimumSumAssuredType;
	}
	public void setMaximumSumAssured(double maximumSumAssured) {
		this.maximumSumAssured = maximumSumAssured;
	}
	public void setMaximumSumAssuredType(int maximumSumAssuredType) {
		this.maximumSumAssuredType = maximumSumAssuredType;
	}
	public void setMinimumFreeCoverLimit(double minimumFreeCoverLimit) {
		this.minimumFreeCoverLimit = minimumFreeCoverLimit;
	}
	public void setMaximumFreeCoverLimit(double maximumFreeCoverLimit) {
		this.maximumFreeCoverLimit = maximumFreeCoverLimit;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "CoverageUINMapModal [uinID=" + uinID + ", coverageID=" + coverageID + ", uinNumber=" + uinNumber
				+ ", versionNo=" + versionNo + ", description=" + description + ", maximumMaturityAge="
				+ maximumMaturityAge + ", maximumMaturityAgeType=" + maximumMaturityAgeType + ", uinEffectiveFrom="
				+ uinEffectiveFrom + ", uinEffectiveTo=" + uinEffectiveTo + ", minimumEntryAge=" + minimumEntryAge
				+ ", minimumEntryAgeType=" + minimumEntryAgeType + ", maximumEntryAge=" + maximumEntryAge
				+ ", maximumEntryAgeType=" + maximumEntryAgeType + ", minimumSumAssured=" + minimumSumAssured
				+ ", minimumSumAssuredType=" + minimumSumAssuredType + ", maximumSumAssured=" + maximumSumAssured
				+ ", maximumSumAssuredType=" + maximumSumAssuredType + ", minimumFreeCoverLimit="
				+ minimumFreeCoverLimit + ", maximumFreeCoverLimit=" + maximumFreeCoverLimit + ", isActive=" + isActive
				+ "]";
	}
	
	
	
}

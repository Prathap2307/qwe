package com.LIC.model;

import java.io.Serializable;

public class PasswordPolicyModal implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private long passwordPolicyId;
	private long orgId;
	private int minPasswordLength;
	private int maxPasswordLength;
	private int noOfAttempts;
	private int passwordHistoryCount;
	private int passwordAge;
	private int alertMsgDay;
	private short isDigitsReq;
	private short isCapitalletterReq;
	private short isSmallletterReq;
	private short isSpecialcharReq;
	private short isPasswordsameasUserID;
	private short isActive;
	
	public long getPasswordPolicyId() {
		return passwordPolicyId;
	}

	public long getOrgId() {
		return orgId;
	}

	public int getMinPasswordLength() {
		return minPasswordLength;
	}

	public int getMaxPasswordLength() {
		return maxPasswordLength;
	}

	public int getNoOfAttempts() {
		return noOfAttempts;
	}

	public int getPasswordHistoryCount() {
		return passwordHistoryCount;
	}

	public int getPasswordAge() {
		return passwordAge;
	}

	public int getAlertMsgDay() {
		return alertMsgDay;
	}

	public short getIsDigitsReq() {
		return isDigitsReq;
	}

	public short getIsCapitalletterReq() {
		return isCapitalletterReq;
	}

	public short getIsSmallletterReq() {
		return isSmallletterReq;
	}

	public short getIsSpecialcharReq() {
		return isSpecialcharReq;
	}

	public short getIsPasswordsameasUserID() {
		return isPasswordsameasUserID;
	}

	public short getIsActive() {
		return isActive;
	}

	public void setPasswordPolicyId(long passwordPolicyId) {
		this.passwordPolicyId = passwordPolicyId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public void setMinPasswordLength(int minPasswordLength) {
		this.minPasswordLength = minPasswordLength;
	}

	public void setMaxPasswordLength(int maxPasswordLength) {
		this.maxPasswordLength = maxPasswordLength;
	}

	public void setNoOfAttempts(int noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	public void setPasswordHistoryCount(int passwordHistoryCount) {
		this.passwordHistoryCount = passwordHistoryCount;
	}

	public void setPasswordAge(int passwordAge) {
		this.passwordAge = passwordAge;
	}

	public void setAlertMsgDay(int alertMsgDay) {
		this.alertMsgDay = alertMsgDay;
	}

	public void setIsDigitsReq(short isDigitsReq) {
		this.isDigitsReq = isDigitsReq;
	}

	public void setIsCapitalletterReq(short isCapitalletterReq) {
		this.isCapitalletterReq = isCapitalletterReq;
	}

	public void setIsSmallletterReq(short isSmallletterReq) {
		this.isSmallletterReq = isSmallletterReq;
	}

	public void setIsSpecialcharReq(short isSpecialcharReq) {
		this.isSpecialcharReq = isSpecialcharReq;
	}

	public void setIsPasswordsameasUserID(short isPasswordsameasUserID) {
		this.isPasswordsameasUserID = isPasswordsameasUserID;
	}

	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	
}

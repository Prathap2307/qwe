package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class CommissionModal implements Serializable 
{
	@Override
	public String toString() {
		return "CommissionModal [PolicyYearTypeID=" + PolicyYearTypeID + ", RangeFrom=" + RangeFrom + ", RangeTo="
				+ RangeTo + ", Amount=" + Amount + ", CreatedBy=" + CreatedBy + ", CreatedOn=" + CreatedOn
				+ ", CommissionID=" + CommissionID + ", MainChannelID=" + MainChannelID + ", FromDate=" + FromDate
				+ ", ToDate=" + ToDate + ", IsActive=" + IsActive + ", SubChannelID=" + SubChannelID + ", PolicyTermID="
				+ PolicyTermID + ", SalesHierarchyID=" + SalesHierarchyID + ", PlanID=" + PlanID + ", DeletedBy="
				+ DeletedBy + ", MainChannel=" + MainChannel + ", ChannelName=" + ChannelName + ", PolicyYearExpressed="
				+ PolicyYearExpressed + ", RangeToForNull=" + RangeToForNull + ", Plan=" + Plan + ", FromDateStr="
				+ FromDateStr + ", ToDateStr=" + ToDateStr + "]";
	}
	private static final long serialVersionUID = 1L;
	 private long PolicyYearTypeID;
     private long RangeFrom;
     private long RangeTo;
     private double Amount;
     private long CreatedBy;
     private Timestamp CreatedOn;
     private long CommissionID;
     private long MainChannelID;
     private Timestamp FromDate;
     private Timestamp ToDate;
     private short IsActive;
     private long SubChannelID;
     private long PolicyTermID;
     private long SalesHierarchyID;
     private long PlanID;
     private long DeletedBy;
     private String MainChannel;
     private String ChannelName;
     private String PolicyYearExpressed;
     private String RangeToForNull;
     private String Plan;
     private String FromDateStr;
     private String ToDateStr;
     
     
	public String getFromDateStr() {
		return FromDateStr;
	}
	public String getToDateStr() {
		return ToDateStr;
	}
	public void setFromDateStr(String fromDateStr) {
		FromDateStr = fromDateStr;
	}
	public void setToDateStr(String toDateStr) {
		ToDateStr = toDateStr;
	}
	public String getMainChannel() {
		return MainChannel;
	}
	public String getChannelName() {
		return ChannelName;
	}
	public String getPolicyYearExpressed() {
		return PolicyYearExpressed;
	}
	public String getRangeToForNull() {
		return RangeToForNull;
	}
	public String getPlan() {
		return Plan;
	}
	public void setMainChannel(String mainChannel) {
		MainChannel = mainChannel;
	}
	public void setChannelName(String channelName) {
		ChannelName = channelName;
	}
	public void setPolicyYearExpressed(String policyYearExpressed) {
		PolicyYearExpressed = policyYearExpressed;
	}
	public void setRangeToForNull(String rangeToForNull) {
		RangeToForNull = rangeToForNull;
	}
	public void setPlan(String plan) {
		Plan = plan;
	}
	public long getDeletedBy() {
		return DeletedBy;
	}
	public void setDeletedBy(long deletedBy) {
		DeletedBy = deletedBy;
	}
	public long getPlanID() {
		return PlanID;
	}
	public void setPlanID(long planID) {
		PlanID = planID;
	}
	public long getPolicyYearTypeID() {
		return PolicyYearTypeID;
	}
	public long getRangeFrom() {
		return RangeFrom;
	}
	public long getRangeTo() {
		return RangeTo;
	}
	public double  getAmount() {
		return Amount;
	}
	public long getCreatedBy() {
		return CreatedBy;
	}
	public Timestamp getCreatedOn() {
		return CreatedOn;
	}
	public long getCommissionID() {
		return CommissionID;
	}
	public long getMainChannelID() {
		return MainChannelID;
	}
	public Timestamp getFromDate() {
		return FromDate;
	}
	public Timestamp getToDate() {
		return ToDate;
	}
	public short getIsActive() {
		return IsActive;
	}
	public long getSubChannelID() {
		return SubChannelID;
	}
	public long getPolicyTermID() {
		return PolicyTermID;
	}
	public long getSalesHierarchyID() {
		return SalesHierarchyID;
	}
	public void setPolicyYearTypeID(long policyYearTypeID) {
		PolicyYearTypeID = policyYearTypeID;
	}
	public void setRangeFrom(long rangeFrom) {
		RangeFrom = rangeFrom;
	}
	public void setRangeTo(long rangeTo) {
		RangeTo = rangeTo;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public void setCreatedBy(long createdBy) {
		CreatedBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		CreatedOn = createdOn;
	}
	public void setCommissionID(long commissionID) {
		CommissionID = commissionID;
	}
	public void setMainChannelID(long mainChannelID) {
		MainChannelID = mainChannelID;
	}
	public void setFromDate(Timestamp fromDate) {
		FromDate = fromDate;
	}
	public void setToDate(Timestamp toDate) {
		ToDate = toDate;
	}
	public void setIsActive(short isActive) {
		IsActive = isActive;
	}
	public void setSubChannelID(long subChannelID) {
		SubChannelID = subChannelID;
	}
	public void setPolicyTermID(long policyTermID) {
		PolicyTermID = policyTermID;
	}
	public void setSalesHierarchyID(long salesHierarchyID) {
		SalesHierarchyID = salesHierarchyID;
	}
}

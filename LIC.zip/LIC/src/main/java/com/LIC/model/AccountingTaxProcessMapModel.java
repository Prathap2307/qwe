package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AccountingTaxProcessMapModel {
@Id
private Number taxMappingID;
private Number taxStructureID;
private Number taxStructureDetailID;
private Number taxProcessID;
private Number createdBy;

private String taxStructureDetailsName;
private String taxStructureName;
private String description;
private String fromDate;
private String toDate;
private String exemptedInID;
private Number parentsTaxStructure;
private Number modes;
private String parentTax;
private String modeName;
private Number hierarchyID;
private Number taxValue;
private Number isReferred;


public AccountingTaxProcessMapModel() {}

public AccountingTaxProcessMapModel(Number taxStructureID, Number taxStructureDetailID, Number taxProcessID,
		Number taxMappingID, Number createdBy) {
	super();
	this.taxStructureID = taxStructureID;
	this.taxStructureDetailID = taxStructureDetailID;
	this.taxProcessID = taxProcessID;
	this.taxMappingID = taxMappingID;	
	this.createdBy = createdBy;
}


public AccountingTaxProcessMapModel(Number taxStructureID, String taxStructureName, String description, String fromDate,
		String toDate, String exemptedInID) {
	super();
	this.taxStructureID = taxStructureID;
	this.taxStructureName = taxStructureName;
	this.description = description;
	this.fromDate = fromDate;
	this.toDate = toDate;
	this.exemptedInID = exemptedInID;
}

public AccountingTaxProcessMapModel( Number taxStructureDetailID,Number taxStructureID, String taxStructureDetailsName,Number parentsTaxStructure,
		Number modes, String parentTax, String modeName,  Number hierarchyID,Number taxValue,Number isReferred,
		Number taxMappingID,Number taxProcessID
		  ) {
	super();
	this.taxStructureDetailID = taxStructureDetailID;
	this.taxStructureID = taxStructureID;
	this.taxStructureDetailsName = taxStructureDetailsName;
	this.parentsTaxStructure = parentsTaxStructure;
	this.modes=modes;
	this.parentTax = parentTax;
	this.modeName = modeName;
	this.hierarchyID = hierarchyID;
	this.taxValue = taxValue;
	this.isReferred = isReferred;
	this.taxMappingID = taxMappingID;
	this.taxProcessID = taxProcessID;

}

public Number getTaxMappingID() {
	return taxMappingID;
}

public void setTaxMappingID(Number taxMappingID) {
	this.taxMappingID = taxMappingID;
}

public Number getTaxStructureID() {
	return taxStructureID;
}

public void setTaxStructureID(Number taxStructureID) {
	this.taxStructureID = taxStructureID;
}

public Number getTaxStructureDetailID() {
	return taxStructureDetailID;
}

public void setTaxStructureDetailID(Number taxStructureDetailID) {
	this.taxStructureDetailID = taxStructureDetailID;
}

public Number getTaxProcessID() {
	return taxProcessID;
}

public void setTaxProcessID(Number taxProcessID) {
	this.taxProcessID = taxProcessID;
}

public Number getCreatedBy() {
	return createdBy;
}

public void setCreatedBy(Number createdBy) {
	this.createdBy = createdBy;
}

public String getTaxStructureDetailsName() {
	return taxStructureDetailsName;
}

public void setTaxStructureDetailsName(String taxStructureDetailsName) {
	this.taxStructureDetailsName = taxStructureDetailsName;
}

public String getTaxStructureName() {
	return taxStructureName;
}

public void setTaxStructureName(String taxStructureName) {
	this.taxStructureName = taxStructureName;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getFromDate() {
	return fromDate;
}

public void setFromDate(String fromDate) {
	this.fromDate = fromDate;
}

public String getToDate() {
	return toDate;
}

public void setToDate(String toDate) {
	this.toDate = toDate;
}

public String getExemptedInID() {
	return exemptedInID;
}

public void setExemptedInID(String exemptedInID) {
	this.exemptedInID = exemptedInID;
}

public Number getParentsTaxStructure() {
	return parentsTaxStructure;
}

public void setParentsTaxStructure(Number parentsTaxStructure) {
	this.parentsTaxStructure = parentsTaxStructure;
}

public Number getModes() {
	return modes;
}

public void setModes(Number modes) {
	this.modes = modes;
}

public String getParentTax() {
	return parentTax;
}

public void setParentTax(String parentTax) {
	this.parentTax = parentTax;
}

public String getModeName() {
	return modeName;
}

public void setModeName(String modeName) {
	this.modeName = modeName;
}

public Number getHierarchyID() {
	return hierarchyID;
}

public void setHierarchyID(Number hierarchyID) {
	this.hierarchyID = hierarchyID;
}

public Number getTaxValue() {
	return taxValue;
}

public void setTaxValue(Number taxValue) {
	this.taxValue = taxValue;
}

public Number getIsReferred() {
	return isReferred;
}

public void setIsReferred(Number isReferred) {
	this.isReferred = isReferred;
}



}

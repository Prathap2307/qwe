package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetMasterPolicyDetailsModel {

	@Id
	private Number groupid;
	private String masterpolicyno;
	private Number masterpolicyid;
	private String tpapolicynumber;
	private String agreementno;
	private Number paymentfrequencyid;
	private String insurermasteragreementno;
	private Number isdeclaration;
	private Number issfq;
	private String declaration;
	private Number gsttypeid;
	private Number isemployee;
	private String agreementenddate;
	private Number isadvancedeposit;
	
	public GetMasterPolicyDetailsModel() {}
	
	public GetMasterPolicyDetailsModel(Number groupid, String masterpolicyno, Number masterpolicyid,
			String tpapolicynumber, String agreementno, Number paymentfrequencyid, String insurermasteragreementno,
			Number isdeclaration, Number issfq, String declaration, Number gsttypeid, Number isemployee,
			String agreementenddate, Number isadvancedeposit) {
		super();
		this.groupid = groupid;
		this.masterpolicyno = masterpolicyno;
		this.masterpolicyid = masterpolicyid;
		this.tpapolicynumber = tpapolicynumber;
		this.agreementno = agreementno;
		this.paymentfrequencyid = paymentfrequencyid;
		this.insurermasteragreementno = insurermasteragreementno;
		this.isdeclaration = isdeclaration;
		this.issfq = issfq;
		this.declaration = declaration;
		this.gsttypeid = gsttypeid;
		this.isemployee = isemployee;
		this.agreementenddate = agreementenddate;
		this.isadvancedeposit = isadvancedeposit;
	}
	
	public Number getGroupid() {
		return groupid;
	}
	public void setGroupid(Number groupid) {
		this.groupid = groupid;
	}
	public String getMasterpolicyno() {
		return masterpolicyno;
	}
	public void setMasterpolicyno(String masterpolicyno) {
		this.masterpolicyno = masterpolicyno;
	}
	public Number getMasterpolicyid() {
		return masterpolicyid;
	}
	public void setMasterpolicyid(Number masterpolicyid) {
		this.masterpolicyid = masterpolicyid;
	}
	public String getTpapolicynumber() {
		return tpapolicynumber;
	}
	public void setTpapolicynumber(String tpapolicynumber) {
		this.tpapolicynumber = tpapolicynumber;
	}
	public String getAgreementno() {
		return agreementno;
	}
	public void setAgreementno(String agreementno) {
		this.agreementno = agreementno;
	}
	public Number getPaymentfrequencyid() {
		return paymentfrequencyid;
	}
	public void setPaymentfrequencyid(Number paymentfrequencyid) {
		this.paymentfrequencyid = paymentfrequencyid;
	}
	public String getInsurermasteragreementno() {
		return insurermasteragreementno;
	}
	public void setInsurermasteragreementno(String insurermasteragreementno) {
		this.insurermasteragreementno = insurermasteragreementno;
	}
	public Number getIsdeclaration() {
		return isdeclaration;
	}
	public void setIsdeclaration(Number isdeclaration) {
		this.isdeclaration = isdeclaration;
	}
	public Number getIssfq() {
		return issfq;
	}
	public void setIssfq(Number issfq) {
		this.issfq = issfq;
	}
	public String getDeclaration() {
		return declaration;
	}
	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}
	public Number getGsttypeid() {
		return gsttypeid;
	}
	public void setGsttypeid(Number gsttypeid) {
		this.gsttypeid = gsttypeid;
	}
	public Number getIsemployee() {
		return isemployee;
	}
	public void setIsemployee(Number isemployee) {
		this.isemployee = isemployee;
	}
	public String getAgreementenddate() {
		return agreementenddate;
	}
	public void setAgreementenddate(String agreementenddate) {
		this.agreementenddate = agreementenddate;
	}
	public Number getIsadvancedeposit() {
		return isadvancedeposit;
	}
	public void setIsadvancedeposit(Number isadvancedeposit) {
		this.isadvancedeposit = isadvancedeposit;
	}

	
}

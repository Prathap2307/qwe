

package com.LIC.model;

import java.io.Serializable;
public class ProductVerbageMap extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer verbageId;
	private Integer productID;
	private Integer endorsementID;
	private Integer verbageTypeID;
	private Integer lineOfBusinessID;
	private String signatureDescription;
	public Integer getVerbageId() {
		return verbageId;
	}
	public void setVerbageId(Integer verbageId) {
		this.verbageId = verbageId;
	}
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public Integer getEndorsementID() {
		return endorsementID;
	}
	public void setEndorsementID(Integer endorsementID) {
		this.endorsementID = endorsementID;
	}
	public Integer getVerbageTypeID() {
		return verbageTypeID;
	}
	public void setVerbageTypeID(Integer verbageTypeID) {
		this.verbageTypeID = verbageTypeID;
	}
	public Integer getLineOfBusinessID() {
		return lineOfBusinessID;
	}
	public void setLineOfBusinessID(Integer lineOfBusinessID) {
		this.lineOfBusinessID = lineOfBusinessID;
	}
	public String getSignatureDescription() {
		return signatureDescription;
	}
	public void setSignatureDescription(String signatureDescription) {
		this.signatureDescription = signatureDescription;
	}

	
	
}

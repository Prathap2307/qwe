package com.LIC.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;


@NamedStoredProcedureQuery(name = "createOrUpdateGLConfiguration", procedureName = "spInsertOrUpdateGLConfiguration", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vGLCONFIGURATIONID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPAYMENTMODE", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPRODUCTID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vPROCESSID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCREDITGLCODE", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDEBITGLCODE", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCREDITNARRATION", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDEBITNARRATION", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vRemark", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vISACTIVE", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCREATEDBY", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCREATEDON", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCOUNTRYID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vStateID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "VRESULT", type = Integer.class)} ,resultClasses = GlConfigurationModel.class)
		

@Entity
@Table(name="GLCONFIGURATION")
public class GlConfigurationModel {
	@Id
	private int glconfigurationId;
	private int typeOfGl;
	private int branchId;
	private int productId;
	private int paymentMode;
	private int bankId;
	private int processId;
	private String processName;
	private int creditGlCode;
	private String creditAccountName;
	private int debitGlCode;
	private String debitAccountName;
	private String creditNarration;
	private String debitNarration;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	private Number isActive;
	private int debitOrder;
	private int creditOrder;
	private int orGid;
	private int orgProductId;
	private int stateId;
	private int tempId;
	private int organisationSubProductId;
	private int schemeId;
	private int subProcessId;
	private int componentId;
	private int costCenterCodeId;
	private int norgProductId;
	private int norganisationSubProductId;
	private int nproductId;
	private int nschemeId;
	private int nprocessId;
	private int nsubProcessId;
	private int nComponentId;
	private int npaymentMode;
	private int ndebitGlCode;
	private int ncreditGlCode;
	private int ndebitOrder;
	private int ncreditOrder;
	private String  ndebitNarration;
	private String ncreditNarration;
	private int statusId;
	private int workFlowId;
	private int nIsActive;
	private int deleted;
	private int upDatecount;
	private String reMarks;
	private int nCostCenterCodeId;
	private int nTypeOfGl;
	private int countryId;
	private String reMark;
	public int getGlconfigurationId() {
		return glconfigurationId;
	}
	public void setGlconfigurationId(int glconfigurationId) {
		this.glconfigurationId = glconfigurationId;
	}
	public int getTypeOfGl() {
		return typeOfGl;
	}
	public void setTypeOfGl(int typeOfGl) {
		this.typeOfGl = typeOfGl;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(int paymentMode) {
		this.paymentMode = paymentMode;
	}
	public int getBankId() {
		return bankId;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public int getProcessId() {
		return processId;
	}
	public void setProcessId(int processId) {
		this.processId = processId;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public int getCreditGlCode() {
		return creditGlCode;
	}
	public void setCreditGlCode(int creditGlCode) {
		this.creditGlCode = creditGlCode;
	}
	public String getCreditAccountName() {
		return creditAccountName;
	}
	public void setCreditAccountName(String creditAccountName) {
		this.creditAccountName = creditAccountName;
	}
	public int getDebitGlCode() {
		return debitGlCode;
	}
	public void setDebitGlCode(int debitGlCode) {
		this.debitGlCode = debitGlCode;
	}
	public String getDebitAccountName() {
		return debitAccountName;
	}
	public void setDebitAccountName(String debitAccountName) {
		this.debitAccountName = debitAccountName;
	}
	public String getCreditNarration() {
		return creditNarration;
	}
	public void setCreditNarration(String creditNarration) {
		this.creditNarration = creditNarration;
	}
	public String getDebitNarration() {
		return debitNarration;
	}
	public void setDebitNarration(String debitNarration) {
		this.debitNarration = debitNarration;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public int getDebitOrder() {
		return debitOrder;
	}
	public void setDebitOrder(int debitOrder) {
		this.debitOrder = debitOrder;
	}
	public int getCreditOrder() {
		return creditOrder;
	}
	public void setCreditOrder(int creditOrder) {
		this.creditOrder = creditOrder;
	}
	public int getOrGid() {
		return orGid;
	}
	public void setOrGid(int orGid) {
		this.orGid = orGid;
	}
	public int getOrgProductId() {
		return orgProductId;
	}
	public void setOrgProductId(int orgProductId) {
		this.orgProductId = orgProductId;
	}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public int getTempId() {
		return tempId;
	}
	public void setTempId(int tempId) {
		this.tempId = tempId;
	}
	public int getOrganisationSubProductId() {
		return organisationSubProductId;
	}
	public void setOrganisationSubProductId(int organisationSubProductId) {
		this.organisationSubProductId = organisationSubProductId;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getSubProcessId() {
		return subProcessId;
	}
	public void setSubProcessId(int subProcessId) {
		this.subProcessId = subProcessId;
	}
	public int getComponentId() {
		return componentId;
	}
	public void setComponentId(int componentId) {
		this.componentId = componentId;
	}
	public int getCostCenterCodeId() {
		return costCenterCodeId;
	}
	public void setCostCenterCodeId(int costCenterCodeId) {
		this.costCenterCodeId = costCenterCodeId;
	}
	public int getNorgProductId() {
		return norgProductId;
	}
	public void setNorgProductId(int norgProductId) {
		this.norgProductId = norgProductId;
	}
	public int getNorganisationSubProductId() {
		return norganisationSubProductId;
	}
	public void setNorganisationSubProductId(int norganisationSubProductId) {
		this.norganisationSubProductId = norganisationSubProductId;
	}
	public int getNproductId() {
		return nproductId;
	}
	public void setNproductId(int nproductId) {
		this.nproductId = nproductId;
	}
	public int getNschemeId() {
		return nschemeId;
	}
	public void setNschemeId(int nschemeId) {
		this.nschemeId = nschemeId;
	}
	public int getNprocessId() {
		return nprocessId;
	}
	public void setNprocessId(int nprocessId) {
		this.nprocessId = nprocessId;
	}
	public int getNsubProcessId() {
		return nsubProcessId;
	}
	public void setNsubProcessId(int nsubProcessId) {
		this.nsubProcessId = nsubProcessId;
	}
	public int getnComponentId() {
		return nComponentId;
	}
	public void setnComponentId(int nComponentId) {
		this.nComponentId = nComponentId;
	}
	public int getNpaymentMode() {
		return npaymentMode;
	}
	public void setNpaymentMode(int npaymentMode) {
		this.npaymentMode = npaymentMode;
	}
	public int getNdebitGlCode() {
		return ndebitGlCode;
	}
	public void setNdebitGlCode(int ndebitGlCode) {
		this.ndebitGlCode = ndebitGlCode;
	}
	public int getNcreditGlCode() {
		return ncreditGlCode;
	}
	public void setNcreditGlCode(int ncreditGlCode) {
		this.ncreditGlCode = ncreditGlCode;
	}
	public int getNdebitOrder() {
		return ndebitOrder;
	}
	public void setNdebitOrder(int ndebitOrder) {
		this.ndebitOrder = ndebitOrder;
	}
	public int getNcreditOrder() {
		return ncreditOrder;
	}
	public void setNcreditOrder(int ncreditOrder) {
		this.ncreditOrder = ncreditOrder;
	}
	public String getNdebitNarration() {
		return ndebitNarration;
	}
	public void setNdebitNarration(String ndebitNarration) {
		this.ndebitNarration = ndebitNarration;
	}
	public String getNcreditNarration() {
		return ncreditNarration;
	}
	public void setNcreditNarration(String ncreditNarration) {
		this.ncreditNarration = ncreditNarration;
	}
	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	public int getWorkFlowId() {
		return workFlowId;
	}
	public void setWorkFlowId(int workFlowId) {
		this.workFlowId = workFlowId;
	}
	public int getnIsActive() {
		return nIsActive;
	}
	public void setnIsActive(int nIsActive) {
		this.nIsActive = nIsActive;
	}
	public int getDeleted() {
		return deleted;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}
	public int getUpDatecount() {
		return upDatecount;
	}
	public void setUpDatecount(int upDatecount) {
		this.upDatecount = upDatecount;
	}
	public String getReMarks() {
		return reMarks;
	}
	public void setReMarks(String reMarks) {
		this.reMarks = reMarks;
	}
	public int getnCostCenterCodeId() {
		return nCostCenterCodeId;
	}
	public void setnCostCenterCodeId(int nCostCenterCodeId) {
		this.nCostCenterCodeId = nCostCenterCodeId;
	}
	public int getnTypeOfGl() {
		return nTypeOfGl;
	}
	public void setnTypeOfGl(int nTypeOfGl) {
		this.nTypeOfGl = nTypeOfGl;
	}
	public int getCountryId() {
		return countryId;
	}
	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	public String getReMark() {
		return reMark;
	}
	public void setReMark(String reMark) {
		this.reMark = reMark;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    
}

package com.LIC.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MemberAdditionModel {
       
       @Id
private Number headerId;
private String filePath;
private String fileName;
private Number groupId;
private Number masterPolicyId;
private Number createdBy;
private Date createdOn;
private String type;
private Number authorisedSignatoryId;
private Number cntTotal;
private Number successRecords;
private Number failureRecords;





public Number getHeaderId() {
       return headerId;
}

public void setHeaderId(Number headerId) {
       this.headerId = headerId;
}

public String getFilePath() {
       return filePath;
}

public void setFilePath(String filePath) {
       this.filePath = filePath;
}

public String getFileName() {
       return fileName;
}

public void setFileName(String fileName) {
       this.fileName = fileName;
}




public Number getGroupId() {
       return groupId;
}

public void setGroupId(Number groupId) {
       this.groupId = groupId;
}

public Number getMasterPolicyId() {
       return masterPolicyId;
}

public void setMasterPolicyId(Number masterPolicyId) {
       this.masterPolicyId = masterPolicyId;
}

public Number getCreatedBy() {
       return createdBy;
}

public void setCreatedBy(Number createdBy) {
       this.createdBy = createdBy;
}

public Date getCreatedOn() {
       return createdOn;
}

public void setCreatedOn(Date createdOn) {
       this.createdOn = createdOn;
}

public String getType() {
       return type;
}

public void setType(String type) {
       this.type = type;
}

public Number getAuthorisedSignatoryId() {
       return authorisedSignatoryId;
}

public void setAuthorisedSignatoryId(Number authorisedSignatoryId) {
       this.authorisedSignatoryId = authorisedSignatoryId;
}

public Number getCntTotal() {
       return cntTotal;
}


public void setCntTotal(Number cntTotal) {
       this.cntTotal = cntTotal;
}

public Number getSuccessRecords() {
       return successRecords;
}

public void setSuccessRecords(Number successRecords) {
       this.successRecords = successRecords;
}

public Number getFailureRecords() {
       return failureRecords;
}

public void setFailureRecords(Number failureRecords) {
       this.failureRecords = failureRecords;
}

public MemberAdditionModel(Number headerId, String filePath, String fileName) {
       this.headerId = headerId;
       this.filePath = filePath;
       this.fileName = fileName;
}








public MemberAdditionModel(Number cntTotal, Number successRecords, Number failureRecords,Number headerId, String fileName ) {
       super();
       
       this.cntTotal = cntTotal;
       this.successRecords = successRecords;
       this.failureRecords = failureRecords;
       this.headerId = headerId;
       this.fileName = fileName;
}

public MemberAdditionModel() {
}



public static List<String> getColumnList() {
	List<String> list = new ArrayList<String>();
	list.add("Type");
	list.add("SchemeNo");
	list.add("EmployeeNo");
	list.add("UniqueID");
	list.add("Title");
	list.add("FirstName");
	list.add("MiddleName");
	list.add("LastName");
	list.add("DateOfBirth");
	list.add("DateOfJoining");
	list.add("SchemeJoiningDate");
	list.add("NBIntimationDate");
	list.add("Age");
	list.add("BasicSalary");
	list.add("Gender");
	list.add("EmailID");
	list.add("AddressType");
	list.add("Address1");
	list.add("Address2");
	list.add("Address3");
	list.add("PinCode");
	list.add("City");
	list.add("State");
	list.add("Country");
	list.add("PhoneNumber");
	list.add("MobileNumber");
	list.add("PanNo");
	list.add("BenefitOption");
	list.add("GPSSumAssured");
	list.add("GPSRiderAD");
	list.add("GPSRiderADD");
	list.add("GPSRiderTPD");
	list.add("GPSRiderAT");
	list.add("GPSRiderCI4");
	list.add("GPSRiderCIRC");
	list.add("GPSRiderCIP");		
	list.add("GPSRiderCIA");
	list.add("GPSRiderTIP");
	list.add("GPSRiderATIR");
	list.add("SIngleJointLife");
	list.add("BenefitTerm");
	list.add("TenureOfTheLoan");
	list.add("PremiumTerm");
	list.add("NomineeEffectiveDate");
	list.add("NomineeName1");
	list.add("NomineeRelationship1");
	list.add("NomineePercentage");
	list.add("NomineeName2");
	list.add("NomineeRelationship2");
	list.add("NomineePercentage2");
	list.add("NomineeName3");
	list.add("NomineeRelationship3");
	list.add("NomineePercentage3");
	list.add("NomineeName4");
	list.add("NomineeRelationship4");
	list.add("NomineePercentage4");
	list.add("BranchCodeOfBank");
	list.add("PremiumReceived");
	list.add("DateOfDisbursementOfLoan");
	list.add("UnderwritingDocumentType");
	list.add("HDFDate");
	list.add("TypeOfLoan");
	list.add("OccupationName");
	list.add("Location");
	list.add("IsWindowPeriodApplicable");
	list.add("Grade");
	list.add("TypeOfClaim");
	list.add("ClaimPayOutOption");
	list.add("OccupationRisk");
	list.add("PaymentFrequency");

	return list;

}


}

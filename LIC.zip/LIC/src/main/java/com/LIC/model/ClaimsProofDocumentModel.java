package com.LIC.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class ClaimsProofDocumentModel implements Serializable {
	private static final long serialVersionUID = 1L;

	private String claimID;
	
	private Number documentTypeID;
	private String documentNumber;
	private String vImageName;
	private Number isAdditionDocument;
	private Number isActive;
	private Number coverageID;
	private Number typeID;	
	private Number serialNo;
	private Number paymentModeID;
	private Date paymentDate;	
	private Number bankID;
	private Number bankBranchID;
	private String chequeNo;	
	private Date chequeDate;
	private Number cardTypeID;
	private String cardNo;	
	private Date cardExpiryDate;
	private Number cardExpiryMonth;
	private String cardExpiryYear;
	private BigDecimal amount;
	private String bankBranchName;
	private String bankName;
	private String description;
	private String iSFCCode;
	private Number createdBy;
	private Date createdOn;
	

	public Number getCoverageID() {
		return coverageID;
	}
	public void setCoverageID(Number coverageID) {
		this.coverageID = coverageID;
	}
	public Number getTypeID() {
		return typeID;
	}
	public void setTypeID(Number typeID) {
		this.typeID = typeID;
	}
	
	public String getClaimID() {
		return claimID;
	}
	public void setClaimID(String claimID) {
		this.claimID = claimID;
	}
	public Number getDocumentTypeID() {
		return documentTypeID;
	}
	public void setDocumentTypeID(Number documentTypeID) {
		this.documentTypeID = documentTypeID;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getvImageName() {
		return vImageName;
	}
	public void setvImageName(String vImageName) {
		this.vImageName = vImageName;
	}
	public Number getIsAdditionDocument() {
		return isAdditionDocument;
	}
	public void setIsAdditionDocument(Number isAdditionDocument) {
		this.isAdditionDocument = isAdditionDocument;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public Number getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(Number serialNo) {
		this.serialNo = serialNo;
	}
	public Number getPaymentModeID() {
		return paymentModeID;
	}
	public void setPaymentModeID(Number paymentModeID) {
		this.paymentModeID = paymentModeID;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public Number getBankID() {
		return bankID;
	}
	public void setBankID(Number bankID) {
		this.bankID = bankID;
	}
	public Number getBankBranchID() {
		return bankBranchID;
	}
	public void setBankBranchID(Number bankBranchID) {
		this.bankBranchID = bankBranchID;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}
	public Number getCardTypeID() {
		return cardTypeID;
	}
	public void setCardTypeID(Number cardTypeID) {
		this.cardTypeID = cardTypeID;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public Date getCardExpiryDate() {
		return cardExpiryDate;
	}
	public void setCardExpiryDate(Date cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	public Number getCardExpiryMonth() {
		return cardExpiryMonth;
	}
	public void setCardExpiryMonth(Number cardExpiryMonth) {
		this.cardExpiryMonth = cardExpiryMonth;
	}
	public String getCardExpiryYear() {
		return cardExpiryYear;
	}
	public void setCardExpiryYear(String cardExpiryYear) {
		this.cardExpiryYear = cardExpiryYear;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getBankBranchName() {
		return bankBranchName;
	}
	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getiSFCCode() {
		return iSFCCode;
	}
	public void setiSFCCode(String iSFCCode) {
		this.iSFCCode = iSFCCode;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
}

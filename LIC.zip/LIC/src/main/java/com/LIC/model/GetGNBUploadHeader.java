package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetGNBUploadHeader {

	@Id
	private Number groupId;
	private Number matserPolicyId;
	private Date fromDate;
	private Date ToDate;
	private String FileName;
	private Number masterPolicyAgreementId;
	private Number Id;
	private Number TotalRecords;
	private Number sucessRecords;
	private Number failurRecords;
	private Number createdBy;
	private Date uploadedDate;
	private Number isActive;
	private Number isPolicyissuence;
	private Number Policyissuence;
	public Number getGroupId() {
		return groupId;
	}
	public void setGroupId(Number groupId) {
		this.groupId = groupId;
	}
	public Number getMatserPolicyId() {
		return matserPolicyId;
	}
	public void setMatserPolicyId(Number matserPolicyId) {
		this.matserPolicyId = matserPolicyId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return ToDate;
	}
	public void setToDate(Date toDate) {
		ToDate = toDate;
	}
	public String getFileName() {
		return FileName;
	}
	public void setFileName(String fileName) {
		FileName = fileName;
	}
	public Number getMasterPolicyAgreementId() {
		return masterPolicyAgreementId;
	}
	public void setMasterPolicyAgreementId(Number masterPolicyAgreementId) {
		this.masterPolicyAgreementId = masterPolicyAgreementId;
	}
	public Number getId() {
		return Id;
	}
	public void setId(Number id) {
		Id = id;
	}
	public Number getTotalRecords() {
		return TotalRecords;
	}
	public void setTotalRecords(Number totalRecords) {
		TotalRecords = totalRecords;
	}
	public Number getSucessRecords() {
		return sucessRecords;
	}
	public void setSucessRecords(Number sucessRecords) {
		this.sucessRecords = sucessRecords;
	}
	public Number getFailurRecords() {
		return failurRecords;
	}
	public void setFailurRecords(Number failurRecords) {
		this.failurRecords = failurRecords;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public Date getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(Date uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public Number getIsPolicyissuence() {
		return isPolicyissuence;
	}
	public void setIsPolicyissuence(Number isPolicyissuence) {
		this.isPolicyissuence = isPolicyissuence;
	}
	public Number getPolicyissuence() {
		return Policyissuence;
	}
	public void setPolicyissuence(Number policyissuence) {
		Policyissuence = policyissuence;
	}
	
	
	public GetGNBUploadHeader(Number id,Number groupId, Number matserPolicyId, String fileName, Number totalRecords,
			Number sucessRecords, Number failurRecords, Number createdBy, Date uploadedDate ,
			Number Isactive,Number policyissuence,Number isPolicyissuence) {
		this.Id = id;
		this.groupId = groupId;
		this.matserPolicyId = matserPolicyId;
		this.FileName = fileName;
		this.TotalRecords = totalRecords;
		this.sucessRecords = sucessRecords;
		this.failurRecords = failurRecords;
		this.createdBy = createdBy;
		this.uploadedDate = uploadedDate;
		this.isActive=Isactive;
		this.Policyissuence = policyissuence;
		this.isPolicyissuence = isPolicyissuence;
	
	}
	public GetGNBUploadHeader() {
		super();
	}
}

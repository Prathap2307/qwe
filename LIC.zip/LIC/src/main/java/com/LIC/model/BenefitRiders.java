
package com.LIC.model;

import java.io.Serializable;


public class BenefitRiders extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer coverageId;
	private String coverageName;
	private String description; 
	private Integer lineOfBusiness;
	private String coverCode;
	private Integer coverageHouseHoldLimitPerYear;
	private Integer sectionId;
	private Integer type;
	private Double Amount;
	
	public Integer getCoverageId() {
		return coverageId;
	}
	public void setCoverageId(Integer coverageId) {
		this.coverageId = coverageId;
	}
	public String getCoverageName() {
		return coverageName;
	}
	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getLineOfBusiness() {
		return lineOfBusiness;
	}
	public void setLineOfBusiness(Integer lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	public String getCoverCode() {
		return coverCode;
	}
	public void setCoverCode(String coverCode) {
		this.coverCode = coverCode;
	}
	public Integer getCoverageHouseHoldLimitPerYear() {
		return coverageHouseHoldLimitPerYear;
	}
	public void setCoverageHouseHoldLimitPerYear(Integer coverageHouseHoldLimitPerYear) {
		this.coverageHouseHoldLimitPerYear = coverageHouseHoldLimitPerYear;
	}
	public Integer getSectionId() {
		return sectionId;
	}
	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double amount) {
		Amount = amount;
	}


	

	
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class MessageTemplateModal  implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private long 		messageTemplatesID;
	private long 		featureID;
	private String 		process;
	private String 		emailTemplates;
	private short 		smsIsActive;
	private String 		smsTemplates;
	private short 		emailIsActive;
	private String 		subject;
	private short 		isAttachement;
	private long 		createdBy;
	private Timestamp 	createdOn;
	private short 		isActive;
	private String 		templateDescription;
	private long 		emailSMSTypeID;
	private String 		whatsAppTemplates;
	private short	 	whatsAppIsActive;
	private long 		templateTypeId;
	//attachement
	private long 		reportID;
	private String 		reportName;
	//messageFields
	private long 		messageFieldsID;
	private String 		fieldName;
	private String 		code;
	private String 		featureName;
	private long 		modifiedBy;
	private Timestamp 	modifiedOn;
	private long 		deletedBy;
	private Timestamp 	deletedOn;

	private long 		mainMenuID;
	private String 		menuName;
	private String 		emailSMSTypeName;
    //private long 	outParam;
    
	public long getMessageTemplatesID() {
		return messageTemplatesID;
	}
	public long getMainMenuID() {
		return mainMenuID;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMainMenuID(long mainMenuID) {
		this.mainMenuID = mainMenuID;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public long getFeatureID() {
		return featureID;
	}
	public String getProcess() {
		return process;
	}
	public String getEmailTemplates() {
		return emailTemplates;
	}
	public short getSmsIsActive() {
		return smsIsActive;
	}
	public String getSmsTemplates() {
		return smsTemplates;
	}
	public short getEmailIsActive() {
		return emailIsActive;
	}
	public String getSubject() {
		return subject;
	}
	public short getIsAttachement() {
		return isAttachement;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public short getIsActive() {
		return isActive;
	}
	public String getTemplateDescription() {
		return templateDescription;
	}
	public long getEmailSMSTypeID() {
		return emailSMSTypeID;
	}
	public String getWhatsAppTemplates() {
		return whatsAppTemplates;
	}
	public short getWhatsAppIsActive() {
		return whatsAppIsActive;
	}
	public long getTemplateTypeId() {
		return templateTypeId;
	}
	public long getReportID() {
		return reportID;
	}
	public String getReportName() {
		return reportName;
	}
	public long getMessageFieldsID() {
		return messageFieldsID;
	}
	public String getFieldName() {
		return fieldName;
	}
	public String getCode() {
		return code;
	}
	public String getFeatureName() {
		return featureName;
	}
	public long getModifiedBy() {
		return modifiedBy;
	}
	public Timestamp getModifiedOn() {
		return modifiedOn;
	}
	public long getDeletedBy() {
		return deletedBy;
	}
	public Timestamp getDeletedOn() {
		return deletedOn;
	}
	public void setMessageTemplatesID(long messageTemplatesID) {
		this.messageTemplatesID = messageTemplatesID;
	}
	public void setFeatureID(long featureID) {
		this.featureID = featureID;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public void setEmailTemplates(String emailTemplates) {
		this.emailTemplates = emailTemplates;
	}
	public void setSmsIsActive(short smsIsActive) {
		this.smsIsActive = smsIsActive;
	}
	public void setSmsTemplates(String smsTemplates) {
		this.smsTemplates = smsTemplates;
	}
	public void setEmailIsActive(short emailIsActive) {
		this.emailIsActive = emailIsActive;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public void setIsAttachement(short isAttachement) {
		this.isAttachement = isAttachement;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	public void setTemplateDescription(String templateDescription) {
		this.templateDescription = templateDescription;
	}
	public void setEmailSMSTypeID(long emailSMSTypeID) {
		this.emailSMSTypeID = emailSMSTypeID;
	}
	public void setWhatsAppTemplates(String whatsAppTemplates) {
		this.whatsAppTemplates = whatsAppTemplates;
	}
	public void setWhatsAppIsActive(short whatsAppIsActive) {
		this.whatsAppIsActive = whatsAppIsActive;
	}
	public void setTemplateTypeId(long templateTypeId) {
		this.templateTypeId = templateTypeId;
	}
	public void setReportID(long reportID) {
		this.reportID = reportID;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public void setMessageFieldsID(long messageFieldsID) {
		this.messageFieldsID = messageFieldsID;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public void setFeatureName(String description) {
		this.featureName = description;
	}
	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public void setDeletedBy(long deletedBy) {
		this.deletedBy = deletedBy;
	}
	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}
	public String getEmailSMSTypeName() {
		return emailSMSTypeName;
	}
	public void setEmailSMSTypeName(String emailSMSTypeName) {
		this.emailSMSTypeName = emailSMSTypeName;
	}
}

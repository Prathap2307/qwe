package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="master_bank")
@Getter
@Setter

public class GetBankMasterModel {

    @Id
    private Number bankId;
    private String bankName;
    private String bankShortName;
    private Number createdBy;
    private Date createdOn;
    private Number modifiedBy;
    private Date modifiedOn;
    private Number deletedBy;
    private Date deletedOn;
    private Number isActive;
    
    
    
    
    public GetBankMasterModel(Number bankId, String bankName, String bankShortName, Number createdBy, Date createdOn,
			Number modifiedBy, Date modifiedOn, Number deletedBy, Date deletedOn, Number isActive) {
		super();
		this.bankId = bankId;
		this.bankName = bankName;
		this.bankShortName = bankShortName;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
		this.deletedBy = deletedBy;
		this.deletedOn = deletedOn;
		this.isActive = isActive;
	}
    
    
    
	public GetBankMasterModel(Number bankId, String bankName, String bankShortName) {
		super();
		this.bankId = bankId;
		this.bankName = bankName;
		this.bankShortName = bankShortName;
	}
    public GetBankMasterModel()
    {
    	
    }



	public Number getBankId() {
		return bankId;
	}



	public void setBankId(Number bankId) {
		this.bankId = bankId;
	}



	public String getBankName() {
		return bankName;
	}



	public void setBankName(String bankName) {
		this.bankName = bankName;
	}



	public String getBankShortName() {
		return bankShortName;
	}



	public void setBankShortName(String bankShortName) {
		this.bankShortName = bankShortName;
	}



	public Number getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}



	public Date getCreatedOn() {
		return createdOn;
	}



	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}



	public Number getModifiedBy() {
		return modifiedBy;
	}



	public void setModifiedBy(Number modifiedBy) {
		this.modifiedBy = modifiedBy;
	}



	public Date getModifiedOn() {
		return modifiedOn;
	}



	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}



	public Number getDeletedBy() {
		return deletedBy;
	}



	public void setDeletedBy(Number deletedBy) {
		this.deletedBy = deletedBy;
	}



	public Date getDeletedOn() {
		return deletedOn;
	}



	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}



	public Number getIsActive() {
		return isActive;
	}



	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	
}


    

	


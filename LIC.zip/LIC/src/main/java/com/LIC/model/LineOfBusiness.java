
package com.LIC.model;

import java.io.Serializable;


public class LineOfBusiness extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer 	lineOfBusinessId;
	private String 		description;
	
	public Integer getLineOfBusinessId() {
		return lineOfBusinessId;
	}
	public void setLineOfBusinessId(Integer lineOfBusinessId) {
		this.lineOfBusinessId = lineOfBusinessId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}

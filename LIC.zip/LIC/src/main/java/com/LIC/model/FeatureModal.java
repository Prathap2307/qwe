package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class FeatureModal implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private long 	     featureID;
	private String 		description;
	private long 	     moduleID;
	private long 	     healthLobID;
	private long 	     paLobID;
	private long 	     motorLobID;
	private long 	     indemnityLobID;
	private long 	     opsLobID;
	private long 	     hhiLobID;
	private long 	     wealthLobID;
	private long 	     lifeLobID;
	private long 	     createdBy;
	private Timestamp 	 createdOn;
	private String 		modifiedBy;
	private String 		modifiedOn;
	private String 		deletedBy;
	private String 		deletedOn;
	private long 	     isActive;
	private String 		processType;
	
	public long getFeatureID() {
		return featureID;
	}
	public String getDescription() {
		return description;
	}
	public long getModuleID() {
		return moduleID;
	}
	public long getHealthLobID() {
		return healthLobID;
	}
	public long getPaLobID() {
		return paLobID;
	}
	public long getMotorLobID() {
		return motorLobID;
	}
	public long getIndemnityLobID() {
		return indemnityLobID;
	}
	public long getOpsLobID() {
		return opsLobID;
	}
	public long getHhiLobID() {
		return hhiLobID;
	}
	public long getWealthLobID() {
		return wealthLobID;
	}
	public long getLifeLobID() {
		return lifeLobID;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public String getDeletedBy() {
		return deletedBy;
	}
	public String getDeletedOn() {
		return deletedOn;
	}
	public long getIsActive() {
		return isActive;
	}
	public String getProcessType() {
		return processType;
	}
	public void setFeatureID(long featureID) {
		this.featureID = featureID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setModuleID(long moduleID) {
		this.moduleID = moduleID;
	}
	public void setHealthLobID(long healthLobID) {
		this.healthLobID = healthLobID;
	}
	public void setPaLobID(long paLobID) {
		this.paLobID = paLobID;
	}
	public void setMotorLobID(long motorLobID) {
		this.motorLobID = motorLobID;
	}
	public void setIndemnityLobID(long indemnityLobID) {
		this.indemnityLobID = indemnityLobID;
	}
	public void setOpsLobID(long opsLobID) {
		this.opsLobID = opsLobID;
	}
	public void setHhiLobID(long hhiLobID) {
		this.hhiLobID = hhiLobID;
	}
	public void setWealthLobID(long wealthLobID) {
		this.wealthLobID = wealthLobID;
	}
	public void setLifeLobID(long lifeLobID) {
		this.lifeLobID = lifeLobID;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}
	public void setDeletedOn(String deletedOn) {
		this.deletedOn = deletedOn;
	}
	public void setIsActive(long isActive) {
		this.isActive = isActive;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
}

package com.LIC.model;

import java.io.Serializable;

public class CoverageNatureOfServiceNewModal implements Serializable {
	private static final long serialVersionUID = 1L;

	private long 			coverageNatureOfServiceID;
	private long 			providerTypeID;
	private CoverageModal 	coverage;
	private long 			natureBenefitID;
	private String 			description;
	private String 			providerType;
	private String 			limitPerIncidenceType;
	private double 			amount;
	private double 			rate;
	private long 			isRuleApplied; 
	private long 			ruleID;
	
	public long getCoverageNatureOfServiceID() {
		return coverageNatureOfServiceID;
	}
	public long getProviderTypeID() {
		return providerTypeID;
	}
	public CoverageModal getCoverage() {
		return coverage;
	}
	public long getNatureBenefitID() {
		return natureBenefitID;
	}
	public String getDescription() {
		return description;
	}
	public String getProviderType() {
		return providerType;
	}
	public String getLimitPerIncidenceType() {
		return limitPerIncidenceType;
	}
	public double getAmount() {
		return amount;
	}
	public double getRate() {
		return rate;
	}
	public long getIsRuleApplied() {
		return isRuleApplied;
	}
	public long getRuleID() {
		return ruleID;
	}
	public void setCoverageNatureOfServiceID(long coverageNatureOfServiceID) {
		this.coverageNatureOfServiceID = coverageNatureOfServiceID;
	}
	public void setProviderTypeID(long providerTypeID) {
		this.providerTypeID = providerTypeID;
	}
	public void setCoverage(CoverageModal coverage) {
		this.coverage = coverage;
	}
	public void setNatureBenefitID(long natureBenefitID) {
		this.natureBenefitID = natureBenefitID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}
	public void setLimitPerIncidenceType(String limitPerIncidenceType) {
		this.limitPerIncidenceType = limitPerIncidenceType;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public void setIsRuleApplied(long isRuleApplied) {
		this.isRuleApplied = isRuleApplied;
	}
	public void setRuleID(long ruleID) {
		this.ruleID = ruleID;
	}
	
}

package com.LIC.model;

public class ClaimsIntimationDropDownModel {

	public Number getPaymentModeID() {
		return paymentModeID;
	}

	public void setPaymentModeID(Number paymentModeID) {
		this.paymentModeID = paymentModeID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	private Number paymentModeID;
	private String description;

	public ClaimsIntimationDropDownModel(Number paymentModeID, String description) {
		super();
		this.paymentModeID = paymentModeID;
		this.description = description;
	}

}

package com.LIC.model;

import java.io.Serializable;
 
public class Variant  extends RecordModifier implements  Serializable {
	private static final long serialVersionUID = 1L;
	
	 private Integer productID  ;    	
	 private Integer organisationID ;    
	 private Integer insurerID ;      
	 private String code ;
	 private String description;    
	 private Integer productTypeID ;    
	 private Integer lineOfBusinessID;      
	 private Integer planTypeId  ;      
	 private String productVersion;    
	 private String startDate ;    
	 private String endDate;    
	 private Integer maxAge;        
	 private Integer minAge ;     
	 private Integer minimumAgeTypeID;    
	 private Integer maximumAgeTypeID ;    
	 private Integer maxTerm  ;   
	 private Integer minTerm  ;         
	 private Integer maxSumAssured ;        
	 private Integer minSumAssured ;      
	 private Integer interestRate ;      
	 private Integer isParticipate ;      
	 private Integer familyDiscount;      
	 private Integer lapseDays  ;             
	 private String newBusinessGLCode;    
	 private String premiumCollectionGLCode;      
	 private Integer planCategoryID;   
	 private Integer insuredProductTypeID;  
	 private Integer noOfBackdatedForNB;  
	 private Integer noOfBackdatedForEndorsemant;  
	 private Integer isUnderWritingApplicable;  
	 private Integer isFloaterApplicable;  
	 private Integer isEmployeeApplicable;  
	 private Integer planID;  
	 private Integer lifeCategoryID;  
	 private Integer freelookup;  
	 private Integer waitingPeriodforClaim;  
	 private Integer isEligibleforLoan;  
	 private Integer waitingPeriodforLoan ;  
	 private Integer isFreemium;  
	 private Integer typeOfCoverID;  
	 private Integer vehicleCategory;  
	 private String planShortName ;  
	 private String effectiveDate;
	 private String uANNo;  
	 private Integer autoIssuePolicyUpToFCLLimit;
	 private String remarks;
	 private String exclusion;
	 private String verbiage;
	 private String insurerStr;
	 
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public Integer getOrganisationID() {
		return organisationID;
	}
	public void setOrganisationID(Integer organisationID) {
		this.organisationID = organisationID;
	}
	public Integer getInsurerID() {
		return insurerID;
	}
	public void setInsurerID(Integer insurerID) {
		this.insurerID = insurerID;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getProductTypeID() {
		return productTypeID;
	}
	public void setProductTypeID(Integer productTypeID) {
		this.productTypeID = productTypeID;
	}
	public Integer getLineOfBusinessID() {
		return lineOfBusinessID;
	}
	public void setLineOfBusinessID(Integer lineOfBusinessID) {
		this.lineOfBusinessID = lineOfBusinessID;
	}
	public Integer getPlanTypeId() {
		return planTypeId;
	}
	public void setPlanTypeId(Integer planTypeId) {
		this.planTypeId = planTypeId;
	}
	public String getProductVersion() {
		return productVersion;
	}
	public void setProductVersion(String productVersion) {
		this.productVersion = productVersion;
	}
	
	public Integer getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(Integer maxAge) {
		this.maxAge = maxAge;
	}
	public Integer getMinAge() {
		return minAge;
	}
	public void setMinAge(Integer minAge) {
		this.minAge = minAge;
	}
	public Integer getMinimumAgeTypeID() {
		return minimumAgeTypeID;
	}
	public void setMinimumAgeTypeID(Integer minimumAgeTypeID) {
		this.minimumAgeTypeID = minimumAgeTypeID;
	}
	public Integer getMaximumAgeTypeID() {
		return maximumAgeTypeID;
	}
	public void setMaximumAgeTypeID(Integer maximumAgeTypeID) {
		this.maximumAgeTypeID = maximumAgeTypeID;
	}
	public Integer getMaxTerm() {
		return maxTerm;
	}
	public void setMaxTerm(Integer maxTerm) {
		this.maxTerm = maxTerm;
	}
	public Integer getMinTerm() {
		return minTerm;
	}
	public void setMinTerm(Integer minTerm) {
		this.minTerm = minTerm;
	}
	
	public Integer getMaxSumAssured() {
		return maxSumAssured;
	}
	public void setMaxSumAssured(Integer maxSumAssured) {
		this.maxSumAssured = maxSumAssured;
	}
	public Integer getMinSumAssured() {
		return minSumAssured;
	}
	public void setMinSumAssured(Integer minSumAssured) {
		this.minSumAssured = minSumAssured;
	}
	public Integer getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(Integer interestRate) {
		this.interestRate = interestRate;
	}
	public Integer getIsParticipate() {
		return isParticipate;
	}
	public void setIsParticipate(Integer isParticipate) {
		this.isParticipate = isParticipate;
	}
	public Integer getFamilyDiscount() {
		return familyDiscount;
	}
	public void setFamilyDiscount(Integer familyDiscount) {
		this.familyDiscount = familyDiscount;
	}
	public Integer getLapseDays() {
		return lapseDays;
	}
	public void setLapseDays(Integer lapseDays) {
		this.lapseDays = lapseDays;
	}
	public String getNewBusinessGLCode() {
		return newBusinessGLCode;
	}
	public void setNewBusinessGLCode(String newBusinessGLCode) {
		this.newBusinessGLCode = newBusinessGLCode;
	}
	public String getPremiumCollectionGLCode() {
		return premiumCollectionGLCode;
	}
	public void setPremiumCollectionGLCode(String premiumCollectionGLCode) {
		this.premiumCollectionGLCode = premiumCollectionGLCode;
	}
	public Integer getPlanCategoryID() {
		return planCategoryID;
	}
	public void setPlanCategoryID(Integer planCategoryID) {
		this.planCategoryID = planCategoryID;
	}
	public Integer getInsuredProductTypeID() {
		return insuredProductTypeID;
	}
	public void setInsuredProductTypeID(Integer insuredProductTypeID) {
		this.insuredProductTypeID = insuredProductTypeID;
	}
	public Integer getNoOfBackdatedForNB() {
		return noOfBackdatedForNB;
	}
	public void setNoOfBackdatedForNB(Integer noOfBackdatedForNB) {
		this.noOfBackdatedForNB = noOfBackdatedForNB;
	}
	public Integer getNoOfBackdatedForEndorsemant() {
		return noOfBackdatedForEndorsemant;
	}
	public void setNoOfBackdatedForEndorsemant(Integer noOfBackdatedForEndorsemant) {
		this.noOfBackdatedForEndorsemant = noOfBackdatedForEndorsemant;
	}
	public Integer getIsUnderWritingApplicable() {
		return isUnderWritingApplicable;
	}
	public void setIsUnderWritingApplicable(Integer isUnderWritingApplicable) {
		this.isUnderWritingApplicable = isUnderWritingApplicable;
	}
	public Integer getIsFloaterApplicable() {
		return isFloaterApplicable;
	}
	public void setIsFloaterApplicable(Integer isFloaterApplicable) {
		this.isFloaterApplicable = isFloaterApplicable;
	}
	public Integer getIsEmployeeApplicable() {
		return isEmployeeApplicable;
	}
	public void setIsEmployeeApplicable(Integer isEmployeeApplicable) {
		this.isEmployeeApplicable = isEmployeeApplicable;
	}
	public Integer getPlanID() {
		return planID;
	}
	public void setPlanID(Integer planID) {
		this.planID = planID;
	}
	public Integer getLifeCategoryID() {
		return lifeCategoryID;
	}
	public void setLifeCategoryID(Integer lifeCategoryID) {
		this.lifeCategoryID = lifeCategoryID;
	}
	public Integer getFreelookup() {
		return freelookup;
	}
	public void setFreelookup(Integer freelookup) {
		this.freelookup = freelookup;
	}
	public Integer getWaitingPeriodforClaim() {
		return waitingPeriodforClaim;
	}
	public void setWaitingPeriodforClaim(Integer waitingPeriodforClaim) {
		this.waitingPeriodforClaim = waitingPeriodforClaim;
	}
	public Integer getIsEligibleforLoan() {
		return isEligibleforLoan;
	}
	public void setIsEligibleforLoan(Integer isEligibleforLoan) {
		this.isEligibleforLoan = isEligibleforLoan;
	}
	public Integer getWaitingPeriodforLoan() {
		if(null == isEligibleforLoan || !isEligibleforLoan.equals(1)) {
			waitingPeriodforLoan = 0;
		}
		return waitingPeriodforLoan;
	}
	public void setWaitingPeriodforLoan(Integer waitingPeriodforLoan) {
		this.waitingPeriodforLoan = waitingPeriodforLoan;
	}
	public Integer getIsFreemium() {
		return isFreemium;
	}
	public void setIsFreemium(Integer isFreemium) {
		this.isFreemium = isFreemium;
	}
	public Integer getTypeOfCoverID() {
		return typeOfCoverID;
	}
	public void setTypeOfCoverID(Integer typeOfCoverID) {
		this.typeOfCoverID = typeOfCoverID;
	}
	public Integer getVehicleCategory() {
		return vehicleCategory;
	}
	public void setVehicleCategory(Integer vehicleCategory) {
		this.vehicleCategory = vehicleCategory;
	}
	public String getPlanShortName() {
		return planShortName;
	}
	public void setPlanShortName(String planShortName) {
		this.planShortName = planShortName;
	}
	public String getuANNo() {
		return uANNo;
	}
	public void setuANNo(String uANNo) {
		this.uANNo = uANNo;
	}
	public Integer getAutoIssuePolicyUpToFCLLimit() {
		if(null == isUnderWritingApplicable || !isUnderWritingApplicable.equals(1)) {
			autoIssuePolicyUpToFCLLimit = 0;
		}
		return autoIssuePolicyUpToFCLLimit;
	}
	public void setAutoIssuePolicyUpToFCLLimit(Integer autoIssuePolicyUpToFCLLimit) {
		this.autoIssuePolicyUpToFCLLimit = autoIssuePolicyUpToFCLLimit;
	}
	
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	 
	public String getExclusion() {
		return exclusion;
	}
	public void setExclusion(String exclusion) {
		this.exclusion = exclusion;
	}
	 
	public String getVerbiage() {
		return verbiage;
	}
	public void setVerbiage(String verbiage) {
		this.verbiage = verbiage;
	}
	public String getInsurerStr() {
		return insurerStr;
	}
	public void setInsurerStr(String insurerStr) {
		this.insurerStr = insurerStr;
	}
	@Override
	public String toString() {
		return "Variant [productID=" + productID + ", organisationID=" + organisationID + ", insurerID=" + insurerID
				+ ", code=" + code + ", description=" + description + ", productTypeID=" + productTypeID
				+ ", lineOfBusinessID=" + lineOfBusinessID + ", planTypeId=" + planTypeId + ", productVersion="
				+ productVersion + ", startDate=" + startDate + ", endDate=" + endDate + ", maxAge=" + maxAge
				+ ", minAge=" + minAge + ", minimumAgeTypeID=" + minimumAgeTypeID + ", maximumAgeTypeID="
				+ maximumAgeTypeID + ", maxTerm=" + maxTerm + ", minTerm=" + minTerm + ", maxSumAssured="
				+ maxSumAssured + ", minSumAssured=" + minSumAssured + ", interestRate=" + interestRate
				+ ", isParticipate=" + isParticipate + ", familyDiscount=" + familyDiscount + ", lapseDays=" + lapseDays
				+ ", newBusinessGLCode=" + newBusinessGLCode + ", premiumCollectionGLCode=" + premiumCollectionGLCode
				+ ", planCategoryID=" + planCategoryID + ", insuredProductTypeID=" + insuredProductTypeID
				+ ", noOfBackdatedForNB=" + noOfBackdatedForNB + ", noOfBackdatedForEndorsemant="
				+ noOfBackdatedForEndorsemant + ", isUnderWritingApplicable=" + isUnderWritingApplicable
				+ ", isFloaterApplicable=" + isFloaterApplicable + ", isEmployeeApplicable=" + isEmployeeApplicable
				+ ", planID=" + planID + ", lifeCategoryID=" + lifeCategoryID + ", freelookup=" + freelookup
				+ ", waitingPeriodforClaim=" + waitingPeriodforClaim + ", isEligibleforLoan=" + isEligibleforLoan
				+ ", waitingPeriodforLoan=" + waitingPeriodforLoan + ", isFreemium=" + isFreemium + ", typeOfCoverID="
				+ typeOfCoverID + ", vehicleCategory=" + vehicleCategory + ", planShortName=" + planShortName
				+ ", effectiveDate=" + effectiveDate + ", uANNo=" + uANNo + ", autoIssuePolicyUpToFCLLimit="
				+ autoIssuePolicyUpToFCLLimit + ", remarks=" + remarks + ", exclusion=" + exclusion + ", verbiage="
				+ verbiage + ", insurerStr=" + insurerStr + "]";
	}
	
}

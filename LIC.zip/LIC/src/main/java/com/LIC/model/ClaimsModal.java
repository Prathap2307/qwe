package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class ClaimsModal implements Serializable {

	private static final long 	serialVersionUID 	= 1L;
	public static final String 	CLAIMS_MODAL 		= "ClaimsModal";
	 
	    private long 		claimID;
	    private long 		businessID;
	    private long		insuredID;
	    private long		cliamNumber;
		private long 		cliamID;
		private long 		registration;
		private Timestamp 	dateOfLoss;
		private Timestamp 	dataOfEven;
		private Timestamp 	dateOfInitmation;
	    private Timestamp 	dateOfRegistration;
		private long 		policyNumber;
		private double		reservedAmount;
		private long 		applicationID;
		private long  		productCode;;
		private long		partyID;
		private long 		productID;
		private String 		insuredName;
		private long 		uniqueMemberID;
		private long 		typeid;
		private long 		groupTypeID;
		private String 		status;
		private long 		statusID;
		private String 		claimReportedBy;
		private long 		relationShipID;
		private long 		causeOfDeathID;
		private long 		salutationID;
		private String 		firstName;
		private String 		coverageClaimedType;
		private long 		coverageIDs;
		private long 		isExistingInjuryDisablity;
		private String 		beneficiaryName;
		
		private List<LineOfBusinessModel> lineOfBusinessModelList;
		
		public List<LineOfBusinessModel> getLineOfBusinessModelList() {
			return lineOfBusinessModelList;
		}
		public void setLineOfBusinessModelList(List<LineOfBusinessModel> lineOfBusinessModelList) {
			this.lineOfBusinessModelList = lineOfBusinessModelList;
		}

		public long getClaimID() {
			return claimID;
		}
		public long getBusinessID() {
			return businessID;
		}
		public long getInsuredID() {
			return insuredID;
		}
		public long getCliamNumber() {
			return cliamNumber;
		}
		public long getCliamID() {
			return cliamID;
		}
		public long getRegistration() {
			return registration;
		}
		public Timestamp getDateOfLoss() {
			return dateOfLoss;
		}
		public Timestamp getDataOfEven() {
			return dataOfEven;
		}
		public Timestamp getDateOfInitmation() {
			return dateOfInitmation;
		}
		public Timestamp getDateOfRegistration() {
			return dateOfRegistration;
		}
		public long getPolicyNumber() {
			return policyNumber;
		}
		public double getReservedAmount() {
			return reservedAmount;
		}
		public long getApplicationID() {
			return applicationID;
		}
		public long getProductCode() {
			return productCode;
		}
		public long getPartyID() {
			return partyID;
		}
		public long getProductID() {
			return productID;
		}
		public String getInsuredName() {
			return insuredName;
		}
		public long getUniqueMemberID() {
			return uniqueMemberID;
		}
		public long getTypeid() {
			return typeid;
		}
		public long getGroupTypeID() {
			return groupTypeID;
		}
		public String getStatus() {
			return status;
		}
		public long getStatusID() {
			return statusID;
		}
		public String getClaimReportedBy() {
			return claimReportedBy;
		}
		public long getRelationShipID() {
			return relationShipID;
		}
		public long getCauseOfDeathID() {
			return causeOfDeathID;
		}
		public long getSalutationID() {
			return salutationID;
		}
		public String getFirstName() {
			return firstName;
		}
		public String getCoverageClaimedType() {
			return coverageClaimedType;
		}
		public long getCoverageIDs() {
			return coverageIDs;
		}
		public long getIsExistingInjuryDisablity() {
			return isExistingInjuryDisablity;
		}
		public String getBeneficiaryName() {
			return beneficiaryName;
		}
	
		public void setClaimID(long id) {
			this.claimID = id;
		}
		public void setBusinessID(long businessID) {
			this.businessID = businessID;
		}
		public void setInsuredID(long insuredID) {
			this.insuredID = insuredID;
		}
		public void setCliamNumber(long cliamNumber) {
			this.cliamNumber = cliamNumber;
		}
		public void setCliamID(long cliamID) {
			this.cliamID = cliamID;
		}
		public void setRegistration(long registration) {
			this.registration = registration;
		}
		public void setDateOfLoss(Timestamp dateOfLoss) {
			this.dateOfLoss = dateOfLoss;
		}
		public void setDataOfEven(Timestamp dataOfEven) {
			this.dataOfEven = dataOfEven;
		}
		public void setDateOfInitmation(Timestamp dateOfInitmation) {
			this.dateOfInitmation = dateOfInitmation;
		}
		public void setDateOfRegistration(Timestamp dateOfRegistration) {
			this.dateOfRegistration = dateOfRegistration;
		}
		public void setPolicyNumber(long policyNumber) {
			this.policyNumber = policyNumber;
		}
		public void setReservedAmount(double reservedAmount) {
			this.reservedAmount = reservedAmount;
		}
		public void setApplicationID(long applicationID) {
			this.applicationID = applicationID;
		}
		public void setProductCode(long productCode) {
			this.productCode = productCode;
		}
		public void setPartyID(long partyID) {
			this.partyID = partyID;
		}
		public void setProductID(long productID) {
			this.productID = productID;
		}
		public void setInsuredName(String insuredName) {
			this.insuredName = insuredName;
		}
		public void setUniqueMemberID(long uniqueMemberID) {
			this.uniqueMemberID = uniqueMemberID;
		}
		public void setTypeid(long typeid) {
			this.typeid = typeid;
		}
		public void setGroupTypeID(long groupTypeID) {
			this.groupTypeID = groupTypeID;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public void setStatusID(long statusID) {
			this.statusID = statusID;
		}
		public void setClaimReportedBy(String claimReportedBy) {
			this.claimReportedBy = claimReportedBy;
		}
		public void setRelationShipID(long relationShipID) {
			this.relationShipID = relationShipID;
		}
		public void setCauseOfDeathID(long causeOfDeathID) {
			this.causeOfDeathID = causeOfDeathID;
		}
		public void setSalutationID(long salutationID) {
			this.salutationID = salutationID;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public void setCoverageClaimedType(String coverageClaimedType) {
			this.coverageClaimedType = coverageClaimedType;
		}
		public void setCoverageIDs(long coverageIDs) {
			this.coverageIDs = coverageIDs;
		}
		public void setIsExistingInjuryDisablity(long isExistingInjuryDisablity) {
			this.isExistingInjuryDisablity = isExistingInjuryDisablity;
		}
		public void setBeneficiaryName(String beneficiaryName) {
			this.beneficiaryName = beneficiaryName;
		}
}

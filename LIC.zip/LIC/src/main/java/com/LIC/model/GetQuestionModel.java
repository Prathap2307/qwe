package com.LIC.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetQuestionModel {
	@Id
	private Number questionId;
	private String description;
	private String shortDescription;
	private Number orderId;
	private Number weightAge;
	private Number lob;
	
	private Number createdBy;
	private String createdOn;
	
	









	public Number getCreatedBy() {
		return createdBy;
	}









	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}









	public String getCreatedOn() {
		return createdOn;
	}









	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}









	public GetQuestionModel(Number questionId, Number lob,String description, String shortDescription, Number orderId,
			Number weightAge ) {
		super();
		this.questionId = questionId;
		this.lob = lob;
		this.description = description;
		this.shortDescription = shortDescription;
		this.orderId = orderId;
		this.weightAge = weightAge;
	
	}

	
	
	
	
	
	
	
	
	
	









	public GetQuestionModel(Number questionId, String description, String shortDescription, Number orderId,
			Number weightAge, Number lob) {
		super();
		this.questionId = questionId;
		this.description = description;
		this.shortDescription = shortDescription;
		this.orderId = orderId;
		this.weightAge = weightAge;
		this.lob = lob;
	}
	public GetQuestionModel(Number questionId, Number lob, String description, String shortDescription, Number orderId,
			Number weightAge, Number createdBy, String createdOn) {
		super();
		this.questionId = questionId;
		this.lob = lob;
		this.description = description;
		this.shortDescription = shortDescription;
		this.orderId = orderId;
		this.weightAge = weightAge;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
	}
	public GetQuestionModel() {
		super();
	}

	public Number getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Number questionId) {
		this.questionId = questionId;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public Number getOrderId() {
		return orderId;
	}

	public void setOrderId(Number orderId) {
		this.orderId = orderId;
	}
	public Number getWeightAge() {
		return weightAge;
	}
	public void setWeightAge(Number weightAge) {
		this.weightAge = weightAge;
	}

	public Number getLob() {
		return lob;
	}

	public void setLob(Number lob) {
		this.lob = lob;
	}	

}

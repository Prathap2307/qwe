package com.LIC.model;

import java.io.Serializable;

public class GenderModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private long	 genderID;
	private String	 description;
	private String   shortDesciption;
	private long 	 isActive;
	
	
	public long getGenderID() {
		return genderID;
	}
	public String getDescription() {
		return description;
	}
	public String getShortDesciption() {
		return shortDesciption;
	}
	public long getIsActive() {
		return isActive;
	}
	public void setGenderID(long genderID) {
		this.genderID = genderID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setShortDesciption(String shortDesciption) {
		this.shortDesciption = shortDesciption;
	}
	public void setIsActive(long isActive) {
		this.isActive = isActive;
	}
	

}

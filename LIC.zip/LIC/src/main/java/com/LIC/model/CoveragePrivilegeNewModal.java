package com.LIC.model;


import java.io.Serializable;

public class CoveragePrivilegeNewModal implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long 			coveragePrivilegeID; 
	private CoverageModal 	coverageModal; 
	private String 			description;
	
	
	public long getCoveragePrivilegeID() {
		return coveragePrivilegeID;
	}
	public CoverageModal getCoverageModal() {
		return coverageModal;
	}
	public String getDescription() {
		return description;
	}
	public void setCoveragePrivilegeID(long coveragePrivilegeID) {
		this.coveragePrivilegeID = coveragePrivilegeID;
	}
	public void setCoverageModal(CoverageModal coverageModal) {
		this.coverageModal = coverageModal;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}

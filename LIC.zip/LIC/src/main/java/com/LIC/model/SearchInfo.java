package com.LIC.model;

public class SearchInfo {

	String description;
	int deptId;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	@Override
	public String toString() {
		return "SearchInfo [description=" + description + ", deptId=" + deptId + "]";
	}

}

package com.LIC.model;

import java.sql.Timestamp;

public class LineOfBusinessModel {

	long       		lobID;
	String       	description;
	long       		createdBy;
	Timestamp       createdOn;
	long       		modifiedBy;
	Timestamp       modifiedOn;
	long       		deletedBy;
	Timestamp       deletedOn;
	short       	isActive;
	
	public long getLobID() {
		return lobID;
	}
	public String getDescription() {
		return description;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public long getModifiedBy() {
		return modifiedBy;
	}
	public Timestamp getModifiedOn() {
		return modifiedOn;
	}
	public long getDeletedBy() {
		return deletedBy;
	}
	public Timestamp getDeletedOn() {
		return deletedOn;
	}
	public short getIsActive() {
		return isActive;
	}
	public void setLobID(long lobID) {
		this.lobID = lobID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public void setDeletedBy(long deletedBy) {
		this.deletedBy = deletedBy;
	}
	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
}

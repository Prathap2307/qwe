package com.LIC.model;

import java.io.Serializable;
import java.util.List;

public class ProductAgeProofDocument extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer productId;
	private String documentTypeId;
	private List<Integer> documentTypeListId; 
	private Integer ageFrom;
	private Integer ageTo;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	
	public Integer getAgeFrom() {
		return ageFrom;
	}
	public void setAgeFrom(Integer ageFrom) {
		this.ageFrom = ageFrom;
	}
	public Integer getAgeTo() {
		return ageTo;
	}
	public void setAgeTo(Integer ageTo) {
		this.ageTo = ageTo;
	}
	public String getDocumentTypeId() {
		return documentTypeId;
	}
	public void setDocumentTypeId(String documentTypeId) {
		this.documentTypeId = documentTypeId;
	}
	public List<Integer> getDocumentTypeListId() {
		return documentTypeListId;
	}
	public void setDocumentTypeListId(List<Integer> documentTypeListId) {
		this.documentTypeListId = documentTypeListId;
	}
		
		
}

package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/*
 * @Author = "671621"
 */
@Entity
public class OnSelectionOfGridPIDClaimsAssessmentModel {
	
	@Id
	private int pID;
	
	public OnSelectionOfGridPIDClaimsAssessmentModel() {
		
	}

	public int getpID() {
		return pID;
	}

	public void setpID(int pID) {
		this.pID = pID;
	}

}

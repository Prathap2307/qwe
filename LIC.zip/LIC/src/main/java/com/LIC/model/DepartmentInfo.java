package com.LIC.model;

import java.sql.Timestamp;

/**
 * @author Admin
 *
 *2019
 */

/*
 * @Entity
 * 
 * @Table(name = "department")
 */
public class DepartmentInfo {
	/**
	 * Default Constructor
	 */
	public DepartmentInfo() throws Exception {
	}

	/**
	 * Risk Profile ID
	 */

	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.IDENTITY)
	 */
	private int departmentID;
	/**
	 * Description
	 */
	private String description;
	
	/**
	 * ShortDescription
	 */
	private String shortName;
	private String createdBy;
	private Timestamp createdOn;

	public int getDepartmentID() {
		return departmentID;
	}

	public void setDepartmentID(int value) {
		departmentID = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String value) {
		description = value;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String value) {
		shortName = value;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	@Override
	public String toString() {
		return "DepartmentInfo [departmentID=" + departmentID + ", description=" + description + ", shortName="
				+ shortName + ", createdBy=" + createdBy + ", createdOn=" + createdOn + "]";
	}
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class ClaimsMandatoryDocumentMap implements Serializable
{
	private static final long serialVersionUID = 1L;
	public static final String CLAIMS_MANDATORY_DOCUMENT_MAP  = "ClaimsMandatoryDocumentMap";
	
	
	private long mandatoryDocumentMapID; 
	private long claimID; 
	private long documentTypeID; 
	private short isChecked; 
	private short isWaved; 
	private String additionalDocument; 
	private String isAdditional;
	
	
	public long getMandatoryDocumentMapID() {
		return mandatoryDocumentMapID;
	}
	public void setMandatoryDocumentMapID(long mandatoryDocumentMapID) {
		this.mandatoryDocumentMapID = mandatoryDocumentMapID;
	}
	public long getClaimID() {
		return claimID;
	}
	public void setClaimID(long claimID) {
		this.claimID = claimID;
	}
	public long getDocumentTypeID() {
		return documentTypeID;
	}
	public void setDocumentTypeID(long documentTypeID) {
		this.documentTypeID = documentTypeID;
	}
	public short getIsChecked() {
		return isChecked;
	}
	public void setIsChecked(short isChecked) {
		this.isChecked = isChecked;
	}
	public short getIsWaved() {
		return isWaved;
	}
	public void setIsWaved(short isWaved) {
		this.isWaved = isWaved;
	}
	public String getAdditionalDocument() {
		return additionalDocument;
	}
	public void setAdditionalDocument(String additionalDocument) {
		this.additionalDocument = additionalDocument;
	}
	public String getIsAdditional() {
		return isAdditional;
	}
	public void setIsAdditional(String isAdditional) {
		this.isAdditional = isAdditional;
	}
		
		
		
		}

package com.LIC.model;


import java.io.Serializable;

public class AnnualIncomeHistory extends RecordModifier implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer historyId;
	private Integer annualIncomeID;
	private String shortDescription;
	private String description;
	private String remarks;


	public Integer getHistoryId() {
		return historyId;
	}
	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}
	public Integer getAnnualIncomeID() {
		return annualIncomeID;
	}
	public void setAnnualIncomeID(Integer annualIncomeID) {
		this.annualIncomeID = annualIncomeID;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	

	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	
	 
}

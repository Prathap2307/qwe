package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;












@NamedStoredProcedureQuery(name = "createOrUpdate", procedureName = "spInsertOrUpdateBank", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vBankID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDescription", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vShortDescription", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vCreatedOn", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "vResult", type = String.class)} ,resultClasses = BankMasterModel.class)
		



@NamedStoredProcedureQuery(name="deleteBank", procedureName="spDeleteBank", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pBankID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "paraDELETEDBY", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "paraDELETEDON", type = Date.class)}, resultClasses = BankMasterModel.class)








@Entity

@Table(name="master_bank")
@Getter
@Setter
public class BankMasterModel {
	
	@Id
	private int bankId;
	private String bankName;
	private String bankShortName;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	private int deletedBy;
	private Date deletedOn;
	private int isActive;
	public int getBankId() {
		return bankId;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankShortName() {
		return bankShortName;
	}
	public void setBankShortName(String bankShortName) {
		this.bankShortName = bankShortName;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	
	
	
	
	
	
	
	

}

package com.LIC.model;

public class MasterBranch {

	private String branchName;
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getParentBranchName() {
		return parentBranchName;
	}
	public void setParentBranchName(String parentBranchName) {
		this.parentBranchName = parentBranchName;
	}
	public String getWorkingDate() {
		return workingDate;
	}
	public void setWorkingDate(String workingDate) {
		this.workingDate = workingDate;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public Integer getAddressOner() {
		return addressOner;
	}
	public void setAddressOner(Integer addressOner) {
		this.addressOner = addressOner;
	}
	public Integer getAddressTwo() {
		return addressTwo;
	}
	public void setAddressTwo(Integer addressTwo) {
		this.addressTwo = addressTwo;
	}
	public Integer getAddressThree() {
		return addressThree;
	}
	public void setAddressThree(Integer addressThree) {
		this.addressThree = addressThree;
	}
	public Integer getZipCode() {
		return zipCode;
	}
	public void setZipCode(Integer zipCode) {
		this.zipCode = zipCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getPostOffice() {
		return postOffice;
	}
	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Integer getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Integer getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Integer mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	private String branchCode;
	private String parentBranchName;
	private String workingDate;
	private String zone;
	private String division;
	private Integer addressOner;
	private Integer addressTwo;
	private Integer addressThree;
	private Integer zipCode;
	private String country;
	private String state;
	private String district;
	private String postOffice;
	private String emailId;
	private Integer phoneNumber;
	private Integer mobileNumber;
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
public class UserRoleModal implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private long   moduleID;
	private long   featureID;
	private short  allowEdit;
	private short  allowDelete;
	private short  allowAdd;
    private short  allowSearch;
    private short  allowView;
    
	public long getModuleID() {
		return moduleID;
	}
	public long getFeatureID() {
		return featureID;
	}
	public short getAllowEdit() {
		return allowEdit;
	}
	public short getAllowDelete() {
		return allowDelete;
	}
	public short getAllowAdd() {
		return allowAdd;
	}
	public short getAllowSearch() {
		return allowSearch;
	}
	public short getAllowView() {
		return allowView;
	}
	public void setModuleID(long moduleID) {
		this.moduleID = moduleID;
	}
	public void setFeatureID(long featureID) {
		this.featureID = featureID;
	}
	public void setAllowEdit(short allowEdit) {
		this.allowEdit = allowEdit;
	}
	public void setAllowDelete(short allowDelete) {
		this.allowDelete = allowDelete;
	}
	public void setAllowAdd(short allowAdd) {
		this.allowAdd = allowAdd;
	}
	public void setAllowSearch(short allowSearch) {
		this.allowSearch = allowSearch;
	}
	public void setAllowView(short allowView) {
		this.allowView = allowView;
	}
    
}

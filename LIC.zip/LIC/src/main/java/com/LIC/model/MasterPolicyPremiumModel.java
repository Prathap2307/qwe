package com.LIC.model;

public class MasterPolicyPremiumModel {
	
	private int productID;
	private int quotationID;
	private int masterPolicyID;
	private int groupID;
	private int premiumID;
	private int coverageID;
	private int premiumValue;
	private int actualPremiumValue;
	
		
	public MasterPolicyPremiumModel() {
		super();
	}
	
	
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public int getQuotationID() {
		return quotationID;
	}
	public void setQuotationID(int quotationID) {
		this.quotationID = quotationID;
	}
	public int getMasterPolicyID() {
		return masterPolicyID;
	}
	public void setMasterPolicyID(int masterPolicyID) {
		this.masterPolicyID = masterPolicyID;
	}
	public int getGroupID() {
		return groupID;
	}
	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}
	public int getPremiumID() {
		return premiumID;
	}
	public void setPremiumID(int premiumID) {
		this.premiumID = premiumID;
	}
	public int getCoverageID() {
		return coverageID;
	}
	public void setCoverageID(int coverageID) {
		this.coverageID = coverageID;
	}
	public int getPremiumValue() {
		return premiumValue;
	}
	public void setPremiumValue(int premiumValue) {
		this.premiumValue = premiumValue;
	}
	public int getActualPremiumValue() {
		return actualPremiumValue;
	}
	public void setActualPremiumValue(int actualPremiumValue) {
		this.actualPremiumValue = actualPremiumValue;
	}

	
	

}

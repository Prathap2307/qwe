package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class SalesHierarchyAddressMapModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	 
	    private long  		id;
	    private long  		salesHierarchyID ;
	    private long  		AddressID ;
	    private long  		creaetedBy ;
	    private Timestamp  	createdOn ;
		private short       isActive;
	   
		public short getIsActive() {
			return isActive;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public long getSalesHierarchyID() {
			return salesHierarchyID;
		}
		public void setSalesHierarchyID(long salesHierarchyID) {
			this.salesHierarchyID = salesHierarchyID;
		}
		public long getAddressID() {
			return AddressID;
		}
		public void setAddressID(long addressID) {
			AddressID = addressID;
		}
		public long getCreaetedBy() {
			return creaetedBy;
		}
		public void setCreaetedBy(long creaetedBy) {
			this.creaetedBy = creaetedBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
	 	  	   
}

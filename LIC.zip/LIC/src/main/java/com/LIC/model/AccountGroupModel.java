package com.LIC.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;


@NamedStoredProcedureQuery(name = "createOrUpdateAccountGroup", procedureName = "InsertorUpdateAccountingGroup", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pAccountGroupID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pCode", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pDescription", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pCreatedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pCreatedOn", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pIsactive", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "pRESULT", type = Integer.class)} ,resultClasses = AccountGroupModel.class)
		

@Entity
@Table(name="MASTER_ACCOUNTGROUP")
public class AccountGroupModel {
	@Id
	private int accountingGroupId;
	private String code;
	private String groupName;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	private int deletedBy;
	private Date deletedOn;
	private int isActive;
	private int workFlowId;
	private int statusId;
	private String reMarks;
	private int updateCount;
	private String nCode;
	private String nGroupName;
	private int nisActive;
	public int getAccountingGroupId() {
		return accountingGroupId;
	}
	public void setAccountingGroupId(int accountingGroupId) {
		this.accountingGroupId = accountingGroupId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	public int getWorkFlowId() {
		return workFlowId;
	}
	public void setWorkFlowId(int workFlowId) {
		this.workFlowId = workFlowId;
	}
	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	public String getReMarks() {
		return reMarks;
	}
	public void setReMarks(String reMarks) {
		this.reMarks = reMarks;
	}
	public int getUpdateCount() {
		return updateCount;
	}
	public void setUpdateCount(int updateCount) {
		this.updateCount = updateCount;
	}
	public String getnCode() {
		return nCode;
	}
	public void setnCode(String nCode) {
		this.nCode = nCode;
	}
	public String getnGroupName() {
		return nGroupName;
	}
	public void setnGroupName(String nGroupName) {
		this.nGroupName = nGroupName;
	}
	public int getNisActive() {
		return nisActive;
	}
	public void setNisActive(int nisActive) {
		this.nisActive = nisActive;
	}
	@Override
	public String toString() {
		return "AccountGroupModel [accountingGroupId=" + accountingGroupId + ", code=" + code + ", groupName="
				+ groupName + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", modifiedBy=" + modifiedBy
				+ ", modifiedOn=" + modifiedOn + ", deletedBy=" + deletedBy + ", deletedOn=" + deletedOn + ", isActive="
				+ isActive + ", workFlowId=" + workFlowId + ", statusId=" + statusId + ", reMarks=" + reMarks
				+ ", updateCount=" + updateCount + ", nCode=" + nCode + ", nGroupName=" + nGroupName + ", nisActive="
				+ nisActive + "]";
	}
	
	
}

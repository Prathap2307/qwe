package com.LIC.model;

public class ClaimsRelationShipModel {
	private Number relationshipId;
	private String description;

	public Number getRelationshipId() {
		return relationshipId;
	}

	public void setRelationshipId(Number relationshipId) {
		this.relationshipId = relationshipId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ClaimsRelationShipModel(Number relationshipId, String description) {
		super();
		this.relationshipId = relationshipId;
		this.description = description;
	}

}
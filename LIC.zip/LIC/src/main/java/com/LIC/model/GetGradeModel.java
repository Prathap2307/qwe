package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="master_grade")
public class GetGradeModel {
	
	
	
	@Id
	private Number gradeId;
	private String Description;
	private Number organisationId;
	
	
	public Number getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(Number organisationId) {
		this.organisationId = organisationId;
	}
	public Number getGradeId() {
		return gradeId;
	}
	public void setGradeId(Number gradeId) {
		this.gradeId = gradeId;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	
	public GetGradeModel(Number gradeId, String description) {
		this.gradeId = gradeId;
		Description = description;
	}
	
	public GetGradeModel(){
		
	}
	

}

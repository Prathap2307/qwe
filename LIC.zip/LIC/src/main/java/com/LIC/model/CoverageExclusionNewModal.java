package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class CoverageExclusionNewModal implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private long 			coverageExclusionID;
	private long 			coverageID;
	private long 			createdBy;
	private Timestamp 		createdOn;
	private short 			isActive;
	private CoverageModal 	coverage;
	private String 			description;
	
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public short getIsActive() {
		return isActive;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	public long getCoverageExclusionID() {
		return coverageExclusionID;
	}
	public CoverageModal getCoverage() {
		return coverage;
	}
	public String getDescription() {
		return description;
	}
	public void setCoverageExclusionID(long coverageExclusionID) {
		this.coverageExclusionID = coverageExclusionID;
	}
	public void setCoverage(CoverageModal coverage) {
		this.coverage = coverage;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getCoverageID() {
		return coverageID;
	}
	public void setCoverageID(long coverageID) {
		this.coverageID = coverageID;
	}
	@Override
	public String toString() {
		return "CoverageExclusionNewModal [coverageExclusionID=" + coverageExclusionID + ", coverageID=" + coverageID
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", isActive=" + isActive + ", coverage="
				+ coverage + ", description=" + description + "]";
	}
	
}

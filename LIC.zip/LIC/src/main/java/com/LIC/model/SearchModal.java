package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class SearchModal implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String description;
	private long deptId;
	private long OrganisationID;
	private String pageName;
    private Timestamp fromDate;
    private Timestamp toDate;
	public String getDescription() {
		return description;
	}
	public long getDeptId() {
		return deptId;
	}
	public long getOrganisationID() {
		return OrganisationID;
	}
	public String getPageName() {
		return pageName;
	}
	public Timestamp getFromDate() {
		return fromDate;
	}
	public Timestamp getToDate() {
		return toDate;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}
	public void setOrganisationID(long organisationID) {
		OrganisationID = organisationID;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public void setFromDate(Timestamp fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(Timestamp toDate) {
		this.toDate = toDate;
	}
	

}

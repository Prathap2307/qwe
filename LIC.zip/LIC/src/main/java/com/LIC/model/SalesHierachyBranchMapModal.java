package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class SalesHierachyBranchMapModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	 
	    private long  		id;
	    private long  		salesHierarchyID;
	    private long  		branchID;
	    private long  		creaetedBy;
	    private Timestamp   createdOn;
		
		public long getSalesHierarchyID() {
			return salesHierarchyID;
		}
		public void setSalesHierarchyID(long salesHierarchyID) {
			this.salesHierarchyID = salesHierarchyID;
		}
		public long getBranchID() {
			return branchID;
		}
		public void setBranchID(long branchID) {
			this.branchID = branchID;
		}
		public long getCreaetedBy() {
			return creaetedBy;
		}
		public void setCreaetedBy(long creaetedBy) {
			this.creaetedBy = creaetedBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
}

package com.LIC.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UnderWritingUserRuleLevelModel implements Serializable {

	long       		userLevelID;
	long       		userID;
	long       		underWritingLevelID;
	short	        isActive;
	long       		createdOn;
	
	public long getUserLevelID() {
		return userLevelID;
	}
	public long getUserID() {
		return userID;
	}
	public long getUnderWritingLevelID() {
		return underWritingLevelID;
	}
	public short getIsActive() {
		return isActive;
	}
	public long getCreatedOn() {
		return createdOn;
	}
	public void setUserLevelID(long userLevelID) {
		this.userLevelID = userLevelID;
	}
	public void setUserID(long userID) {
		this.userID = userID;
	}
	public void setUnderWritingLevelID(long underWritingLevelID) {
		this.underWritingLevelID = underWritingLevelID;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	public void setCreatedOn(long createdOn) {
		this.createdOn = createdOn;
	}

	
}

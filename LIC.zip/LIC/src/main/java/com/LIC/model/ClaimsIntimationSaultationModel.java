package com.LIC.model;

public class ClaimsIntimationSaultationModel {

	private Number salutationId;
	private String description;
	private String isActive;
	private String shortDescription;

	public ClaimsIntimationSaultationModel(Number salutationId, String description, String shortDescription) {
		super();
		this.salutationId = salutationId;
		this.description = description;
		this.shortDescription = shortDescription;
	}

	public Number getSalutationId() {
		return salutationId;
	}

	public void setSalutationId(Number salutationId) {
		this.salutationId = salutationId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

}

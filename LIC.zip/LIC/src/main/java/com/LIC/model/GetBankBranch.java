package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_BANKBRANCH")
public class GetBankBranch {
	@Id
	private Number branchId;
	private Number bankId;
	private Number bankCityId;
	private String description;
	private String ifscCode;
	private String micrCode;
	private String bankName;
	private String bankCityName;
	private String address;
	private Number contact;
	private String mp;
	
	
	
	
	

	
	
	public GetBankBranch() {
		super();
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Number getContact() {
		return contact;
	}
	public void setContact(Number contact) {
		this.contact = contact;
	}
	public String getMp() {
		return mp;
	}
	public void setMp(String mp) {
		this.mp = mp;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankCityName() {
		return bankCityName;
	}
	public void setBankCityName(String bankCityName) {
		this.bankCityName = bankCityName;
	}
	private Number isActive;
	private Number createdBy;
	private String createdOn;
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public Number getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public void setBranchId(Number branchId) {
		this.branchId = branchId;
	}
	public void setBankId(Number bankId) {
		this.bankId = bankId;
	}
	public void setBankCityId(Number bankCityId) {
		this.bankCityId = bankCityId;
	}
	public GetBankBranch(Number bankCityId, String description, Number isActive) {
		super();
		this.bankCityId = bankCityId;
		this.description = description;
		this.isActive = isActive;
	}
	public Number getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public Number getBankId() {
		return bankId;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public Number getBankCityId() {
		return bankCityId;
	}
	public void setBankCityId(int bankCityId) {
		this.bankCityId = bankCityId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public GetBankBranch(Number branchId, Number bankId,String bankName,Number bankCityId,String bankCityName,String description, String ifscCode,
            String micrCode,Number createdBy,String createdOn) {
    super();
    this.branchId = branchId;
    this.bankId = bankId;
    this.bankName=bankName;
    this.bankCityId = bankCityId;
    
    this.bankCityName = bankCityName;
    this.description=description;
//    this.address=address;
    this.ifscCode = ifscCode;
    this.micrCode = micrCode;
    this.createdBy=createdBy;
    this.createdOn=createdOn;
}




	
	
	
	
	
	
	
	public GetBankBranch(Number branchId) {
		super();
		this.branchId = branchId;
	}
	
	public GetBankBranch(Number bankId, String description) {
		super();
		this.bankId = bankId;
		this.description = description;
	}
	
	
	
	
	public GetBankBranch(Number branchId, Number bankId, Number bankCityId, String description, String ifscCode, String micrCode,
			String bankName, String bankCityName, String address, Number contact, String mp) {
		
		super();
		this.branchId = branchId;
		this.bankId = bankId;
		this.bankCityId = bankCityId;
		this.description = description;
		this.ifscCode = ifscCode;
		this.micrCode = micrCode;
		this.bankName = bankName;
		this.bankCityName = bankCityName;
		this.address = address;
		this.contact = contact;
		this.mp = mp;
		
		
	}
	



	
	
	
	
	
	

}

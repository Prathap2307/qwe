package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="master_bank")
@Getter
@Setter
public class GetBankModel {
	@Id
	private Number bankId;
	private String bankName;
	private String bankShortName;
	private Number isActive;
	
	public GetBankModel(Number bankId, String bankName,String bankShortName,Number isActive) {
		this.bankId=bankId;
		this.bankName=bankName;
		this.bankShortName=bankShortName;
		this.isActive=isActive;
	}
	
	public Number getBankId() {
		return bankId;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankShortName() {
		return bankShortName;
	}
	public void setBankShortName(String bankShortName) {
		this.bankShortName = bankShortName;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	

}

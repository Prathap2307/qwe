package com.LIC.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AccountingSubHeadModel {
	@Id
	private Number subAccountHeadId;
	private Number accountHeadId;
	private String accountHeadName;
	private String accountHeadCode;
	private String subAccountHeadName;
	private String subAccountHeadCode;
	private Number createdBy;
	private Date createdOn;
	private Number isactive; 
	
	public Number getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Number createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Number getIsactive() {
		return isactive;
	}

	public void setIsactive(Number isactive) {
		this.isactive = isactive;
	}

	public AccountingSubHeadModel()
	{}
	
	public AccountingSubHeadModel(Number accountHeadId,String accountHeadName,String accountHeadCode)
	{
		this.accountHeadId=accountHeadId;
		this.accountHeadName=accountHeadName;
		this.accountHeadCode=accountHeadCode;
	}
	
	public AccountingSubHeadModel(Number subAccountHeadId,String subAccountHeadName,String subAccountHeadCode,String accountHeadName)
	{
		this.subAccountHeadId=subAccountHeadId;
		this.subAccountHeadName=subAccountHeadName;
		this.subAccountHeadCode=subAccountHeadCode;
		this.accountHeadName=accountHeadName;
	}
	
	public AccountingSubHeadModel(Number subAccountHeadId,String subAccountHeadName,String subAccountHeadCode,Number isactive,Number accountHeadId, String accountHeadName)
	{
		this.subAccountHeadId=subAccountHeadId;
		this.subAccountHeadName=subAccountHeadName;
		this.subAccountHeadCode=subAccountHeadCode;
		this.isactive=isactive;
		this.accountHeadId=accountHeadId;
		this.accountHeadName=accountHeadName;
	}
	


	public Number getSubAccountHeadId() {
		return subAccountHeadId;
	}

	public void setSubAccountHeadId(Number subAccountHeadId) {
		this.subAccountHeadId = subAccountHeadId;
	}

	public Number getAccountHeadId() {
		return accountHeadId;
	}

	public void setAccountHeadId(Number accountHeadId) {
		this.accountHeadId = accountHeadId;
	}

	public String getAccountHeadName() {
		return accountHeadName;
	}
	public void setAccountHeadName(String accountHeadName) {
		this.accountHeadName = accountHeadName;
	}
	public String getAccountHeadCode() {
		return accountHeadCode;
	}
	public void setAccountHeadCode(String accountHeadCode) {
		this.accountHeadCode = accountHeadCode;
	}
	public String getSubAccountHeadName() {
		return subAccountHeadName;
	}
	public void setSubAccountHeadName(String subAccountHeadName) {
		this.subAccountHeadName = subAccountHeadName;
	}
	public String getSubAccountHeadCode() {
		return subAccountHeadCode;
	}
	public void setSubAccountHeadCode(String subAccountHeadCode) {
		this.subAccountHeadCode = subAccountHeadCode;
	}
}

package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class SalesHierarchyModal  implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	 	
	    private long 		 	salesHierarchyID;
	    private long 		 	lineOfBusinessID;
	    private long        	salutationID;
	    private String 		 	firstName;
	    private String      	lastName;
	    private String       	code;
	    private long      		fireTypeID;
	    private long    		designationID;
	    private long  			parentHierarchyID;
	    private long   			branchID;	
	    private long  			accountBranchID;
	    private double 	        triggerLimit;
	    private long 			salesTypeID;
	    private String 			type;
	    private short 			isEmployee;
	    private short 			isAdvanceDeposit;
	    private long 		 	createdBy;
	    private Timestamp 	 	createdOn; 
	    private long 			modifiedBy;
	    private Timestamp 	 	modifiedOn;
	    private long       		deletedBy;
	    private  Timestamp  	deletedOn;
	    private long 			salesType; 
	    private long 			channelID;
	    private long 			subChannelID;
	    private long 			policyHolderID;
	    private String 			mobileNumber;
	    private String 			landLineNumber;
	    private String 			panCard;
	    private String 			aadharNumber;
	    private String 			organisationName;
	    private long 			departmentID;
	    private long 			IsPayableFeature;
	    private Timestamp 		applicationDate;
	    private Timestamp 		DateofJoining;
	    private long 			Gender;
	    private Timestamp  		DOB;
	    private long  			Age;
	    private long 			Month;
	    private String   		PanNumber;
	    private String 			Registredunder;
	    private Timestamp 		MIAagreementdate;
	    private Timestamp 		CodeIssuancedate;
	    private Timestamp 		Renewaldate;
	    private Timestamp 		CodeExpiredate;
	    private Timestamp 		Effectivedate; 
	    private Timestamp 		Expiredate;
	    private Timestamp 		RemarksDate;
	    private Timestamp 		Registrationdate;
	    private String          BankName;
	    private String          BranchName;
	    private String          AccountHolderName;
	    private String          AccountNO;
	    private String          AccountType;
	    private String 			IFSCcode;
	    private String 			Micrcode;
	    private String 			AgentLocation;
	    private String 			Remarks;
	    private long            addressID;
	    private short           payableFeature;
	    private String 			Name;
	    private String 			mainChannelName;
	    private String 			subChannelName;
	    private String 			description;
	    private String 			designation;
	    private short 		 	isActive;
	    private short 			IsCDAccount;
	    private String			MainChannelCode;
	    private String			SubChannelCode;
	    private long 			MainChannelID;
	    
	    List<SalesHierarchyAddressModal> salesHierarchyAddressList = null;
	    List<BranchModal> branchModalList = null;
	   
		public List<SalesHierarchyAddressModal> getSalesHierarchyAddressList() {
			return salesHierarchyAddressList;
		}
		public void setSalesHierarchyAddressList(List<SalesHierarchyAddressModal> salesHierarchyAddressList) {
			this.salesHierarchyAddressList = salesHierarchyAddressList;
		}
		public long getMainChannelID() {
			return MainChannelID;
		}
		public void setMainChannelID(long mainChannelID) {
			MainChannelID = mainChannelID;
		}
		public String getSubChannelCode() {
			return SubChannelCode;
		}
		public void setSubChannelCode(String subChannelCode) {
			SubChannelCode = subChannelCode;
		}
		public String getMainChannelCode() {
			return MainChannelCode;
		}
		public void setMainChannelCode(String mainChannelCode) {
			MainChannelCode = mainChannelCode;
		}
		public short getIsCDAccount() {
			return IsCDAccount;
		}
		public void setIsCDAccount(short isCDAccount) {
			IsCDAccount = isCDAccount;
		}
		public short getIsActive() {
			return isActive;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public List<BranchModal> getBranchModalList() {
			return branchModalList;
		}
		public void setBranchModalList(List<BranchModal> branchModalList) {
			this.branchModalList = branchModalList;
		}
		public short getPayableFeature() {
			return payableFeature;
		}
		public void setPayableFeature(short payableFeature) {
			this.payableFeature = payableFeature;
		}
		public long getAddressID() {
			return addressID;
		}
		public void setAddressID(long addressID) {
			this.addressID = addressID;
		}
		public long getSalesHierarchyID() {
			return salesHierarchyID;
		}
		public void setSalesHierarchyID(long salesHierarchyID) {
			this.salesHierarchyID = salesHierarchyID;
		}
		public long getLineOfBusinessID() {
			return lineOfBusinessID;
		}
		public void setLineOfBusinessID(long lineOfBusinessID) {
			this.lineOfBusinessID = lineOfBusinessID;
		}
		public long getSalutationID() {
			return salutationID;
		}
		public void setSalutationID(long salutationID) {
			this.salutationID = salutationID;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getCode() {
			return code;
			
		}
		public void setCode(String code) {
			this.code = code;
		}
		public long getFireTypeID() {
			return fireTypeID;
		}
		public void setFireTypeID(long fireTypeID) {
			this.fireTypeID = fireTypeID;
		}
		public long getDesignationID() {
			return designationID;
		}
		public void setDesignationID(long designationID) {
			this.designationID = designationID;
		}
		public long getParentHierarchyID() {
			return parentHierarchyID;
		}
		public void setParentHierarchyID(long parentHierarchyID) {
			this.parentHierarchyID = parentHierarchyID;
		}
		public long getBranchID() {
			return branchID;
		}
		public void setBranchID(long branchID) {
			this.branchID = branchID;
		}
		public long getAccountBranchID() {
			return accountBranchID;
		}
		public void setAccountBranchID(long accountBranchID) {
			this.accountBranchID = accountBranchID;
		}
		public double getTriggerLimit() {
			return triggerLimit;
		}
		public void setTriggerLimit(Double triggerLimit) {
			this.triggerLimit = triggerLimit;
		}
		public long getSalesTypeID() {
			return salesTypeID;
		}
		public void setSalesTypeID(long salesTypeID) {
			this.salesTypeID = salesTypeID;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public short getIsEmployee() {
			return isEmployee;
		}
		public void setIsEmployee(short isEmployee) {
			this.isEmployee = isEmployee;
		}
		public short getIsAdvanceDeposit() {
			return isAdvanceDeposit;
		}
		public void setIsAdvanceDeposit(short isAdvanceDeposit) {
			this.isAdvanceDeposit = isAdvanceDeposit;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public long getSalesType() {
			return salesType;
		}
		public void setSalesType(long salesType) {
			this.salesType = salesType;
		}
		public long getChannelID() {
			return channelID;
		}
		public void setChannelID(long channelID) {
			this.channelID = channelID;
		}
		public long getSubChannelID() {
			return subChannelID;
		}
		public void setSubChannelID(long subChannelID) {
			this.subChannelID = subChannelID;
		}
		public long getPolicyHolderID() {
			return policyHolderID;
		}
		public void setPolicyHolderID(long policyHolderID) {
			this.policyHolderID = policyHolderID;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getLandLineNumber() {
			return landLineNumber;
		}
		public void setLandLineNumber(String landLineNumber) {
			this.landLineNumber = landLineNumber;
		}
		public String getPanCard() {
			return panCard;
		}
		public void setPanCard(String panCard) {
			this.panCard = panCard;
		}
		public String getAadharNumber() {
			return aadharNumber;
		}
		public void setAadharNumber(String aadharNumber) {
			this.aadharNumber = aadharNumber;
		}
		public String getOrganisationName() {
			return organisationName;
		}
		public void setOrganisationName(String organisationName) {
			this.organisationName = organisationName;
		}
		public long getDepartmentID() {
			return departmentID;
		}
		public void setDepartmentID(long departmentID) {
			this.departmentID = departmentID;
		}
		public long getIsPayableFeature() {
			return IsPayableFeature;
		}
		public void setIsPayableFeature(long isPayableFeature) {
			IsPayableFeature = isPayableFeature;
		}
		public Timestamp getApplicationDate() {
			return applicationDate;
		}
		public void setApplicationDate(Timestamp applicationDate) {
			this.applicationDate = applicationDate;
		}
		public Timestamp getDateofJoining() {
			return DateofJoining;
		}
		public void setDateofJoining(Timestamp dateofJoining) {
			DateofJoining = dateofJoining;
		}
		public long getGender() {
			return Gender;
		}
		public void setGender(long gender) {
			Gender = gender;
		}
		public Timestamp getDOB() {
			return DOB;
		}
		public void setDOB(Timestamp dOB) {
			DOB = dOB;
		}
		public long getAge() {
			return Age;
		}
		public void setAge(long age) {
			Age = age;
		}
		public long getMonth() {
			return Month;
		}
		public void setMonth(long month) {
			Month = month;
		}
		public String getPanNumber() {
			return PanNumber;
		}
		public void setPanNumber(String panNumber) {
			PanNumber = panNumber;
		}
		public String getRegistredunder() {
			return Registredunder;
		}
		public void setRegistredunder(String registredunder) {
			Registredunder = registredunder;
		}
		public Timestamp getMIAagreementdate() {
			return MIAagreementdate;
		}
		public void setMIAagreementdate(Timestamp mIAagreementdate) {
			MIAagreementdate = mIAagreementdate;
		}
		public Timestamp getCodeIssuancedate() {
			return CodeIssuancedate;
		}
		public void setCodeIssuancedate(Timestamp codeIssuancedate) {
			CodeIssuancedate = codeIssuancedate;
		}
		public Timestamp getRenewaldate() {
			return Renewaldate;
		}
		public void setRenewaldate(Timestamp renewaldate) {
			Renewaldate = renewaldate;
		}
		public Timestamp getCodeExpiredate() {
			return CodeExpiredate;
		}
		public void setCodeExpiredate(Timestamp codeExpiredate) {
			CodeExpiredate = codeExpiredate;
		}
		public Timestamp getEffectivedate() {
			return Effectivedate;
		}
		public void setEffectivedate(Timestamp effectivedate) {
			Effectivedate = effectivedate;
		}
		public Timestamp getExpiredate() {
			return Expiredate;
		}
		public void setExpiredate(Timestamp expiredate) {
			Expiredate = expiredate;
		}
		public Timestamp getRemarksDate() {
			return RemarksDate;
		}
		public void setRemarksDate(Timestamp remarksDate) {
			RemarksDate = remarksDate;
		}
		public Timestamp getRegistrationdate() {
			return Registrationdate;
		}
		public void setRegistrationdate(Timestamp registrationdate) {
			Registrationdate = registrationdate;
		}
		public String getBankName() {
			return BankName;
		}
		public void setBankName(String bankName) {
			BankName = bankName;
		}
		public String getBranchName() {
			return BranchName;
		}
		public void setBranchName(String branchName) {
			BranchName = branchName;
		}
		public String getAccountHolderName() {
			return AccountHolderName;
		}
		public void setAccountHolderName(String accountHolderName) {
			AccountHolderName = accountHolderName;
		}
		public String getAccountNO() {
			return AccountNO;
		}
		public void setAccountNO(String accountNO) {
			AccountNO = accountNO;
		}
		public String getAccountType() {
			return AccountType;
		}
		public void setAccountType(String accountType) {
			AccountType = accountType;
		}
		public String getIFSCcode() {
			return IFSCcode;
		}
		public void setIFSCcode(String iFSCcode) {
			IFSCcode = iFSCcode;
		}
		public String getMicrcode() {
			return Micrcode;
		}
		public void setMicrcode(String micrcode) {
			Micrcode = micrcode;
		}
		public String getAgentLocation() {
			return AgentLocation;
		}
		public void setAgentLocation(String agentLocation) {
			AgentLocation = agentLocation;
		}
		public String getRemarks() {
			return Remarks;
		}
		public void setRemarks(String remarks) {
			Remarks = remarks;
		}
		
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		
		
		public String getMainChannelName() {
			return mainChannelName;
		}
		public void setMainChannelName(String mainChannelName) {
			this.mainChannelName = mainChannelName;
		}
		
		public String getSubChannelName() {
			return subChannelName;
		}
		public void setSubChannelName(String subChannelName) {
			this.subChannelName = subChannelName;
		}
		
		
		public String getDescription() {
			return description;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		@Override
		public String toString() {
			return "SalesHierarchyModal [salesHierarchyID=" + salesHierarchyID + ", lineOfBusinessID="
					+ lineOfBusinessID + ", salutationID=" + salutationID + ", firstName=" + firstName + ", lastName="
					+ lastName + ", code=" + code + ", fireTypeID=" + fireTypeID + ", designationID=" + designationID
					+ ", parentHierarchyID=" + parentHierarchyID + ", branchID=" + branchID + ", accountBranchID="
					+ accountBranchID + ", triggerLimit=" + triggerLimit + ", salesTypeID=" + salesTypeID + ", type="
					+ type + ", isEmployee=" + isEmployee + ", isAdvanceDeposit=" + isAdvanceDeposit + ", createdBy="
					+ createdBy + ", createdOn=" + createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn="
					+ modifiedOn + ", deletedBy=" + deletedBy + ", deletedOn=" + deletedOn + ", salesType=" + salesType
					+ ", channelID=" + channelID + ", subChannelID=" + subChannelID + ", policyHolderID="
					+ policyHolderID + ", mobileNumber=" + mobileNumber + ", landLineNumber=" + landLineNumber
					+ ", panCard=" + panCard + ", aadharNumber=" + aadharNumber + ", organisationName="
					+ organisationName + ", departmentID=" + departmentID + ", IsPayableFeature=" + IsPayableFeature
					+ ", applicationDate=" + applicationDate + ", DateofJoining=" + DateofJoining + ", Gender=" + Gender
					+ ", DOB=" + DOB + ", Age=" + Age + ", Month=" + Month + ", PanNumber=" + PanNumber
					+ ", Registredunder=" + Registredunder + ", MIAagreementdate=" + MIAagreementdate
					+ ", CodeIssuancedate=" + CodeIssuancedate + ", Renewaldate=" + Renewaldate + ", CodeExpiredate="
					+ CodeExpiredate + ", Effectivedate=" + Effectivedate + ", Expiredate=" + Expiredate
					+ ", RemarksDate=" + RemarksDate + ", Registrationdate=" + Registrationdate + ", BankName="
					+ BankName + ", BranchName=" + BranchName + ", AccountHolderName=" + AccountHolderName
					+ ", AccountNO=" + AccountNO + ", AccountType=" + AccountType + ", IFSCcode=" + IFSCcode
					+ ", Micrcode=" + Micrcode + ", AgentLocation=" + AgentLocation + ", Remarks=" + Remarks
					+ ", addressID=" + addressID + ", payableFeature=" + payableFeature + ", Name=" + Name
					+ ", mainChannelName=" + mainChannelName + ", subChannelName=" + subChannelName + ", description="
					+ description + ", designation=" + designation + ", isActive=" + isActive + ", IsCDAccount="
					+ IsCDAccount + ", MainChannelCode=" + MainChannelCode + ", SubChannelCode=" + SubChannelCode
					+ ", MainChannelID=" + MainChannelID + ", salesHierarchyAddressModalList="
					+ salesHierarchyAddressList + ", branchModalList=" + branchModalList + "]";
		}
		
}

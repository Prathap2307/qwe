package com.LIC.model;

import java.io.Serializable;

public class CountryTimeZone implements Serializable {
	
	private static final long serialVersionUID = 1L;
	 
    private long 		timeZoneID;
	private String 		description;
	private String 		shortDescription;
	private short		isActive;
	
	public long getTimeZoneID() {
		return timeZoneID;
	}
	public String getDescription() {
		return description;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public short getIsActive() {
		return isActive;
	}
	public void setTimeZoneID(long timeZoneID) {
		this.timeZoneID = timeZoneID;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "CountryTimeZone [timeZoneID=" + timeZoneID + ", description=" + description + ", shortDescription="
				+ shortDescription + ", isActive=" + isActive + "]";
	}
    
   
}

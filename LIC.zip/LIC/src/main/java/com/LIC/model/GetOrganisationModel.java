package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="oraganisation")
public class GetOrganisationModel {
	@Id
	private Number organisationId;
	private String shortName;
	private String organisationName;
	private Number countryId;
	private String countryCode;
	private String shortDescription;
	private Number isDeclined;	
	private String tinNumber;
	private Number stateId;
	private String description;
	private Number districtId;
	private String zipCode;
	private Number postOfficeId;
	private String address2;
	private String address3;
	private String gstNo;
	
	private String phoneNo;
	private String mobileNo;
	private String conferenceNo;
	private String faxNo;
	private String email;
	private String panNo;
	private String sacCode;
	private String country;
    private Number talukId;
    private String taluk;
    private String district;





    
    
    
    
	
	public String getCountry() {
		return country;
	}





	public void setCountry(String country) {
		this.country = country;
	}





	public Number getTalukId() {
		return talukId;
	}





	public void setTalukId(Number talukId) {
		this.talukId = talukId;
	}





	public String getTaluk() {
		return taluk;
	}





	public void setTaluk(String taluk) {
		this.taluk = taluk;
	}





	public String getDistrict() {
		return district;
	}





	public void setDistrict(String district) {
		this.district = district;
	}





	public GetOrganisationModel(
			Number organisationId, String shortName,
			
			String organisationName, Number countryId,
			
			 Number stateId, Number districtId, 
			 
			 String zipCode, Number postOfficeId,
			 
			 
			 
			 
			 
			 String address1,  String address2, 
			 
			 String address3, String gstNo,
			 
			 String phoneNo, String mobileNo,
			 
			 String conferenceNo, String faxNo,
			 
			 String email, String panNo,
			 
			 String sacCode) {
		
		super();
		this.organisationId = organisationId;
		this.shortName = shortName;
		this.organisationName = organisationName;
		this.countryId = countryId;
		
	
		this.stateId = stateId;
	
		this.districtId = districtId;
		this.zipCode = zipCode;
		this.postOfficeId = postOfficeId;
		this.address1 = address1;
		this.address2 = address2;
		this.address3 = address3;
		this.gstNo = gstNo;
		this.phoneNo = phoneNo;
		this.mobileNo = mobileNo;
		this.conferenceNo = conferenceNo;
		this.faxNo = faxNo;
		this.email = email;
		this.panNo = panNo;
		this.sacCode = sacCode;
	}
	private String address1;
	public String getAddress1() {
		return address1;
	}





	public void setAddress1(String address1) {
		this.address1 = address1;
	}





	public String getAddress2() {
		return address2;
	}





	public void setAddress2(String address2) {
		this.address2 = address2;
	}





	public String getAddress3() {
		return address3;
	}





	public void setAddress3(String address3) {
		this.address3 = address3;
	}





	public String getGstNo() {
		return gstNo;
	}





	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}





	public String getPhoneNo() {
		return phoneNo;
	}





	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}





	public String getMobileNo() {
		return mobileNo;
	}





	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}





	public String getConferenceNo() {
		return conferenceNo;
	}





	public void setConferenceNo(String conferenceNo) {
		this.conferenceNo = conferenceNo;
	}





	public String getFaxNo() {
		return faxNo;
	}





	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}





	public String getEmail() {
		return email;
	}





	public void setEmail(String email) {
		this.email = email;
	}





	public String getPanNo() {
		return panNo;
	}





	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}





	public String getSacCode() {
		return sacCode;
	}





	public void setSacCode(String sacCode) {
		this.sacCode = sacCode;
	}
	
	
	/*
	 * public GetOrganisationModel (Number postOfficeId,String description, String
	 * zipCode) { super(); this.description = description; this.zipCode = zipCode;
	 * this.postOfficeId = postOfficeId; }
	 * 
	 */



	/*
	 * public GetOrganisationModel(Number organisationId, String shortName, String
	 * organisationName) { super(); this.organisationId = organisationId;
	 * this.shortName = shortName; this.organisationName = organisationName; }
	 */




	public Number getPostOfficeId() {
		return postOfficeId;
	}





	public void setPostOfficeId(Number postOfficeId) {
		this.postOfficeId = postOfficeId;
	}





	public GetOrganisationModel(String description, Number districtId, String zipCode) {
		super();
		this.description = description;
		this.districtId = districtId;
		this.zipCode = zipCode;
	}





	public Number getDistrictId() {
		return districtId;
	}





	public void setDistrictId(Number districtId) {
		this.districtId = districtId;
	}





	public String getZipCode() {
		return zipCode;
	}





	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}





	public GetOrganisationModel(Number countryId,String description, Number stateId
			) {
		super();
		this.countryId = countryId;
		this.stateId = stateId;
		this.description = description;
	}





	public String getTinNumber() {
		return tinNumber;
	}





	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}





	public Number getStateId() {
		return stateId;
	}





	public void setStateId(Number stateId) {
		this.stateId = stateId;
	}





	public String getDescription() {
		return description;
	}





	public void setDescription(String description) {
		this.description = description;
	}





	public GetOrganisationModel() {
		super();
	}
	
	
	
	

	public GetOrganisationModel(Number postOfficeId,String description, String zipCode) {
		super();
		this.description = description;
		this.zipCode = zipCode;
		this.postOfficeId = postOfficeId;
	}





	public GetOrganisationModel(Number countryId, String countryCode, String description,String shortDescription, Number isDeclined) {
		super();
		this.countryId = countryId;
		this.countryCode = countryCode;
		this.description=description;
		this.shortDescription = shortDescription;
		this.isDeclined = isDeclined;
	}
	
	
	
	public GetOrganisationModel(String description,String country,Number countryId, Number stateId, 
            Number talukId, String taluk,Number districtId, String district) {
     super();
     this.description = description;
     this.country = country;
     this.countryId = countryId;
     this.stateId = stateId;
     this.talukId = talukId;
     this.taluk = taluk;
     this.districtId = districtId;
     this.district = district;
}
	
	
	
	
	
	
	
	
	public Number getCountryId() {
		return countryId;
	}
	public void setCountryId(Number countryId) {
		this.countryId = countryId;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public Number getIsDeclined() {
		return isDeclined;
	}
	public void setIsDeclined(Number isDeclined) {
		this.isDeclined = isDeclined;
	}
	
	public Number getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(Number organisationId) {
		this.organisationId = organisationId;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getOrganisationName() {
		return organisationName;
	}
	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}
	
	

}

package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
//@Table(name = "")
@Getter
@Setter
public class ClaimsRegistrationModel {

	@Id
	private int pClaimID;
	
	private int pLineOfBusinessID;
	private String pClaimNumber;
	private String pFirstName;
	private String pLastName;
	private String pPolicyNumber;
	private String pContactID;
	private String pAgeing;
	private int pStatusID;
	private int pAssessorID;
	private int vSearchData;
	private int vISAdmin;
	private String vCoverages;

	private int pApplicationID;
	private int pProductID;

	private int pID;

	private int vClaimID;
	private String vPolicyNumber;
	private Date vDateOfLoss;
	private int vLineOfBusinessID;
	private int vExistCount;
	private int pCount;

	//private int vClaimID;
	//private Date vDateOfLoss;
	private String vTimeOfLoss;
	private String vPlaceOfLoss;
	private String vParticularsOfDeath;
	private String vDoctorNameAndAddress;
	private int vPartialAdvanceClaimPayment;
	private int vCreatedBy;
	private Date vCreatedOn;
	private int vIsActive;
	private int vIsAdditionalDcoument;
	private int vStatusID;
	private String vAssessmentRemarks;
	private int vResult;
	//private int pID;
	//private int pCount;

	//private int vClaimID;

	//private int vClaimID;
	private int vCoverageID;
	private int vTypeID;
	//private int vResult;
	//private int pID;

	//private String vClaimID;
	private int vDocumentTypeID;
	private String vDocumentNumber;
	private String vImageName;
	private int vIsAdditionDocument;
	//private int vIsActive;
	//private int vResult;
	//private int pID;
	
	//private String vClaimID;
	//private int vDocumentTypeID;
	//private String vDocumentNumber;
	//private String vImageName;
	//private int vIsAdditionDocument;
	//private int vIsActive;
	//private int vResult;
	//private int pID;
		
	public int getpLineOfBusinessID() {
		return pLineOfBusinessID;
	}
	public void setpLineOfBusinessID(int pLineOfBusinessID) {
		this.pLineOfBusinessID = pLineOfBusinessID;
	}
	public String getpClaimNumber() {
		return pClaimNumber;
	}
	public void setpClaimNumber(String pClaimNumber) {
		this.pClaimNumber = pClaimNumber;
	}
	public String getpFirstName() {
		return pFirstName;
	}
	public void setpFirstName(String pFirstName) {
		this.pFirstName = pFirstName;
	}
	public String getpLastName() {
		return pLastName;
	}
	public void setpLastName(String pLastName) {
		this.pLastName = pLastName;
	}
	public String getpPolicyNumber() {
		return pPolicyNumber;
	}
	public void setpPolicyNumber(String pPolicyNumber) {
		this.pPolicyNumber = pPolicyNumber;
	}
	public String getpContactID() {
		return pContactID;
	}
	public void setpContactID(String pContactID) {
		this.pContactID = pContactID;
	}
	public String getpAgeing() {
		return pAgeing;
	}
	public void setpAgeing(String pAgeing) {
		this.pAgeing = pAgeing;
	}
	public int getpStatusID() {
		return pStatusID;
	}
	public void setpStatusID(int pStatusID) {
		this.pStatusID = pStatusID;
	}
	public int getpAssessorID() {
		return pAssessorID;
	}
	public void setpAssessorID(int pAssessorID) {
		this.pAssessorID = pAssessorID;
	}
	public int getvSearchData() {
		return vSearchData;
	}
	public void setvSearchData(int vSearchData) {
		this.vSearchData = vSearchData;
	}
	public int getvISAdmin() {
		return vISAdmin;
	}
	public void setvISAdmin(int vISAdmin) {
		this.vISAdmin = vISAdmin;
	}
	public String getvCoverages() {
		return vCoverages;
	}
	public void setvCoverages(String vCoverages) {
		this.vCoverages = vCoverages;
	}
	public int getpClaimID() {
		return pClaimID;
	}
	public void setpClaimID(int pClaimID) {
		this.pClaimID = pClaimID;
	}
	public int getpApplicationID() {
		return pApplicationID;
	}
	public void setpApplicationID(int pApplicationID) {
		this.pApplicationID = pApplicationID;
	}
	public int getpProductID() {
		return pProductID;
	}
	public void setpProductID(int pProductID) {
		this.pProductID = pProductID;
	}
	public int getpID() {
		return pID;
	}
	public void setpID(int pID) {
		this.pID = pID;
	}
	public int getvClaimID() {
		return vClaimID;
	}
	public void setvClaimID(int vClaimID) {
		this.vClaimID = vClaimID;
	}
	public String getvPolicyNumber() {
		return vPolicyNumber;
	}
	public void setvPolicyNumber(String vPolicyNumber) {
		this.vPolicyNumber = vPolicyNumber;
	}
	public Date getvDateOfLoss() {
		return vDateOfLoss;
	}
	public void setvDateOfLoss(Date vDateOfLoss) {
		this.vDateOfLoss = vDateOfLoss;
	}
	public int getvLineOfBusinessID() {
		return vLineOfBusinessID;
	}
	public void setvLineOfBusinessID(int vLineOfBusinessID) {
		this.vLineOfBusinessID = vLineOfBusinessID;
	}
	public int getvExistCount() {
		return vExistCount;
	}
	public void setvExistCount(int vExistCount) {
		this.vExistCount = vExistCount;
	}
	public int getpCount() {
		return pCount;
	}
	public void setpCount(int pCount) {
		this.pCount = pCount;
	}
	public String getvTimeOfLoss() {
		return vTimeOfLoss;
	}
	public void setvTimeOfLoss(String vTimeOfLoss) {
		this.vTimeOfLoss = vTimeOfLoss;
	}
	public String getvPlaceOfLoss() {
		return vPlaceOfLoss;
	}
	public void setvPlaceOfLoss(String vPlaceOfLoss) {
		this.vPlaceOfLoss = vPlaceOfLoss;
	}
	public String getvParticularsOfDeath() {
		return vParticularsOfDeath;
	}
	public void setvParticularsOfDeath(String vParticularsOfDeath) {
		this.vParticularsOfDeath = vParticularsOfDeath;
	}
	public String getvDoctorNameAndAddress() {
		return vDoctorNameAndAddress;
	}
	public void setvDoctorNameAndAddress(String vDoctorNameAndAddress) {
		this.vDoctorNameAndAddress = vDoctorNameAndAddress;
	}
	public int getvPartialAdvanceClaimPayment() {
		return vPartialAdvanceClaimPayment;
	}
	public void setvPartialAdvanceClaimPayment(int vPartialAdvanceClaimPayment) {
		this.vPartialAdvanceClaimPayment = vPartialAdvanceClaimPayment;
	}
	public int getvCreatedBy() {
		return vCreatedBy;
	}
	public void setvCreatedBy(int vCreatedBy) {
		this.vCreatedBy = vCreatedBy;
	}
	public Date getvCreatedOn() {
		return vCreatedOn;
	}
	public void setvCreatedOn(Date vCreatedOn) {
		this.vCreatedOn = vCreatedOn;
	}
	public int getvIsActive() {
		return vIsActive;
	}
	public void setvIsActive(int vIsActive) {
		this.vIsActive = vIsActive;
	}
	public int getvIsAdditionalDcoument() {
		return vIsAdditionalDcoument;
	}
	public void setvIsAdditionalDcoument(int vIsAdditionalDcoument) {
		this.vIsAdditionalDcoument = vIsAdditionalDcoument;
	}
	public int getvStatusID() {
		return vStatusID;
	}
	public void setvStatusID(int vStatusID) {
		this.vStatusID = vStatusID;
	}
	public String getvAssessmentRemarks() {
		return vAssessmentRemarks;
	}
	public void setvAssessmentRemarks(String vAssessmentRemarks) {
		this.vAssessmentRemarks = vAssessmentRemarks;
	}
	public int getvResult() {
		return vResult;
	}
	public void setvResult(int vResult) {
		this.vResult = vResult;
	}
	public int getvCoverageID() {
		return vCoverageID;
	}
	public void setvCoverageID(int vCoverageID) {
		this.vCoverageID = vCoverageID;
	}
	public int getvTypeID() {
		return vTypeID;
	}
	public void setvTypeID(int vTypeID) {
		this.vTypeID = vTypeID;
	}
	public int getvDocumentTypeID() {
		return vDocumentTypeID;
	}
	public void setvDocumentTypeID(int vDocumentTypeID) {
		this.vDocumentTypeID = vDocumentTypeID;
	}
	public String getvDocumentNumber() {
		return vDocumentNumber;
	}
	public void setvDocumentNumber(String vDocumentNumber) {
		this.vDocumentNumber = vDocumentNumber;
	}
	public String getvImageName() {
		return vImageName;
	}
	public void setvImageName(String vImageName) {
		this.vImageName = vImageName;
	}
	public int getvIsAdditionDocument() {
		return vIsAdditionDocument;
	}
	public void setvIsAdditionDocument(int vIsAdditionDocument) {
		this.vIsAdditionDocument = vIsAdditionDocument;
	}
	
}
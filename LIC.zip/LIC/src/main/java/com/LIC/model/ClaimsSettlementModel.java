package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class ClaimsSettlementModel {
	
	@Id
	private String vClaimID;

	private String pClaimID;
	private String pPolicyNumber;
	private String pFirstName;
	private String pLastName;
	private String pAgentCode;
	private String pServiceBranch;

	// private int pClaimID;
	private int pCreatedBy;
	private Date pCreatedOn;
	private int pStatusID;
	private int vAPPLICATIONID;

	//private int pClaimID;

	private int vSerialNo;
	private int vPaymentModeID;
	private Date vPaymentDate;
	private int vBankID;
	private int vBankBranchID;
	private String vChequeNo;
	private Date vChequeDate;
	private int vCardTypeID;
	private String vCardNo;
	private Date vCardExpiryDate;
	private String vCardExpiryMonth;
	private String vCardExpiryYear;
	private float vAmount;
	private String vBankBranchName;
	private String vBankName;
	private String vDescription;
	private String vISFCCode;
	private int vCreatedBy;
	private Date vCreatedOn;
	private int vResult;

	// private int pClaimID;
	
	public String getvClaimID() {
		return vClaimID;
	}
	public void setvClaimID(String vClaimID) {
		this.vClaimID = vClaimID;
	}
	public String getpClaimID() {
		return pClaimID;
	}
	public void setpClaimID(String pClaimID) {
		this.pClaimID = pClaimID;
	}
	public String getpPolicyNumber() {
		return pPolicyNumber;
	}
	public void setpPolicyNumber(String pPolicyNumber) {
		this.pPolicyNumber = pPolicyNumber;
	}
	public String getpFirstName() {
		return pFirstName;
	}
	public void setpFirstName(String pFirstName) {
		this.pFirstName = pFirstName;
	}
	public String getpLastName() {
		return pLastName;
	}
	public void setpLastName(String pLastName) {
		this.pLastName = pLastName;
	}
	public String getpAgentCode() {
		return pAgentCode;
	}
	public void setpAgentCode(String pAgentCode) {
		this.pAgentCode = pAgentCode;
	}
	public String getpServiceBranch() {
		return pServiceBranch;
	}
	public void setpServiceBranch(String pServiceBranch) {
		this.pServiceBranch = pServiceBranch;
	}
	public int getpCreatedBy() {
		return pCreatedBy;
	}
	public void setpCreatedBy(int pCreatedBy) {
		this.pCreatedBy = pCreatedBy;
	}
	public Date getpCreatedOn() {
		return pCreatedOn;
	}
	public void setpCreatedOn(Date pCreatedOn) {
		this.pCreatedOn = pCreatedOn;
	}
	public int getpStatusID() {
		return pStatusID;
	}
	public void setpStatusID(int pStatusID) {
		this.pStatusID = pStatusID;
	}
	public int getvAPPLICATIONID() {
		return vAPPLICATIONID;
	}
	public void setvAPPLICATIONID(int vAPPLICATIONID) {
		this.vAPPLICATIONID = vAPPLICATIONID;
	}
	public int getvSerialNo() {
		return vSerialNo;
	}
	public void setvSerialNo(int vSerialNo) {
		this.vSerialNo = vSerialNo;
	}
	public int getvPaymentModeID() {
		return vPaymentModeID;
	}
	public void setvPaymentModeID(int vPaymentModeID) {
		this.vPaymentModeID = vPaymentModeID;
	}
	public Date getvPaymentDate() {
		return vPaymentDate;
	}
	public void setvPaymentDate(Date vPaymentDate) {
		this.vPaymentDate = vPaymentDate;
	}
	public int getvBankID() {
		return vBankID;
	}
	public void setvBankID(int vBankID) {
		this.vBankID = vBankID;
	}
	public int getvBankBranchID() {
		return vBankBranchID;
	}
	public void setvBankBranchID(int vBankBranchID) {
		this.vBankBranchID = vBankBranchID;
	}
	public String getvChequeNo() {
		return vChequeNo;
	}
	public void setvChequeNo(String vChequeNo) {
		this.vChequeNo = vChequeNo;
	}
	public Date getvChequeDate() {
		return vChequeDate;
	}
	public void setvChequeDate(Date vChequeDate) {
		this.vChequeDate = vChequeDate;
	}
	public int getvCardTypeID() {
		return vCardTypeID;
	}
	public void setvCardTypeID(int vCardTypeID) {
		this.vCardTypeID = vCardTypeID;
	}
	public String getvCardNo() {
		return vCardNo;
	}
	public void setvCardNo(String vCardNo) {
		this.vCardNo = vCardNo;
	}
	public Date getvCardExpiryDate() {
		return vCardExpiryDate;
	}
	public void setvCardExpiryDate(Date vCardExpiryDate) {
		this.vCardExpiryDate = vCardExpiryDate;
	}
	public String getvCardExpiryMonth() {
		return vCardExpiryMonth;
	}
	public void setvCardExpiryMonth(String vCardExpiryMonth) {
		this.vCardExpiryMonth = vCardExpiryMonth;
	}
	public String getvCardExpiryYear() {
		return vCardExpiryYear;
	}
	public void setvCardExpiryYear(String vCardExpiryYear) {
		this.vCardExpiryYear = vCardExpiryYear;
	}
	public float getvAmount() {
		return vAmount;
	}
	public void setvAmount(float vAmount) {
		this.vAmount = vAmount;
	}
	public String getvBankBranchName() {
		return vBankBranchName;
	}
	public void setvBankBranchName(String vBankBranchName) {
		this.vBankBranchName = vBankBranchName;
	}
	public String getvBankName() {
		return vBankName;
	}
	public void setvBankName(String vBankName) {
		this.vBankName = vBankName;
	}
	public String getvDescription() {
		return vDescription;
	}
	public void setvDescription(String vDescription) {
		this.vDescription = vDescription;
	}
	public String getvISFCCode() {
		return vISFCCode;
	}
	public void setvISFCCode(String vISFCCode) {
		this.vISFCCode = vISFCCode;
	}
	public int getvCreatedBy() {
		return vCreatedBy;
	}
	public void setvCreatedBy(int vCreatedBy) {
		this.vCreatedBy = vCreatedBy;
	}
	public Date getvCreatedOn() {
		return vCreatedOn;
	}
	public void setvCreatedOn(Date vCreatedOn) {
		this.vCreatedOn = vCreatedOn;
	}
	public int getvResult() {
		return vResult;
	}
	public void setvResult(int vResult) {
		this.vResult = vResult;
	}
		
}
package com.LIC.model;

import java.io.Serializable;

public class Lookup   implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer lookupId;
	private String lookupName;
	private String lookupValue;
	public Integer getLookupId() {
		return lookupId;
	}
	public void setLookupId(Integer lookupId) {
		this.lookupId = lookupId;
	}
	public String getLookupName() {
		return lookupName;
	}
	public void setLookupName(String lookupName) {
		this.lookupName = lookupName;
	}
	public String getLookupValue() {
		return lookupValue;
	}
	public void setLookupValue(String lookupValue) {
		this.lookupValue = lookupValue;
	}
	
	
	
	
}
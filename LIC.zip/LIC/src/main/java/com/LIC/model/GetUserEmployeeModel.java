package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
public class GetUserEmployeeModel implements Serializable {
	
	private static final long serialVersionUID 			= 1L;
	public static final String GET_USER_EMPLOYEE_MODEL 	= "GetUserEmployeeModel";
	
	
	private long            organisationID;
	private long            branchID;
	private long            departmentID;
	private long 		    gradeID;
	private long 		    designationID;
	private long			employeeID;
	private long			userID;
	private String 		    employeeNo;
	private long            salutationID;
	private String          firstName;
	private String          lastName;
	private String          initial;
	private String 			userName;
	private String 			password;
	private String          gender;
	private int            	maritalStatus;
	private long            reportingTo;
	private Timestamp       dateOfBirth;
	private Timestamp       dateOfJoin;
	private long            reportingTypeID;
	private short           selectAllBranch;
	private long            groupID;
	private long            educationID;
	private String          phoneNo;
	private String          photos;
	private String          mobileNo;
	private String          conferenceNo;
	private String          faxNo;
	private String          email;
	private short           isUnderWriter;
	private long            levelID;
	private String          address;
	private long            createdBy;
	private Timestamp       createdOn;
	private short           employeeIsActive;
	private short           userIsActive;
	private long 			modifiedBy;
	private Timestamp 		modifiedOn;
	private long 			deletedBy;
	private Timestamp 		deletedOn;
	private String          department;
	private String          designation;
	private String          branchName;
	private String          groupName;
	private short 			isAdmin;
	private short 			isSuperUser;
	private long 			userTypeID;
	private short 			userType;
	private int 			selected;
	private Timestamp 		currentLoginTime;
	private String	 		firstLoginTime;
	private Timestamp 		lastLoginTime;
	private long 			lineofBusinessID;
	private String 			name;

	public Timestamp getCurrentLoginTime() {
		return currentLoginTime;
	}
	public String getFirstLoginTime() {
		return firstLoginTime;
	}
	public Timestamp getLastLoginTime() {
		return lastLoginTime;
	}
	public long getLineofBusinessID() {
		return lineofBusinessID;
	}
	public void setCurrentLoginTime(Timestamp currentLoginTime) {
		this.currentLoginTime = currentLoginTime;
	}
	public void setFirstLoginTime(String firstLoginTime) {
		this.firstLoginTime = firstLoginTime;
	}
	public void setLastLoginTime(Timestamp lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	public void setLineofBusinessID(long lineofBusinessID) {
		this.lineofBusinessID = lineofBusinessID;
	}
	public short getEmployeeIsActive() {
		return employeeIsActive;
	}
	public short getUserIsActive() {
		return userIsActive;
	}
	public void setEmployeeIsActive(short employeeIsActive) {
		this.employeeIsActive = employeeIsActive;
	}
	public void setUserIsActive(short userIsActive) {
		this.userIsActive = userIsActive;
	}
	public long getModifiedBy() {
		return modifiedBy;
	}
	public Timestamp getModifiedOn() {
		return modifiedOn;
	}
	public long getDeletedBy() {
		return deletedBy;
	}
	public Timestamp getDeletedOn() {
		return deletedOn;
	}
	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public void setDeletedBy(long deletedBy) {
		this.deletedBy = deletedBy;
	}
	public void setDeletedOn(Timestamp deletedOn) {
		this.deletedOn = deletedOn;
	}
	public String getGender() {
		return gender;
	}
	public int getMaritalStatus() {
		return maritalStatus;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setMaritalStatus(int maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public long getOrganisationID() {
		return organisationID;
	}
	public long getBranchID() {
		return branchID;
	}
	public long getDepartmentID() {
		return departmentID;
	}
	public long getGradeID() {
		return gradeID;
	}
	public long getDesignationID() {
		return designationID;
	}
	public long getEmployeeID() {
		return employeeID;
	}
	public String getEmployeeNo() {
		return employeeNo;
	}
	public long getSalutationID() {
		return salutationID;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getInitial() {
		return initial;
	}
	public long getReportingTo() {
		return reportingTo;
	}
	public Timestamp getDateOfBirth() {
		return dateOfBirth;
	}
	public Timestamp getDateOfJoin() {
		return dateOfJoin;
	}
	public long getReportingTypeID() {
		return reportingTypeID;
	}
	public short getSelectAllBranch() {
		return selectAllBranch;
	}
	public long getGroupID() {
		return groupID;
	}
	public long getEducationID() {
		return educationID;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public String getPhotos() {
		return photos;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public String getConferenceNo() {
		return conferenceNo;
	}
	public String getFaxNo() {
		return faxNo;
	}
	public String getEmail() {
		return email;
	}
	public short getIsUnderWriter() {
		return isUnderWriter;
	}
	public long getLevelID() {
		return levelID;
	}
	public String getAddress() {
		return address;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	
	public void setOrganisationID(long organisationID) {
		this.organisationID = organisationID;
	}
	public void setBranchID(long branchID) {
		this.branchID = branchID;
	}
	public void setDepartmentID(long departmentID) {
		this.departmentID = departmentID;
	}
	public void setGradeID(long gradeID) {
		this.gradeID = gradeID;
	}
	public void setDesignationID(long designationID) {
		this.designationID = designationID;
	}
	public void setEmployeeID(long employeeID) {
		this.employeeID = employeeID;
	}
	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}
	public void setSalutationID(long salutationID) {
		this.salutationID = salutationID;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	public void setReportingTo(long reportingTo) {
		this.reportingTo = reportingTo;
	}
	public void setDateOfBirth(Timestamp dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public void setDateOfJoin(Timestamp dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	public void setReportingTypeID(long reportingTypeID) {
		this.reportingTypeID = reportingTypeID;
	}
	public void setSelectAllBranch(short selectAllBranch) {
		this.selectAllBranch = selectAllBranch;
	}
	public void setGroupID(long groupID) {
		this.groupID = groupID;
	}
	public void setEducationID(long educationID) {
		this.educationID = educationID;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public void setPhotos(String photos) {
		this.photos = photos;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public void setConferenceNo(String conferenceNo) {
		this.conferenceNo = conferenceNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setIsUnderWriter(short isUnderWriter) {
		this.isUnderWriter = isUnderWriter;
	}
	public void setLevelID(long levelID) {
		this.levelID = levelID;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public short getIsAdmin() {
		return isAdmin;
	}
	public void setIsAdmin(short isAdmin) {
		this.isAdmin = isAdmin;
	}
	public short getIsSuperUser() {
		return isSuperUser;
	}
	public void setIsSuperUser(short isSuperUser) {
		this.isSuperUser = isSuperUser;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getUserTypeID() {
		return userTypeID;
	}
	public void setUserTypeID(long userTypeID) {
		this.userTypeID = userTypeID;
	}
	public short getUserType() {
		return userType;
	}
	public void setUserType(short userType) {
		this.userType = userType;
	}
	public int getSelected() {
		return selected;
	}
	public void setSelected(int selected) {
		this.selected = selected;
	}
	public long getUserID() {
		return userID;
	}
	public void setUserID(long userID) {
		this.userID = userID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}


package com.LIC.model;

import java.io.Serializable;

public class State extends RecordModifier  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer stateId;
	private Integer countryId;
	private String description;
	private String tinNumber; 
	private String remarks;
	private Integer isDeclined;
	  
	
	public Integer getStateId() {
		return stateId;
	}
	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTinNumber() {
		return tinNumber;
	}
	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}
	public Integer getIsDeclined() {
		return isDeclined;
	}
	public void setIsDeclined(Integer isDeclined) {
		this.isDeclined = isDeclined;
	}
	public String getRemarks() {
		if(null == remarks) {
			remarks = "";
		}
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	} 
	
}

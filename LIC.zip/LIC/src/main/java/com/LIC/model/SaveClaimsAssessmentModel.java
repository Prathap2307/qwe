package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

/*
 * @Author = "671621"
 */
@Entity
public class SaveClaimsAssessmentModel {

	@Id
	private int vClaimID;
	private int vCoverageID;
	private int vTypeID;
	private String vPolicyNumber;
	private Date vDateOfLoss;
	private int vLineOfBusinessID;
	private String vTimeOfLoss;
	private String vPlaceOfLoss;
	private String vParticularsOfDeath;
	private String vDoctorNameAndAddress;
	private int vPartialAdvanceClaimPayment;
	private int vCreatedBy;
	private Date vCreatedOn;
	private int vIsActive;
	private int vIsAdditionalDcoument;
	private int vStatusID;
	private String vAssessmentRemarks;
	private int vDocumentTypeID;
	private String vDocumentNumber;
	private String vImageName;
	private int vIsAdditionDocument;

	public SaveClaimsAssessmentModel() {

	}

	public int getvClaimID() {
		return vClaimID;
	}

	public void setvClaimID(int vClaimID) {
		this.vClaimID = vClaimID;
	}

	public int getvCoverageID() {
		return vCoverageID;
	}

	public void setvCoverageID(int vCoverageID) {
		this.vCoverageID = vCoverageID;
	}

	public int getvTypeID() {
		return vTypeID;
	}

	public void setvTypeID(int vTypeID) {
		this.vTypeID = vTypeID;
	}

	public String getvPolicyNumber() {
		return vPolicyNumber;
	}

	public void setvPolicyNumber(String vPolicyNumber) {
		this.vPolicyNumber = vPolicyNumber;
	}

	public Date getvDateOfLoss() {
		return vDateOfLoss;
	}

	public void setvDateOfLoss(Date vDateOfLoss) {
		this.vDateOfLoss = vDateOfLoss;
	}

	public int getvLineOfBusinessID() {
		return vLineOfBusinessID;
	}

	public void setvLineOfBusinessID(int vLineOfBusinessID) {
		this.vLineOfBusinessID = vLineOfBusinessID;
	}

	public String getvTimeOfLoss() {
		return vTimeOfLoss;
	}

	public void setvTimeOfLoss(String vTimeOfLoss) {
		this.vTimeOfLoss = vTimeOfLoss;
	}

	public String getvPlaceOfLoss() {
		return vPlaceOfLoss;
	}

	public void setvPlaceOfLoss(String vPlaceOfLoss) {
		this.vPlaceOfLoss = vPlaceOfLoss;
	}

	public String getvParticularsOfDeath() {
		return vParticularsOfDeath;
	}

	public void setvParticularsOfDeath(String vParticularsOfDeath) {
		this.vParticularsOfDeath = vParticularsOfDeath;
	}

	public String getvDoctorNameAndAddress() {
		return vDoctorNameAndAddress;
	}

	public void setvDoctorNameAndAddress(String vDoctorNameAndAddress) {
		this.vDoctorNameAndAddress = vDoctorNameAndAddress;
	}

	public int getvPartialAdvanceClaimPayment() {
		return vPartialAdvanceClaimPayment;
	}

	public void setvPartialAdvanceClaimPayment(int vPartialAdvanceClaimPayment) {
		this.vPartialAdvanceClaimPayment = vPartialAdvanceClaimPayment;
	}

	public int getvCreatedBy() {
		return vCreatedBy;
	}

	public void setvCreatedBy(int vCreatedBy) {
		this.vCreatedBy = vCreatedBy;
	}

	public Date getvCreatedOn() {
		return vCreatedOn;
	}

	public void setvCreatedOn(Date vCreatedOn) {
		this.vCreatedOn = vCreatedOn;
	}

	public int getvIsActive() {
		return vIsActive;
	}

	public void setvIsActive(int vIsActive) {
		this.vIsActive = vIsActive;
	}

	public int getvIsAdditionalDcoument() {
		return vIsAdditionalDcoument;
	}

	public void setvIsAdditionalDcoument(int vIsAdditionalDcoument) {
		this.vIsAdditionalDcoument = vIsAdditionalDcoument;
	}

	public int getvStatusID() {
		return vStatusID;
	}

	public void setvStatusID(int vStatusID) {
		this.vStatusID = vStatusID;
	}

	public String getvAssessmentRemarks() {
		return vAssessmentRemarks;
	}

	public void setvAssessmentRemarks(String vAssessmentRemarks) {
		this.vAssessmentRemarks = vAssessmentRemarks;
	}

	public int getvDocumentTypeID() {
		return vDocumentTypeID;
	}

	public void setvDocumentTypeID(int vDocumentTypeID) {
		this.vDocumentTypeID = vDocumentTypeID;
	}

	public String getvDocumentNumber() {
		return vDocumentNumber;
	}

	public void setvDocumentNumber(String vDocumentNumber) {
		this.vDocumentNumber = vDocumentNumber;
	}

	public String getvImageName() {
		return vImageName;
	}

	public void setvImageName(String vImageName) {
		this.vImageName = vImageName;
	}

	public int getvIsAdditionDocument() {
		return vIsAdditionDocument;
	}

	public void setvIsAdditionDocument(int vIsAdditionDocument) {
		this.vIsAdditionDocument = vIsAdditionDocument;
	}

}

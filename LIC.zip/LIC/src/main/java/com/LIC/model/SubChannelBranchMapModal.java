package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class SubChannelBranchMapModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	 
	    private long  id;
	    private long  subChannelID ;
	    private long  BbanchID ;
	    private long  creaetedBy ;
	    private Timestamp  createdOn ;
		
		public long getSubChannelID() {
			return subChannelID;
		}
		public void setSubChannelID(long subChannelID) {
			this.subChannelID = subChannelID;
		}
		public long getBbanchID() {
			return BbanchID;
		}
		public void setBbanchID(long bbanchID) {
			BbanchID = bbanchID;
		}
		public long getCreaetedBy() {
			return creaetedBy;
		}
		public void setCreaetedBy(long creaetedBy) {
			this.creaetedBy = creaetedBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
}

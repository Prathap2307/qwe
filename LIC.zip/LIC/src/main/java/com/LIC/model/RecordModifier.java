package com.LIC.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.LIC.utils.DateUtil;


public class RecordModifier implements Serializable {	

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private	Date createdOn;
	@JsonIgnore
	private	Date modifiedOn;
	@JsonIgnore
	private	Date deletedOn;
	private Integer createdBy;
	@JsonIgnore
	private Integer modifiedBy;
	@JsonIgnore
	private	Integer deletedBy;
	private Integer isActive;
	private String createdOnStr;
	private String modifiedOnStr;
	private String deletedOnStr;
	private String createdByStr;
	private String modifiedByStr;
	private String deletedByStr;
	
	
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	
	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	
	public Date getDeletedOn() {
		return deletedOn;
	}

	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}

	
	@Column(name="CreatedBy")
	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	
	
	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	
	public Integer getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(Integer deletedBy) {
		this.deletedBy = deletedBy;
	}

	
	
	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}
	
	public String getCreatedOnStr() {
		if(null != createdOnStr) {
			createdOnStr = DateUtil.getViewDateFormat(createdOnStr);
		}else {
			createdOnStr = "";
		}
		return createdOnStr;
	}
	
	public void setCreatedOnStr(String createdOnStr) {
		this.createdOnStr = createdOnStr;
	}
	
	public String getModifiedOnStr() {
		if(null != modifiedOnStr) {
			modifiedOnStr = DateUtil.getViewDateFormat(modifiedOnStr);
		}else {
			modifiedOnStr = "";
		}
		return modifiedOnStr;
	}
	public void setModifiedOnStr(String modifiedOnStr) {
		this.modifiedOnStr = modifiedOnStr;
	}
	
	public String getCreatedByStr() {
		if(null != createdBy) {
			createdByStr = "Some User";
		}else {
			createdByStr = "";
		}
		return createdByStr;
	}
	public void setCreatedByStr(String createdByStr) {
		this.createdByStr = createdByStr;
	}
	
	public String getModifiedByStr() {
		if(null != modifiedBy) {
			modifiedByStr = "Some User";
		}else {
			modifiedByStr = "";
		}
		return modifiedByStr;
	}
	public void setModifiedByStr(String modifiedByStr) {
		this.modifiedByStr = modifiedByStr;
	}

	public String getDeletedOnStr() {
		if(null != deletedOnStr) {
			deletedOnStr = DateUtil.getViewDateFormat(deletedOnStr);
		}else {
			deletedOnStr = "";
		}
		return deletedOnStr;
	}

	public void setDeletedOnStr(String deletedOnStr) {
		this.deletedOnStr = deletedOnStr;
	}

	public String getDeletedByStr() {
		if(null != deletedByStr) {
			deletedByStr = "Some User";
		}else {
			deletedByStr = "";
		}
		return deletedByStr;
	}

	public void setDeletedByStr(String deletedByStr) {
		this.deletedByStr = deletedByStr;
	}
	
}

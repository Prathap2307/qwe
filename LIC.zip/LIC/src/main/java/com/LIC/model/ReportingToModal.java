package com.LIC.model;

public class ReportingToModal {
	
	private String description;
	
	private long ID;

	public String getDescription() {
		return description;
	}

	public long getID() {
		return ID;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setID(long ID) {
		this.ID = ID;
	}

	@Override
	public String toString() {
		return "ReportingTo [description=" + description + ", ID=" + ID + "]";
	}
	
	

}

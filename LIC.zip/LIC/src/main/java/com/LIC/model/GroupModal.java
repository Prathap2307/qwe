package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class GroupModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	 
	    private long 		groupID;
	    private long 		organisationID;
	    private long 		userID;
		private String 		groupName;
		private long 		createdBy;
		private Timestamp 	createdOn;
		private long 		modifiedBy;
		private Timestamp 	modifiedOn;
		private long 		deletedBy;
		private Timestamp 	deletedOn;
		private short 		isActive;
		private List<GetLOBUsers>	userModalList;
		
		public long getGroupID() {
			return groupID;
		}
		public void setGroupID(long groupID) {
			this.groupID = groupID;
		}
		public long getOrganisationID() {
			return organisationID;
		}
		public void setOrganisationID(long organisationID) {
			this.organisationID = organisationID;
		}
		public long getUserID() {
			return userID;
		}
		public void setUserID(long userID) {
			this.userID = userID;
		}
		public String getGroupName() {
			return groupName;
		}
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public List<GetLOBUsers> getUserModalList() {
			return userModalList;
		}
		public void setUserModalList(List<GetLOBUsers> userModalList) {
			this.userModalList = userModalList;
		}
	   
}


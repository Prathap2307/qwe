package com.LIC.model;

import java.io.Serializable;
import java.sql.Date;

public class MasterGrade implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer organisationId;		
		private int gradeId;
		private String description;
		private String createdBy;
		private Date createdOn;
		private Integer isActive;
		private int groupId;
			public int getGroupId() {
			return groupId;
		}
		public void setGroupId(int groupId) {
			this.groupId = groupId;
		}
		public Integer getOrganisationId() {
			return organisationId;
		}
		public void setOrganisationId(Integer organisationId) {
			this.organisationId = organisationId;
		}
		public int getGradeId() {
			return gradeId;
		}
		public void setGradeId(int gradeId) {
			this.gradeId = gradeId;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}
		public Date getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Date createdOn) {
			this.createdOn = createdOn;
		}
		public Integer getIsActive() {
			return isActive;
		}
		public void setIsActive(Integer isActive) {
			this.isActive = isActive;
		}
		@Override
		public String toString() {
			return "MasterGrade [organisationId=" + organisationId + ", gradeId=" + gradeId + ", description="
					+ description + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", isActive=" + isActive
					+ ", groupId=" + groupId + "]";
		}
		
		
		
	    }

package com.LIC.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;


@NamedStoredProcedureQuery(name = "createOrUpdateGrade", procedureName = "spInsertOrUpdateGrade", parameters = {

		
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "p_OrganisationID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "p_GradeID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "p_Description", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "p_CreatedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.REF_CURSOR, name = "cur", type = Class.class)} ,resultClasses = GradeModel.class)
		


@NamedStoredProcedureQuery(name = "deleteGrade", procedureName = "spDeleteGrade", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vGradeID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDELETEDBY", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDELETEDON", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "RESULT1", type = String.class)}, resultClasses = GradeModel.class)



@Entity
@Table(name="master_grade")
public class GradeModel {
	@Id
    private int gradeId;
	private int  organisationId;
	private String description;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	private int deletedBy;
	private Date deletedOn;
	
	private int isActive;
	public int getGradeId() {
		return gradeId;
	}
	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}
	public int getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(int organisationId) {
		this.organisationId = organisationId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	
	
	
	
	
	
	

}





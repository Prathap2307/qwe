package com.LIC.model;

import java.io.Serializable;

public class PremiumPaymentFrequency extends RecordModifier implements Serializable {
		
    private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer planID;
	private Integer premPaymentFrequencyID;
	private Integer gracePeriod;
	private Integer noticePeriod;
	private Double modalFactor;
	private String dispPlanName;
	private String dispPaymentFrequencyName;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getPlanID() {
		return planID;
	}
	public void setPlanID(Integer planID) {
		this.planID = planID;
	}
	 
	public Integer getPremPaymentFrequencyID() {
		return premPaymentFrequencyID;
	}
	public void setPremPaymentFrequencyID(Integer premPaymentFrequencyID) {
		this.premPaymentFrequencyID = premPaymentFrequencyID;
	}
	public Integer getGracePeriod() {
		return gracePeriod;
	}
	public void setGracePeriod(Integer gracePeriod) {
		this.gracePeriod = gracePeriod;
	}
	public Integer getNoticePeriod() {
		return noticePeriod;
	}
	public void setNoticePeriod(Integer noticePeriod) {
		this.noticePeriod = noticePeriod;
	}
	public Double getModalFactor() {
		return modalFactor;
	}
	public void setModalFactor(Double modalFactor) {
		this.modalFactor = modalFactor;
	}
	public String getDispPlanName() {
		return dispPlanName;
	}
	public void setDispPlanName(String dispPlanName) {
		this.dispPlanName = dispPlanName;
	}
	public String getDispPaymentFrequencyName() {
		return dispPaymentFrequencyName;
	}
	public void setDispPaymentFrequencyName(String dispPaymentFrequencyName) {
		this.dispPaymentFrequencyName = dispPaymentFrequencyName;
	}
	 
}

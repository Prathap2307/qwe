package com.LIC.model;

public class ClaimsCauseOFDeathModel {

	private Number id;

	public Number getId() {
		return id;
	}

	public void setId(Number id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ClaimsCauseOFDeathModel(Number id, String description) {
		super();
		this.id = id;
		this.description = description;
	}

	private String description;

}

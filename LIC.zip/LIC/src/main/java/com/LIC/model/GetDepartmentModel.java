package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_DEPARTMENT")
public class GetDepartmentModel {
	
	@Id
	private Number departmentId;
	
	private String shortName;
	private String description;
	private Number isActive;
	public Number getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Number departmentId) {
		this.departmentId = departmentId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public Number getIsActive() {
		return isActive;
	}
	public void setIsActive(Number isActive) {
		this.isActive = isActive;
	}
	public GetDepartmentModel(Number departmentId, String shortName, String description, Number isActive) {
		
		this.departmentId = departmentId;
		this.shortName = shortName;
		this.description = description;
		this.isActive = isActive;
	}
	public GetDepartmentModel() {
		super();
	}
	
	
	
	
	
}


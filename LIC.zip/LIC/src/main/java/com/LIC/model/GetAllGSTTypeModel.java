package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetAllGSTTypeModel {
@Id

private Number gstTypeID;
private String gstType;

public GetAllGSTTypeModel(Number gstTypeID, String gstType) {
	super();
	this.gstTypeID = gstTypeID;
	this.gstType = gstType;
}

public Number getGstTypeID() {
	return gstTypeID;
}
public void setGstTypeID(Number gstTypeID) {
	this.gstTypeID = gstTypeID;
}
public String getGstType() {
	return gstType;
}
public void setGstType(String gstType) {
	this.gstType = gstType;
}


}

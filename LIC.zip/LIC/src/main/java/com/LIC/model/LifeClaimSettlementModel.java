package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
public class LifeClaimSettlementModel implements Serializable{

	private static final long serialVersionUID = 1L;
	public static final String LIFE_CLAIM_SETTLEMENT_MODEL = "LifeClaimSettlementModel";
	
	
	private long 			settlementID;
	private long 			claimID;
	private long 			serialNo;
	private long 			paymentModeID; 
	private Timestamp 		paymentDate; 
	private long 			bankID; 
	private long 			bankBranchID; 
	private String 			bankBranchName; 
	private String 			chequeNo; 
	private Timestamp 		chequeDate;
	private long 			cardTypeID; 
	private String 			cardNo; 
	private Timestamp 		cardExpiryDate; 
	private String 			cardExpiryMonth; 
	private String 			cardExpiryYear; 
	private double 			amount; 
	private String 			bankName; 
	private String 			description;
	private long 			createdBy; 
	private Timestamp 		createdOn; 
	private long 			applicationID; 
	private long 			statusID; 
	private String 			iSFCCode;
	
	
	public long getSettlementID() {
		return settlementID;
	}
	public void setSettlementID(long settlementID) {
		this.settlementID = settlementID;
	}
	public long getClaimID() {
		return claimID;
	}
	public void setClaimID(long claimID) {
		this.claimID = claimID;
	}
	public long getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(long serialNo) {
		this.serialNo = serialNo;
	}
	public long getPaymentModeID() {
		return paymentModeID;
	}
	public void setPaymentModeID(long paymentModeID) {
		this.paymentModeID = paymentModeID;
	}
	public Timestamp getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Timestamp paymentDate) {
		this.paymentDate = paymentDate;
	}
	public long getBankID() {
		return bankID;
	}
	public void setBankID(long bankID) {
		this.bankID = bankID;
	}
	public long getBankBranchID() {
		return bankBranchID;
	}
	public void setBankBranchID(long bankBranchID) {
		this.bankBranchID = bankBranchID;
	}
	public String getBankBranchName() {
		return bankBranchName;
	}
	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public Timestamp getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Timestamp chequeDate) {
		this.chequeDate = chequeDate;
	}
	public long getCardTypeID() {
		return cardTypeID;
	}
	public void setCardTypeID(long cardTypeID) {
		this.cardTypeID = cardTypeID;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public Timestamp getCardExpiryDate() {
		return cardExpiryDate;
	}
	public void setCardExpiryDate(Timestamp cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	public String getCardExpiryMonth() {
		return cardExpiryMonth;
	}
	public void setCardExpiryMonth(String cardExpiryMonth) {
		this.cardExpiryMonth = cardExpiryMonth;
	}
	public String getCardExpiryYear() {
		return cardExpiryYear;
	}
	public void setCardExpiryYear(String cardExpiryYear) {
		this.cardExpiryYear = cardExpiryYear;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public long getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(long applicationID) {
		this.applicationID = applicationID;
	}
	public long getStatusID() {
		return statusID;
	}
	public void setStatusID(long statusID) {
		this.statusID = statusID;
	}
	public String getiSFCCode() {
		return iSFCCode;
	}
	public void setiSFCCode(String iSFCCode) {
		this.iSFCCode = iSFCCode;
	}
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
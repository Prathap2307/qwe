package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class SalesCategoryModal  implements Serializable {
	
	private static final long serialVersionUID = 1L;
	 
	    private long 		 	categoryID;
	    private String 		 	description;
	    private String       	code;
	    private String      	channelName;
	    private String       	channelCode;
	    private long 		 	createdBy;
	    private Timestamp 		createdOn; 
	    private long 		 	modifiedBy;
	    private Timestamp 	 	modifiedOn;
	    private short 		 	isActive;
	    private long         	deletedBy;
	    private Timestamp   	deletedOn;
	    
	
		public long getCategoryID() {
			return categoryID;
		}
		public void setCategoryID(long categoryID) {
			this.categoryID = categoryID;
		}
		public String getDescription() {
			return description;
		}
		public String getCode() {
			return code;
		}
		public String getChannelName() {
			return channelName;
		}
		public String getChannelCode() {
			return channelCode;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public void setChannelName(String channelName) {
			this.channelName = channelName;
		}
		public void setChannelCode(String channelCode) {
			this.channelCode = channelCode;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
	    
}

package com.LIC.model;

import java.sql.Date;

public class ApplicationPremiumDetails {
	
	private int premiumId;
	public int getPremiumId() {
		return premiumId;
	}
	public void setPremiumId(int premiumId) {
		this.premiumId = premiumId;
	}
	private int organisationID  ;  
	 private long partyID;
	private int serialNo   ;  
	 private int paymentModeID;  
	 private Date paymentDate        ;  
	 private int bankID    ;  
	    private int bankBranchID ;  
	 private String chequeNo ;    
	 private Date chequeDate   ;  
	 private int cardTypeID   ;  
	 private String cardNo ;     
	    private Date cardExpiryDate  ;  
	 private String cardExpiryMonth ;  
	 private String cardExpiryYear   ; 
	 private int amount    ;  
	 private String bankBranchName   ; 
	 private String bankName; 
	 private String paymentType;
	 
	 private String instrumentNumber;
	 public String getInstrumentNumber() {
		return instrumentNumber;
	}
	public void setInstrumentNumber(String instrumentNumber) {
		this.instrumentNumber = instrumentNumber;
	}
	public Date getInstrumentDate() {
		return instrumentDate;
	}
	public void setInstrumentDate(Date instrumentDate) {
		this.instrumentDate = instrumentDate;
	}
	private Date instrumentDate;
	 
	 
	 public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public int getOrganisationID() {
		return organisationID;
	}
	public void setOrganisationID(int organisationID) {
		this.organisationID = organisationID;
	}
	public long getPartyID() {
		return partyID;
	}
	public void setPartyID(long partyID) {
		this.partyID = partyID;
	}
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	public int getPaymentModeID() {
		return paymentModeID;
	}
	public void setPaymentModeID(int paymentModeID) {
		this.paymentModeID = paymentModeID;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public int getBankID() {
		return bankID;
	}
	public void setBankID(int bankID) {
		this.bankID = bankID;
	}
	public int getBankBranchID() {
		return bankBranchID;
	}
	public void setBankBranchID(int bankBranchID) {
		this.bankBranchID = bankBranchID;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}
	public int getCardTypeID() {
		return cardTypeID;
	}
	public void setCardTypeID(int cardTypeID) {
		this.cardTypeID = cardTypeID;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public Date getCardExpiryDate() {
		return cardExpiryDate;
	}
	public void setCardExpiryDate(Date cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	public String getCardExpiryMonth() {
		return cardExpiryMonth;
	}
	public void setCardExpiryMonth(String cardExpiryMonth) {
		this.cardExpiryMonth = cardExpiryMonth;
	}
	public String getCardExpiryYear() {
		return cardExpiryYear;
	}
	public void setCardExpiryYear(String cardExpiryYear) {
		this.cardExpiryYear = cardExpiryYear;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getBankBranchName() {
		return bankBranchName;
	}
	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public int getAuthCode() {
		return authCode;
	}
	public void setAuthCode(int authCode) {
		this.authCode = authCode;
	}
	public int getReceiptID() {
		return receiptID;
	}
	public void setReceiptID(int receiptID) {
		this.receiptID = receiptID;
	}
	public String getSubReceiptNo() {
		return subReceiptNo;
	}
	public void setSubReceiptNo(String subReceiptNo) {
		this.subReceiptNo = subReceiptNo;
	}
	public int getChequeBounceAmount() {
		return chequeBounceAmount;
	}
	public void setChequeBounceAmount(int chequeBounceAmount) {
		this.chequeBounceAmount = chequeBounceAmount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getPathName() {
		return pathName;
	}
	public void setPathName(String pathName) {
		this.pathName = pathName;
	}
	public long getMasterPolicyID() {
		return masterPolicyID;
	}
	public void setMasterPolicyID(long masterPolicyID) {
		this.masterPolicyID = masterPolicyID;
	}
	public int getTypeID() {
		return typeID;
	}
	public void setTypeID(int typeID) {
		this.typeID = typeID;
	}
	public int getIsAffinity() {
		return isAffinity;
	}
	public void setIsAffinity(int isAffinity) {
		this.isAffinity = isAffinity;
	}
	private int authCode   ;  
	 private int receiptID   ;  
	 private String subReceiptNo ;        
	 private int chequeBounceAmount ;    
	 private String description ;    
	 private int createdBy   ;  
	 private Date createdOn   ;  
	 private String fileName   ;
	 private String pathName   ;
	 private long masterPolicyID ;  
	 private int typeID ;    
	 private int isAffinity ;  
}

package com.LIC.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

@NamedStoredProcedureQuery(name = "createOrUpdateDep", procedureName = "spInsertOrUpdateDepartment", parameters = {

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDepartmentID", type = Integer.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vShortName", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDescription", type = String.class),

		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pCreatedBy", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pCreatedOn", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pIsActive", type = Integer.class)}, resultClasses = DepartmentModel.class)
		

@NamedStoredProcedureQuery(name = "deleteDep", procedureName = "spDeleteDepartment ", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "vDepartmentID", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pDELETEDBY", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pDELETEDON", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.OUT, name = "pRESULT", type = String.class)}, resultClasses = DepartmentModel.class)






@Entity
@Table(name="MASTER_DEPARTMENT")
public class DepartmentModel {
	@Id
	private int departmentId;
	private String shortName;
	private String description;
	private Date deletedOn;
	private int deletedBy;
	private int isActive;
	private int createdBy;
	private Date createdOn;
	private int modifiedBy;
	private Date modifiedOn;
	
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public Date getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(int deletedBy) {
		this.deletedBy = deletedBy;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	
	
	

}

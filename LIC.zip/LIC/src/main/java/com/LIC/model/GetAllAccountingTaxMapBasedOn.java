package com.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GetAllAccountingTaxMapBasedOn {
	@Id
	private Number BasedOnID;
	private String BasedOn;

	public GetAllAccountingTaxMapBasedOn(Number basedOnID, String basedOn) {
		super();
		BasedOnID = basedOnID;
		BasedOn = basedOn;
	}
	
	public Number getBasedOnID() {
		return BasedOnID;
	}
	public void setBasedOnID(Number basedOnID) {
		BasedOnID = basedOnID;
	}
	public String getBasedOn() {
		return BasedOn;
	}
	public void setBasedOn(String basedOn) {
		BasedOn = basedOn;
	}
	
	

}

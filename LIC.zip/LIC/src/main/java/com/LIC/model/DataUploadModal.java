package com.LIC.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class DataUploadModal implements Serializable {

	private static final long serialVersionUID = 1L;
	  private String pageName;
	  private String pileName;
	  private String fileName;
	  private long   lineOfBusinessID;
	  private long   typeID;
	  private long	 createdBy;
	  private Timestamp createdOn;
	  private long      groupID;
	  private long      productID;
	  private long      quotationID;
	  private long      masterPolicyID;
	  private Timestamp fromDate;
	  private Timestamp toDate;
	  private long      	masterPolicyAgreementID;
	  private long      	statusID;
	  private long      	headerID;
	  private short      	isPolicyIssuance;
	  private String       	status;
	  private long       	processID;
	  
	public short getIsPolicyIssuance() {
		return isPolicyIssuance;
	}
	public String getStatus() {
		return status;
	}
	public long getProcessID() {
		return processID;
	}
	public void setIsPolicyIssuance(short isPolicyIssuance) {
		this.isPolicyIssuance = isPolicyIssuance;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setProcessID(long processID) {
		this.processID = processID;
	}  
	public long getStatusID() {
		return statusID;
	}
	public long getHeaderID() {
		return headerID;
	}
	public void setStatusID(long statusID) {
		this.statusID = statusID;
	}
	public void setHeaderID(long headerID) {
		this.headerID = headerID;
	}
	public long getMasterPolicyAgreementID() {
		return masterPolicyAgreementID;
	}
	public void setMasterPolicyAgreementID(long masterPolicyAgreementID) {
		this.masterPolicyAgreementID = masterPolicyAgreementID;
	}
	public Timestamp getFromDate() {
		return fromDate;
	}
	public void setFromDate(Timestamp fromDate) {
		this.fromDate = fromDate;
	}
	public Timestamp getToDate() {
		return toDate;
	}
	public void setToDate(Timestamp toDate) {
		this.toDate = toDate;
	}
	public long getQuotationID() {
		return quotationID;
	}
	public void setQuotationID(long quotationID) {
		this.quotationID = quotationID;
	}
	public long getMasterPolicyID() {
		return masterPolicyID;
	}
	public void setMasterPolicyID(long masterPolicyID) {
		this.masterPolicyID = masterPolicyID;
	}
	public long getGroupID() {
		return groupID;
	}
	public long getProductID() {
		return productID;
	}
	public void setGroupID(long groupID) {
		this.groupID = groupID;
	}
	public void setProductID(long productID) {
		this.productID = productID;
	}
	public String getFileName() {
		return fileName;
	}
	public long getLineOfBusinessID() {
		return lineOfBusinessID;
	}
	public long getTypeID() {
		return typeID;
	}
	public long getCreatedBy() {
		return createdBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setLineOfBusinessID(long lineOfBusinessID) {
		this.lineOfBusinessID = lineOfBusinessID;
	}
	public void setTypeID(long typeID) {
		this.typeID = typeID;
	}
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public String getPageName() {
		return pageName;
	}
	public String getPileName() {
		return pileName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public void setPileName(String pileName) {
		this.pileName = pileName;
	}
}

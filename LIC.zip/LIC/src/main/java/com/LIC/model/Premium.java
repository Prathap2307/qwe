package com.LIC.model;

import java.io.Serializable;

public class Premium extends RecordModifier implements Serializable {
		
    private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer variantId;
	private Integer variantPremiumTypeId;
	private Integer benefitRiderId;
	private Integer processID;
	private Integer amountTypeId;
	private String ruleSetName;
	private Double premiumValue;
	private PremiumDetailsMap premiumDetailsMap;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVariantId() {
		return variantId;
	}
	public void setVariantId(Integer variantId) {
		this.variantId = variantId;
	}
	public Integer getVariantPremiumTypeId() {
		return variantPremiumTypeId;
	}
	public void setVariantPremiumTypeId(Integer variantPremiumTypeId) {
		this.variantPremiumTypeId = variantPremiumTypeId;
	}
	public Integer getBenefitRiderId() {
		return benefitRiderId;
	}
	public void setBenefitRiderId(Integer benefitRiderId) {
		this.benefitRiderId = benefitRiderId;
	}

	public String getRuleSetName() {
		return ruleSetName;
	}
	public void setRuleSetName(String ruleSetName) {
		this.ruleSetName = ruleSetName;
	}
	public Double getPremiumValue() {
		return premiumValue;
	}
	public void setPremiumValue(Double premiumValue) {
		this.premiumValue = premiumValue;
	}
	
	
	public PremiumDetailsMap getPremiumDetailsMap() {
		return premiumDetailsMap;
	}
	public void setPremiumDetailsMap(PremiumDetailsMap premiumDetailsMap) {
		this.premiumDetailsMap = premiumDetailsMap;
	}
	public Integer getProcessID() {
		return processID;
	}
	public void setProcessID(Integer processID) {
		this.processID = processID;
	}
	public Integer getAmountTypeId() {
		return amountTypeId;
	}
	public void setAmountTypeId(Integer amountTypeId) {
		this.amountTypeId = amountTypeId;
	}
	@Override
	public String toString() {
		return "Premium [id=" + id + ", variantId=" + variantId + ", variantPremiumTypeId=" + variantPremiumTypeId
				+ ", benefitRiderId=" + benefitRiderId + ", processID=" + processID + ", amountTypeId=" + amountTypeId
				+ ", ruleSetName=" + ruleSetName + ", premiumValue=" + premiumValue + ", premiumDetailsMap="
				+ premiumDetailsMap + "]";
	}
	
	 
}


package com.LIC.model;

import java.io.Serializable;

import com.LIC.model.RecordModifier;
public class ProductFrequencyMap extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer id;
	private Integer productID;
	private Integer frequencyId;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public Integer getFrequencyId() {
		return frequencyId;
	}
	public void setFrequencyId(Integer frequencyId) {
		this.frequencyId = frequencyId;
	}
	
	
}

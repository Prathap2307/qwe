

package com.LIC.model;

import java.io.Serializable;


public class ProductType extends RecordModifier implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Integer productTypeId;
	private String description; 
	private Integer lineBusinessId;
	
	
	public Integer getProductTypeId() {
		return productTypeId;
	}
	public void setProductTypeId(Integer productTypeId) {
		this.productTypeId = productTypeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getLineBusinessId() {
		return lineBusinessId;
	}
	public void setLineBusinessId(Integer lineBusinessId) {
		this.lineBusinessId = lineBusinessId;
	}
	
	
}
	
	 

package com.LIC.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;


public class ClaimsIntimationModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private Number vID;
	private Number vLineofBusinesId;
	private Number vTypeID;
	private String vClaimID;
	private Date vDateOfInitmation;

	private Date vDateOfRegistration;
	private Date vDateOfDeath;
	private Number vCauseOfDeathID;
	private String vDeathOfMemberOrSpouseID;
	private BigDecimal vMPHPayment;
	private BigDecimal vNomineePayment;
	private BigDecimal vTotalAmount;
	private String vAccountNumber;
	private String vInvoiceNumber;
	private Date vInvoiceDate;
	private String vDIR;
	private String vCSIP;
	private String vPincode;
	private String vNomineePhoneNumber;
	private Date vDateOfLoss;
	private BigDecimal vReservedAmount;
	private Number vApplicationID;
	private Number vGroupTypeID;
	private Number vCreatedBy;
	private Date vCreatedOn;
	private Number vInsuredID;
	private String vClaimReportedBy;
	private Number vRelationshipID;
	private String vDescription;
	private Number vSalutationID;
	private String vPolicyNumber;
	private String vBeneficiaryName;
	private Number vIsExistingInjuryDisablility;
	private String curOut;

	public String getCurOut() {
		return curOut;
	}

	public void setCurOut(String curOut) {
		this.curOut = curOut;
	}

	public Number getvID() {
		return vID;
	}

	public void setvID(Number vID) {
		this.vID = vID;
	}

	public Number getvLineofBusinesId() {
		return vLineofBusinesId;
	}

	public void setvLineofBusinesId(Number vLineofBusinesId) {
		this.vLineofBusinesId = vLineofBusinesId;
	}

	public Number getvTypeID() {
		return vTypeID;
	}

	public void setvTypeID(Number vTypeID) {
		this.vTypeID = vTypeID;
	}

	public String getvClaimID() {
		return vClaimID;
	}

	public void setvClaimID(String vClaimID) {
		this.vClaimID = vClaimID;
	}

	public Date getvDateOfInitmation() {
		return vDateOfInitmation;
	}

	public void setvDateOfInitmation(Date vDateOfInitmation) {
		this.vDateOfInitmation = vDateOfInitmation;
	}

	public Date getvDateOfRegistration() {
		return vDateOfRegistration;
	}

	public void setvDateOfRegistration(Date vDateOfRegistration) {
		this.vDateOfRegistration = vDateOfRegistration;
	}

	public Date getvDateOfDeath() {
		return vDateOfDeath;
	}

	public void setvDateOfDeath(Date vDateOfDeath) {
		this.vDateOfDeath = vDateOfDeath;
	}

	public Number getvCauseOfDeathID() {
		return vCauseOfDeathID;
	}

	public void setvCauseOfDeathID(Number vCauseOfDeathID) {
		this.vCauseOfDeathID = vCauseOfDeathID;
	}

	public String getvDeathOfMemberOrSpouseID() {
		return vDeathOfMemberOrSpouseID;
	}

	public void setvDeathOfMemberOrSpouseID(String vDeathOfMemberOrSpouseID) {
		this.vDeathOfMemberOrSpouseID = vDeathOfMemberOrSpouseID;
	}

	public BigDecimal getvMPHPayment() {
		return vMPHPayment;
	}

	public void setvMPHPayment(BigDecimal vMPHPayment) {
		this.vMPHPayment = vMPHPayment;
	}

	public BigDecimal getvNomineePayment() {
		return vNomineePayment;
	}

	public void setvNomineePayment(BigDecimal vNomineePayment) {
		this.vNomineePayment = vNomineePayment;
	}

	public BigDecimal getvTotalAmount() {
		return vTotalAmount;
	}

	public void setvTotalAmount(BigDecimal vTotalAmount) {
		this.vTotalAmount = vTotalAmount;
	}

	public String getvAccountNumber() {
		return vAccountNumber;
	}

	public void setvAccountNumber(String vAccountNumber) {
		this.vAccountNumber = vAccountNumber;
	}

	public String getvInvoiceNumber() {
		return vInvoiceNumber;
	}

	public void setvInvoiceNumber(String vInvoiceNumber) {
		this.vInvoiceNumber = vInvoiceNumber;
	}

	public Date getvInvoiceDate() {
		return vInvoiceDate;
	}

	public void setvInvoiceDate(Date vInvoiceDate) {
		this.vInvoiceDate = vInvoiceDate;
	}

	public String getvDIR() {
		return vDIR;
	}

	public void setvDIR(String vDIR) {
		this.vDIR = vDIR;
	}

	public String getvCSIP() {
		return vCSIP;
	}

	public void setvCSIP(String vCSIP) {
		this.vCSIP = vCSIP;
	}

	public String getvPincode() {
		return vPincode;
	}

	public void setvPincode(String vPincode) {
		this.vPincode = vPincode;
	}

	public String getvNomineePhoneNumber() {
		return vNomineePhoneNumber;
	}

	public void setvNomineePhoneNumber(String vNomineePhoneNumber) {
		this.vNomineePhoneNumber = vNomineePhoneNumber;
	}

	public Date getvDateOfLoss() {
		return vDateOfLoss;
	}

	public void setvDateOfLoss(Date vDateOfLoss) {
		this.vDateOfLoss = vDateOfLoss;
	}

	public BigDecimal getvReservedAmount() {
		return vReservedAmount;
	}

	public void setvReservedAmount(BigDecimal vReservedAmount) {
		this.vReservedAmount = vReservedAmount;
	}

	public Number getvApplicationID() {
		return vApplicationID;
	}

	public void setvApplicationID(Number vApplicationID) {
		this.vApplicationID = vApplicationID;
	}

	public Number getvGroupTypeID() {
		return vGroupTypeID;
	}

	public void setvGroupTypeID(Number vGroupTypeID) {
		this.vGroupTypeID = vGroupTypeID;
	}

	public Number getvCreatedBy() {
		return vCreatedBy;
	}

	public void setvCreatedBy(Number vCreatedBy) {
		this.vCreatedBy = vCreatedBy;
	}

	public Date getvCreatedOn() {
		return vCreatedOn;
	}

	public void setvCreatedOn(Date vCreatedOn) {
		this.vCreatedOn = vCreatedOn;
	}

	public Number getvInsuredID() {
		return vInsuredID;
	}

	public void setvInsuredID(Number vInsuredID) {
		this.vInsuredID = vInsuredID;
	}

	public String getvClaimReportedBy() {
		return vClaimReportedBy;
	}

	public void setvClaimReportedBy(String vClaimReportedBy) {
		this.vClaimReportedBy = vClaimReportedBy;
	}

	public Number getvRelationshipID() {
		return vRelationshipID;
	}

	public void setvRelationshipID(Number vRelationshipID) {
		this.vRelationshipID = vRelationshipID;
	}

	public String getvDescription() {
		return vDescription;
	}

	public void setvDescription(String vDescription) {
		this.vDescription = vDescription;
	}

	public Number getvSalutationID() {
		return vSalutationID;
	}

	public void setvSalutationID(Number vSalutationID) {
		this.vSalutationID = vSalutationID;
	}

	public String getvPolicyNumber() {
		return vPolicyNumber;
	}

	public void setvPolicyNumber(String vPolicyNumber) {
		this.vPolicyNumber = vPolicyNumber;
	}

	public String getvBeneficiaryName() {
		return vBeneficiaryName;
	}

	public void setvBeneficiaryName(String vBeneficiaryName) {
		this.vBeneficiaryName = vBeneficiaryName;
	}

	public Number getvIsExistingInjuryDisablility() {
		return vIsExistingInjuryDisablility;
	}

	public void setvIsExistingInjuryDisablility(Number vIsExistingInjuryDisablility) {
		this.vIsExistingInjuryDisablility = vIsExistingInjuryDisablility;
	}

}

package com.LIC.controller;

import java.io.IOException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.Response;
import com.LIC.model.TransactionContext;
import com.LIC.service.CoverageService;
import com.LIC.service.PrivilegesService;
import com.LIC.service.UsersService;
import com.LIC.utils.dataobject.ValueObject;

@RestController
public class UserManagementController {
	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(UserManagementController.class);
	
	@Autowired
	public UserManagementController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	
	@Autowired 	 UsersService 						usersService;
	@Autowired 	 CoverageService    	coverageService;
	@Autowired 	 PrivilegesService    	privilegesService;
	
	@PostMapping(value = "/SaveUploadedImageFile")
    public ResponseEntity<Response> SaveUploadedFile(@RequestHeader HttpHeaders httpHeaders,@RequestBody HashMap<Object, Object> allRequestParams
    		) throws IOException {
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);   
		
		ValueObject	object	= null;

		try {
			System.out.println("allRequestParams >>"+allRequestParams);
			object	= new ValueObject(allRequestParams);
			
			System.out.println("file >>"+object);
			//return responseGenerator.successResponse(context, usersService.SaveUploadedImageFile(file), HttpStatus.OK);
			//return usersService.SaveUploadedImageFile(file);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		return null;
    }

	//Login
	@GetMapping(value = "/VerifyLogin", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> VerifyLogin(@RequestHeader HttpHeaders httpHeaders,	@RequestParam("userName") String userName,
			@RequestParam("password") String password) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, usersService.VerifyLogin( userName,  password).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	//LogOut
	@GetMapping(value = "/UpdateAdminIsLoggedOut", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> UpdateAdminIsLoggedOut(@RequestHeader HttpHeaders httpHeaders,	@RequestParam("UserID") long UserID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, usersService.UpdateAdminIsLoggedOut(UserID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/InsertUserAndEmployeeDetails", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public ResponseEntity<Response> InsertUserAndEmployeeDetails(@RequestHeader HttpHeaders httpHeader,
				@RequestBody HashMap<Object, Object> allRequestParams ) {
	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParams);

			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, usersService.InsertUserAndEmployeeDetails(object).getHtData(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsPasswordExists", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsPasswordExists(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, usersService.IsPasswordExists(object).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/IsUserExist", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> IsUserExist(@RequestHeader HttpHeaders httpHeaders,	@RequestParam("UserID") long UserID,
			@RequestParam("UserName") String UserName) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			System.out.println("dd>"+UserID);
			return responseGenerator.successResponse(context, usersService.IsUserExist( UserID,UserName), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsUserEmployeeExist", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsUserEmployeeExist(@RequestHeader HttpHeaders httpHeaders, 
			@RequestBody HashMap<Object, Object> allRequestParam) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParam);
			
			return responseGenerator.successResponse(context, usersService.IsUserEmployeeExist(object).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetAllUsersBySearch", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> GetAllUsersBySearch(@RequestHeader HttpHeaders httpHeaders, 
			@RequestBody HashMap<Object, Object> allRequestParam) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParam);
			
			return responseGenerator.successResponse(context, usersService.GetAllUsersBySearch(object).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetSearchUser", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> GetSearchUser(@RequestHeader HttpHeaders httpHeaders, 
			@RequestBody HashMap<Object, Object> allRequestParam) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParam);
			
			return responseGenerator.successResponse(context, usersService.GetSearchUser(object).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/changePassword", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> changePassword1(@RequestHeader HttpHeaders httpHeader,@RequestParam("UserID") long UserID ,
			@RequestParam("UserName") String UserName,@RequestParam("NewPassword") String NewPassword
			,@RequestParam("OldPassword") String OldPassword) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, usersService.UpdatePassword(UserID, UserName, NewPassword, OldPassword), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}
	@GetMapping(value = "/getTimeZoneByID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getTImeZoneID(@RequestHeader HttpHeaders httpHeaders,
			@RequestParam("TimeZoneID") long TimeZoneID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			System.out.println("sss >>"+TimeZoneID);
			return responseGenerator.successResponse(context, usersService.getTImeZoneID(TimeZoneID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	@GetMapping(value = "/GetEmployeeByID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetEmployeeByID(@RequestHeader HttpHeaders httpHeaders, @RequestParam("EmployeeID") long EmployeID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, usersService.GetEmployeeByID(EmployeID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	//privillages  
	@GetMapping(value = "/GetUserModulesFeatureByUserID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetUserModulesFeatureByUserID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("UserId") long UserID,
			@RequestParam("LineOfBusinessID") long LineOfBusinessID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			return responseGenerator.successResponse(context, privilegesService.GetUserModulesFeatureByUserID(UserID,LineOfBusinessID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetUserGroupModulesFeaturesRolesByID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetUserGroupModulesFeaturesRolesByDepartmentID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("TypeID") int TypeID,
			@RequestParam("UserGroupID")long UserGroupID,@RequestParam("DesignationID") long DesignationID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, privilegesService.GetUserGroupModulesFeaturesRolesByID(TypeID, UserGroupID, DesignationID), 
					HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "/InsertPrivileges", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public ResponseEntity<Response> InsertPrivileges(@RequestHeader HttpHeaders httpHeader,
				@RequestBody HashMap<Object, Object> allRequestParam) {	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);		
		ValueObject	object	= null;
		try {			
			object	= new ValueObject(allRequestParam);
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, privilegesService.InsertPrivileges(object), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}		
	}
	
	@GetMapping(value = "/GetAllFeaturesForProcess", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllFeaturesForProcess(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			return responseGenerator.successResponse(context, privilegesService.getAllFeaturesForProcess(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	//end privilleges 
	
	@GetMapping(value = "/getAllReportingTo", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllReportingTo(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			return responseGenerator.successResponse(context, usersService.getAllReportingTo(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
}

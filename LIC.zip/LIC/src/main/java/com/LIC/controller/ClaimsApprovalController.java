package com.LIC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsApprovalDao;
import com.LIC.model.SaveClaimsApprovalModel;

/*
 * @Author = "671621"
 */
@RestController
@RequestMapping("/ClaimsApproval")
public class ClaimsApprovalController {

	@Autowired
	private ClaimsApprovalDao claimsApprovalDao;

	@RequestMapping(value = "/updateClaimsPayableDetails", method = RequestMethod.PUT)
	public boolean updateClaimsPayableDetails(@RequestBody SaveClaimsApprovalModel saveClaimsApprovalModel) {
		return claimsApprovalDao.updateClaimsPayableDetails(saveClaimsApprovalModel);
	}

	@RequestMapping(value = "/insertClaimCoverageBenefitDetails", method = RequestMethod.POST)
	public int insertClaimCoverageBenefitDetails(@RequestBody SaveClaimsApprovalModel saveClaimsApprovalModel) {
		return claimsApprovalDao.insertClaimCoverageBenefitDetails(saveClaimsApprovalModel);
	}


}

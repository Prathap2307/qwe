import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
//import { Accountingglconfiguration} from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingglconfiguration';
import { Accountingglconfiguration, ProcessName, PaymentMode, ProductVariant, DebitName, CreditName, country, state } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingglconfiguration';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountingglconfigurationService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  // GET SEARCH & GRID GL CONFIGURATION
  getAllGLConfigDetails(ProcessId: number, VariantId: number, PaymentId: number): Observable<Accountingglconfiguration[]> {
    const AllGLConfigTableSearchUrl = this.baseUrl + `/all/${ProcessId}/${VariantId}/${PaymentId}`;
    return this.http.get<Accountingglconfiguration[]>(AllGLConfigTableSearchUrl).pipe();
  }

   // GET CREATE & UPDATE GL CONFIGURATION 
   createGLConfigurationUrl = this.baseUrl + `/createGlConfig`;
   addGLConfigurationDetails(GLConfiguration: Accountingglconfiguration): Observable<Accountingglconfiguration[]> {
     return this.http.post<Accountingglconfiguration[]>(this.createGLConfigurationUrl, GLConfiguration).pipe();
   }

  // GET ACCOUNT PROCESS DDL DETAILS
  getAccountProcessNameDetails(): Observable<ProcessName[]> {
    const AccountProcessByNameUrl = this.baseUrl + `/process`;
    return this.http.get<ProcessName[]>(AccountProcessByNameUrl).pipe();
  }
  // GET PRODUCT DDL DETAILS
  getProductVariantDetails(lobId: number): Observable<ProductVariant[]> {
    const ProductVariantNameUrl = this.baseUrl + `/varient/${lobId}`;
    return this.http.get<ProductVariant[]>(ProductVariantNameUrl).pipe();
  }
  // GET PAYMENT MODE DDL DETAILS
  getPaymentModeDetails(): Observable<PaymentMode[]> {
    const PaymentModeByNameUrl = this.baseUrl + `/payment`;
    return this.http.get<PaymentMode[]>(PaymentModeByNameUrl).pipe();
  }
  // GET DEBIT & CREDIT DDL DETAILS
  getDebitDetails(AccountHeadId: number): Observable<DebitName[]> {
    const DebitCreditNameUrl = this.baseUrl + `/debitcredit/${AccountHeadId}`;
    return this.http.get<DebitName[]>(DebitCreditNameUrl).pipe();
  }
  // GET DEBIT & CREDIT DDL DETAILS
  getCreditDetails(AccountHeadId: number): Observable<CreditName[]> {
    const DebitCreditNameUrl = this.baseUrl + `/debitcredit/${AccountHeadId}`;
    return this.http.get<CreditName[]>(DebitCreditNameUrl).pipe();
  }
  // GET ALL COUNTRY DDL DETAILS
  getAllCountriesDetails(): Observable<country[]> {
    const GLConfigCountryUrl = this.baseUrl + `/gcountries`;
    return this.http.get<country[]>(GLConfigCountryUrl).pipe();
  }
  // GET ALL STATE DDL DETAILS
  getAllStatesDetails(countryId: number): Observable<state[]> {
    const GLConfigStateUrl = this.baseUrl + `/gstate/${countryId}`;
    return this.http.get<state[]>(GLConfigStateUrl).pipe();
  }
}

import { TestBed } from '@angular/core/testing';

import { MemberadditionService } from './memberaddition.service';

describe('MemberadditionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MemberadditionService = TestBed.get(MemberadditionService);
    expect(service).toBeTruthy();
  });
});

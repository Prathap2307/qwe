import { TestBed } from '@angular/core/testing';

import { AccountingProcessService } from './accountingprocess.service';

describe('AccountingProcessService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AccountingProcessService = TestBed.get(AccountingProcessService);
    expect(service).toBeTruthy();
  });
});

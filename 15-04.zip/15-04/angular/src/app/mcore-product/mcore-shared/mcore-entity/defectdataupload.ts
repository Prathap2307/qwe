export interface DefectDataUpload {
    // partyID: number;
    // firstName: string;
    // groupID: number;
    // groupName: string;
    // customerGroupID: number;
    // coreBusiness: string;
    // salutationID: number;
    // contactFirstName: string;
    // contactMiddleName: string;
    // contactLastName: string;
    // contactNumber: number;
    // masterPolicyAgreement: number;
    // agreementStartDate: Date;
    // agreementEndDate: Date;
    // branchID: number;
    // parentGroupID: number;
    // hierarchyID: number;
    // gstNo: string,
    // userID: number;
    // pANNo: string;

    groupid: number;
    masterpolicyno: string;
    agreementno: string;

    id: number;
    description: string;

    fromDate: Date;
    toDate: Date;
    fileName: string;
    uploadDate: any;
    totalRecords: number;
    successRecords: number;
    failedRecords: number;
    status: string;
}

export interface SuccessMessage {
    headerId: number;
    totalRecords: number;
    successRecords: number;
    failureRecords: number;
    fileName: string;
    uploadDate: Date;

}

export interface UploadFileurl {
    headerId: number;
    filePath: string;
    fileName: string;
    groupID: number;
    masterPolicyID: number;
    createdBy: number;
    createdOn: Date;
    type: string;
    authorisedSignatoryID: number;

}
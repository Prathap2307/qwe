import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advancedepositreceipt',
  templateUrl: './advancedepositreceipt.component.html',
  styleUrls: ['./advancedepositreceipt.component.css']
})
export class AdvancedepositreceiptComponent implements OnInit {
  dummyObj: string;
  displayedColumns: string[] = ['View', 'Edit', 'ClientName', 'MasterPolicyNumber', 'AgreementNumber' , 'ReceiptNumber', 'SubReceiptNumber', 'Receipt'  ];
  dataSource = ELEMENT_DATA;

  constructor() { }

  ngOnInit() {
  }

}

export interface PeriodicElement {
  ClientName: string;
  MasterPolicyNumber: number;
  AgreementNumber: number;
  ReceiptNumber: number;
  SubReceiptNumber: number;
  Receipt: number;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {ClientName: 'CitiFootballGroup' , MasterPolicyNumber: 2002412 , AgreementNumber: 654987321 , ReceiptNumber: 987654, SubReceiptNumber: 987654777, Receipt: 1705},
  {ClientName: 'ArsenalGunners' , MasterPolicyNumber: 22412 , AgreementNumber: 6549321 , ReceiptNumber: 987651, SubReceiptNumber: 987654123, Receipt: 1996},
];
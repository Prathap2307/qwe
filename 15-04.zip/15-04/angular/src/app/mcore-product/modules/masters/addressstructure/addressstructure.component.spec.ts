import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressstructureComponent } from './addressstructure.component';

describe('AddressstructureComponent', () => {
  let component: AddressstructureComponent;
  let fixture: ComponentFixture<AddressstructureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressstructureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressstructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

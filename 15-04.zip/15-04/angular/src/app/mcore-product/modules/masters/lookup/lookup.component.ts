import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LookupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/lookup.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-lookup',
  templateUrl: './lookup.component.html',
  styleUrls: ['./lookup.component.css']
})
export class LookupComponent implements OnInit {
  // lookUpObj: any = ['Account Type', 'Address Type', 'Annual Income', 'Bank City', 'Benefit Type', 'City',
  //                  'Country', 'Currency', 'District', 'Document', 'Document Category', 'Martial Status', 'Medical Test',
  //                  'Occupation Risk Category Code', 'Payment Mode', 'Post Office', 'Premium Payment Frequency', 'Profession',
  //                  'Region', 'Relationship', 'Residence Type', 'Salutation', 'State', 'Type of Business', 'Underwriter Loading'
  //                 ];
  lookUpName : any;
  userId: any;
  token: any;
  addressArr: any = [];
  addressTypeHistoryList: any = [];
  addressObj: any = {};
  viewRemarkInput = false;
  editRemarkInput = false;
  deleteAddId: any;
  searchAddressObj: any = {};
  isReadonly = true;
  accountDataObj: any = {};
  accountArr: any = [];
  acctTypeHistoryList: any = [];
  deleteAccId: any;
  searchAccountObj: any = {};
  annualDataObj: any = {};
  annualArr: any = [];
  annualIncomeHistoryList: any = [];
  deleteAnnId: any;
  searchAnnualObj: any = {};
  addressErrMsg: any;
  errMsg: any;
  bankCityObj: any = {};
  bankCityArr: any = [];
  bankCityHistoryList: any = [];
  deleteBnkCityId: any;
  searchBankCityObj: any = {};
  benefitObj: any = {};
  benefitArr: any = [];
  benefitTypeHistoryList: any = [];
  deleteBenefitTypeId: any;
  searchBenefitObj: any = {};
  documentCategoryObj: any = {};
  documentCategoryArr: any = [];
  documentCategoryHistoryList: any = [];
  deleteDocumentCategoryID: any;
  searchDocumentCategoryObj: any = {};
  accountErrMsg: string;
  annualErrMsg: string;
  bankCityErrMsg: string;
  benefitErrMsg: string;
  documentCategoryErrMsg: string;
  documentObj: any = {};
  documentErrMsg: string;
  documentArr: any = [];
  documentTypeHistoryList: any = [];
  deleteDocumentID: any;
  searchDocumentObj: any = {};
  maritalStatusObj: any = {};
  maritalStatusErrMsg: string;
  maritalStatusArr: any = [];
  maritalStatusHistoryList: any = [];
  deleteMaritalStatusID: any;
  searchMaritalStatusObj: any = {};
  occupationDataObj: any = {};
  occupationErrMsg: string;
  occupationArr: any = [];
  buttonDisable = false;
  searchOccupationObj: any = {};
  occupationHistoryList: any = [];
  deleteOccupationID: any;
  countryObj: any = [];
  countryErrMsg: string;
  countryArr: any = [];
  searchCountryObj: any = {};
  countryHistoryList: any = [];
  deleteCountryID: any;
  paymentObj : any = {};
  paymentErrMsg : any;
  paymentArr : any = [];
  deletePayId : any;
  searchPaymentObj : any = {};
  paymentModeHistoryList : any = [];
  regionObj: any = {};
  regionErrMsg: string;
  searchRegionObj: any = {};
  regionArr: any = [];
  deleteRegionID: any;
  regionHistoryList: any = [];
  relationshipObj : any = {};
  relationshipErrMsg : any;
  relationshipArr : any = [];
  relationshipHistoryList : any = [];
  deleteRelId : any;
  searchRelationshipObj : any = {};
  residenceObj: any = {};
  residenceErrMsg: string;
  residenceArr: any = [];
  searchResidenceObj:any = {};
  residenceTypeHistoryList:any = [];
  deleteResidenceID: any;
  professionObj: any = {};
  professionErrMsg: string;
  professionArr: any = [];
  searchProfessionObj: any = {};
  professionHistoryList: any = [];
  deleteProfessionID: any;
  medicalTestObj:any = {};
  medicalTestErrMsg: string;
  searchMedicalTestObj:any = {};
  medicalTestArr: any = [];
  medicalTestHistoryList:any = [];
  deleteMedicalTestID: any;
  countryValue: any;
  frequencyObj : any = {};
  frequencyErrMsg : any;
  frequencyArr : any = [];
  deleteFreId : any;
  searchFrequencyObj : any = {};
  paymentFrequencyHistoryList : any = [];
  businessObj : any = {};
  businessErrMsg : any;
  businessArr : any = [];
  deleteBusId : any;
  searchBusinessObj : any = {};
  businessTypeHistoryList : any = [];
  stateObj: any = {};
  stateErrMsg: string;
  stateArr: any = [];
  stateHistoryList: any = [];
  deleteStateID: any;
  searchStateObj: any = {};
  stateValue: any;
  districtArr:any = [];
  districtValue: any;
  districtObj: any = {};
  districtErrMsg: string;
  searchDistrictObj: any = {};
  districtHistoryList:any = [];
  deleteDistrictID: any;
  postOfficeObj: any = {};
  postOfficeErrMsg: string;
  postOfficeArr:any = [];
  searchPostOfficeObj:any = {};
  postOfficeHistoryList:any = [];
  deletePostOfficeID: any;
  cityObj: any = {};
  cityErrMsg: string;
  cityArr: any = [];
  cityHistoryList:any = [];
  searchCityObj:any = {};
  deleteCityID: any;
  districtArrEmpty: string;
  lookupArr:any = [];
  salutationDataObj: any = {};
  salutationArr: any = [];
  salutationHistory: any = [];
  deleteSalId: any;
  searchSalutationObj: any = {};
  salutationErrMsg: string;
  currencyObj: any = {};
  currencyArr: any = [];
  currencyHistoryList: any = [];
  deleteCurId: any;
  searchCurrencyObj: any = {};
  currencyErrMsg: string;
  d:any;
  address:any;
  annual:any;
  bankCityPage:any;
  benefitPage:any;
  cityPage:any;
  countryPage:any;
  currencyPage:any;
  districtPage:any;
  documentPage:any;
  documentCategoryPage : any;
  maritalStatusPage : any;
  occupationPage : any;
  paymentPage : any;
  postOfficePage : any;
  frequencyPage : any;
  regionPage : any;
  relationshipPage : any;
  residencePage : any;
  salutationPage : any;
  statePage : any;
  businessPage : any
  professionPage:any;
  medicalTestPage:any;
  editingbenefitId: any;
  editAccId: any;
  editAnnualId: any;

  constructor(
    private _lookupSevice : LookupService,
    private spinner: NgxSpinnerService,
    private _snackBar: MatSnackBar,
    private datePipe: DatePipe,
  ) {
    for (let i = 1; i <= this.accountArr.length; i++) {
      this.accountArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.addressArr.length; i++) {
      this.addressArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.annualArr.length; i++) {
      this.annualArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.bankCityArr.length; i++) {
      this.bankCityArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.benefitArr.length; i++) {
      this.benefitArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.cityArr.length; i++) {
      this.cityArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.countryArr.length; i++) {
      this.countryArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.currencyArr.length; i++) {
      this.currencyArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.districtArr.length; i++) {
      this.districtArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.documentArr.length; i++) {
      this.documentArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.documentCategoryArr.length; i++) {
      this.documentCategoryArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.maritalStatusArr.length; i++) {
      this.maritalStatusArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.occupationArr.length; i++) {
      this.occupationArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.paymentArr.length; i++) {
      this.paymentArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.postOfficeArr.length; i++) {
      this.postOfficeArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.frequencyArr.length; i++) {
      this.frequencyArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.regionArr.length; i++) {
      this.regionArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.relationshipArr.length; i++) {
      this.relationshipArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.residenceArr.length; i++) {
      this.residenceArr.push(`deal ${i}.0`);
    }
     for (let i = 1; i <= this.salutationArr.length; i++) {
      this.salutationArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.stateArr.length; i++) {
      this.stateArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.businessArr.length; i++) {
      this.businessArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.professionArr.length; i++) {
      this.professionArr.push(`deal ${i}.0`);
    }
    for (let i = 1; i <= this.medicalTestArr.length; i++) {
      this.medicalTestArr.push(`deal ${i}.0`);
    }
  }

  ngOnInit() {
    this.userId = JSON.parse(localStorage.getItem('userID'));
    this.token = JSON.parse(localStorage.getItem('token'));
    this.spinner.show();
    this.getLookUp();
  }

  getLookUp(){
    this._lookupSevice.getLookup().subscribe(res =>{
   
      this.lookupArr = res.lookUpList;
      this.getAddress();
      this.getAccount();
      this.getAnnual();
      this.getBenefit();
      this.getDocumentCategory();
      this.getDocument();
      this.getMaritalStatus();
      this.getOccupation();
      this.getCountry();
      this.getPayment();
      this.getRegion();
      this.getRelationship();
      this.getResidence();
      this.getProfession();
      this.getMedicalTest();
      this.getBusiness();
      this.getFrequency();
      this.getSalutation();
      this.getCurrency();
    },err =>{
      console.log(err);
    })
  }

  selectValue(data){
    this.lookUpName = data;
    this.getLookUp();
  }

  selectCountryValue(val){
    this.countryValue = val;
    this.spinner.show();
    this.getState();
  }

  selectStateValue(stateValue){
    this.stateValue = stateValue;
    this.getDistrict();
  }

  selectDistrictValue(districtValue){
    this.districtValue = districtValue;
    this.getPostoffice();
    this.getBankCity();
    this.getCity();
  }

  // Address Type

  AddressForm = new FormGroup({
    description: new FormControl("", [Validators.required]),
    createdBy: new FormControl(""),
    remarks: new FormControl(""),
    addressTypeID: new FormControl("")
  });

  addressData(){
    if(!this.addressObj.addressTypeID){
      this.AddressForm.removeControl('remarks');
      this.addressObj.addressTypeID = 0
    }
    if(this.AddressForm.valid){
     this.addressObj.createdBy = this.userId;
     this.addressObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
 
     console.log(this.addressObj)
     this._lookupSevice.addAddress(this.addressObj).subscribe(res =>{
      console.log(res)
       this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getAddress();
      // this.spinner.show();
     }, err =>{
       console.log(err);
     })
    }
  }

  getAddress(){
    this.address = 1;
    this.addressErrMsg = '';
    this.AddressForm.markAsPristine();
    this.AddressForm.markAsUntouched();      
    this.buttonDisable = false;
    this.addressObj = {};
    this.addressTypeHistoryList = [];
    this.searchAddressObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this._lookupSevice.getAddress().subscribe(res =>{
      this.addressArr = res.addressTypeList;
      if(this.addressArr.length == 0)
      {
        this.addressErrMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  viewAddress(id){
    if(this.buttonDisable == false){
      this.spinner.show();
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.AddressForm.markAsPristine();
      this.AddressForm.markAsUntouched();
      this.addressObj = {};
      // this.searchAddressObj = {};
      this.addressTypeHistoryList = [];
      this.AddressForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleAddress(id).subscribe(res =>{
        this.addressObj = res.addressType;
        this.addressTypeHistoryList = res.addressTypeHistoryList;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
  }

  editAddress(editId){
    if(this.buttonDisable == false){
    this.spinner.show();
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.AddressForm.markAsPristine();
    this.AddressForm.markAsUntouched();
    this.addressObj = {};
    // this.searchAddressObj = {};
    this.addressTypeHistoryList = [];
    this.AddressForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleAddress(editId).subscribe(res =>{
      this.addressObj = res.addressType;
      this.addressTypeHistoryList = res.addressTypeHistoryList;
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
  }

  deleteId(deleteId){
    if(this.buttonDisable == false){
    this.deleteAddId = deleteId;
    this.AddressForm.markAsPristine();
    this.AddressForm.markAsUntouched();
    this.addressObj = {};
    // this.searchAddressObj = {};
    this.addressTypeHistoryList = [];
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    }
  }

  deleteAddress(){
    if(this.buttonDisable == false){
    this.spinner.show();
    this._lookupSevice.deleteAddress(this.deleteAddId, this.userId).subscribe(res =>{
      this.address = 1;
      this.getAddress();
    },err =>{
      console.log(err);
    })
  }
  }

  formClear(){
    this.spinner.show();
    this.AddressForm.removeControl('remarks');
    this.getAddress();
  }

  searchAddress(){
    this.spinner.show();
    this.addressErrMsg = '';
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.buttonDisable = false;
    this.isReadonly = true;
    this.AddressForm.markAsPristine();
    this.AddressForm.markAsUntouched();
    this.addressObj = {};
    this.addressTypeHistoryList = [];
    this._lookupSevice.searchAddress(this.searchAddressObj).subscribe(res =>{
      this.addressArr = res.addressTypeList;
      if(this.addressArr.length == 0){
        this.addressErrMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

     //Account Type

     AccountForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      shortDescription : new FormControl("",[Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });

    getAccount(){
      this.d = 1;
      this.accountErrMsg = '';
      this.AccountForm.markAsPristine();
          this.AccountForm.markAsUntouched();
          this.accountDataObj = {};
          this.searchAccountObj = {};
          this.acctTypeHistoryList = [];
          this.buttonDisable = false;
          this.viewRemarkInput = false;
          this.editRemarkInput = false;
          this.isReadonly = true;
      this._lookupSevice.getAccount().subscribe(res =>{
        this.accountArr = res.accountList;
        if(this.accountArr.length == 0){
          this.accountErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }
 
    accountData(){
      if(!this.accountDataObj.accountTypeId){
        this.AccountForm.removeControl('remarks');
        this.accountDataObj.accountTypeId = 0
      }
   
      if(this.AccountForm.valid)
      {
        // this.spinner.show();
       ;

        this.accountDataObj.createdBy = this.userId;
        this.accountDataObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
        console.log(this.accountDataObj)
        this._lookupSevice.addAccount(this.accountDataObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getAccount();
        })
      }
    }

    viewAccount(id){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.AccountForm.markAsPristine();
      this.AccountForm.markAsUntouched();
      this.accountDataObj = {};
      // this.searchAccountObj = {};
      this.acctTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.AccountForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleAccount(id).subscribe(res =>{
        this.accountDataObj = res.accountType;
        this.acctTypeHistoryList = res.acctTypeHistoryList;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    accountFormClear(){
      this.spinner.show();
      this.AccountForm.removeControl('remarks');
      this.getAccount();
    }

    editAccount(editAccId){
      if(this.buttonDisable == false){
        this.editAccId=editAccId
      this.spinner.show();
      this.AccountForm.markAsPristine();
      this.AccountForm.markAsUntouched();
      this.accountDataObj = {};
      // this.searchAccountObj = {};
      this.acctTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.AccountForm.addControl('remarks', new FormControl(''));
      console.log(editAccId)
      this._lookupSevice.getSingleAccount(editAccId).subscribe(res =>{
        this.accountDataObj = res.accountType;
        this.acctTypeHistoryList = res.acctTypeHistoryList;
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    deleteAccountId(delAccId){
      if(this.buttonDisable == false){
      this.AccountForm.markAsPristine();
      this.AccountForm.markAsUntouched();
      this.accountDataObj = {};
      // this.searchAccountObj = {};
      this.acctTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.deleteAccId = delAccId;
      }
    }

    deleteAccount(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteAccount(this.deleteAccId, this.userId).subscribe(res =>{
        this.d = 1;
        this.getAccount();
      },err =>{
        console.log(err);
      })
    }
    }

    searchAccount(){
      this.spinner.show();
      this.accountErrMsg = '';
      this.AccountForm.markAsPristine();
      this.AccountForm.markAsUntouched();
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.buttonDisable = false;
      this.accountDataObj = {};
      this.acctTypeHistoryList = [];
      this._lookupSevice.searchAccount(this.searchAccountObj).subscribe(res =>{
        this.accountArr = res.accountList;
        if(this.accountArr.length == 0){
          this.accountErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

 //Annual Income

   AnnualForm = new FormGroup({
    description : new FormControl("", [Validators.required]),
    shortDescription : new FormControl("",[Validators.required]),
    remarks : new FormControl(""),
    createdBy: new FormControl(""),
   
  });

    annualData(){
      if(!this.annualDataObj.annualIncomeID){
        this.AnnualForm.removeControl('remarks');
        this.annualDataObj.annualIncomeID = 0;
      }
      else{
       
        // this.annualDataObj.annualIncomeID = this.editAnnualId;
      }
      if(this.AnnualForm.valid)
      {
        // this.spinner.show();
        this.annualDataObj.createdBy = this.userId;
        this.annualDataObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
     
     
        console.log(this.annualDataObj)
        this._lookupSevice.addAnnual(this.annualDataObj).subscribe(res =>  
        {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getAnnual();
        })
      }
    }

    getAnnual(){
      this.annualErrMsg = '';
      this.AnnualForm.markAsPristine();
          this.AnnualForm.markAsUntouched();
          this.annualDataObj = {};
          this.searchAnnualObj = {};
          this.annualIncomeHistoryList = [];
          this.buttonDisable = false;
          this.viewRemarkInput = false;
          this.editRemarkInput = false;
          this.isReadonly = true;
          this.annual = 1;
      this._lookupSevice.getAnnual().subscribe(res =>{
        this.annualArr = res.annualIncomeList;
        if(this.annualArr.length == 0){
          this.annualErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    viewAnnual(id){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.AnnualForm.markAsPristine();
      this.AnnualForm.markAsUntouched();
      this.annualDataObj = {};
      // this.searchAnnualObj = {};
      this.annualIncomeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.AnnualForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleAnnual(id).subscribe(res =>{
        this.annualDataObj = res.annualIncome;
        this.annualIncomeHistoryList = res.annualIncomeHistoryList;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    annualFormClear(){
      this.spinner.show();
      this.AnnualForm.removeControl('remarks');
      this.getAnnual();
    }

    editAnnual(editAnnualId){
      if(this.buttonDisable == false){
        this.editAnnualId=editAnnualId
      this.spinner.show();
      this.AnnualForm.markAsPristine();
      this.AnnualForm.markAsUntouched();
      this.annualDataObj = {};
      // this.searchAnnualObj = {};
      this.annualIncomeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.AnnualForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleAnnual(editAnnualId).subscribe(res =>{
        this.annualDataObj = res.annualIncome;
        this.annualIncomeHistoryList = res.annualIncomeHistoryList;
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    deleteAnnualId(deleteAnnualId){
      if(this.buttonDisable == false){
        this.AnnualForm.markAsPristine();
        this.AnnualForm.markAsUntouched();
        this.annualDataObj = {};
        // this.searchAnnualObj = {};
        this.annualIncomeHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
      this.deleteAnnId = deleteAnnualId;
      }
    }

    deleteAnnual(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteAnnual(this.deleteAnnId, this.userId).subscribe(res =>{
        this.annual = 1;
        this.getAnnual();
      },err =>{
        console.log(err);
      })
    }
    }

    searchAnnual(){
      this.spinner.show();
      this.annualErrMsg = '';
      this.AnnualForm.markAsPristine();
      this.AnnualForm.markAsUntouched();
      this.annualDataObj = {};
      this.annualIncomeHistoryList = [];
      this.buttonDisable = false
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this._lookupSevice.searchAnnual(this.searchAnnualObj).subscribe(res =>{
        this.annualArr = res.annualIncomeList;
        if(this.annualArr.length == 0){
          this.annualErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    //Bank City

    bankCityForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      shortDescription : new FormControl("",[Validators.required]),
      districtId : new FormControl(""),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),

 
    });

    bankCityData(){
      if(!this.bankCityObj.bankCityId){
        this.bankCityForm.removeControl('remarks');
        this.bankCityObj.bankCityId = 0;
      }
      if(this.bankCityForm.valid)
      {
        // this.spinner.show();
        this.bankCityObj.districtId = this.districtValue;
        this.bankCityObj.createdBy = this.userId;
        this.bankCityObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
     
        console.log(this.bankCityObj)
        this._lookupSevice.addBankCity(this.bankCityObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getBankCity();
        })
      }
    }

    getBankCity(){
      this.bankCityPage = 1;
      this.bankCityErrMsg = '';
      this.bankCityForm.markAsPristine();
          this.bankCityForm.markAsUntouched();
          this.bankCityObj = {};
          this.buttonDisable = false;
          this.searchBankCityObj = {};
          this.bankCityHistoryList = [];
          this.viewRemarkInput = false;
          this.editRemarkInput = false;
          this.isReadonly = true;
      this._lookupSevice.getBankCity(this.districtValue).subscribe(res =>{
        this.bankCityArr = res.list;
        if(this.bankCityArr.length == 0){
          this.bankCityErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    viewBankCity(id){
      if(this.buttonDisable == false){
      this.spinner.show();
          this.bankCityForm.markAsPristine();
          this.bankCityForm.markAsUntouched();
          this.bankCityObj = {};
          // this.searchBankCityObj = {};
          this.bankCityHistoryList = [];
          this.viewRemarkInput = false;
          this.editRemarkInput = false;
          this.isReadonly = true;
          this.bankCityForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleBankCity(id).subscribe(res =>{
        this.bankCityObj = res.obj;
        this.bankCityHistoryList = res.list;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    clearBankCityForm(){
      this.spinner.show();
      this.bankCityForm.removeControl('remarks');
      this.getBankCity();
    }

    editBankCity(editBankCityId){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.bankCityForm.markAsPristine();
      this.bankCityForm.markAsUntouched();
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.bankCityObj = {};
      this.bankCityHistoryList = [];
      // this.searchBankCityObj = {};
      this.bankCityForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleBankCity(editBankCityId).subscribe(res =>{
        this.bankCityObj = res.obj;
        this.bankCityHistoryList = res.list;
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    deleteBankCityId(deleteBankCtyId){
      if(this.buttonDisable == false){
        this.bankCityForm.markAsPristine();
        this.bankCityForm.markAsUntouched();
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.bankCityObj = {};
        this.bankCityHistoryList = [];
        // this.searchBankCityObj = {};
      this.deleteBnkCityId = deleteBankCtyId;
      }
    }

    deleteBankCity(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteBankCity(this.deleteBnkCityId, this.userId).subscribe(res =>{
        this.bankCityPage = 1;
        this.getBankCity();
      },err =>{
        console.log(err);
      })
    }
    }

    searchBankCity(){
      this.spinner.show();
      this.bankCityErrMsg = '';
      this.bankCityForm.markAsPristine();
      this.bankCityForm.markAsUntouched();
      this.buttonDisable = false;
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.bankCityObj = {};
      this.bankCityHistoryList = [];
      this.searchBankCityObj.districtId = this.districtValue;
      this._lookupSevice.searchBankCity(this.searchBankCityObj).subscribe(res =>{
        this.bankCityArr = res.list;
        if(this.bankCityArr.length == 0){
          this.bankCityErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    //Benefit

    benefitForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      shortDescription : new FormControl("",[Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });    

    benefitData(){


   
      if(!this.benefitObj.benefitTypeId){
        this.benefitForm.removeControl('remarks');
        this.benefitObj.benefitTypeId=0
      }
 
     
      if(this.benefitForm.valid)
      {
        // this.spinner.show();
        this.benefitObj.createdBy = this.userId;
        // this.benefitObj.benefitTypeId=0
        this.benefitObj.benefitTypeId=this.editingbenefitId;
        this.benefitObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
        console.log(this.benefitObj)
        this._lookupSevice.addBenefit(this.benefitObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getBenefit();
        })
      }
    }

    getBenefit(){
      this.benefitPage = 1;
      this.benefitErrMsg = '';
      this.benefitForm.markAsPristine();
      this.benefitForm.markAsUntouched();
      this.benefitObj = {};
      this.searchBenefitObj = {};
      this.benefitTypeHistoryList = [];
      this.buttonDisable = false;
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this._lookupSevice.getBenefit().subscribe(res =>{
        this.benefitArr = res.benefitList;
        if(this.benefitArr.length == 0){
          this.benefitErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    viewBenefit(id){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.benefitForm.markAsPristine();
      this.benefitForm.markAsUntouched();
      this.benefitObj = {};
      // this.searchBenefitObj = {};
      this.benefitTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.benefitForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleBenefit(id).subscribe(res =>{
        this.benefitObj = res.benefitType;
        this.benefitTypeHistoryList = res.benefitTypeHistoryList;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    clearBenefitForm(){
          this.spinner.show();
          this.benefitForm.removeControl('remarks');
          this.getBenefit();
    }

    editBenefit(editBenefitId){
      if(this.buttonDisable == false){
      this.editingbenefitId=editBenefitId
      console.log( this.editingbenefitId)
      this.spinner.show();
      this.benefitForm.markAsPristine();
      this.benefitForm.markAsUntouched();
      this.benefitObj = {};
      // this.searchBenefitObj = {};
      this.benefitTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.benefitForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleBenefit(editBenefitId).subscribe(res =>{
        this.benefitObj = res.benefitType;
        this.benefitTypeHistoryList = res.benefitTypeHistoryList;
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    deleteBenefitId(deleteBenefitId){
      if(this.buttonDisable == false){
        this.benefitForm.markAsPristine();
        this.benefitForm.markAsUntouched();
        this.benefitObj = {};
        // this.searchBenefitObj = {};
        this.benefitTypeHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
      this.deleteBenefitTypeId = deleteBenefitId;
      }
    }

    deleteBenefit(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteBenefit(this.deleteBenefitTypeId, this.userId).subscribe(res =>{
        this.benefitPage = 1;
        this.getBenefit();
      },err =>{
        console.log(err);
      })
    }
    }

    searchBenefit(){
      this.spinner.show();
      this.benefitErrMsg = '';
      this.benefitForm.markAsPristine();
      this.benefitForm.markAsUntouched();
      this.benefitObj = {};
      this.benefitTypeHistoryList = [];
      this.buttonDisable = false;
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this._lookupSevice.searchBenefit(this.searchBenefitObj).subscribe(res =>{
        this.benefitArr = res.benefitList;
        if(this.benefitArr.length == 0){
          this.benefitErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    //Document Category

    documentCategoryForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      shortDescription : new FormControl("",[Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });    

    documentCategoryData(){
      if(!this.documentCategoryObj.documentCategoryId){
        this.documentCategoryForm.removeControl('remarks');
        this.documentCategoryObj.documentCategoryId = 0
      }
      if(this.documentCategoryForm.valid)
      {
        // this.spinner.show();
        this.documentCategoryObj.createdBy = this.userId;
        this.documentCategoryObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
       
        console.log(this.documentCategoryObj)
        this._lookupSevice.addDocumentCategory(this.documentCategoryObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getDocumentCategory();
        })
      }
    }

    getDocumentCategory(){
      this.documentCategoryPage = 1;
      this.documentCategoryErrMsg = '';
      this.documentCategoryForm.reset();
      this.documentCategoryForm.markAsPristine();
          this.documentCategoryForm.markAsUntouched();
          this.documentCategoryObj = {};
          this.searchDocumentCategoryObj = {};
          this.documentCategoryHistoryList = [];
          this.viewRemarkInput = false;
          this.buttonDisable = false;
          this.editRemarkInput = false;
          this.isReadonly = true;
      this._lookupSevice.getDocumentCategory().subscribe(res =>{
        this.documentCategoryArr = res.documentCategoryList;
        if(this.documentCategoryArr.length == 0){
          this.documentCategoryErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    viewDocumentCategory(id){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.documentCategoryForm.markAsPristine();
      this.documentCategoryForm.markAsUntouched();
      this.documentCategoryObj = {};
      // this.searchDocumentCategoryObj = {};
      this.documentCategoryHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.documentCategoryForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleDocumentCategory(id).subscribe(res =>{
        this.documentCategoryObj = res.documentCategory;
        this.documentCategoryHistoryList = res.documentCategoryHistoryList;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    clearDocumentCategoryForm(){
      this.spinner.show();
      this.documentCategoryForm.removeControl('remarks');
      this.getDocumentCategory();
    }

    editDocumentCategory(editDocumentCategoryId){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.documentCategoryForm.reset();
      this.documentCategoryForm.markAsPristine();
      this.documentCategoryForm.markAsUntouched();
      this.documentCategoryObj = {};
      // this.searchDocumentCategoryObj = {};
      this.documentCategoryHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.documentCategoryForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleDocumentCategory(editDocumentCategoryId).subscribe(res =>{
        this.documentCategoryObj = res.documentCategory;
        this.documentCategoryHistoryList = res.documentCategoryHistoryList;
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    deleteDocumentCategoryId(deleteDocumentCatId){
      if(this.buttonDisable == false){
        this.documentCategoryForm.markAsPristine();
        this.documentCategoryForm.markAsUntouched();
        this.documentCategoryObj = {};
        // this.searchDocumentCategoryObj = {};
        this.documentCategoryHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
      this.deleteDocumentCategoryID = deleteDocumentCatId;
      }
    }

    deleteDocumentCategory(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteDocumentCategory(this.deleteDocumentCategoryID, this.userId).subscribe(res =>{
        this.getDocumentCategory();
      },err =>{
        console.log(err);
      })
    }
    }

    searchDocumentCategory(){
      this.spinner.show();
      this.documentCategoryErrMsg = '';
      this.documentCategoryForm.markAsPristine();
      this.documentCategoryForm.markAsUntouched();
      this.documentCategoryObj = {};
      this.documentCategoryHistoryList = [];
      this.viewRemarkInput = false;
      this.buttonDisable = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this._lookupSevice.searchDocumentCategory(this.searchDocumentCategoryObj).subscribe(res =>{
        this.documentCategoryArr = res.documentCategoryList;
        if(this.documentCategoryArr.length == 0){
          this.documentCategoryErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    //Document

    documentForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });

    documentData(){
      if(!this.documentObj.documentTypeId){
        this.documentForm.removeControl('remarks');
        this.documentObj.documentTypeId = 0
      }
      if(this.documentForm.valid)
      {
        // this.spinner.show();
        this.documentObj.createdBy = this.userId;
        this.documentObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
       
        console.log(this.documentObj)
        this._lookupSevice.addDocument(this.documentObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getDocument();
        })
      }
    }

    getDocument(){
      this.documentPage = 1;
      this.documentErrMsg = '';
      this.documentForm.reset();
      this.documentForm.markAsPristine();
      this.documentForm.markAsUntouched();
      this.documentObj = {};
      this.searchDocumentObj = {};
      this.documentTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.buttonDisable = false;
      this.isReadonly = true;
      this._lookupSevice.getDocument().subscribe(res =>{
        this.documentArr = res.documentList;
        if(this.documentArr.length == 0){
          this.documentErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    viewDocument(id){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.documentForm.markAsPristine();
      this.documentForm.markAsUntouched();
      this.documentObj = {};
      // this.searchDocumentObj = {};
      this.documentTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.documentForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleDocument(id).subscribe(res =>{
        this.documentObj = res.documentType;
        this.documentTypeHistoryList = res.documentTypeHistoryList;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    clearDocumentForm(){
      this.spinner.show();
     // this.documentForm.removeControl('remarks');
      this.getDocument();
    }

    editDocument(editDocumentId){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.documentForm.markAsPristine();
      this.documentForm.markAsUntouched();
      this.documentObj = {};
      // this.searchDocumentObj = {};
      this.documentTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.documentForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleDocument(editDocumentId).subscribe(res =>{
        this.documentObj = res.documentType;
        this.documentTypeHistoryList = res.documentTypeHistoryList;
        // this.documentForm.addControl('remarks', AbstractControl);
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    deleteDocumentId(deleteDocId){
      if(this.buttonDisable == false){
      this.documentForm.markAsPristine();
      this.documentForm.markAsUntouched();
      this.documentObj = {};
      // this.searchDocumentObj = {};
      this.documentTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.deleteDocumentID = deleteDocId;
      }
    }

    deleteDocument(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteDocument(this.deleteDocumentID, this.userId).subscribe(res =>{
        this.getDocument();
      },err =>{
        console.log(err);
      })
    }
    }

    searchDocument(){
      this.spinner.show();
      this.documentErrMsg = '';
      this.documentForm.markAsPristine();
      this.documentForm.markAsUntouched();
      this.documentObj = {};
      this.documentTypeHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.buttonDisable = false;
      this.isReadonly = true;
      this._lookupSevice.searchDocument(this.searchDocumentObj).subscribe(res =>{
        this.documentArr = res.documentList;
        if(this.documentArr.length == 0){
          this.documentErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    //marital Status

    maritalStatusForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });

    maritalStatusData(){
      if(!this.maritalStatusObj.maritalStatusId){
        this.maritalStatusForm.removeControl('remarks');
        this.maritalStatusObj.maritalStatusId = 0
      }
    if(this.maritalStatusForm.valid)
      {
        // this.spinner.show();
        this.maritalStatusObj.createdBy = this.userId;
        this.maritalStatusObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
       
        console.log(this.maritalStatusObj)
        this._lookupSevice.addMaritalStatus(this.maritalStatusObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getMaritalStatus();
        })
      }
    }

    getMaritalStatus(){
      this.maritalStatusPage = 1;
      this.maritalStatusErrMsg = '';
      this.maritalStatusForm.markAsPristine();
      this.maritalStatusForm.markAsUntouched();
      this.maritalStatusObj = {};
      this.searchMaritalStatusObj = {};
      this.maritalStatusHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.buttonDisable = false;
      this.isReadonly = true;
      this._lookupSevice.getMaritalStatus().subscribe(res =>{
        this.maritalStatusArr = res.maritalStatusList;
        if(this.maritalStatusArr.length == 0){
          this.maritalStatusErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    viewMaritalStatus(id){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.maritalStatusForm.markAsPristine();
      this.maritalStatusForm.markAsUntouched();
      this.maritalStatusObj = {};
      // this.searchMaritalStatusObj = {};
      this.maritalStatusHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.maritalStatusForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleMaritalStatus(id).subscribe(res =>{
        this.maritalStatusObj = res.maritalStatus;
        this.maritalStatusHistoryList = res.maritalStatusHistoryList;
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    clearMaritalStatus(){
      this.spinner.show();
      // this.maritalStatusForm.removeControl('remarks');
      this.getMaritalStatus();
    }

    editMaritalStatus(editMaritalStatusId){
      if(this.buttonDisable == false){
      this.spinner.show();
      this.maritalStatusForm.markAsPristine();
      this.maritalStatusForm.markAsUntouched();
      this.maritalStatusObj = {};
      // this.searchMaritalStatusObj = {};
      this.maritalStatusHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.maritalStatusForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleMaritalStatus(editMaritalStatusId).subscribe(res =>{
        this.maritalStatusObj = res.maritalStatus;
        this.maritalStatusHistoryList = res.maritalStatusHistoryList;
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
    }

    deleteMaritalStatusId(deleteMaritalStatusId){
      if(this.buttonDisable == false){
        this.maritalStatusForm.markAsPristine();
        this.maritalStatusForm.markAsUntouched();
        this.maritalStatusObj = {};
        // this.searchMaritalStatusObj = {};
        this.maritalStatusHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
      this.deleteMaritalStatusID = deleteMaritalStatusId;
    }
    }

    deleteMaritalStatus(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteMaritalStatus(this.deleteMaritalStatusID, this.userId).subscribe(res =>{
       
        this.getMaritalStatus();
      },err =>{
        console.log(err);
      })
    }
    }

    searchMaritalStatus(){
      this.spinner.show();
      this.maritalStatusErrMsg = '';
      this.maritalStatusForm.markAsPristine();
      this.maritalStatusForm.markAsUntouched();
      this.maritalStatusObj = {};
      this.maritalStatusHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.buttonDisable = false;
      this.isReadonly = true;
      this._lookupSevice.searchMaritalStatus(this.searchMaritalStatusObj).subscribe(res =>{
       
        this.maritalStatusArr = res.maritalStatusList;
        if(this.maritalStatusArr.length == 0){
          this.maritalStatusErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    //Occupation Risk Category Code

    occupationForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      shortDescription : new FormControl("", [Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });

    occupationData(){
      if(!this.occupationDataObj.occupationId){
        this.occupationForm.removeControl('remarks');
        this.occupationDataObj.occupationId = 0
      }
      if(this.occupationForm.valid)
      {
        // this.spinner.show();
        this.occupationDataObj.createdBy = this.userId;
        this.occupationDataObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
     
        console.log(this.occupationDataObj)
        this._lookupSevice.addOccupation(this.occupationDataObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getOccupation();
        })
      }
    }

    getOccupation(){
      this.occupationPage = 1;
      this.occupationErrMsg = '';
      this.occupationForm.markAsPristine();
      this.occupationForm.markAsUntouched();
      this.occupationDataObj = {};
      this.searchOccupationObj = {};
      this.occupationHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.buttonDisable = false;
      this._lookupSevice.getOccupation().subscribe(res =>{
        this.occupationArr = res.occupationList;
       
        if(this.occupationArr && this.occupationArr.length == 0){
          this.occupationErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    viewOccupation(id){
      if(this.buttonDisable == false){
        this.spinner.show();
        this.occupationForm.markAsPristine();
        this.occupationForm.markAsUntouched();
        this.occupationDataObj = {};
        // this.searchOccupationObj = {};
        this.occupationHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.occupationForm.addControl('remarks', new FormControl(''));
        this._lookupSevice.getSingleOccupation(id).subscribe(res =>{
          this.occupationDataObj = res.occupation;
          this.occupationHistoryList = res.occupationHistoryList;
         
          this.buttonDisable = true;
          this.viewRemarkInput = true;
          this.isReadonly = false;
          this.spinner.hide();
        }, err =>{
          console.log(err);
        })
      }
    }

    clearOccupation(){
      this.spinner.show();
      // this.occupationForm.removeControl('remarks');
      this.getOccupation();
    }

    editOccupation(editOccupationId){
      if(this.buttonDisable == false){
        this.spinner.show();
        this.occupationForm.markAsPristine();
        this.occupationForm.markAsUntouched();
        this.occupationDataObj = {};
        // this.searchOccupationObj = {};
        this.occupationHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.occupationForm.addControl('remarks', new FormControl(''));
        this._lookupSevice.getSingleOccupation(editOccupationId).subscribe(res =>{
          this.occupationDataObj = res.occupation;
          this.occupationHistoryList = res.occupationHistoryList;
         
          this.buttonDisable = true;
          this.editRemarkInput = true;
          this.isReadonly = true;
          this.spinner.hide();
        }, err =>{
          console.log(err);
        })
      }
    }

    deleteOccupationId(deleteOccupationId){
      if(this.buttonDisable == false){
        this.occupationForm.markAsPristine();
        this.occupationForm.markAsUntouched();
        this.occupationDataObj = {};
        // this.searchOccupationObj = {};
        this.occupationHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.buttonDisable = false;
        this.deleteOccupationID = deleteOccupationId;
      }
    }

    deleteOccupation(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteOccupation(this.deleteOccupationID, this.userId).subscribe(res =>{
       
        this.getOccupation();
      },err =>{
        console.log(err);
      })
    }
    }

    searchOccupation(){
      this.spinner.show();
      this.occupationErrMsg = '';
      this.occupationForm.markAsPristine();
      this.occupationForm.markAsUntouched();
      this.occupationDataObj = {};
      this.occupationHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.buttonDisable = false;
      this._lookupSevice.searchOccupation(this.searchOccupationObj).subscribe(res =>{
       
        this.occupationArr = res.occupationList;
        if(this.occupationArr.length == 0){
          this.occupationErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

   //Country

    countryForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      shortDescription : new FormControl("", [Validators.required]),
      countryCode : new FormControl("", [Validators.required]),
      isDeclined : new FormControl("", [Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });

    countryData(){
      if(!this.countryObj.countryId){
        this.countryForm.removeControl('remarks');
        this.countryObj.countryId = 0
      }
      if(this.countryForm.valid)
      {
        // this.spinner.show();
        this.countryObj.createdBy = this.userId;
        this.countryObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
       
                console.log(this.countryObj)
        this._lookupSevice.addCountry(this.countryObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
          this.getCountry();
        })
      }
    }

    getCountry(){
      this.countryPage = 1;
      this.countryErrMsg = '';
      this.countryForm.markAsPristine();
      this.countryForm.markAsUntouched();
      this.countryObj = {};
      this.searchCountryObj = {};
      this.countryHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.buttonDisable = false;
      this._lookupSevice.getCountry().subscribe(res =>{
        this.countryArr = res.list;
       
        if(this.countryArr.length == 0){
          this.countryErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })

    }

    viewCountry(id){
      console.log(id);
      if(this.buttonDisable == false){
        this.spinner.show();
        this.countryForm.markAsPristine();
        this.countryForm.markAsUntouched();
        this.countryObj = {};
        // this.searchCountryObj = {};
        this.countryHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.countryForm.addControl('remarks', new FormControl(''));
        this._lookupSevice.getSingleCountry(id).subscribe(res =>{
          this.countryObj = res.obj;
          this.countryHistoryList = res.list;
         
          this.buttonDisable = true;
          this.viewRemarkInput = true;
          this.isReadonly = false;
          this.spinner.hide();
        }, err =>{
          console.log(err);
        })
      }
    }

    clearCountryForm(){
      this.spinner.show();
      // this.countryForm.removeControl('remarks');
      this.getCountry();
    }

    editCountry(editCountryId){
      if(this.buttonDisable == false){
        this.spinner.show();
        this.countryForm.markAsPristine();
        this.countryForm.markAsUntouched();
        this.countryObj = {};
        // this.searchCountryObj = {};
        this.countryHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.countryForm.addControl('remarks', new FormControl(''));
        this._lookupSevice.getSingleCountry(editCountryId).subscribe(res =>{
          this.countryObj = res.obj;
          this.countryHistoryList = res.list;
         
          this.buttonDisable = true;
          this.editRemarkInput = true;
          this.isReadonly = true;
          this.spinner.hide();
        }, err =>{
          console.log(err);
        })
      }

    }

    deleteCountryId(deleteCountryId){
      if(this.buttonDisable == false){
        this.countryForm.markAsPristine();
        this.countryForm.markAsUntouched();
        this.countryObj = {};
        // this.searchCountryObj = {};
        this.countryHistoryList = [];
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.buttonDisable = false;
        this.deleteCountryID = deleteCountryId;
      }
    }

    deleteCountry(){
      if(this.buttonDisable == false){
      this.spinner.show();
      this._lookupSevice.deleteCountry(this.deleteCountryID, this.userId).subscribe(res =>{
       
        this.getCountry();
      },err =>{
        console.log(err);
      })
    }
    }

    searchCountry(){
      this.spinner.show();
      this.countryErrMsg = '';
      this.countryForm.markAsPristine();
      this.countryForm.markAsUntouched();
      this.countryObj = {};
      this.countryHistoryList = [];
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.buttonDisable = false;
      this._lookupSevice.searchCountry(this.searchCountryObj).subscribe(res =>{
       

        this.countryArr = res.list;
        if(this.countryArr.length == 0){
          this.countryErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

    // Payment Mode

    PaymentForm = new FormGroup({
      description : new FormControl("", [Validators.required]),
      shortDescription : new FormControl("",[Validators.required]),
      remarks : new FormControl(""),
      createdBy: new FormControl(""),
    });

    addPayment()
    {
      if(!this.paymentObj.paymentModeId){
        this.PaymentForm.removeControl('remarks');
        this.paymentObj.paymentModeId = 0
      }
      if(this.PaymentForm.valid)
      {
        // this.spinner.show();
        this.paymentObj.createdBy = this.userId;
        this.paymentObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
     
        console.log(this.paymentObj)
        this._lookupSevice.addPayment(this.paymentObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
        this.getPayment();
        },err => {
          console.log(err)
        })

      }
    }

    getPayment(){
      this.paymentPage = 1;
      this.paymentErrMsg = '';
      this.paymentObj = {};
      this.PaymentForm.markAsPristine();
      this.PaymentForm.markAsUntouched();
      this.isReadonly = true;
      this.buttonDisable = false;
      this.paymentModeHistoryList = [];
      this.searchPaymentObj = {};
     this.viewRemarkInput = false;
     this.editRemarkInput = false;
      this.isReadonly = true;
      this._lookupSevice.getPayment().subscribe(res =>{
        this.paymentArr = res.paymentList;
        if(this.paymentArr.length == 0){
          this.paymentErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }


    deletePaymentId(delPayId)
    {
      if(this.buttonDisable == false){
        this.deletePayId = delPayId;
        this.PaymentForm.markAsPristine();
        this.PaymentForm.markAsUntouched();
        this.paymentObj = {};
        // this.searchPaymentObj = {};
        this.paymentModeHistoryList = {};
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;

     
      }

    }

    deletePayment()
    {
      if(this.buttonDisable == false)
      {
        this.spinner.show();
        this._lookupSevice.deletePayment(this.deletePayId,this.userId).subscribe(res => {
         
          this.getPayment();
        },err => {
          console.log(err)
        })
         
      }
    }


  editPayment(editPayId){
    if(this.buttonDisable == false){
    this.spinner.show();
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.PaymentForm.markAsPristine();
    this.PaymentForm.markAsUntouched();
    this.paymentObj = {};
    // this.searchPaymentObj = {};
    this.paymentModeHistoryList = [];
    this.PaymentForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSinglePayment(editPayId).subscribe(res =>{
      this.paymentObj = res.paymentMode;
      this.paymentModeHistoryList = res.paymentModeHistoryList;
     
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
  }

    paymentClear(){
      this.spinner.show();
      // this.PaymentForm.removeControl('remarks');
      this.getPayment();
    }

    viewPayment(id){
      if(this.buttonDisable == false){
        this.spinner.show();
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
        this.PaymentForm.markAsPristine();
        this.PaymentForm.markAsUntouched();
        this.paymentObj = {};
        // this.searchPaymentObj = {};
        this.paymentModeHistoryList = [];
        this.PaymentForm.addControl('remarks', new FormControl(''));
        this._lookupSevice.getSinglePayment(id).subscribe(res =>{
          this.paymentObj = res.paymentMode;
          this.paymentModeHistoryList = res.paymentModeHistoryList;
         
          this.buttonDisable = true;
          this.viewRemarkInput = true;
          this.isReadonly = false;
          this.spinner.hide();
        }, err =>{
          console.log(err);
        })
      }
    }

    searchPayment(){
    this.spinner.show();
    this.paymentErrMsg = '';
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.buttonDisable = false;
    this.isReadonly = true;
    this.PaymentForm.markAsPristine();
    this.PaymentForm.markAsUntouched();
    this.paymentObj = {};
    this.paymentModeHistoryList = [];
    this._lookupSevice.searchPayment(this.searchPaymentObj).subscribe(res =>{
     
      this.paymentArr = res.paymentList;
      if(this.paymentArr.length == 0){
        this.paymentErrMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  //Region

  regionForm = new FormGroup({
        description : new FormControl("", [Validators.required]),
        shortDescription : new FormControl("", [Validators.required]),
        remarks : new FormControl(""),
        createdBy: new FormControl(""),
  });

  regionData(){
    if(!this.regionObj.regionId){
      this.regionForm.removeControl('remarks');
      this.regionObj.regionId = 0
    }
    if(this.regionForm.valid)
    {
      // this.spinner.show();
      this.regionObj.createdBy = this.userId;
      this.regionObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
   
      console.log(this.regionObj)
      this._lookupSevice.addRegion(this.regionObj).subscribe(res => {
        console.log(res)
        this._snackBar.open(res.message, 'Done', {
          duration: 2000,
        });
        this.getRegion();
      })
    }
  }

  getRegion(){
    this.regionPage = 1;
    this.regionErrMsg = '';
    this.regionForm.markAsPristine();
    this.regionForm.markAsUntouched();      
    this.buttonDisable = false;
    this.regionObj = {};
    this.regionHistoryList = [];
    this.searchRegionObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this._lookupSevice.getRegion().subscribe(res =>{
     
      this.regionArr = res.regionList;
      if(this.regionArr.length == 0){
        this.regionErrMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  viewRegion(id){
    if(this.buttonDisable == false){
      this.spinner.show();
      this.regionForm.markAsPristine();
      this.regionForm.markAsUntouched();      
      this.regionObj = {};
      this.regionHistoryList = [];
      // this.searchRegionObj = {};
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.regionForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleRegion(id).subscribe(res =>{
       
        this.regionObj = res.region;
        this.regionHistoryList = res.regionHistoryList;
       
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
  }

  regionFormClear(){
    this.spinner.show();
    // this.regionForm.removeControl('remarks');
    this.getRegion();
  }

  editRegion(editRegionId){
    if(this.buttonDisable == false){
      this.spinner.show();
      this.regionForm.markAsPristine();
      this.regionForm.markAsUntouched();      
      this.regionObj = {};
      this.regionHistoryList = [];
      // this.searchRegionObj = {};
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.regionForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleRegion(editRegionId).subscribe(res =>{
        this.regionObj = res.region;
        this.regionHistoryList = res.regionHistoryList;
       
        this.buttonDisable = true;
        this.editRemarkInput = true;
        this.isReadonly = true;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }  
  }

  deleteRegionId(deleteRegId){
    if(this.buttonDisable == false){
      this.regionForm.markAsPristine();
      this.regionForm.markAsUntouched();      
      this.buttonDisable = false;
      this.regionObj = {};
      this.regionHistoryList = [];
      this.searchRegionObj = {};
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.deleteRegionID = deleteRegId;
    }
  }

  deleteRegion(){
    if(this.buttonDisable == false){
    this.spinner.show();
    this._lookupSevice.deleteRegion(this.deleteRegionID, this.userId).subscribe(res =>{
     
      this.getRegion();
    },err =>{
      console.log(err);
    })
  }
  }

  searchRegion(){
    this.spinner.show();
    this.regionErrMsg = '';
    this.regionForm.markAsPristine();
    this.regionForm.markAsUntouched();      
    this.buttonDisable = false;
    this.regionObj = {};
    this.regionHistoryList = [];
    // this.searchRegionObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this._lookupSevice.searchRegion(this.searchRegionObj).subscribe(res =>{
     
      this.regionArr = res.regionList;
      if(this.regionArr.length == 0){
        this.regionErrMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  //Relationship Form

  RelationshipForm = new FormGroup({
    description : new FormControl("", [Validators.required]),
    shortDescription : new FormControl(""),
    remarks : new FormControl(""),
    createdBy: new FormControl(""),
  });

  relationshipData()
  {
    if(!this.relationshipObj.relationshipId){
      this.RelationshipForm.removeControl('remarks');
      this.relationshipObj.relationshipId = 0
    }
    if(this.RelationshipForm.valid)
      {
        // this.spinner.show();
        this.relationshipObj.createdBy = this.userId;
        this.relationshipObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
     
        console.log(this.relationshipObj)
        this._lookupSevice.addRelationship(this.relationshipObj).subscribe(res => {
          console.log(res)
          this._snackBar.open(res.message, 'Done', {
            duration: 2000,
          });
        this.getRelationship();
        },err => {
          console.log(err)
        })

      }

  }

  getRelationship()
  {
    this.relationshipPage = 1;
    this.relationshipErrMsg = '';
      this.relationshipObj = {};
      this.RelationshipForm.markAsPristine();
      this.RelationshipForm.markAsUntouched();
      this.isReadonly = true;
      this.buttonDisable = false;
      this.relationshipHistoryList = [];
      this.searchRelationshipObj = {};
     this.viewRemarkInput = false;
     this.editRemarkInput = false;
      this.isReadonly = true;
      this._lookupSevice.getRelationship().subscribe(res =>{
        this.relationshipArr = res.relationshipList;
        if(this.relationshipArr.length == 0){
          this.relationshipErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
  }

  relationshipClear(){
    this.spinner.show();
    // this.RelationshipForm.removeControl('remarks');
    this.getRelationship();
  }

  editRelationship(editRelationId){
    if(this.buttonDisable == false){
    this.spinner.show();
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.RelationshipForm.markAsPristine();
    this.RelationshipForm.markAsUntouched();
    this.relationshipObj = {};
    // this.searchRelationshipObj = {};
    this.relationshipHistoryList = [];
    this.RelationshipForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleRelationship(editRelationId).subscribe(res =>{
      this.relationshipObj = res.relationship;
      this.relationshipHistoryList = res.relationshipHistoryList;
     
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
  }

  viewRelationship(id){
    if(this.buttonDisable == false){
      this.spinner.show();
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
      this.RelationshipForm.markAsPristine();
      this.RelationshipForm.markAsUntouched();
      this.paymentObj = {};
      this.addressTypeHistoryList = [];
      this.RelationshipForm.addControl('remarks', new FormControl(''));
      this._lookupSevice.getSingleRelationship(id).subscribe(res =>{
        this.relationshipObj = res.relationship;
        this.relationshipHistoryList = res.relationshipHistoryList;
       
        this.buttonDisable = true;
        this.viewRemarkInput = true;
        this.isReadonly = false;
        this.spinner.hide();
      }, err =>{
        console.log(err);
      })
    }
  }

  deleteRelationshipId(delRelId)
    {
      if(this.buttonDisable == false){
        this.deleteRelId = delRelId;
        this.RelationshipForm.markAsPristine();
        this.RelationshipForm.markAsUntouched();
        this.relationshipObj = {};
        // this.searchPaymentObj = {};
        this.relationshipHistoryList = {};
        this.viewRemarkInput = false;
        this.editRemarkInput = false;
        this.isReadonly = true;
      }

    }

    deleteRelationship()
    {
      if(this.buttonDisable == false)
      {
        this.spinner.show();
        this._lookupSevice.deleteRelationship(this.deleteRelId,this.userId).subscribe(res => {
         
          this.getRelationship();
        },err => {
          console.log(err)
        })
         
      }
    }

    searchRelationship(){
      this.spinner.show();
      this.relationshipErrMsg = '';
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.buttonDisable = false;
      this.isReadonly = true;
      this.RelationshipForm.markAsPristine();
      this.RelationshipForm.markAsUntouched();
      this.relationshipObj = {};
      this.relationshipHistoryList = [];
      this._lookupSevice.searchRelationship(this.searchRelationshipObj).subscribe(res =>{
       
        this.relationshipArr = res.relationshipList;
        if(this.relationshipArr.length == 0){
          this.relationshipErrMsg = 'Not Found';
        }
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }

//Residence Type

residenceForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  shortDescription : new FormControl(""),
  remarks : new FormControl(""),
  createdBy: new FormControl(""),
});

residenceData(){
  if(!this.residenceObj.residenceTypeId){
    this.residenceForm.removeControl('remarks');
    this.residenceObj.residenceTypeId = 0
  }
if(this.residenceForm.valid)
{
  // this.spinner.show();
  this.residenceObj.createdBy = this.userId;
  this.residenceObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')

  console.log(this.residenceObj)
  this._lookupSevice.addResidence(this.residenceObj).subscribe(res => {
    console.log(res)
    this._snackBar.open(res.message, 'Done', {
      duration: 2000,
    });
    this.getResidence();
  })
}
}

getResidence(){
  this.residencePage = 1;
  this.residenceErrMsg = '';
  this.residenceForm.markAsPristine();
  this.residenceForm.markAsUntouched();      
  this.buttonDisable = false;
  this.residenceObj = {};
  this.residenceTypeHistoryList = [];
  this.searchResidenceObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getResidence().subscribe(res =>{
   
    this.residenceArr = res.residenceList;
    if(this.residenceArr.length == 0){
      this.residenceErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

viewResidence(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.residenceForm.markAsPristine();
    this.residenceForm.markAsUntouched();      
    this.buttonDisable = false;
    this.residenceObj = {};
    this.residenceTypeHistoryList = [];
    // this.searchResidenceObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.residenceForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleResidence(id).subscribe(res =>{
     
      this.residenceObj = res.residenceType;
      this.residenceTypeHistoryList = res.residenceTypeHistoryList;
     
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

clearResidence(){
this.spinner.show();
// this.residenceForm.removeControl('remarks');
this.getResidence();
}

editResidence(editResidenceId){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.residenceForm.markAsPristine();
    this.residenceForm.markAsUntouched();      
    this.buttonDisable = false;
    this.residenceObj = {};
    this.residenceTypeHistoryList = [];
    // this.searchResidenceObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.residenceForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleResidence(editResidenceId).subscribe(res =>{
      this.residenceObj = res.residenceType;
      this.residenceTypeHistoryList = res.residenceTypeHistoryList;
     
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

deleteResidenceId(deleteResidenceId){
  if(this.buttonDisable == false){
    this.residenceForm.markAsPristine();
    this.residenceForm.markAsUntouched();      
    this.buttonDisable = false;
    this.residenceObj = {};
    this.residenceTypeHistoryList = [];
    // this.searchResidenceObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.deleteResidenceID = deleteResidenceId;
  }
}

deleteResidence(){
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteResidence(this.deleteResidenceID,this.userId).subscribe(res => {
     
      this.getResidence();
    },err => {
      console.log(err)
    })
     
  }
}

searchResidence(){
  this.spinner.show();
  this.residenceErrMsg = '';
  this.residenceForm.markAsPristine();
  this.residenceForm.markAsUntouched();      
  this.buttonDisable = false;
  this.residenceObj = {};
  this.residenceTypeHistoryList = [];
  // this.searchResidenceObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.searchResidence(this.searchResidenceObj).subscribe(res =>{
   
    this.residenceArr = res.residenceList;
    if(this.residenceArr.length == 0){
      this.residenceErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

//Profession

professionForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  shortDescription : new FormControl("", [Validators.required]),
  remarks : new FormControl(""),
  createdBy: new FormControl(""),
});

professionData(){
  if(!this.professionObj.professionId){
    this.professionForm.removeControl('remarks');
    this.professionObj.professionId = 0
  }
  if(this.professionForm.valid)
  {
    // this.spinner.show();
    this.professionObj.createdBy = this.userId;
    this.professionObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')

    console.log(this.professionObj)
    this._lookupSevice.addProfession(this.professionObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getProfession();
    })
  }
}

getProfession(){
  this.professionPage = 1;
  this.professionErrMsg = '';
  this.professionForm.markAsPristine();
  this.professionForm.markAsUntouched();      
  this.buttonDisable = false;
  this.professionObj = {};
  this.professionHistoryList = [];
  this.searchProfessionObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getProfession().subscribe(res =>{
   
    this.professionArr = res.professionList;
    if(this.professionArr.length == 0){
      this.professionErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

viewProfession(id){
  if(this.buttonDisable == false){
    this.spinner.show();
  this.professionForm.markAsPristine();
  this.professionForm.markAsUntouched();      
  this.buttonDisable = false;
  this.professionObj = {};
  this.professionHistoryList = [];
  // this.searchProfessionObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.professionForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleProfession(id).subscribe(res =>{
     
      this.professionObj = res.profession;
      this.professionHistoryList = res.professionHistoryList;
     
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

clearProfession(){
this.spinner.show();
// this.professionForm.removeControl('remarks');
this.getProfession();
}

editProfession(editProfessionId){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.professionForm.markAsPristine();
    this.professionForm.markAsUntouched();      
    this.buttonDisable = false;
    this.professionObj = {};
    this.professionHistoryList = [];
    // this.searchProfessionObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.professionForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleProfession(editProfessionId).subscribe(res =>{
      this.professionObj = res.profession;
      this.professionHistoryList = res.professionHistoryList;
     
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

deleteProfessionId(deleteProfessionId){
  if(this.buttonDisable == false){
    this.professionForm.markAsPristine();
    this.professionForm.markAsUntouched();      
    this.buttonDisable = false;
    this.professionObj = {};
    this.professionHistoryList = [];
    // this.searchProfessionObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.deleteProfessionID = deleteProfessionId;
  }
}

deleteProfession(){
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteProfession(this.deleteProfessionID,this.userId).subscribe(res => {
     
      this.getProfession();
    },err => {
      console.log(err)
    })
     
  }
}

searchProfession(){
  this.spinner.show();
  this.professionErrMsg = '';
  this.professionForm.markAsPristine();
  this.professionForm.markAsUntouched();      
  this.buttonDisable = false;
  this.professionObj = {};
  this.professionHistoryList = [];
  // this.searchProfessionObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.searchProfession(this.searchProfessionObj).subscribe(res =>{
   
    this.professionArr = res.professionList;
    if(this.professionArr.length == 0){
      this.professionErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

// Medical Test

medicalTestForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  shortDescription : new FormControl("", [Validators.required]),
  remarks : new FormControl(""),
  createdBy: new FormControl(""),
});

medicalTestData(){
  if(!this.medicalTestObj.id){
    this.medicalTestForm.removeControl('remarks');
    this.medicalTestObj.id = 0
  }
  if(this.medicalTestForm.valid)
  {
    // this.spinner.show();
    this.medicalTestObj.createdBy = this.userId;
    this.medicalTestObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
   
    console.log(this.medicalTestObj)
    this._lookupSevice.addMedicalTest(this.medicalTestObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getMedicalTest();
    })
  }
}

getMedicalTest(){
  this.medicalTestPage = 1;
  this.medicalTestErrMsg = '';
  this.medicalTestForm.markAsPristine();
  this.medicalTestForm.markAsUntouched();      
  this.buttonDisable = false;
  this.medicalTestObj = {};
  this.medicalTestHistoryList = [];
  this.searchMedicalTestObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getMedicalTest().subscribe(res =>{
   
    this.medicalTestArr = res.list;
    if(this.medicalTestArr.length == 0){
      this.medicalTestErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

viewMedicalTest(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.medicalTestForm.markAsPristine();
    this.medicalTestForm.markAsUntouched();      
    this.buttonDisable = false;
    this.medicalTestObj = {};
    this.medicalTestHistoryList = [];
    // this.searchMedicalTestObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.medicalTestForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleMedicalTest(id).subscribe(res =>{
     
      this.medicalTestObj = res.obj;
      this.medicalTestHistoryList = res.list;
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

clearMedicalTest(){
this.spinner.show();
// this.medicalTestForm.removeControl('remarks');
this.getMedicalTest();
}

editMedicalTest(editMedicalTestId){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.medicalTestForm.markAsPristine();
    this.medicalTestForm.markAsUntouched();      
    this.buttonDisable = false;
    this.medicalTestObj = {};
    this.medicalTestHistoryList = [];
    // this.searchMedicalTestObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.medicalTestForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleMedicalTest(editMedicalTestId).subscribe(res =>{
      this.medicalTestObj = res.obj;
      this.medicalTestHistoryList = res.list;
     
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

deleteMedicalTestId(deleteMedicalTestId){
  if(this.buttonDisable == false){
    this.medicalTestForm.markAsPristine();
    this.medicalTestForm.markAsUntouched();      
    this.buttonDisable = false;
    this.medicalTestObj = {};
    this.medicalTestHistoryList = [];
    // this.searchMedicalTestObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.deleteMedicalTestID = deleteMedicalTestId;
  }
}

deleteMedicalTest(){
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteMedicalTest(this.deleteMedicalTestID,this.userId).subscribe(res => {
     
      this.getMedicalTest();
    },err => {
      console.log(err)
    })
  }
}

searchMedicalTest(){
  this.spinner.show();
  this.medicalTestErrMsg = '';
  this.medicalTestForm.markAsPristine();
  this.medicalTestForm.markAsUntouched();      
  this.buttonDisable = false;
  this.medicalTestObj = {};
  this.medicalTestHistoryList = [];
  // this.searchMedicalTestObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.searchMedicalTest(this.searchMedicalTestObj).subscribe(res =>{
   
    this.medicalTestArr = res.list;
    if(this.medicalTestArr.length == 0){
      this.medicalTestErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })

}

FrequencyForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  shortDescription : new FormControl("",[Validators.required]),
  remarks : new FormControl(""),
  createdBy: new FormControl(""),
});

addFrequency()
{
  if(!this.frequencyObj.frequencyId){
    this.FrequencyForm.removeControl('remarks');
    this.frequencyObj.frequencyId = 0
  }
  if(this.FrequencyForm.valid)
  {
    // this.spinner.show();
    this.frequencyObj.createdBy = this.userId;
    this.frequencyObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
   
    console.log(this.frequencyObj)
    this._lookupSevice.addFrequency(this.frequencyObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
    this.getFrequency();
    },err => {
      console.log(err)
    })

  }
}

getFrequency(){
  this.frequencyPage = 1;
  this.frequencyErrMsg = '';
  this.frequencyObj = {};
  this.FrequencyForm.markAsPristine();
  this.FrequencyForm.markAsUntouched();
  this.isReadonly = true;
  this.buttonDisable = false;
  this.paymentFrequencyHistoryList = [];
  this.searchFrequencyObj = {};
 this.viewRemarkInput = false;
 this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getFrequency().subscribe(res =>{
   
    this.frequencyArr = res.paymentFrequencyist;
    if(this.frequencyArr.length == 0){
      this.frequencyErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}


deleteFrequencyId(delFreId)
{
  if(this.buttonDisable == false){
    this.deleteFreId = delFreId;
    this.FrequencyForm.markAsPristine();
    this.FrequencyForm.markAsUntouched();
    this.frequencyObj = {};
    // this.searchPaymentObj = {};
    this.paymentFrequencyHistoryList = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;

 
  }

}

deleteFrequency()
{
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteFrequency(this.deleteFreId,this.userId).subscribe(res => {
     
      this.getFrequency();
    },err => {
      console.log(err)
    })
     
  }
}


editFrequency(editFreId){
if(this.buttonDisable == false){
this.spinner.show();
this.viewRemarkInput = false;
this.editRemarkInput = false;
this.isReadonly = true;
this.FrequencyForm.markAsPristine();
this.FrequencyForm.markAsUntouched();
this.frequencyObj = {};
// this.searchPaymentObj = {};
this.paymentFrequencyHistoryList = [];
this.FrequencyForm.addControl('remarks', new FormControl(''));
this._lookupSevice.getSingleFrequency(editFreId).subscribe(res =>{
 
  this.frequencyObj = res.paymentFrequency;
  this.paymentFrequencyHistoryList = res.paymentFrequencyList;
  this.buttonDisable = true;
  this.editRemarkInput = true;
  this.isReadonly = true;
  this.spinner.hide();
}, err =>{
  console.log(err);
})
}
}

frequencyClear(){
  this.spinner.show();
  // this.FrequencyForm.removeControl('remarks');
  this.getFrequency();
}

viewFrequency(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.FrequencyForm.markAsPristine();
    this.FrequencyForm.markAsUntouched();
    this.frequencyObj = {};
    // this.searchPaymentObj = {};
    this.paymentFrequencyHistoryList = [];
    this.FrequencyForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleFrequency(id).subscribe(res =>{
      this.frequencyObj = res.paymentFrequency;
      this.paymentFrequencyHistoryList = res.paymentFrequencyList;
     
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

searchFrequency(){
this.spinner.show();
this.frequencyErrMsg = '';
this.viewRemarkInput = false;
this.editRemarkInput = false;
this.buttonDisable = false;
this.isReadonly = true;
this.FrequencyForm.markAsPristine();
this.FrequencyForm.markAsUntouched();
this.frequencyObj = {};
this.paymentFrequencyHistoryList = [];
this._lookupSevice.searchFrequency(this.searchFrequencyObj).subscribe(res =>{
  this.frequencyArr = res.paymentFrequencyList;
  if(this.frequencyArr.length == 0){
    this.frequencyErrMsg = 'Not Found';
  }
  this.spinner.hide();
},err =>{
  console.log(err);
})
}

//Type of Business

BusinessForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  shortDescription : new FormControl("",[Validators.required]),
  remarks : new FormControl(""),
  createdBy: new FormControl(""),
});

addBusiness()
{
  if(!this.businessObj.businessTypeId){
    this.BusinessForm.removeControl('remarks');
    this.businessObj.businessTypeId = 0
  }
  if(this.BusinessForm.valid)
  {
    // this.spinner.show();
    this.businessObj.createdBy = this.userId;
    this.businessObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
 
    console.log(this.businessObj)
    this._lookupSevice.addBusiness(this.businessObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
    this.getBusiness();
    },err => {
      console.log(err)
    })

  }
}

getBusiness(){
  this.businessPage = 1;
  this.businessErrMsg = '';
  this.businessObj = {};
  this.BusinessForm.markAsPristine();
  this.BusinessForm.markAsUntouched();
  this.isReadonly = true;
  this.buttonDisable = false;
  this.businessTypeHistoryList = [];
  this.searchBusinessObj = {};
 this.viewRemarkInput = false;
 this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getBusiness().subscribe(res =>{
    this.businessArr = res.businessList;
    if(this.businessArr.length == 0){
      this.businessErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}


deleteBusinessId(delBusId)
{
  if(this.buttonDisable == false){
    this.deleteBusId = delBusId;
    this.BusinessForm.markAsPristine();
    this.BusinessForm.markAsUntouched();
    this.businessObj = {};
    // this.searchPaymentObj = {};
    this.businessTypeHistoryList = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;

 
  }

}

deleteBusiness()
{
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteBusiness(this.deleteBusId,this.userId).subscribe(res => {
      this.getBusiness();
    },err => {
      console.log(err)
    })
     
  }
}


editBusiness(editBusId){
if(this.buttonDisable == false){
this.spinner.show();
this.viewRemarkInput = false;
this.editRemarkInput = false;
this.isReadonly = true;
this.BusinessForm.markAsPristine();
this.BusinessForm.markAsUntouched();
this.businessObj = {};
// this.searchPaymentObj = {};
this.businessTypeHistoryList = [];
this.BusinessForm.addControl('remarks', new FormControl(''));
this._lookupSevice.getSingleBusiness(editBusId).subscribe(res =>{
  this.businessObj = res.businessType;
  this.businessTypeHistoryList = res.businessTypeHistoryList;
  this.buttonDisable = true;
  this.editRemarkInput = true;
  this.isReadonly = true;
  this.spinner.hide();
}, err =>{
  console.log(err);
})
}
}

businessClear(){
  this.spinner.show();
  // this.BusinessForm.removeControl('remarks');
  this.getBusiness();
}

viewBusiness(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.BusinessForm.markAsPristine();
    this.BusinessForm.markAsUntouched();
    this.businessObj = {};
    // this.searchPaymentObj = {};
    this.businessTypeHistoryList = [];
    this.BusinessForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleBusiness(id).subscribe(res =>{
      this.businessObj = res.businessType;
      this.businessTypeHistoryList = res.businessTypeHistoryList;
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

searchBusiness(){
this.spinner.show();
this.businessErrMsg = '';
this.viewRemarkInput = false;
this.editRemarkInput = false;
this.buttonDisable = false;
this.isReadonly = true;
this.BusinessForm.markAsPristine();
this.BusinessForm.markAsUntouched();
this.businessObj = {};
this.businessTypeHistoryList = [];
this._lookupSevice.searchBusiness(this.searchBusinessObj).subscribe(res =>{
 
  this.businessArr = res.businessList;
  if(this.businessArr.length == 0){
    this.businessErrMsg = 'Not Found';
  }
  this.spinner.hide();
},err =>{
  console.log(err);
})
}

//State

stateForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  isDeclined : new FormControl("",[Validators.required]),
  remarks : new FormControl(""),
  countryId : new FormControl(""),
  tinNumber : new FormControl(""),
  createdBy: new FormControl(""),
});

stateData(){
  if(!this.stateObj.stateId){
    this.stateForm.removeControl('remarks');
    this.stateObj.stateId = 0
  }
  if(this.stateForm.valid)
  {
    // this.spinner.show();
    this.stateObj.createdBy = this.userId;
    this.stateObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
    this.stateObj.countryId = this.countryValue;
  ;
    console.log(this.stateObj)
    this._lookupSevice.addState(this.stateObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getState();
    })
  }
}

getState(){
  this.statePage = 1;
  this.stateErrMsg = '';
  this.stateForm.markAsPristine();
  this.stateForm.markAsUntouched();      
  this.buttonDisable = false;
  this.stateObj = {};
  this.stateHistoryList = [];
  this.searchStateObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getState(this.countryValue).subscribe(res =>{
   
    this.stateArr = res.list;
    if(this.stateArr.length == 0){
      this.stateErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

viewState(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.stateForm.markAsPristine();
    this.stateForm.markAsUntouched();      
    this.buttonDisable = false;
    this.stateObj = {};
    this.stateHistoryList = [];
    // this.searchStateObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.stateForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleState(id).subscribe(res =>{
     
      this.stateObj = res.obj;
      this.stateHistoryList = res.list;
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

clearState(){
  this.spinner.show();
  // this.stateForm.removeControl('remarks');
  this.getState();
}

editState(editStateId){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.stateForm.markAsPristine();
    this.stateForm.markAsUntouched();      
    this.buttonDisable = false;
    this.stateObj = {};
    this.stateHistoryList = [];
    // this.searchStateObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.stateForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleState(editStateId).subscribe(res =>{
      this.stateObj = res.obj;
      this.stateHistoryList = res.list;
     
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

deleteStateId(deleteStateId){
  if(this.buttonDisable == false){
    this.stateForm.markAsPristine();
    this.stateForm.markAsUntouched();      
    this.buttonDisable = false;
    this.stateObj = {};
    this.stateHistoryList = [];
    // this.searchStateObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.deleteStateID = deleteStateId;
  }
}

deleteState(){
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteState(this.deleteStateID,this.userId).subscribe(res => {
      this.getState();
    },err => {
      console.log(err)
    })
  }
}

searchState(){
  this.spinner.show();
  this.stateErrMsg = '';
  this.stateForm.markAsPristine();
  this.stateForm.markAsUntouched();      
  this.buttonDisable = false;
  this.stateObj = {};
  this.stateHistoryList = [];
  // this.searchStateObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.searchStateObj.countryId = this.countryValue;
  this._lookupSevice.searchState(this.searchStateObj).subscribe(res =>{
    this.stateArr = res.list;
    if(this.stateArr.length == 0){
      this.stateErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

//District

districtForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  zipCode : new FormControl("",[Validators.required]),
  remarks : new FormControl(""),
  stateId : new FormControl(""),
  createdBy: new FormControl(""),
});

districtData(){
  if(!this.districtObj.districtId){
    this.districtForm.removeControl('remarks');
    this.districtObj.districtId = 0;
  }
  if(this.districtForm.valid)
  {
    // this.spinner.show();
    this.districtObj.createdBy = this.userId;
    this.districtObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
    this.districtObj.stateId = this.stateValue;
 
    console.log(this.districtObj)
    this._lookupSevice.addDistrict(this.districtObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getDistrict();
    })
  }
}

getDistrict(){
  this.districtPage = 1;
  this.districtErrMsg = '';
  this.districtForm.markAsPristine();
  this.districtForm.markAsUntouched();      
  this.buttonDisable = false;
  this.districtObj = {};
  this.districtHistoryList = [];
  this.searchDistrictObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getDistrict(this.stateValue).subscribe(res =>{
   this.districtArr = res.list;
    if(this.districtArr.length == 0){
      this.districtErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

viewDistrict(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.districtForm.markAsPristine();
    this.districtForm.markAsUntouched();      
    this.buttonDisable = false;
    this.districtObj = {};
    this.districtHistoryList = [];
    // this.searchDistrictObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.districtForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleDistrict(id).subscribe(res =>{
     this.districtObj = res.obj;
      this.districtHistoryList = res.list;
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

clearDistrict(){
  this.spinner.show();
  // this.districtForm.removeControl('remarks');
  this.getDistrict();
}

editDistrict(editDistrictId){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.districtForm.markAsPristine();
    this.districtForm.markAsUntouched();      
    this.buttonDisable = false;
    this.districtObj = {};
    this.districtHistoryList = [];
    // this.searchDistrictObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.districtForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleDistrict(editDistrictId).subscribe(res =>{
      this.districtObj = res.obj;
      this.districtHistoryList = res.list;
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

deleteDistrictId(deleteDistrictId){
  if(this.buttonDisable == false){
    this.districtForm.markAsPristine();
    this.districtForm.markAsUntouched();      
    this.buttonDisable = false;
    this.districtObj = {};
    this.districtHistoryList = [];
    // this.searchDistrictObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.deleteDistrictID = deleteDistrictId;
  }
}

deleteDistrict(){
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteDistrict(this.deleteDistrictID,this.userId).subscribe(res => {
     
      this.getDistrict();
    },err => {
      console.log(err)
    })
  }
}

searchDistrict(){
  this.spinner.show();
  this.districtErrMsg = '';
  this.districtForm.markAsPristine();
  this.districtForm.markAsUntouched();      
  this.buttonDisable = false;
  this.districtObj = {};
  this.districtHistoryList = [];
  // this.searchDistrictObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.searchDistrictObj.stateId = this.stateValue;
  this._lookupSevice.searchDistrict(this.searchDistrictObj).subscribe(res =>{
    this.districtArr = res.list;
    if(this.districtArr.length == 0){
      this.districtErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

//Post Office

postOfficeForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  zipCode : new FormControl("",[Validators.required]),
  remarks : new FormControl(""),
  districtId : new FormControl(""),
  createdBy: new FormControl(""),
});

postOfficeData(){
  if(!this.postOfficeObj.postOfficeId){
    this.postOfficeForm.removeControl('remarks');
    this.postOfficeObj.postOfficeId = 0;
  }
  if(this.postOfficeForm.valid)
  {
    // this.spinner.show();
    this.postOfficeObj.createdBy = this.userId;
    this.postOfficeObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
    this.postOfficeObj.districtId = this.districtValue;
 
   
    console.log(this.postOfficeObj)
    this._lookupSevice.addPostOffice(this.postOfficeObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getPostoffice();
    })
  }
}

getPostoffice(){
  this.postOfficePage = 1;
  this.postOfficeErrMsg = '';
  this.postOfficeForm.markAsPristine();
  this.postOfficeForm.markAsUntouched();      
  this.buttonDisable = false;
  this.postOfficeObj = {};
  this.postOfficeHistoryList = [];
  this.searchPostOfficeObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getPostOffice(this.districtValue).subscribe(res =>{
   this.postOfficeArr = res.list;
    if(this.postOfficeArr.length == 0){
      this.postOfficeErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

viewPostOffice(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.postOfficeForm.markAsPristine();
    this.postOfficeForm.markAsUntouched();      
    this.buttonDisable = false;
    this.postOfficeObj = {};
    this.postOfficeHistoryList = [];
    // this.searchPostOfficeObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.postOfficeForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSinglePostOffice(id).subscribe(res =>{
      this.postOfficeObj = res.obj;
      this.postOfficeHistoryList = res.list;
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

clearPostOffice(){
  this.spinner.show();
  // this.postOfficeForm.removeControl('remarks');
  this.getPostoffice();
}

editPostOffice(editPostOfficeId){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.postOfficeForm.markAsPristine();
    this.postOfficeForm.markAsUntouched();      
    this.buttonDisable = false;
    this.postOfficeObj = {};
    this.postOfficeHistoryList = [];
    // this.searchPostOfficeObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.postOfficeForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSinglePostOffice(editPostOfficeId).subscribe(res =>{
      this.postOfficeObj = res.obj;
      this.postOfficeHistoryList = res.list;
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

deletePostOfficeId(deletePostOfficeId){
  if(this.buttonDisable == false){
    this.postOfficeForm.markAsPristine();
    this.postOfficeForm.markAsUntouched();      
    this.buttonDisable = false;
    this.postOfficeObj = {};
    this.postOfficeHistoryList = [];
    // this.searchPostOfficeObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.deletePostOfficeID = deletePostOfficeId;
  }
}

deletePostOffice(){
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deletePostOffice(this.deletePostOfficeID,this.userId).subscribe(res => {
      this.getPostoffice();
    },err => {
      console.log(err)
    })
  }
}

searchPostOffice(){
  this.spinner.show();
  this.postOfficeErrMsg = '';
  this.postOfficeForm.markAsPristine();
  this.postOfficeForm.markAsUntouched();      
  this.buttonDisable = false;
  this.postOfficeObj = {};
  this.postOfficeHistoryList = [];
  // this.searchPostOfficeObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.searchPostOfficeObj.districtId = this.districtValue;
  this._lookupSevice.searchPostOffice(this.searchPostOfficeObj).subscribe(res =>{
    this.postOfficeArr = res.list;
    if(this.postOfficeArr.length == 0){
      this.postOfficeErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

//City

cityForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  shortDescription : new FormControl("",[Validators.required]),
  remarks : new FormControl(""),
  districtId : new FormControl(""),
  createdBy: new FormControl(""),
});

cityData(){
  if(!this.cityObj.cityId){
    this.cityForm.removeControl('remarks');
    this.cityObj.cityId = 0;
  }
  if(this.cityForm.valid){
    // this.spinner.show();
    this.cityObj.createdBy = this.userId;
    this.cityObj.districtId = this.districtValue;
 
    this.cityObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
    console.log(this.cityObj)
    this._lookupSevice.addCity(this.cityObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getCity();
    })
  }
}

getCity(){
  this.cityPage = 1;
  this.cityErrMsg = '';
  this.cityForm.markAsPristine();
  this.cityForm.markAsUntouched();      
  this.buttonDisable = false;
  this.cityObj = {};
  this.cityHistoryList = [];
  this.searchCityObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this._lookupSevice.getCity(this.districtValue).subscribe(res =>{
   this.cityArr = res.list;
    if(this.cityArr.length == 0){
      this.cityErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

viewCity(id){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.cityForm.markAsPristine();
    this.cityForm.markAsUntouched();      
    this.buttonDisable = false;
    this.cityObj = {};
    this.cityHistoryList = [];
    // this.searchCityObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.cityForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleCity(id).subscribe(res =>{
      this.cityObj = res.obj;
      this.cityHistoryList = res.list;
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

clearCityForm(){
  this.spinner.show();
  // this.cityForm.removeControl('remarks');
  this.getCity();
}

editCity(editCityId){
  if(this.buttonDisable == false){
    this.spinner.show();
    this.cityForm.markAsPristine();
    this.cityForm.markAsUntouched();      
    this.buttonDisable = false;
    this.cityObj = {};
    this.cityHistoryList = [];
    // this.searchCityObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.cityForm.addControl('remarks', new FormControl(''));
    this._lookupSevice.getSingleCity(editCityId).subscribe(res =>{
      this.cityObj = res.obj;
      this.cityHistoryList = res.list;
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
}

deleteCityId(deleteCityId){
  if(this.buttonDisable == false){
    this.cityForm.markAsPristine();
    this.cityForm.markAsUntouched();      
    this.buttonDisable = false;
    this.cityObj = {};
    this.cityHistoryList = [];
    // this.searchCityObj = {};
    this.viewRemarkInput = false;
    this.editRemarkInput = false;
    this.isReadonly = true;
    this.deleteCityID = deleteCityId;
  }
}

deleteCity(){
  if(this.buttonDisable == false)
  {
    this.spinner.show();
    this._lookupSevice.deleteCity(this.deleteCityID,this.userId).subscribe(res => {
      this.getCity();
    },err => {
      console.log(err)
    })
  }
}

searchCity(){
  this.spinner.show();
  this.cityErrMsg = '';
  this.cityForm.markAsPristine();
  this.cityForm.markAsUntouched();      
  this.buttonDisable = false;
  this.cityObj = {};
  this.cityHistoryList = [];
  // this.searchCityObj = {};
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.searchCityObj.districtId = this.districtValue;
  this._lookupSevice.searchCity(this.searchCityObj).subscribe(res =>{
    this.cityArr = res.list;
    if(this.cityArr.length == 0){
      this.cityErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

//Salutation

SalutationForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  remarks : new FormControl(""),
  createdBy: new FormControl(""),
});

getSalutation(){
  this.salutationPage = 1;
  this.salutationErrMsg = '';
  this.SalutationForm.markAsPristine();
      this.SalutationForm.markAsUntouched();
      this.salutationDataObj = {};
      this.searchSalutationObj = {};
      this.salutationHistory = [];
      this.buttonDisable = false;
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
  this._lookupSevice.getSalutation().subscribe(res =>{
    this.salutationArr = res.salutationList;
    if(this.salutationArr.length == 0){
      this.salutationErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

salutationData(){
  if(!this.salutationDataObj.salutationId){
    this.SalutationForm.removeControl('remarks');
    this.salutationDataObj.salutationId = 0
  }
  if(this.SalutationForm.valid)
  {
    // this.spinner.show();
    this.salutationDataObj.createdBy = this.userId;
    this.salutationDataObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
   
    console.log(this.salutationDataObj)
    this._lookupSevice.addSalutation(this.salutationDataObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getSalutation();
    })
  }
}

viewSalutation(id){
  if(this.buttonDisable == false){
  this.spinner.show();
  this.SalutationForm.markAsPristine();
  this.SalutationForm.markAsUntouched();
  this.salutationDataObj = {};
  // this.searchSalutationObj = {};
  this.salutationHistory = [];
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.SalutationForm.addControl('remarks', new FormControl(''));
  this._lookupSevice.getSingleSalutation(id).subscribe(res =>{
    this.salutationDataObj = res.salutation;
    // this.salutationHistory = res.salutationHistory;
    this.buttonDisable = true;
    this.viewRemarkInput = true;
    this.isReadonly = false;
    this.spinner.hide();
  }, err =>{
    console.log(err);
  })
}
}

salutationFormClear(){
  this.spinner.show();
  // this.SalutationForm.removeControl('remarks');
  this.getSalutation();
}

editSalutation(editSalId){
  if(this.buttonDisable == false){
  this.spinner.show();
  this.SalutationForm.markAsPristine();
  this.SalutationForm.markAsUntouched();
  this.salutationDataObj = {};
  // this.searchAccountObj = {};
  this.salutationHistory = [];
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.SalutationForm.addControl('remarks', new FormControl(''));
  this._lookupSevice.getSingleSalutation(editSalId).subscribe(res =>{
    this.salutationDataObj = res.salutation;
    // this.salutationHistory = res.salutionHistoryList;
    this.buttonDisable = true;
    this.editRemarkInput = true;
    this.isReadonly = true;
    this.spinner.hide();
  }, err =>{
    console.log(err);
  })
}
}

deleteSalutationId(delSalId){
  if(this.buttonDisable == false){
  this.SalutationForm.markAsPristine();
  this.SalutationForm.markAsUntouched();
  this.salutationDataObj = {};
  // this.searchSalutationObj = {};
  this.salutationHistory = [];
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.deleteSalId = delSalId;
  }
}

deleteSalutation(){
  if(this.buttonDisable == false){
  this.spinner.show();
  this._lookupSevice.deleteSalutation(this.deleteSalId, this.userId).subscribe(res =>{
    this.getSalutation();
  },err =>{
    console.log(err);
  })
}
}

searchSalutation(){
  this.spinner.show();
  this.salutationErrMsg = '';
  this.SalutationForm.markAsPristine();
  this.SalutationForm.markAsUntouched();
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.buttonDisable = false;
  this.salutationDataObj = {};
  this.salutationHistory = [];
  this._lookupSevice.searchSalutation(this.searchSalutationObj).subscribe(res =>{
    this.salutationArr = res.salutationList;
    if(this.salutationArr.length == 0){
      this.salutationErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

clearSearchSalutation(){
  this.spinner.show();
  // this.SalutationForm.removeControl('remarks');
   this.getSalutation();
}

//Currency

CurrencyForm = new FormGroup({
  description : new FormControl("", [Validators.required]),
  shortDescription : new FormControl("",[Validators.required]),
  remarks : new FormControl(""),
  createdBy: new FormControl(""),
});

getCurrency(){
  this.currencyPage = 1;
  this.currencyErrMsg = '';
  this.CurrencyForm.markAsPristine();
      this.CurrencyForm.markAsUntouched();
      this.currencyObj = {};
      this.searchCurrencyObj = {};
      this.currencyHistoryList = [];
      this.buttonDisable = false;
      this.viewRemarkInput = false;
      this.editRemarkInput = false;
      this.isReadonly = true;
  this._lookupSevice.getCurrency().subscribe(res =>{
    this.currencyArr = res.currencyList;
    if(this.currencyArr.length == 0){
      this.currencyErrMsg = 'Not Found';  
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

currencyData(){
  if(!this.currencyObj.currencyId){
    this.CurrencyForm.removeControl('remarks');
    this.currencyObj.currencyId = 0
  }
  if(this.CurrencyForm.valid)
  {
    // this.spinner.show();
    this.currencyObj.createdBy = this.userId;
    this.currencyObj.createdOn = this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
 
    console.log(this.currencyObj)
    this._lookupSevice.addCurrency(this.currencyObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getCurrency();
    })
  }
}

viewCurrency(id){
  if(this.buttonDisable == false){
  this.spinner.show();
  this.CurrencyForm.markAsPristine();
  this.CurrencyForm.markAsUntouched();
  this.currencyObj = {};
  // this.searchCurrencyObj = {};
  this.currencyHistoryList = [];
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.CurrencyForm.addControl('remarks', new FormControl(''));
  this._lookupSevice.getSingleCurrency(id).subscribe(res =>{
    this.currencyObj = res.currency;
    this.currencyHistoryList = res.currencyHistoryList;
    this.buttonDisable = true;
    this.viewRemarkInput = true;
    this.isReadonly = false;
    this.spinner.hide();
  }, err =>{
    console.log(err);
  })
}
}

currencyFormClear(){
  this.spinner.show();
  // this.CurrencyForm.removeControl('remarks');
  this.getCurrency();
}

editCurrency(editCurId){
  if(this.buttonDisable == false){
  this.spinner.show();
  this.CurrencyForm.markAsPristine();
  this.CurrencyForm.markAsUntouched();
  this.currencyObj = {};
  // this.searchCurrencyObj = {};
  this.currencyHistoryList = [];
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.CurrencyForm.addControl('remarks', new FormControl(''));
  this._lookupSevice.getSingleCurrency(editCurId).subscribe(res =>{
    this.currencyObj = res.currency;
    this.currencyHistoryList = res.currencyHistoryList;
    this.buttonDisable = true;
    this.editRemarkInput = true;
    this.isReadonly = true;
    this.spinner.hide();
  }, err =>{
    console.log(err);
  })
}
}

deleteCurrencyId(delCurId){
  if(this.buttonDisable == false){
  this.CurrencyForm.markAsPristine();
  this.CurrencyForm.markAsUntouched();
  this.currencyObj = {};
  // this.searchCurrencyObj = {};
  this.currencyHistoryList = [];
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.deleteCurId = delCurId;
  }
}

deleteCurrency(){
  if(this.buttonDisable == false){
  this.spinner.show();
  this._lookupSevice.deleteCurrency(this.deleteCurId, this.userId).subscribe(res =>{
    this.getCurrency();
  },err =>{
    console.log(err);
  })
}
}

searchCurrency(){
  this.spinner.show();
  this.currencyErrMsg = '';
  this.CurrencyForm.markAsPristine();
  this.CurrencyForm.markAsUntouched();
  this.viewRemarkInput = false;
  this.editRemarkInput = false;
  this.isReadonly = true;
  this.buttonDisable = false;
  this.currencyObj = {};
  this.currencyHistoryList = [];
  this._lookupSevice.searchCurrency(this.searchCurrencyObj).subscribe(res =>{
    this.currencyArr = res.currencyList;
    if(this.currencyArr.length == 0){
      this.currencyErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

clearSearchCurrency(){
  this.spinner.show();
  // this.CurrencyForm.removeControl('remarks');
  this.getCurrency();
}

cfn(val) {
  console.log(val);
}
 
}
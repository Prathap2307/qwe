import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
// import moment from 'moment'
import * as moment from "moment"
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
import { DesignationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/designation.service';
import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';
import { MatTableDataSource } from '@angular/material';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
import { CommisionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/commision.service';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';

// import moment = require('moment');
@Component({
  selector: 'app-fsaleshierarchy',
  templateUrl: './fsaleshierarchy.component.html',
  styleUrls: ['./fsaleshierarchy.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class FsaleshierarchyComponent implements OnInit {
  @ViewChild('picker', { static: true }) picker;
  @ViewChild('picker1', { static: true }) picker1;
  @ViewChild('picker2', { static: true }) picker2;
  @ViewChild('picker3', { static: true }) picker3;
  @ViewChild('picker4', { static: true }) picker4;
  @ViewChild('picker5', { static: true }) picker5;
  @ViewChild('picker6', { static: true }) picker6;
  @ViewChild('picker7', { static: true }) picker7;
  @ViewChild('picker8', { static: true }) picker8;
  @ViewChild('picker9', { static: true }) picker9;
  @ViewChild('picker10', { static: true }) picker10;
  pinobj: any;
  departmentObj: DepartmentType[];
  designationDDObj: Designation[];
  allchannel: any;
  allsubchannel: any;
  Sales: any;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  salesObj: any;
  transaction: string;
  addressIndex: any;
  msg: any;
  addressType: any;
  salutation: any;
  reporting: any;
  addresserror: boolean;
  organisationID: string;
  fail: boolean;
  resultdate: boolean;
  status: boolean=true;
  open() {
    this.picker.open();
    this.picker1.open();
    this.picker2.open();
    this.picker3.open();
    this.picker4.open();
    this.picker5.open();
    this.picker6.open();
    this.picker7.open();
    this.picker8.open();
    this.picker9.open();
    this.picker10.open();
  }
  SearchMarketingHierarchy: FormGroup;
  AddMarketingHierarchy: FormGroup;
  // AddAddress: FormGroup;
  submitted1: boolean;
  submitted2: boolean;
  submitted: boolean;


  SubchannelHeading: string = 'Add New - Marketing Hierarchy';
  saveBtnMode: boolean = true;
  AddAdressBtnMode: boolean = true;
  textSaveBtn: string = 'Save';

  checked = true
  view: boolean = false;
  AddressHeading: string = 'Add New - Address Details';
  adressSaveBtn: string = 'Add Address';
  country: any;
  state: any;
  District: any;
  add: any;
  allbranch: any;
  // Address: FormArray;
  address: FormGroup;
  Addressdata: any[] = [];
  id: any;
  isdob: boolean;
  isage: boolean;
  invalidsDob: boolean = false;
  invalidAge: boolean = false;
  display: string = 'none';
  validform: boolean;

  constructor(private fb: FormBuilder, private user: UserService, private fchannelService: FchannelService, private designationService: DesignationService, private departmentService: DepartmentService, private CommissionService: CommisionService, private BranchService: BranchService) {
  }

  pageChanged(event) {
    this.config.currentPage = event;
  }

  ngOnInit() {
    this.GetAllReportingTo()
    this.organisationID = localStorage.getItem('organisationID')
    this.getDesignationDetails();
    this.getDepartmentDetails();
    this.GetAllcountries()
    this.GetAllSalutation()
    this.getallbranches()
    this.getallchannel()
    this.GetAllSalesHierarchyBySearch()
    this.getaddresstype()
    this.SearchMarketingHierarchy = this.fb.group({
      firstName: [],
      lastName: [],
      Marketing_Officer_Code: [],
      channelID: [],
      subChannelID: [],
      Reporting_To: []

    })
    this.marketform()
    this.addressform()

  }

  marketform() {
    this.AddMarketingHierarchy = this.fb.group({
      salesHierarchyID: [],
      lineOfBusinessID: [5],
      applicationDate: [],
      dateofJoining: [],
      agentLocation: ['', [Validators.required]],
      organisationName: [],
      firstName: ['', [Validators.required]],
      salutationID: ['', [Validators.required]],
      lastName: [],
      gender: ['', [Validators.required]],
      dob: [],
      panNumber: ['', [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$')]],
      registredunder: [],
      registrationdate: [],
      miaagreementdate: [],
      codeIssuancedate: [],
      codeExpiredate: [],
      renewaldate: [],
      effectivedate: [],
      expiredate: [],
      code: ['', [Validators.required]],
      channelID: ['', [Validators.required]],
      subChannelID: ['', [Validators.required]],
      Reporting_To: [],
      isEmployee: ['', [Validators.required]],
      departmentID: ['', [Validators.required]],
      designationID: ['', [Validators.required]],
      branchID: ['',],
      isActive: ['', [Validators.required]],
      remarks: [],
      remarksDate: [],
      salesHierarchyAddressList: this.fb.array([
      ]),
      branchModalList: this.fb.array([
      ])
    })
  }
  addressform() {
    this.address = this.fb.group({
      addressID: ['',],
      address1: ['', [Validators.required]],
      address2: ['',],
      address3: [''],
      addressTypeID: ['', [Validators.required]],
      zipCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
      countryID: ['', [Validators.required]],
      stateID: ['', [Validators.required]],
      districtID: ['', [Validators.required]],
      phoneNo: [],
      mobileNo: [],
      conferenceNo: [],
      faxNo: [],
      email: ['', Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")],
    })

  }
  get m() { return this.SearchMarketingHierarchy.controls; }

  SearchMarket() {
    this.submitted = true;
    console.log(this.SearchMarketingHierarchy.value)
  }
  cancelsearch() {
    this.SearchMarketingHierarchy.reset()
    this.GetAllSalesHierarchyBySearch()
  }

  get am() { return this.AddMarketingHierarchy.controls; }
  get addr() { return this.address.controls }

  onCheckChange(event: any) {
    console.log(event)
    console.log(event.source.value)
    if (event.checked) {
      for (let i = 0; i < this.allbranch.length; i++) {
        if (event.source.value.branchId === this.allbranch[i].branchId) {
          this.allbranch[i]["checked"] = true
        }
      }
    }
    else {
      for (let i = 0; i < this.allbranch.length; i++) {
        if (event.source.value.branchId === this.allbranch[i].branchId) {
          this.allbranch[i]["checked"] = false
        }
      }
    }
    console.log(this.allbranch)

  }

  GetAllSalutation() {
    this.user.GetAllSalutation()
      .subscribe(result => {
        console.log(result)
        this.salutation = result.salutationList
      })
  }
  bindbysalutation(event: any) {
    console.log(event.target.value)
    if (event.target.value === '1') {
      let gender = {
        gender: 1,
      }
      this.AddMarketingHierarchy.patchValue(gender)
    
    }
    else if (event.target.value === '3') {
      let gender = {
        gender: '',
      }
      this.AddMarketingHierarchy.patchValue(gender)
    }
    else {
      let gender = {
        gender: 2,
      }
      this.AddMarketingHierarchy.patchValue(gender)
    }
  }
  AddMarket() {
    console.log(this.AddMarketingHierarchy.value)
    for (let key in this.AddMarketingHierarchy.controls) {

      if (key === 'applicationDate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        console.log(this.AddMarketingHierarchy.value[key])
        this.AddMarketingHierarchy.value[key] = null
        console.log(this.AddMarketingHierarchy.value[key])
        console.log(this.AddMarketingHierarchy.controls["value"])
      }
      if (key === 'dateofJoining' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'dob' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'registrationdate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'miaagreementdate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'codeIssuancedate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'codeExpiredate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'renewaldate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'effectivedate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'expiredate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
      if (key === 'remarksDate' && this.AddMarketingHierarchy.controls[key].status === "INVALID") {
        this.AddMarketingHierarchy.value[key] = null
      }
    }
    console.log(this.AddMarketingHierarchy.value)
    this.submitted1 = true;
    this.AddMarketingHierarchy.value['salesHierarchyAddressList'] = this.Addressdata
    // this.AddMarketingHierarchy.value['branchModalList']=this.Addressdata
    let m = new Date().getUTCMonth() + 1
    let y = new Date().getUTCFullYear()
    let d = new Date().getUTCDate()
    let fromvalue = moment(new Date(this.AddMarketingHierarchy.value["dob"])).format('YYYY/MM/DD')
    let firstDate = moment(fromvalue);

    let secondDate = y + '/' + m + '/' + d;
    console.log(firstDate)
    let result = firstDate.diff(secondDate, 'days');
    console.log(result)
    console.log(this.AddMarketingHierarchy.controls)
    // for (let key in this.AddMarketingHierarchy.controls) {
    //   if ( this.AddMarketingHierarchy.controls[key].status === "INVALID" ) {
    //         console.log(this.AddMarketingHierarchy.controls[key])
    //         this.AddMarketingHierarchy.value[key]=null
    //       }
    // }
    if (result >= 0) {
      this.openModalDialog1()
      this.invalidsDob = true
      console.log("DOB should not be greater than or equal to current date")
    }
    else if (result > -18 && result < 0) {
      this.openModalDialog1()
      this.invalidAge = true
      console.log("Age should not be less than 18 years")
    }
    let fromDate = moment(new Date(this.AddMarketingHierarchy.value["codeIssuancedate"])).format('YYYY/MM/DD')
    let toDate = moment(new Date(this.AddMarketingHierarchy.value["codeExpiredate"])).format('YYYY/MM/DD')
    let codeIssuancedate = moment(fromDate);
    let codeExpiredate = moment(toDate);
    let resultdate = codeIssuancedate.diff(codeExpiredate, 'days');
    console.log(resultdate)
    if (resultdate > 0) {
      let msg = "Code Expire date should be greater than equal to Code Issuance date	"
      this.openModalDialog1()
      this.resultdate = true
      console.log(this.resultdate)
      
    }
    else if (this.AddMarketingHierarchy.valid && !this.invalidsDob && !this.invalidAge) {
      console.log(this.AddMarketingHierarchy.value)

      this.AddMarketingHierarchy.value['branchModalList'] = []
      for (let i = 0; i < this.allbranch.length; i++) {
        if (this.allbranch[i]["checked"] === true) {
          console.log(this.allbranch[i])
          this.AddMarketingHierarchy.value['branchModalList'].push(this.allbranch[i]);
        }
      }
      if (this.Addressdata && this.Addressdata.length === 0) {
        let message = "Please add atleast one Address Details."
        this.openModalDialog(message)
        this.addresserror = true
      }
      // this.AddMarketingHierarchy.value["applicationDate"]=moment(new Date(this.AddMarketingHierarchy.value["applicationDate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["dateofJoining"]=moment(new Date(this.AddMarketingHierarchy.value["dateofJoining"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["dob"]=moment(new Date(this.AddMarketingHierarchy.value["dob"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["registrationdate"]=moment(new Date(this.AddMarketingHierarchy.value["registrationdate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["miaagreementdate"]=moment(new Date(this.AddMarketingHierarchy.value["miaagreementdate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["codeIssuancedate"]=moment(new Date(this.AddMarketingHierarchy.value["codeIssuancedate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["codeExpiredate"]=moment(new Date(this.AddMarketingHierarchy.value["codeExpiredate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["renewaldate"]=moment(new Date(this.AddMarketingHierarchy.value["renewaldate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["effectivedate"]=moment(new Date(this.AddMarketingHierarchy.value["effectivedate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["expiredate"]=moment(new Date(this.AddMarketingHierarchy.value["expiredate"])).format('DD-MM-YYYY ')
      // this.AddMarketingHierarchy.value["remarksDate"]=moment(new Date(this.AddMarketingHierarchy.value["remarksDate"])).format('DD-MM-YYYY ')

      else {
        this.fchannelService.InsertOrUpdateSalesHierarchy(this.AddMarketingHierarchy.value)
          .subscribe(result => {
            console.log(result)
            if (result.data.salesHirarchyId > 0) {
              this.validform = true
              if (this.textSaveBtn === 'Update') {
                this.transaction = 'Marketing Hierarchy Updated Successufully'
                this.openModalDialog(this.transaction)
              }
              else {
                this.transaction = 'Marketing Hierarchy Created Successufully'
                this.openModalDialog(this.transaction)
              }
              this.cancel()
              this.submitted1 = false
              this.GetAllSalesHierarchyBySearch()
              this.getallbranches()
            }
            else {
              console.log(this.fail)
              this.fail = true
              this.openModalDialog(result.error)
            }

          });
        this.submitted1 = false
      }

    }
    console.log(this.invalidAge)
    console.log(this.invalidsDob)
  }

  getallbranches() {
    let branch = {
      "OrganisationID": this.organisationID,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
        if (this.allbranch) {
          console.log(this.allbranch)
          for (let k = 0; k < this.allbranch.length; k++) {
            this.allbranch[k]["checked"] = false

          }
        }
      });
  }
  GetAllSalesHierarchyBySearch() {
    this.fchannelService.GetAllSalesHierarchyBySearch()
      .subscribe(result => {
        console.log(result)
        this.Sales = result.data
        if (this.Sales) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.Sales.length
          }
        }
      });
  }
  get ad() { return this.AddMarketingHierarchy.controls.AddAddress; }


  AddAdress() {
    this.submitted2 = true;
    console.log(this.AddMarketingHierarchy.get('salesHierarchyAddressList'))
    if (this.address.valid) {
      this.validform = true
      console.log(this.id)
      if (this.id === -1 || this.id === undefined) {
        this.Addressdata.push(this.address.value);
        this.transaction = 'Address Details Added Successufully'
        this.openModalDialog(this.transaction)
        console.log(this.Addressdata);
      } else {
        this.Addressdata[this.id] = this.address.value;
        this.transaction = 'Address Details Updated Successufully'
        this.openModalDialog(this.transaction)
        console.log(this.Addressdata);
      }
      this.addressform()
      this.Addresscancel()

    }
  }
  getDesignationDetails(): void {

    this.designationService.getDesignationDetails(0, null)
      .subscribe(a => {
        this.designationDDObj = a;

      });

  }
  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => {
        this.departmentObj = departmentObj;

      });

  }
  removeaddress(id) {
    (<FormArray>this.AddMarketingHierarchy.get('salesHierarchyAddressList')).removeAt(id)
  }
  btngEdit_Click(id) {

    this.SubchannelHeading = 'Edit - Marketing Hierarchy';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.GetSalesHierarchyByID(id)
  }
  btngView_Click(id) {
    this.SubchannelHeading = 'View - Marketing Hierarchy';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.GetSalesHierarchyByID(id)
  }
  getaddresstype() {
    this.fchannelService.getaddresstype()
      .subscribe(result => {
        console.log(result)
        this.addressType = result.addressTypeList
      })
  }
  GetAllReportingTo() {
    console.log("result")
    this.fchannelService.GetAllReportingTo()
      .subscribe(result => {
        console.log(result)
        this.reporting = result.data
      })
  }

  GetSalesHierarchyByID(id) {
    this.fchannelService.GetSalesHierarchyByID(id)
      .subscribe(result => {
        console.log(result)
        this.salesObj = result.data
        console.log(this.salesObj)
        if (this.salesObj) {
          for (let key in this.salesObj) {
            // console.log(key, this.salesObj[key]);
            if (key === 'applicationDate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'dateofJoining' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'dob' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'registrationdate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'miaagreementdate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'codeIssuancedate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'codeExpiredate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'renewaldate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'effectivedate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'expiredate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
            if (key === 'remarksDate' && this.salesObj[key] === null) {
              this.salesObj[key] = ''
            }
          }
          this.AddMarketingHierarchy = this.fb.group({
            salesHierarchyID: [{ value: this.salesObj.salesHierarchyID, disabled: false }],
            lineOfBusinessID: [{ value: this.salesObj.lineOfBusinessID, disabled: false }],
            applicationDate: [{ value: new Date(this.salesObj.applicationDate), disabled: false }],
            dateofJoining: [{ value: new Date(this.salesObj.dateofJoining), disabled: false }],
            agentLocation: [{ value: this.salesObj.agentLocation, disabled: false }, [Validators.required]],
            organisationName: [{ value: this.salesObj.organisationName, disabled: false }],
            firstName: [{ value: this.salesObj.firstName, disabled: false }, [Validators.required]],
            salutationID: [{ value: this.salesObj.salutationID, disabled: false }, [Validators.required]],
            lastName: [{ value: this.salesObj.lastName, disabled: false }],
            gender: [{ value: this.salesObj.gender, disabled: false }, [Validators.required]],
            branchID: [{ value: true, disabled: false }],
            dob: [{ value: new Date(this.salesObj.dob), disabled: false }],
            panNumber: [{ value: this.salesObj.panNumber, disabled: false }, [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$')]],
            registredunder: [{ value: this.salesObj.registredunder, disabled: false }],
            registrationdate: [{ value: new Date(this.salesObj.registrationdate), disabled: false }],
            miaagreementdate: [{ value: new Date(this.salesObj.miaagreementdate), disabled: false }],
            codeIssuancedate: [{ value: new Date(this.salesObj.codeIssuancedate), disabled: false }],
            codeExpiredate: [{ value: new Date(this.salesObj.codeExpiredate), disabled: false }],
            renewaldate: [{ value: new Date(this.salesObj.renewaldate), disabled: false }],
            effectivedate: [{ value: new Date(this.salesObj.effectivedate), disabled: false }],
            expiredate: [{ value: new Date(this.salesObj.expiredate), disabled: false }],
            code: [{ value: this.salesObj.code, disabled: false }, [Validators.required]],
            channelID: [{ value: this.salesObj.channelID, disabled: false }, [Validators.required]],
            subChannelID: [{ value: this.salesObj.subChannelID, disabled: false }, [Validators.required]],
            Reporting_To: [{ value: this.salesObj.Reporting_To, disabled: false }],
            isEmployee: [{ value: this.salesObj.isEmployee, disabled: false }, [Validators.required]],
            departmentID: [{ value: this.salesObj.departmentID, disabled: false }, [Validators.required]],
            designationID: [{ value: this.salesObj.designationID, disabled: false }, [Validators.required]],
            isActive: [{ value: this.salesObj.isActive, disabled: false }, [Validators.required]],
            remarks: [{ value: this.salesObj.remarks, disabled: false }],
            remarksDate: [{ value: new Date(this.salesObj.remarksDate), disabled: false }],
            branchModalList: this.fb.array(this.salesObj.branchModalList),

          })
          // if( this.salesObj.branchModalList){
          //   const formArray: FormArray = this.AddMarketingHierarchy.get('branchModalList') as FormArray;
          //   for(let i=)
          //   formArray.push
          // }
          this.status=false
          console.log(this.AddMarketingHierarchy.value["branchModalList"])
          if (this.salesObj.subChannelID) {
            this.GetAllSubChannel(this.salesObj.subChannelID);
          }
          if (this.salesObj.salesHierarchyAddressList) {
            this.Addressdata = this.salesObj.salesHierarchyAddressList
          }
          if (this.salesObj.branchModalList) {
            for (let i = 0; i < this.salesObj.branchModalList.length; i++) {
              for (let k = 0; k < this.allbranch.length; k++) {
                if (this.salesObj.branchModalList[i]['branchId'] === this.allbranch[k]["branchId"]) {
                  console.log(this.allbranch[k])
                  console.log(true)
                  this.allbranch[k].checked = true

                }
              }
            }
          }


        }
      })
  }

  cancel() {
    this.marketform()
    this.getallbranches()
    console.log(this.submitted)
    this.Addressdata = []
    this.submitted1 = false
    this.SubchannelHeading = 'Add New - Marketing Hierarchy';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  AddressEdit_Click(id) {
    console.log(id)
    this.AddressHeading = 'Edit - Address Details';
    this.AddAdressBtnMode = true;
    this.adressSaveBtn = 'Update Address'
    this.id = id
    this.address = this.fb.group({
      address1: { value: this.Addressdata[id].address1, disabled: false },
      address2: { value: this.Addressdata[id].address2, disabled: false },
      address3: { value: this.Addressdata[id].address3, disabled: false },
      addressTypeID: { value: this.Addressdata[id].addressTypeID, disabled: false },
      zipCode: { value: this.Addressdata[id].zipCode, disabled: false },
      countryID: { value: this.Addressdata[id].countryID, disabled: false },
      stateID: { value: this.Addressdata[id].stateID, disabled: false },
      districtID: { value: this.Addressdata[id].districtID, disabled: false },
      phoneNo: { value: this.Addressdata[id].phoneNo, disabled: false },
      mobileNo: { value: this.Addressdata[id].mobileNo, disabled: false },
      conferenceNo: { value: this.Addressdata[id].conferenceNo, disabled: false },
      faxNo: { value: this.Addressdata[id].faxNo, disabled: false },
      email: { value: this.Addressdata[id].email, disabled: false },
    })
    if (this.Addressdata[id].countryID) {
      this.GetAllStates(this.Addressdata[id].countryID);
    }
    if (this.Addressdata[id].stateID) {
      this.GetAllDistricts(this.Addressdata[id].stateID);
    }
  }

  setIdDelete(i) {
    this.addressIndex = i

  }

  deleteAddress() {
    if (this.addressIndex !== -1) {
      this.Addressdata.splice(this.addressIndex, 1);
    }
    console.log()
  }
  Addresscancel() {
    this.addressform()
    console.log(this.submitted2)
    this.submitted2 = false
    this.AddressHeading = 'Add New - Address Details';
    this.AddAdressBtnMode = true;
    this.adressSaveBtn = 'Add Address'
  }
  pinValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }

  Select_country(event: any) {
    console.log(event.target.value)
    let zip = {
      PinCode: '',
    }

    this.address.patchValue(zip);
    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)
    let zip = {
      PinCode: '',
    }

    this.address.patchValue(zip);
    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    let zip = {
      PinCode: '',
    }

    this.address.patchValue(zip);
    console.log(event.target.value)


  }
  getallchannel() {
    this.CommissionService.GetAllMainChannel()
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        console.log(this.allchannel)
      });
  }
  Select_channel(event: any) {
    console.log(event.target.value)

    this.GetAllSubChannel(event.target.value);
  }
  GetAllSubChannel(id) {
    this.CommissionService.GetSubChannelByChannelID(id)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        console.log(this.allsubchannel)
      });
  }
  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  getdetailsbypin(a) {
    console.log(a)
    this.BranchService.GetAllDetailsByZipCode(a)
      .subscribe(result => {
        console.log(result)
        if (result.data.length > 0) {
          this.pinobj = result.data[0]
          this.GetAllStates(this.pinobj.countryID)
          this.GetAllDistricts(this.pinobj.stateID)

          let pin = {
            countryID: this.pinobj.countryID,
            stateID: this.pinobj.stateID,
            districtID: this.pinobj.districtID,

          }

          this.address.patchValue(pin);
        }
        else {
          let pin = {
            countryID: '',
            stateID: '',
            districtID: '',
          }

          this.address.patchValue(pin);
        }

      });
  }

  detectpin(event: any) {
    console.log(event.target.value.length);
    if (event.target.value.length === 6) {
      this.getdetailsbypin(this.address.value["zipCode"])
    }
  }
  dob(e: any) {
    console.log(e)
    console.log(this.AddMarketingHierarchy.value['dob'])
    if (this.AddMarketingHierarchy.value['dob'] > new Date()) {
      console.log("more")
    }
  }
  dateValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (charCode === 32 || (charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)

        event.preventDefault();
      }
    }
  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();

        }
        console.log(event.keyCode)
        // event.target.value = event.target.value.slice(0, 5).replace(/[^a-zA-Z]/g, "");
      }
      else if (l >= 5 && l <= 8) {

        console.log(l)
        console.log(charCode)
        // console.log(event.target.value.slice(5,9))
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l >= 8 && l <= 9) {
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  get PanError() {
    if (this.AddMarketingHierarchy.controls['panNumber'].hasError('pattern')) {
      return 'Please enter Valid PAN Number';
    } else if (this.AddMarketingHierarchy.controls['panNumber'].hasError('minlength')) {
      return 'Please Enter 10 digits of PAN Number.';
    }
  }
  faxNphoneValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 11) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }

  openModalDialog(msg) {
    console.log(this.display)
    this.msg = msg
    this.display = 'block'; //Set block css
  }
  openModalDialog1() {
    console.log(this.display)
    this.display = 'block'; //Set block css
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    if (this.invalidsDob) {
      this.invalidsDob = false
    }
    else if (this.invalidAge) {
      this.invalidAge = false
    }
    // else if (this.submitted1 === false) {
    //   this.marketform()

    // }
    this.resultdate=false
    this.addresserror = false
    this.fail = false
    this.msg = ''
  }
  // get pinError() {
  //   if (this.AddAddress.controls['PinCode'].hasError('required')) {
  //     return 'Please enter the Pin Code / Zip Code.';
  //   } else if (this.AddAddress.controls['PinCode'].hasError('pattern')) {
  //     return 'Please Enter Valid  Pin Code / Zip Code.';
  //   }
  // }


}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountingclassificationComponent } from './accountingclassification.component';

describe('AccountingclassificationComponent', () => {
  let component: AccountingclassificationComponent;
  let fixture: ComponentFixture<AccountingclassificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountingclassificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountingclassificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

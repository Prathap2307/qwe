export interface UserLoginType {
    FirstName: string;
    UserPassword: string;
}
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClaimassessmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/claimassessment.service';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
@Component({
  selector: 'app-claimsregistrationnew',
  templateUrl: './claimsregistrationnew.component.html',
  styleUrls: ['./claimsregistrationnew.component.css']
})
export class ClaimsregistrationnewComponent implements OnInit {

  dummyObj: string;
  tableColumns1: string[] = ['Select', 'CLAIMNUMBER', 'POLICYHOLDERNAME', 'POLICYNUMBER'];

  tableColumnsOne: string[] = ['edit', 'delete', 'documentType', 'image'];
  tableColumnsThree: string[] = ['claimNumber', 'assessor', 'assessorName', 'assessorBranch', 'assessorExpenses', 'assessmentRemarks'];
  constructor(private activatedRoute: ActivatedRoute, private claimAssessmentService: ClaimassessmentService, private fb: FormBuilder) { }

  divAssessorRemarksDetails: boolean;
  divAssessmentHistory: boolean;

  divCoverageDetails: boolean;
  divTotalPayable: boolean;
  divAssessorSelection: Boolean;
  divProcesses: Boolean;

  TypeClaim: string;
  ClaimForm: FormGroup;
  relationshipObj: any;

  causeOfDeathObj: any;
  paymentModeObj: any;
  selectProcessObj: any = [];
  claimDetailsObj: any;
  get ClaimDetailsGroup() {
    return this.ClaimForm.get('ClaimDetailsGroup') as FormGroup;
  }
  get TotalPayableGroup() {
    return this.ClaimForm.get('TotalPayableGroup') as FormGroup;
  }
  get expiryDetailsGroup() {
    return this.ClaimForm.get('expiryDetailsGroup') as FormGroup;
  }
  get claimId() {
    return this.ClaimForm.get('claimId') as FormControl;
  }
  get BeneficiaryDetailsGroup() {
    return this.ClaimForm.get('BeneficiaryDetailsGroup') as FormGroup;
  }

  beneficiaryGridObj: any = [];
  beneficiaryDataGridObj = new MatTableDataSource<any>(this.beneficiaryGridObj);
  AccountingTaxMappingColumns: string[] = ['Edit', 'Delete', 'beneficiaryName', 'beneficiaryAccountHolderName', 'relationShipID', 'share', 'claimAmountShare'];
  ngOnInit() {
    this.beneficiaryDataGridObj = new MatTableDataSource<any>(this.beneficiaryGridObj);

    this.activatedRoute.queryParams.subscribe(params => {
      this.TypeClaim = params['Type'];
      this.claimsPageLoad();
    });

    this.ClaimForm = this.fb.group({
      claimId: [''],
      ClaimDetailsGroup: this.fb.group({

        policyNumber: [''],
        claimNumber: [''],
        policyHolderName: [''],
        policyInceptionDate: [''],
        policyExpiryDate: [''],
        customerID: [''],
        plan: [''],
        profession: [''],
        sumInsured: [''],
        claimIntimationDate: [''],
        causeOfDeath: [''],
        DateOfEvent: [''],
      }),
      TotalPayableGroup: this.fb.group({
        amountPayable: ['']
      }),
      BeneficiaryDetailsGroup: this.fb.group({
        beneficiaryTempID: [''],
        beneficiaryID: [''],
        beneficiaryName: ['', Validators.required],
        beneficiaryAccountHolderName: ['', Validators.required],
        relationShipID: ['', Validators.required],
        iFSCCode: [''],
        accountType: [''],
        bankName: [''],
        accountNumber: [''],
        contactNo: [''],
        emailID: [''],
        share: ['', Validators.required],
        claimAmountShare: ['', Validators.required]
      }),
      expiryDetailsGroup: this.fb.group({
        dateOfLoss: [''],
        timeOfLoss: [''],
        placeOfLoss: [''],
        particularsOfLoss: [''],
        doctorNameandAddress: ['']
      })
    });

    this.getAllPendingClaims();
    this.getAllCauseOfDeath();
    this.getRelationshipDetails();
    this.getAllPaymentMode();
  }
  getRelationshipDetails() {
    this.claimAssessmentService.getRelationshipDetails()
      .subscribe(data => {

        this.relationshipObj = data;
      });

  }
  getAllPaymentMode() {
    this.claimAssessmentService.getAllPaymentMode()
      .subscribe(data => {

        this.paymentModeObj = data;
      });

  }
  claimsPageLoad() {
    if (this.TypeClaim.trim() == 'request') {
      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = false;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = true;
      this.divProcesses = true;


      this.selectProcessObj = [{
        "id": 1,
        "description": "Save"
      },
      {
        "id": 2,
        "description": "Hold"
      }];

    }

    if (this.TypeClaim.trim() == 'Assessment') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = false;
      this.divProcesses = true;

      this.selectProcessObj = [{
        "id": 1,
        "description": "Save"
      },
      {
        "id": 2,
        "description": "Hold"
      },
      {
        "id": 3,
        "description": "Reject"
      }];
    }

    if (this.TypeClaim.trim() == 'Approval') {
      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = false;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = true;
      this.divProcesses = true;

      this.selectProcessObj = [{
        "id": 1,
        "description": "Approve"
      },
      {
        "id": 2,
        "description": "Return"
      },
      {
        "id": 3,
        "description": "Reject"
      }];
    }

    if (this.TypeClaim.trim() == 'View') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = false;
      this.divProcesses = false;
    }

    if (this.TypeClaim.trim() == 'Reopen') {

      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = true;
      this.divProcesses = true;
    }
  }
  pendingClaimsObj: any;
  pendingClaimFilteredObj: any;
  getAllPendingClaimsTestFn() {
    //  this.pendingClaimsObj = [];
    this.pendingClaimsObj = [{
      "CONTACTNUMBER": "9812345678",
      "SHORTNAME": null,
      "CONTACTLASTNAME": "DURAI",
      "CUSTOMERGROUPID": "2000000001",
      "AGREEMENTENDDATE": null,
      "COREBUSINESS": "IT",
      "CONTACTFIRSTNAME": "DEEPAN",
      "GROUPID": 1,
      "GROUPNAME": "DEEPAN D12345",
      "AGREEMENTSTARTDATE": null,
      "SALUTATIONID": 1,
      "CONTACTMIDDLENAME": "SING",
      "MASTERPOLICYAGREEMENT": 0,
      "TNAME": "GRP",
      "FULLNAME": "DEEPANDURAI",
      "BRANCHID": 301
    }];
  }

  getAllPendingClaims() {



    this.claimAssessmentService.getAllPendingClaims(2, "hi", "a", "b", "dd", "ee", "we", 18, 2)
      .subscribe(data => {

        this.pendingClaimsObj = data;

      });

    //  this.getAllPendingClaimsTestFn();
  }
  getAllCauseOfDeath() {



    this.claimAssessmentService.getAllCauseOfDeath()
      .subscribe(data => {

        this.causeOfDeathObj = data;

      });

    //  this.getAllPendingClaimsTestFn();
  }
  cfn(a) {
    console.log(a);
  }

  btngvEdit_Click(id) {

    this.pendingClaimFilteredObj = this.pendingClaimsObj.filter((unit) => unit.CLAIMID == id);

    this.ClaimDetailsGroup.patchValue({

      policyNumber: this.pendingClaimFilteredObj[0].POLICYNUMBER,
      claimNumber: this.pendingClaimFilteredObj[0].CLAIMNUMBER,
      policyHolderName: this.pendingClaimFilteredObj[0].POLICYHOLDERNAME,
      policyInceptionDate: this.pendingClaimFilteredObj[0].POLICYSTARTDATE,
      policyExpiryDate: this.pendingClaimFilteredObj[0].POLICYSTARTDATE,
      customerID: this.pendingClaimFilteredObj[0].CONTACTID,
    });
    this.ClaimDetailsGroup.disable();
    this.TotalPayableGroup.disable();
    if (this.TypeClaim.trim() != 'request') {
      this.expiryDetailsGroup.disable();
    }

    // this.ClaimDetailsGroup.get('policyNumber').disable();
    // this.ClaimDetailsGroup.get('claimID').disable();
    // this.ClaimDetailsGroup.get('policyHolderName').disable();

    this.getClaimDetailsByClaimId(id);
    this.claimId.patchValue(
      this.pendingClaimFilteredObj[0].CLAIMID
    );

  }

  clearClaim() {

    this.ClaimDetailsGroup.reset({
      policyNumber: '',
      claimNumber: '',
      policyHolderName: '',
      policyInceptionDate: '',
      policyExpiryDate: '',
      customerID: '',
      plan: '',
      profession: '',
      sumInsured: '',
      claimIntimationDate: '',
      causeOfDeath: '',
      DateOfEvent: ''
    });

    this.TotalPayableGroup.reset({
      amountPayable: ''
    });
    this.ClaimForm.enable();
  }

  // TotalPayableGroup: this.fb.group({
  //   amountPayable: ['']
  // })

  ClaimDetailsByClaimIdPatch() {



    this.TotalPayableGroup.patchValue({
      amountPayable: this.claimDetailsObj[0].SUMINSURED
    });
    this.expiryDetailsGroup.patchValue({
      dateOfLoss: this.claimDetailsObj[0].DATEOFLOSS,
      timeOfLoss: this.claimDetailsObj[1].TIMEOFLOSS,
      placeOfLoss: this.claimDetailsObj[1].PLACEOFLOSS,
      particularsOfLoss: this.claimDetailsObj[1].PARTICULARSOFDEATH,
      doctorNameandAddress: this.claimDetailsObj[1].DOCTORNAMEANDADDRESS,
    });
  }
  getClaimDetailsByClaimId(id) {



    this.claimAssessmentService.getClaimDetailsByClaimId(id)
      .subscribe(data => {

        this.claimDetailsObj = data;
        this.ClaimDetailsByClaimIdPatch();
      });


  }


  saveBtnClick() {

    //this.ClaimForm.markAllAsTouched();

    //  if (this.PlanInformationFormGroup.valid) {
    console.log(this.TypeClaim.trim());

    if (this.TypeClaim.trim() == 'request') {

      let obj: Object = {
        "vClaimID": this.claimId.value,
        "vIsDeductible": 123,
        "vDeductibleAmount": 100,
        "vAccountBalance": 1100,
        "vAmountDeducted": 2500,
        "vAmountAdded": 5000,
        "vTotalApprovedAmount": 350.00,
        "vTotalAmountPayable": this.TotalPayableGroup.get('amountPayable').value,
        "vPreviousBalanceAmount": 2500,
        "vProfessionalCharges": 25000,
        "vProfessionalServiceTax": 2600,
        "vTotalProfessionalCharges": 28123987,
        "vSurveyorIncidentalCharges": 25422
      }

      console.log(obj);

      this.claimAssessmentService.updateClaimsPayableDetails(obj)
        .subscribe(data => { });


    }

    if (this.TypeClaim.trim() == 'Assessment') {

      let obj: Object = {
        "vClaimID": this.claimId.value,
        "vIsDeductible": 123,
        "vDeductibleAmount": 100,
        "vAccountBalance": 1100,
        "vAmountDeducted": 2500,
        "vAmountAdded": 5000,
        "vTotalApprovedAmount": 350.00,
        "vTotalAmountPayable": this.TotalPayableGroup.get('amountPayable').value,
        "vPreviousBalanceAmount": 2500,
        "vProfessionalCharges": 25000,
        "vProfessionalServiceTax": 2600,
        "vTotalProfessionalCharges": 28123987,
        "vSurveyorIncidentalCharges": 25422
      }

      console.log(obj);

      this.claimAssessmentService.updateClaimsPayableDetails(obj)
        .subscribe(data => { });


    }


    if (this.TypeClaim.trim() == 'Approval') {

      let obj: Object = {
        "vClaimID": this.claimId.value,
        "vIsDeductible": 123,
        "vDeductibleAmount": 100,
        "vAccountBalance": 1100,
        "vAmountDeducted": 2500,
        "vAmountAdded": 5000,
        "vTotalApprovedAmount": 350.00,
        "vTotalAmountPayable": this.TotalPayableGroup.get('amountPayable').value,
        "vPreviousBalanceAmount": 2500,
        "vProfessionalCharges": 25000,
        "vProfessionalServiceTax": 2600,
        "vTotalProfessionalCharges": 28123987,
        "vSurveyorIncidentalCharges": 25422
      }

      console.log(obj);

      this.claimAssessmentService.updateClaimsPayableDetails(obj)
        .subscribe(data => { });


    }

    // if (this.TypeClaim.trim() == 'Reopen') {
    //   let obj: Object = {
    //     "vClaimID": 1,
    //     "vDateOfLoss": 1,
    //     "vTimeOfLoss": 1,
    //     "vPlaceOfLoss": 1,
    //     "vParticularsOfDeath": 1,
    //     "vDoctorNameAndAddress": 1,
    //     "vPartialAdvanceClaimPayment": 1,
    //     "vCreatedBy": 1,
    //     "vCreatedOn": 1,
    //     "vIsActive": 1,
    //     "vIsAdditionalDcoument": 1,
    //     "vStatusID": 1,
    //     "vAssessmentRemarks": 1,
    //     "pApplicationID": 1,
    //     "pID": 1,
    //     "pCount": 1,
    //     "vResult": 1

    //   }

    //   console.log(obj);

    //   this.claimAssessmentService.updateClaimsPayableDetails(obj)
    //     .subscribe(data => { });

    // }


    //    }

  }

  addBeneficiaryFn() {
    this.BeneficiaryDetailsGroup.markAllAsTouched();
    if (this.BeneficiaryDetailsGroup.valid) {
      this.beneficiaryDataGridObj.data.push(this.createNewBeneficiary(this.beneficiaryDataGridObj.data.length + 1));
      this.beneficiaryDataGridObj.filter = "";


      this.BeneficiaryDetailsGroup.reset({
        beneficiaryName: '',
          beneficiaryAccountHolderName: '',
          relationShipID: '',
          iFSCCode: '',
          accountType: '',
          bankName: '',
          accountNumber: '',
          contactNo: '',
          emailID: '',
          share: '',
          claimAmountShare: ''
      });

    }
   
   
  }
  beneficiaryFilterGridObj: any;
  btngvEditBeneficiary_Click(id) {

   this.beneficiaryFilterGridObj = this.beneficiaryGridObj.filter((unit) => unit.beneficiaryTempID == id);
  
 
 console.log(this.beneficiaryFilterGridObj[0]);

 this.BeneficiaryDetailsGroup.reset({
 beneficiaryName: this.beneficiaryFilterGridObj[0].beneficiaryName,
    beneficiaryAccountHolderName: '',
    relationShipID: '',
    iFSCCode: '',
    accountType: '',
    bankName: '',
    accountNumber: '',
    contactNo: '',
    emailID: '',
    share: '',
    claimAmountShare: ''
});

    
  
  }
  createNewBeneficiary(id: number): any {
    return {
      beneficiaryTempID: id,

      beneficiaryID: this.BeneficiaryDetailsGroup.get('beneficiaryID').value,
      beneficiaryName: this.BeneficiaryDetailsGroup.get('beneficiaryName').value,
      beneficiaryAccountHolderName: this.BeneficiaryDetailsGroup.get('beneficiaryAccountHolderName').value,
      relationShipID: this.BeneficiaryDetailsGroup.get('relationShipID').value,
      iFSCCode: this.BeneficiaryDetailsGroup.get('iFSCCode').value,
      accountType: this.BeneficiaryDetailsGroup.get('accountType').value,
      bankName: this.BeneficiaryDetailsGroup.get('bankName').value,
      accountNumber: this.BeneficiaryDetailsGroup.get('accountNumber').value,
      contactNo: this.BeneficiaryDetailsGroup.get('contactNo').value,
      emailID: this.BeneficiaryDetailsGroup.get('emailID').value,
      share: this.BeneficiaryDetailsGroup.get('share').value,
      claimAmountShare: this.BeneficiaryDetailsGroup.get('claimAmountShare').value
    };
  }
}

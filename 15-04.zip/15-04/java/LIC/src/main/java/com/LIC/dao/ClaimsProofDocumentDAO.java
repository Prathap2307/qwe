package com.LIC.dao;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ClaimsProofDocumentModel;

@Repository
@SuppressWarnings("unchecked")
public class ClaimsProofDocumentDAO {
	

	@Autowired
	private EntityManager em;
	public int createClaimsProofDocument(ClaimsProofDocumentModel model) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spInsertClaimsProofOfDocument")
				
				.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)			
				.registerStoredProcedureParameter("vDocumentTypeID", Integer.class, ParameterMode.IN)				
				.registerStoredProcedureParameter("vDocumentNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vImageName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsAdditionDocument", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsactive", Integer.class, ParameterMode.IN)
				
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
				
				.setParameter("vClaimID", model.getClaimID())
				.setParameter("vDocumentTypeID", model.getDocumentTypeID())
				.setParameter("vDocumentNumber", model.getDocumentNumber())
				.setParameter("vImageName", model.getvImageName())
				.setParameter("vIsAdditionDocument", model.getIsAdditionDocument())
				.setParameter("vIsactive", model.getIsActive());
			
		query.execute();
		return (int)query.getOutputParameterValue("vResult");
	}
		
		public int createClaimCoverageMap(ClaimsProofDocumentModel model) {
			StoredProcedureQuery query = em.createStoredProcedureQuery("spInsertClaimCoverageMap")
					
					.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vCoverageID", Integer.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vTypeID", Integer.class, ParameterMode.IN)
				
					.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
					
					.setParameter("vClaimID", model.getClaimID())
					.setParameter("vCoverageID", model.getCoverageID())
					.setParameter("vTypeID", model.getTypeID());
				
			query.execute();
			return (int)query.getOutputParameterValue("vResult");
		

	}

		public int createclaimsMandatoryDocumentMap(ClaimsProofDocumentModel model) {
			StoredProcedureQuery query = em.createStoredProcedureQuery("spInsertClaimsMandatoryDocumentMap")
					
					.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vDocumentTypeID", Integer.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vDocumentNumber", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("vImageName", String.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vIsAdditionDocument", Integer.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				
					.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
					
					.setParameter("vClaimID", model.getClaimID())
					.setParameter("vDocumentTypeID", model.getDocumentTypeID())
					.setParameter("vDocumentNumber", model.getDocumentNumber())
					.setParameter("vImageName", model.getvImageName())
					.setParameter("vIsAdditionDocument", model.getIsAdditionDocument())
					.setParameter("vIsActive", model.getIsActive());
					
				
			query.execute();
			return (int)query.getOutputParameterValue("vResult");
		}
		
		
	/*
	 * vClaimID varchar2, vSerialNo number, vPaymentModeID number, vPaymentDate
	 * timestamp, vBankID number, vBankBranchID number, vChequeNo varchar2,
	 * vChequeDate timestamp, vCardTypeID number, vCardNo varchar2, vCardExpiryDate
	 * timestamp, vCardExpiryMonth varchar2, vCardExpiryYear varchar2, vAmount
	 * decimal, vBankBranchName Varchar2, vBankName Varchar2, vDescription Varchar2,
	 * vISFCCode Varchar2, vCreatedBy number, vCreatedOn timestamp,
	 */
		public int createclaimsSettlementPaymentDetails(ClaimsProofDocumentModel model) {
			StoredProcedureQuery query = em.createStoredProcedureQuery("spInsertClaimsSettlementPaymentDetails")
					
					.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vSerialNo", Integer.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vPaymentModeID", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("vPaymentDate", Date.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vBankID", Integer.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vBankBranchID", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("vChequeNo", String.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vChequeDate", Date.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vCardTypeID", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("vCardNo", String.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vCardExpiryDate", Date.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vCardExpiryMonth", Integer.class, ParameterMode.IN)
					.registerStoredProcedureParameter("vCardExpiryYear", String.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vAmount", BigDecimal.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vBankBranchName", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("vBankName", String.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vDescription", String.class, ParameterMode.IN)				
					.registerStoredProcedureParameter("vISFCCode", String.class, ParameterMode.IN)
					.registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)			
					.registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)				
				
					.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)					
					
					.setParameter("vClaimID", model.getClaimID())
					.setParameter("vSerialNo", model.getSerialNo())
					.setParameter("vPaymentModeID", model.getPaymentModeID())
					.setParameter("vPaymentDate", model.getPaymentDate())
					.setParameter("vBankID", model.getBankID())
					.setParameter("vBankBranchID", model.getBankBranchID())
					.setParameter("vChequeNo", model.getChequeNo())
					.setParameter("vChequeDate", model.getChequeDate())
					.setParameter("vCardTypeID", model.getCardTypeID())
					.setParameter("vCardNo", model.getCardNo())					
					.setParameter("vCardExpiryDate", model.getCardExpiryDate())
					.setParameter("vCardExpiryMonth", model.getCardExpiryMonth())
					.setParameter("vCardExpiryYear", model.getCardExpiryYear())
					.setParameter("vAmount", model.getAmount())
					.setParameter("vBankBranchName", model.getBankBranchName())
					.setParameter("vBankName", model.getBankName())
					.setParameter("vDescription", model.getDescription())
					.setParameter("vISFCCode", model.getiSFCCode())
					.setParameter("vCreatedBy", model.getCreatedBy())
					.setParameter("vCreatedOn", model.getCreatedOn());
				
			query.execute();
			return (int)query.getOutputParameterValue("vResult");
		}
}

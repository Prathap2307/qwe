package com.LIC.controller;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.InsurerModal;
import com.LIC.model.Response;
import com.LIC.model.TransactionContext;
import com.LIC.service.BranchService;
import com.LIC.service.ChannelService;
import com.LIC.service.ContactAddressService;
import com.LIC.service.CountryService;
import com.LIC.service.InsurerService;
import com.LIC.service.StateService;
import com.LIC.utils.dataobject.ValueObject;


@RestController
public class ConfigurationController {
	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(ConfigurationController.class);
	
	@Autowired
	public ConfigurationController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	@Autowired 	BranchService 			branchService;
	@Autowired 	CountryService			countryService;
	@Autowired 	StateService			stateService;
	@Autowired 	ChannelService 			channelService;
	@Autowired 	InsurerService 			insurerService;
	@Autowired 	ContactAddressService 	contactAddressService;
	
	@GetMapping(value = "/test", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getTest(@RequestHeader HttpHeaders httpHeaders) {
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		try {
			return responseGenerator.successResponse(context, "Success",
					HttpStatus.OK);
		} catch (Exception e) {
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllDetailsByZipCode", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllDetailsByZipCode(@RequestHeader HttpHeaders httpHeaders, @RequestParam("ZipCode") String ZipCode) {
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			System.out.println("ZipCode >"+ZipCode);
			return responseGenerator.successResponse(context, contactAddressService.GetAllDetailsByZipCode(ZipCode),HttpStatus.OK);
		} catch (Exception e) {
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetParentBranch", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetParentBranch(@RequestHeader HttpHeaders httpHeaders,@RequestParam("OrganizationId") long OrganizationId,
			@RequestParam("BranchId") long BranchId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, branchService.GetParentBranch(OrganizationId,BranchId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/InsertOrUpdateBranch", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public ResponseEntity<Response> InsertOrUpdate(@RequestHeader HttpHeaders httpHeader,
				@RequestBody HashMap<Object, Object> allRequestParams ) {
	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParams);

			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, branchService.InsertOrUpdateBranch(object), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@RequestMapping(value = "/getAllBranches", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> getAllBranches(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, branchService.getAllBranches(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@GetMapping(value = "/GetBranchByIdSer", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetBranchByIdSer(@RequestHeader HttpHeaders httpHeaders,@RequestParam("branchId") long BranchId) {

		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
					
			return responseGenerator.successResponse(context, branchService.GetBranchByIdSer(BranchId), HttpStatus.OK);
		
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/ActivateBranch", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> activateBranch(@RequestHeader HttpHeaders httpHeaders,@RequestParam("BranchId") long BranchId) {

		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {

			return responseGenerator.successResponse(context, branchService.activateBranch(BranchId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllDivisionByZoanlID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllDivisionByZoanlID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("ZonalId") long ZonalId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, branchService.getAllDivisionByZoanlID(ZonalId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllBranchByPageTypeID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllBranchByPageTypeID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("PageTypeId") long PageTypeId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, branchService.getAllBranchByPageTypeID(PageTypeId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/DeleteBranch", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> deleteBranchById(@RequestHeader HttpHeaders httpHeaders,@RequestParam("BranchId") long branchId
			,@RequestParam("deletedBy") int deletedBy
			,@RequestParam("pageTypeID") short pageTypeID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, branchService.deleteBranchById(branchId, deletedBy, pageTypeID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
}

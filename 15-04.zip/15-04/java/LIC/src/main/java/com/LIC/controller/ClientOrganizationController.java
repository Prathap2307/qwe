package com.LIC.controller;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.BenefitTypeDAO;
import com.LIC.dao.QuotationDAO;
import com.LIC.model.ApplicationPremiumDetails;
import com.LIC.model.Bank;
import com.LIC.model.BankBranch;
import com.LIC.model.BenefitType;
import com.LIC.model.ClientAddressDetails;
import com.LIC.model.ErrorDto;
import com.LIC.model.MasterBranch;
import com.LIC.model.MasterDedupe;
import com.LIC.model.MasterGrade;
import com.LIC.model.MasterGroupDetails;
import com.LIC.model.MasterModule;
import com.LIC.model.MasterPartyDetails;
import com.LIC.model.MasterPolicyNo;
import com.LIC.model.MasterPolicyUnitAddress;
import com.LIC.model.PartyReceiptDetails;
import com.LIC.model.PolicyAccountStatement;
import com.LIC.model.QuestionMap;
import com.LIC.model.Variant;
import com.LIC.service.IClientOrganizationService;
import com.LIC.service.IVariantService;

@CrossOrigin
@RestController
@RequestMapping("/client")
public class ClientOrganizationController {

	@Autowired 	private IClientOrganizationService iClientOrganizationService;
	
	@Autowired BenefitTypeDAO benefitTypeDao;
	
	@Autowired(required=true) IVariantService variantService;
	
	@Autowired private QuotationDAO quotationDAO;
	
	@RequestMapping(value = "/addClientOrganization/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateClientOrganization(@RequestBody MasterGroupDetails masterGroupDetails) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == masterGroupDetails) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		iClientOrganizationService.saveOrUpdate(masterGroupDetails);
		response.put("status", 1);
		response.put("message","addClientOrganization successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/addClientAddressDetails/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateClientAddress(@RequestBody ClientAddressDetails clientAddressDetails) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == clientAddressDetails) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		clientAddressDetails = iClientOrganizationService.saveOrUpdateAddress(clientAddressDetails);
		response.put("status", 1);
		response.put("message","addClientAddressDetails successfully.");
		response.put("ClientAddress", clientAddressDetails);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/groupGrade/delete/{gradeId}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteAccountType(@PathVariable Integer gradeId )throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == gradeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Account Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		iClientOrganizationService.deleteGroupGrade(gradeId);
		response.put("status", 1);
		response.put("message","groupGrade deleted successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/branch/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllBranch() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MasterBranch> list = iClientOrganizationService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/client/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchBranchBy(@RequestBody MasterGroupDetails masterGroupDetails) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MasterGroupDetails> list = iClientOrganizationService.searchBranch(masterGroupDetails);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/client/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllCient() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MasterGroupDetails> list = iClientOrganizationService.getAllCient(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/client/{clientId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getClientById(@PathVariable Integer clientId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		MasterGroupDetails  masterGroupDetails= iClientOrganizationService.getClientById(clientId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("masterGroupDetails", masterGroupDetails); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/grade/save", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> gradeSave(@RequestBody MasterGrade masterGrade) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterGrade) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		MasterGrade maGrade = iClientOrganizationService.gradeSave(masterGrade);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", maGrade); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/groupAddressDetails/delete/{addressId}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> groupAddressDelete(@PathVariable Integer addressId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == addressId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		iClientOrganizationService.deleteAddressDetails(addressId);
		response.put("status", 1);
		response.put("message","GroupAddressDetails deleted successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/addMasterPolicyNo/update", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> saveOrUpdateMasterPolicyNo(@RequestBody MasterPolicyNo masterPolicyNo) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterPolicyNo) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		System.out.println("saveOrUpdateMasterPolicyNo "+masterPolicyNo.toString());
		iClientOrganizationService.saveOrUpdateMasterPolicyNo(masterPolicyNo);
		response.put("status", 1);
		response.put("message","MasterPolicyNo added successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/addMasterPolicyUnitAddress/update", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> saveOrUpdadateMasterPolicyUnitAddress(@RequestBody MasterPolicyUnitAddress masterPolicyUnitAddress) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterPolicyUnitAddress) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		masterPolicyUnitAddress=iClientOrganizationService.saveOrUpdateMasterPolicyUnitAddress(masterPolicyUnitAddress);
		response.put("status", 1);
		response.put("obj",masterPolicyUnitAddress);
		return ResponseEntity.accepted().body(response);
	}

	
	
	@RequestMapping(value = "/searchAdvancedReceipt", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchAdvancedReceipt(@RequestBody MasterPolicyNo masterPolicyNos) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterPolicyNos) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<MasterPolicyNo> masterPolicyNo = iClientOrganizationService.searchAdvanceDepositReceipt(masterPolicyNos.getGroupName(), masterPolicyNos.getReceiptNo());
		response.put("status", 1);
		response.put("message","AdvancedReceipt searched successfully.");
		response.put("response" , masterPolicyNo);
		return ResponseEntity.accepted().body(response);
	}
	
	//@RequestMapping(value = "/searchMasterPolicyDetails", method = RequestMethod.POST, produces = "application/json")
	@RequestMapping(value = "/searchMasterPolicyDetailsByGroupId", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> searchMasterGroupDetailsByGroupId(@RequestParam Long groupId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List salesHierarchyDetails = null;
		ErrorDto errorDto = null;
		if (null == groupId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		List<MasterPolicyNo> masterGroupDetailsList 	= iClientOrganizationService.searchMasterGroupDetailsByGroupId(groupId);
		List<MasterPolicyNo> masterPolicyDetailsList 	= iClientOrganizationService.getMasterPolicyDetailsByGroupId(groupId);
		if(masterGroupDetailsList != null && masterGroupDetailsList.size() > 0) {
			
			if(masterGroupDetailsList.get(0).getCode() != null && !masterGroupDetailsList.get(0).getCode().isEmpty()) {
				salesHierarchyDetails = quotationDAO.getSalesHierarchyDetails(masterGroupDetailsList.get(0).getCode());
			}
			
		}
		
		
		response.put("status", 1);
		response.put("masterGroupDetailsList" , masterGroupDetailsList);
		response.put("masterPolicyDetailsList" , masterPolicyDetailsList);
		response.put("salesHierarchyDetailsList" , salesHierarchyDetails);
		response.put("message","MasterPolicyDetails searched successfully.");
		return ResponseEntity.accepted().body(response);
	}
	////NOT IN USE
	@RequestMapping(value = "/getMasterPolicyDetailsByGroupId", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getMasterPolicyDetailsByGroupId(@RequestParam Long groupId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == groupId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		System.out.println("groupId "+groupId);
		List<MasterPolicyNo> masterGroupDetailsList = iClientOrganizationService.getMasterPolicyDetailsByGroupId(groupId);
		response.put("status", 1);
		response.put("message","MasterPolicyDetails searched successfully.");
		response.put("response" , masterGroupDetailsList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/getSearchGroupDetailsByAgreementNo", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getSearchGroupDetailsByAgreementNo(@RequestParam Long groupId,@RequestParam String agreementNumber) throws Exception {
		
		Map<String, Object> response = new HashMap<String, Object>();
		
		ErrorDto errorDto = null;
		
		if (null == agreementNumber ) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		List<MasterPolicyNo> masterGroupDetailsList = iClientOrganizationService.getSearchGroupDetailsByAgreementNo(groupId,agreementNumber);
		System.out.println("masterGroupDetailsList "+masterGroupDetailsList);
		
		response.put("status", 1);
		response.put("message","MasterPolicyDetails searched successfully.");
		response.put("response" , masterGroupDetailsList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/addApplicationPremiumDetails/update", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> saveOrUpdateApplicationPremiumDetails(@RequestBody ApplicationPremiumDetails applicationPremiumDetails) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == applicationPremiumDetails) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		ApplicationPremiumDetails applicationPremiumDetailss = iClientOrganizationService.saveOrUpdateApplicationPremiumDetails(applicationPremiumDetails);
		response.put("status", 1);
		response.put("message","ApplicationPremiumDetails added successfully.");
		response.put("response" , applicationPremiumDetailss);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/benefitType/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllBenefitType() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<BenefitType> list = benefitTypeDao.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/masterPolicyNoByGroupId/{groupId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> searchMasterPolicyNoByGroupId(@PathVariable Long groupId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == groupId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<MasterPolicyNo> masterPolicyNo = iClientOrganizationService.getMasterPolicyByGroupId(groupId);
		response.put("status", 1);
		response.put("message","masterPolicyNoByGroupId searched successfully.");
		response.put("response" , masterPolicyNo);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/searchAppPremium/{policyId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> searchApplicationPremiumDetailsByPolicyId(@PathVariable long policyId) throws SQLException{
		Map<String, Object> response = new HashMap<String, Object>();
		List<ApplicationPremiumDetails> applicationPremiumDetails = iClientOrganizationService.searchApplicationPremiumDetailsByPolicyId(policyId);
		response.put("status", 1);
		response.put("message","searchApplicationPremiumDetailsByAgreementNoAndPolicyNo searched successfully.");
		response.put("response" , applicationPremiumDetails);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/searchAppPremiumDetails/{primumId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> searchApplicationPremiumDetailsByPrimumId(@PathVariable long primumId) throws SQLException{
		Map<String, Object> response = new HashMap<String, Object>();
		ApplicationPremiumDetails applicationPremiumDetails = iClientOrganizationService.searchApplicationPremiumDetailsByAppPemiumId(primumId);
		response.put("status", 1);
		response.put("message","searchApplicationPremiumDetailsByPrimumId searched successfully.");
		response.put("response" , applicationPremiumDetails);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/getAllBanks", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllBanks() throws SQLException{
		Map<String, Object> response = new HashMap<String, Object>();
		 List<Bank> banks = iClientOrganizationService.getAllBank();
		response.put("status", 1);
		response.put("message","getAllBanks searched successfully.");
		response.put("response" , banks);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/getBankBranch/{bankId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getBankBranchByBankId(@PathVariable long bankId) throws SQLException{
		Map<String, Object> response = new HashMap<String, Object>();
		 List<BankBranch> bankBranch = iClientOrganizationService.getBankBranchByBankId(bankId);
		response.put("status", 1);
		response.put("message","getBankBranchByBankId searched successfully.");
		response.put("response" , bankBranch);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/getAllMasterModule", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllMasterModule() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MasterModule> masterModule = iClientOrganizationService.getAllMasterModule();
		response.put("status", 1);
		response.put("message","getAllMasterModule searched successfully.");
		response.put("response" , masterModule);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/getAllMasterDedupe/{description}/{moduleId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllMasterDedupe(@PathVariable String description, @PathVariable long moduleId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MasterDedupe> masterModule = iClientOrganizationService.getMasterDedupeByDedupeAndModuleId(description, moduleId);
		response.put("status", 1);
		response.put("message","getAllMasterModule searched successfully.");
		response.put("response" , masterModule);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/addMasterPartyDetails", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> addMasterPartyDetails(@RequestBody MasterPartyDetails masterPartyDetails) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterPartyDetails) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		String receiptno = iClientOrganizationService.saveOrUpdateMasterPartyDetails(masterPartyDetails);
		response.put("status", 1);
		response.put("message","addMasterPartyDetails saved successfully.");
		response.put("response" , receiptno);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/addRepecieptDetails", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> addRepecieptDetails(@RequestBody PartyReceiptDetails partyReceiptDetails) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == partyReceiptDetails) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		String recieptNo = iClientOrganizationService.saveOrUpdatePartyReceiptDetails(partyReceiptDetails);
		response.put("status", 1);
		response.put("message","getAllMasterModule searched successfully.");
		response.put("response" , recieptNo);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/masterGroupDetails/search", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> searchMasterGroupDetailsByName(@RequestParam String groupName) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
			if (null == groupName) {
				errorDto = new ErrorDto();
				errorDto.setCode("400");
				errorDto.setMessage("Invalid Request Payload.");
				response.put("status", 0);
				response.put("error", errorDto);
				return ResponseEntity.badRequest().body(response);
			}
			else{
		List<MasterGroupDetails> list=iClientOrganizationService.searchMasterGroupDetailsByName(groupName);
		response.put("status", 1);
		response.put("list",list);
		return ResponseEntity.accepted().body(response);
		}
	}
	
	@RequestMapping(value = "/masterPolicyAdress/delete/{addressId}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> masterPolicyAddressDelete(@PathVariable Integer addressId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == addressId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		iClientOrganizationService.deleteAddressDetails(addressId);
		response.put("status", 1);
		response.put("message","GroupAddressDetails deleted successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/masterPolicyNo/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> masterPolicyNoDetailsById(@RequestParam Integer masterPolicyNoId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterPolicyNoId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		MasterPolicyNo list=iClientOrganizationService.searchMasterPolicyNoDetails(masterPolicyNoId);
		response.put("status", 1);
		response.put("list",list);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/addMasterPolicyAddress/update", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> saveOrUpdadateMasterPolicyAddress(@RequestBody MasterPolicyUnitAddress masterPolicyUnitAddress) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterPolicyUnitAddress) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		masterPolicyUnitAddress=iClientOrganizationService.saveOrUpdateMasterPolicyAddress(masterPolicyUnitAddress);
		response.put("status", 1);
		response.put("obj",masterPolicyUnitAddress);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/masterPolicyNo/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchMasterPolicyNo(@RequestBody MasterPolicyNo masterPolicyNo) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == masterPolicyNo) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<MasterPolicyNo> list=iClientOrganizationService.searchMasterPolicyNo(masterPolicyNo);
		response.put("status", 1);
		response.put("list",list);
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/masterPolicyAddress/delete", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> deleteMasterPolicyAddress(@RequestParam Integer addressId ,@RequestParam Integer policyNoId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == addressId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		iClientOrganizationService.deleteMasterPolicyAddress(addressId,policyNoId);
		response.put("status", 1);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/product/getVarient", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllVariantRequestByLineOfBusinessId(@RequestParam Integer lineOfBusinessId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Variant> variantRequestList = variantService.getAllVariantByLineofBusinessId(lineOfBusinessId);
		response.put("status", 1);
		response.put("message","Success");
		System.out.println("variantRequestList 2 >>>> "+variantRequestList);
		response.put("variantList", variantRequestList); 
		return ResponseEntity.accepted().body(response);
	}
	
	//////// new merged >> API >> ////////
	

	
	
	@RequestMapping(value = "/masterPolicy/delete", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> masterPolicyNoDelete(@RequestParam Long masterPolicyNoId,@RequestParam Long deletedBy) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		System.out.println("masterPolicyNoDelete masterpolicyId = "+masterPolicyNoId);
		System.out.println("masterPolicyNoDelete deletedBy = "+deletedBy);
		if (null == masterPolicyNoId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		iClientOrganizationService.deleteMasterPolicyNo(masterPolicyNoId,deletedBy);
		response.put("status", 1);
		response.put("message","masterPolicyNoDelete deleted successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/policyAccountStatement/get", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> policyAccountStatement(@RequestBody PolicyAccountStatement policyAccountStatement) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == policyAccountStatement) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<PolicyAccountStatement> policyAccountStatements = iClientOrganizationService.getPolicyAccountStatement(policyAccountStatement);
		response.put("status", 1);
		response.put("message","policyAccountStatement get successfully.");
		response.put("response", policyAccountStatements);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/saveQuestionMap/save", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> saveQuestionMap(@RequestBody QuestionMap questionMap) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == questionMap) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		questionMap = iClientOrganizationService.saveQuestionMap(questionMap);
		response.put("status", 1);
		response.put("message","saveQuestionMap saved successfully.");
		response.put("response", questionMap);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/deleteQuestionMap/delete/{questionId}/{policyId}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteQuestionMap(@PathVariable long questionId, @PathVariable long policyId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (0 == questionId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		iClientOrganizationService.deleteQuestionMap(questionId, policyId);
		response.put("status", 1);
		response.put("message","QuestionMap deleted successfully.");
		//response.put("response", questionMap);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/questionMap/get/{policyId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> deleteQuestionMap(@PathVariable long policyId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (0 == policyId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<QuestionMap> questions = iClientOrganizationService.getAllQuestionMap(policyId);
		response.put("status", 1);
		response.put("message","QuestionMap get successfully.");
		response.put("response", questions);
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/getClientAddressDetailsbyGroupId/{groupdId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getClientAddressDetailsbyGroupId(@PathVariable long groupdId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (0 == groupdId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<ClientAddressDetails> clientAddressDetailsList = iClientOrganizationService.getClientAddressDetailsbyGroupId(groupdId);
		response.put("status", 1);
		if(clientAddressDetailsList != null && clientAddressDetailsList.size() > 0) {
			response.put("message","ClientAddressDetails get successfully.");
		}else {
			response.put("message","No Record Found");
			
		}
		response.put("response", clientAddressDetailsList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/getProductFrequencyBasedModalFactorRate/{variantId}/{frequencyId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getClientAddressDetailsbyGroupId(@PathVariable long variantId,@PathVariable long frequencyId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (0 == variantId ) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		int modalFactor = iClientOrganizationService.getProductFrequencyBasedModalFactorRateByVariantIdAndFrequencyId(variantId, frequencyId);
		
		if(modalFactor > 0) {
			response.put("message","modalFactor get successfully.");
		}else {
			response.put("message","No Record Found");
			
		}
		response.put("status", 1);
		response.put("response", modalFactor);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/getProductbyPlanId/{planId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getProductbyPlanId(@PathVariable long planId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (0 == planId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<Variant> variantList = iClientOrganizationService.getProductbyPlanId(planId);
		response.put("status", 1);
		if(variantList != null && variantList.size() > 0) {
			response.put("message","ProductDetails get successfully.");
		}else {
			response.put("message","No Record Found");
			
		}
		response.put("response", variantList);
		return ResponseEntity.accepted().body(response);
	}

}

package com.LIC.dao;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;

import com.LIC.model.ClaimsSettlementModel;
import org.springframework.stereotype.Repository;
@Repository
public class ClaimsSettlementDao {
	
	@Autowired
    private EntityManager entityManager;
	
	public int getAllClaimsForSettlement(ClaimsSettlementModel claimsSettlementModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spGetAllClaimsForSettlement")
				.registerStoredProcedureParameter("pClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPolicyNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pFirstName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pLastName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pAgentCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pServiceBranch", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsSettlementModel.getpClaimID())
				.setParameter("pPolicyNumber", claimsSettlementModel.getpPolicyNumber())
				.setParameter("pFirstName", claimsSettlementModel.getpFirstName())
				.setParameter("pLastName", claimsSettlementModel.getpLastName())
				.setParameter("pAgentCode", claimsSettlementModel.getpAgentCode())
				.setParameter("pServiceBranch", claimsSettlementModel.getpServiceBranch());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int insertClaimsSettlement(ClaimsSettlementModel claimsSettlementModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spInsertClaimsSettlement")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pStatusID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAPPLICATIONID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsSettlementModel.getpClaimID())
				.setParameter("pCreatedBy", claimsSettlementModel.getpCreatedBy())
				.setParameter("pCreatedOn", claimsSettlementModel.getpCreatedOn())
				.setParameter("pStatusID", claimsSettlementModel.getpStatusID())
				.setParameter("vAPPLICATIONID", claimsSettlementModel.getvAPPLICATIONID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int deleteClaimsSettlementPaymentDetails(ClaimsSettlementModel claimsSettlementModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spDeleteClaimsSettlementPaymentDetails")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("pClaimID", claimsSettlementModel.getpClaimID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}
	
	public int insertClaimsSettlementPayment(ClaimsSettlementModel claimsSettlementModel) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spInsertClaimsSettlementPaymentDetails")
                     .registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vSerialNo", Integer.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vPaymentModeID", Integer.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vPaymentDate", Date.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vBankID", Integer.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vBankBranchID", Integer.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vChequeNo", String.class, ParameterMode.IN)
                      .registerStoredProcedureParameter("vChequeDate", Date.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vCardTypeID", Integer.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vCardNo", String.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vCardExpiryDate", Date.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vCardExpiryMonth", Date.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vCardExpiryYear", Date.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vAmount", Float.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vBankBranchName", String.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vBankName", String.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vDescription", String.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vISFCCode", String.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
                     .registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

                     .setParameter("vClaimID", claimsSettlementModel.getvClaimID())
                     .setParameter("vSerialNo", claimsSettlementModel.getvSerialNo())
                     .setParameter("vPaymentModeID", claimsSettlementModel.getvPaymentModeID())
                     .setParameter("vPaymentDate", claimsSettlementModel.getvPaymentDate())
                     .setParameter("vBankID", claimsSettlementModel.getvBankID())
                     .setParameter("vBankBranchID", claimsSettlementModel.getvBankBranchID())
                     .setParameter("vChequeNo", claimsSettlementModel.getvChequeNo())
                     .setParameter("vChequeDate", claimsSettlementModel.getvChequeDate())
                     .setParameter("vCardTypeID", claimsSettlementModel.getvCardTypeID())
                     .setParameter("vCardNo", claimsSettlementModel.getvCardNo())
                     .setParameter("vCardExpiryDate", claimsSettlementModel.getvCardExpiryDate())
                     .setParameter("vCardExpiryMonth", claimsSettlementModel.getvCardExpiryMonth())
                     .setParameter("vCardExpiryYear", claimsSettlementModel.getvCardExpiryYear())
                     .setParameter("vAmount", claimsSettlementModel.getvAmount())
                     .setParameter("vBankBranchName", claimsSettlementModel.getvBankBranchName())
                     .setParameter("vBankName", claimsSettlementModel.getvBankName())
                     .setParameter("vDescription", claimsSettlementModel.getvDescription())
                     .setParameter("vISFCCode", claimsSettlementModel.getvISFCCode())
                     .setParameter("vCreatedBy", claimsSettlementModel.getvCreatedBy())
                     .setParameter("vCreatedOn", claimsSettlementModel.getvCreatedOn())
                     .setParameter("vResult", claimsSettlementModel.getvResult());
        
        storedProcedureQuery.execute();
        return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int getClaimNumberByClaimID(ClaimsSettlementModel claimsSettlementModel) {
		 StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetClaimNumberByClaimID")
                 .registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
                 .registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
    
                 .setParameter("pClaimID", claimsSettlementModel.getpClaimID());
                 
		 storedProcedureQuery.execute();
		 return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

}
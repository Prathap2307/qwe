package com.LIC.bl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.LIC.dao.InsurerDao;
import com.LIC.model.ContactAddressModal;
import com.LIC.model.InsurerModal;
import com.LIC.model.LineOfBusinessInsurerModel;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;
import com.LIC.utils.exception.ExceptionProcess;



public class InsurerBL  {
	
	private static final Logger logger = Logger.getLogger(InsurerBL.class);
	private static final String		TRACE_ID = InsurerDao.class.getName();
	
	@SuppressWarnings("unchecked")
	public  InsurerModal CreateInsurerModal(ValueObject object) {
		ValueObject 				objectMapper 					= null;
		List<Object>				lineOfBusinessInsurerList		= null;
		List<LineOfBusinessInsurerModel>		lineOfBusinessInsurerModelList		= null;
		InsurerModal		 		insurerModal 					= null;
		LineOfBusinessInsurerModel  lineOfBusinessInsurerModel		= null;
		ContactAddressModal contactAddressModal = null;
		try {
			
			insurerModal	= new InsurerModal();
			
			insurerModal.setInsurerID(object.getLong("insurerID",0));
			insurerModal.setLineOfBusinessID(object.getLong("lineOfBusinessID",0));
			insurerModal.setDistributionID(object.getLong("distributionID",0));
			
			if(object.get("dateOfCommencement") != null && !object.getString("dateOfCommencement").equals("")) {
				insurerModal.setDateOfCommencement((Timestamp) DateTimeUtility.getTimeStamp(object.getString("dateOfCommencement")));
			} else {
				insurerModal.setDateOfCommencement(new Timestamp(System.currentTimeMillis()));
			}
		
			insurerModal.setGeographicalPresence(object.getString("geographicalPresence",""));
			insurerModal.setInsurerName(object.getString("insurerName",""));
			
			insurerModal.setLogo(object.getString("logo",""));
			insurerModal.setAddressId(object.getLong("addressId",0));
			insurerModal.setCreatedBy(object.getLong("createdBy",0));
			
			if(object.get("createdOn") != null && !object.getString("createdOn").equals("")) {
				insurerModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				insurerModal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			
			
			if(object.get("modifiedOn") != null && !object.getString("modifiedOn").equals("")) {
				insurerModal.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("modifiedOn")));
			} 
			insurerModal.setModifiedBy(object.getLong("modifiedBy",0));
			
			if(object.get("deletedOn") != null && !object.getString("deletedOn").equals("")) {
				insurerModal.setDeletedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("deletedOn")));
			}

	        insurerModal.setDeletedBy(object.getLong("deletedBy",0));
	
			insurerModal.setIsActive(object.getShort("isActive",(short)1));
			insurerModal.setCollectionGLCode(object.getString("collectionGLCode",""));
			
			insurerModal.setPaymentGLCode(object.getString("paymentGLCode",""));
			
			insurerModal.setFreshGLCode(object.getString("freshGLCode",""));
			
			insurerModal.setApOnlineGLCode(object.getString("apOnlineGLCode",""));
			
			insurerModal.setLicPremiumPaymentGLCode(object.getString("licPremiumPaymentGLCode",""));
			
			insurerModal.setRevivalGLCode(object.getString("revivalGLCode",""));
			insurerModal.setMedicalGLCode(object.getString("medicalGLCode",""));
			
			insurerModal.setClaimGLCode(object.getString("claimGLCode",""));
			insurerModal.setTriggerLimitforStampDuty(object.getLong("triggerLimitforStampDuty",0));
			insurerModal.setIntimationEmailaddressforStampDuty(object.getString("intimationEmailaddressforStampDuty",""));
			insurerModal.setIntimationMobileNumberforStampDuty(object.getString("intimationMobileNumberforStampDuty",""));
			insurerModal.setPanNo(object.getString("panNo",""));
			insurerModal.setGstNo(object.getString("gstNo",""));
			
			lineOfBusinessInsurerList		= (List<Object>) object.get("lineOfBusinessInsurerList",null);
			lineOfBusinessInsurerModelList = new ArrayList<LineOfBusinessInsurerModel>();
			if(lineOfBusinessInsurerList != null) {
				int i= 0;
				for(Object obj : lineOfBusinessInsurerList) {
					i++;
					objectMapper	= new ValueObject((HashMap<Object, Object>) obj);
					if(objectMapper != null) {
					System.out.println("lineOfBusinessInsurerList : "+i+" "+objectMapper);
					lineOfBusinessInsurerModel	= createLineOfBusinessInsurerModelDto((ValueObject) objectMapper);
					lineOfBusinessInsurerModelList.add(lineOfBusinessInsurerModel);
					}
				}
			}
			contactAddressModal  = createLineOfContactAddressModal(object);
			
			 insurerModal.setLineOfBusinessInsurerList(lineOfBusinessInsurerModelList);
			 insurerModal.setContactAddressModal(contactAddressModal);
			return insurerModal;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	


public LineOfBusinessInsurerModel createLineOfBusinessInsurerModelDto(ValueObject object)throws Exception {
	LineOfBusinessInsurerModel lineOfBusinessInsurerModel = null;
		try {
				lineOfBusinessInsurerModel	 = new LineOfBusinessInsurerModel();
				
				
				lineOfBusinessInsurerModel.setLobID(object.getLong("lobID",0));
				lineOfBusinessInsurerModel.setCreatedBy(object.getLong("createdBy",0));
				lineOfBusinessInsurerModel.setDescription(object.getString("description",null));
				/*if(object.getString("createdOn") != null) {
					lineOfBusinessInsurerModel.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
				}else {
					lineOfBusinessInsurerModel.setCreatedOn(new Timestamp(System.currentTimeMillis()));
				}
				lineOfBusinessInsurerModel.setModifiedBy(object.getLong("modifiedBy",0));
				
				if(object.getString("modifiedOn") != null) {
					lineOfBusinessInsurerModel.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("modifiedOn")));
				}else {
					lineOfBusinessInsurerModel.setModifiedOn(new Timestamp(System.currentTimeMillis()));
				}
				
				lineOfBusinessInsurerModel.setDeletedBy(object.getLong("deletedBy",0));
				
				if(object.getString("deletedOn") != null) {
					lineOfBusinessInsurerModel.setDeletedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("deletedOn")));
				}else {
					lineOfBusinessInsurerModel.setDeletedOn(new Timestamp(System.currentTimeMillis()));
				}*/
				
				lineOfBusinessInsurerModel.setIsActive(object.getShort("isActive",(short)0));
				
				
			
			return lineOfBusinessInsurerModel;
		} catch(Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}
}
public ContactAddressModal createLineOfContactAddressModal(ValueObject object)throws Exception {
	ContactAddressModal contactAddressModal = null;
		try {
			contactAddressModal = new ContactAddressModal();
			contactAddressModal.setAddressId(object.getLong("addressId",0));
			contactAddressModal.setAddressTypeID(object.getShort("addressTypeID",(short)0));
			contactAddressModal.setCountryID(object.getLong("countryID",0));
			contactAddressModal.setStateID(object.getLong("stateID",0));
			contactAddressModal.setDistrictID(object.getLong("districtID",0));
			contactAddressModal.setTalukID(object.getLong("talukID",0));
			contactAddressModal.setZipcode(object.getString("zipCode",null));
			contactAddressModal.setPhoneNumber(object.getString("phoneNo","0000000000"));
			contactAddressModal.setAddress1(object.getString("address1",""));
			contactAddressModal.setAddress2(object.getString("address2",""));
			contactAddressModal.setAddress3(object.getString("address3",""));
			contactAddressModal.setConferenceNumber(object.getString("mobilNumber",""));
			contactAddressModal.setFaxNumber(object.getString("faxNumber",""));
			contactAddressModal.setEmail(object.getString("email",""));
			contactAddressModal.setPhoneNumberCountryCode(object.getString("phoneNumberCountryCode",""));
			contactAddressModal.setPhoneNumberResidenceCountryCode(object.getString("phoneNumberResidenceCountryCode",""));
			contactAddressModal.setFaxNumberCountryCode(object.getString("faxNumberCountryCode",""));
			contactAddressModal.setCityID(object.getLong("cityID",0));
			contactAddressModal.setCountryName(object.getString("countryName",""));
			contactAddressModal.setStateName(object.getString("stateName",""));
			contactAddressModal.setDistrictName(object.getString("districtName",""));
			contactAddressModal.setTalukName(object.getString("talukName",""));
			contactAddressModal.setTehsil(object.getString("tehsil",""));
			contactAddressModal.setCreatedBy(object.getLong("createdBy",0));
			
			if(object.get("createdOn") != null && !object.getString("createdOn").equals("")) {
				contactAddressModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			}else {
				contactAddressModal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			
			contactAddressModal.setIsActive(object.getShort("isActive",(short)0));
			
			return contactAddressModal;
		} catch(Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}
}

}



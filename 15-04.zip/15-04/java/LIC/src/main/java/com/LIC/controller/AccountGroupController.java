package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.AccountGroupDAO;
import com.LIC.model.AccountGroupModel;
import com.LIC.model.GetAccountGroupModel;

@RestController
public class AccountGroupController {
	@Autowired
	private AccountGroupDAO AcGroup;
	
	
	
	@PostMapping("/createAccountGroup")
	public void postAccountGroup(@RequestBody AccountGroupModel model) {
		AcGroup.createAccountGroupInfo(model);

	}
	@RequestMapping(method = RequestMethod.GET, value = "/code/{Type}")
     public List<GetAccountGroupModel> getAccountGruopdetailsofcodeanddescription(@PathVariable String Type) {
                 return	AcGroup.GetAllAccountGroupByCodeAndDescription(Type);
       }
	
	@RequestMapping(method = RequestMethod.GET, value = "/details/{accountGroupId}/{code}/{groupName}/{name}")
    public List<GetAccountGroupModel> getAccountDetailsAll(@PathVariable Integer accountGroupId,@PathVariable Integer code,@PathVariable Integer groupName,@PathVariable String name) {
                return	AcGroup.GetAllSearch(accountGroupId,code,groupName,name);
      }
	
	@GetMapping ("/codeexist/{code}/{group}/{dupid}")
      public String GetAllCodeExistOrNot(@PathVariable String code,@PathVariable String group,@PathVariable Integer dupid) {
                          return	AcGroup.CodeExistOrNot(code,group,dupid);
}

}

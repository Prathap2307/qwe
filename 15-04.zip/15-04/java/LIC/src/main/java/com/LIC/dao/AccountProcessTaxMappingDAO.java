package com.LIC.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.AccountingTaxProcessMapModel;
import com.LIC.model.GetAllAccountProcessTaxMapModeModel;
import com.LIC.model.GetAllAccountingTaxMapBasedOn;
import com.LIC.model.GetAllAccountingTaxProcessModel;
import com.LIC.model.GetProcessTaxMapRowNumberModel;

@RestController
@SuppressWarnings("unchecked") 
public class AccountProcessTaxMappingDAO {
	
	@Autowired
	EntityManager em;
	
	
	//Get All Based on
		public List<GetAllAccountingTaxMapBasedOn> GetAllAccountingTaxMapBasedOn() {
		   	 StoredProcedureQuery query = em
		               .createStoredProcedureQuery("GetAllAccountingTaxMapBasedOn")
		               .registerStoredProcedureParameter("oBO", Class.class, ParameterMode.REF_CURSOR);
		   	 query.execute();
		   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
			 List<GetAllAccountingTaxMapBasedOn> FList = list.stream().map(
		             o -> new GetAllAccountingTaxMapBasedOn((Number) o[0], (String) o[1])).collect(Collectors.toList());
			  	 
		    	return FList;
			}
		
		//Get All Mode
			public List<GetAllAccountProcessTaxMapModeModel> GetAllAccountProcessTaxMapMode() {
			   	 StoredProcedureQuery query = em
			               .createStoredProcedureQuery("GetAllAccountProcessTaxMapMode")
			               .registerStoredProcedureParameter("oBO", Class.class, ParameterMode.REF_CURSOR);
			   	 query.execute();
			   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
				 List<GetAllAccountProcessTaxMapModeModel> FList = list.stream().map(
			             o -> new GetAllAccountProcessTaxMapModeModel((Number) o[0], (String) o[1])).collect(Collectors.toList());
				  	 
			    	return FList;
				}
		
	    //GenerateRowNumbers
		public List<GetProcessTaxMapRowNumberModel> GenerateRowNumber() {
			List<GetProcessTaxMapRowNumberModel> objNumbers= new ArrayList<GetProcessTaxMapRowNumberModel>();
			 for(int i=1;i<=100;i++)
			 {
				 objNumbers.add(new GetProcessTaxMapRowNumberModel(i));
			 }
		     return objNumbers;
		}
	
	// Get All Accounting Tax Process
	public List<GetAllAccountingTaxProcessModel> GetAllTaxProcess() {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllAccountingTaxProcess")
               .registerStoredProcedureParameter("oAP", Class.class, ParameterMode.REF_CURSOR);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<GetAllAccountingTaxProcessModel> FList = list.stream().map(
             o -> new GetAllAccountingTaxProcessModel((Number) o[0], (String) o[1]  ,(String) o[2],(Number) o[3]
            		 ,(String) o[4],(Number) o[5],(String) o[6],(Number) o[7],(Number) o[8],(Number) o[9],(Number) o[10]
            		 )).collect(Collectors.toList());
	  	 
    	return FList;

	}
	
	
	// Create Tax ProcessMapping
		public int CreateTaxProcessMapping(List<AccountingTaxProcessMapModel> TaxStructureInfo) {
			int MapID=0;
			for (AccountingTaxProcessMapModel taxdtl : TaxStructureInfo) {
				
				 StoredProcedureQuery query = em
			                .createStoredProcedureQuery("spInsertTaxProcessDetails")
			                .registerStoredProcedureParameter("vTaxStructureID", Integer.class, ParameterMode.IN)
			                .registerStoredProcedureParameter("vTaxStructureDetailID", Integer.class, ParameterMode.IN)
			                .registerStoredProcedureParameter("vTaxProcessID", Integer.class, ParameterMode.IN)
			                .registerStoredProcedureParameter("vTaxMappingID", Integer.class, ParameterMode.IN)
			                .registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
			                .registerStoredProcedureParameter("pResult", Integer.class, ParameterMode.OUT)
			                .setParameter("vTaxStructureID", taxdtl.getTaxStructureID())
			                .setParameter("vTaxStructureDetailID",taxdtl.getTaxStructureID())
			                .setParameter("vTaxProcessID", taxdtl.getTaxProcessID())
			                .setParameter("vTaxMappingID", taxdtl.getTaxMappingID())
			                .setParameter("vCreatedBy", taxdtl.getCreatedBy());
			    	query.execute();
			    	MapID= (int)query.getOutputParameterValue("pResult");
			}
			
			return MapID;
		}

		
	// Get All Tax Structure Based on TaxName
	public List<AccountingTaxProcessMapModel> GetAllTaxStructureBasedonTaxName(AccountingTaxProcessMapModel MDLTaxStructureName) {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllTaxStructureBasedonTaxName")
               .registerStoredProcedureParameter("P_TaxStructureName", String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oTSN", Class.class, ParameterMode.REF_CURSOR)
   	 			.setParameter("P_TaxStructureName", MDLTaxStructureName.getTaxStructureName());
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<AccountingTaxProcessMapModel> FList = list.stream().map(
             o -> new AccountingTaxProcessMapModel((Number) o[0], (String) o[1]  ,(String) o[2],(String) o[3]
            		 ,(String) o[4],(String) o[5])).collect(Collectors.toList());
	  	 
    	return FList;

	}
	

	// Get All Tax Structure Based on TaxName
	public List<AccountingTaxProcessMapModel> TaxProcessDetailsByID(int TaxStructureID) {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetTaxProcessDetailsByID")
               .registerStoredProcedureParameter("vTaxStructureID", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oTaxMap", Class.class, ParameterMode.REF_CURSOR)
   	 			.setParameter("vTaxStructureID", TaxStructureID);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<AccountingTaxProcessMapModel> FList = list.stream().map(
             o -> new AccountingTaxProcessMapModel((Number) o[0], (Number) o[1]  ,(String) o[2],(Number) o[3]
            		 ,(Number) o[4],(String) o[5],(Number) o[6],(Number) o[7],(Number) o[8],(Number) o[9],(Number) o[10],(Number) o[11] )).collect(Collectors.toList());
	  	 
    	return FList;

	}
	
	
}

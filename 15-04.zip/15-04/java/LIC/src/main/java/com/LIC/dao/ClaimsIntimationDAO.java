package com.LIC.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ClaimIntimationCoverageModel;
import com.LIC.model.ClaimsCauseOFDeathModel;
import com.LIC.model.ClaimsIntimationDropDownModel;
import com.LIC.model.ClaimsIntimationModel;
import com.LIC.model.ClaimsIntimationSaultationModel;
import com.LIC.model.ClaimsRelationShipModel;
//import com.LIC.model.SearchClaimDetailsModel;
import com.LIC.model.SearchClaimDetailsModel;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class ClaimsIntimationDAO {

	@Autowired
	private EntityManager em;
	
	Connection conn = null;
	CallableStatement cstm = null;
	@Autowired
	private JDBCConnection jdbcConnection;

	private static final Logger logger = Logger.getLogger(ClaimsIntimationDAO.class);

	public String createClaimIntimation(ClaimsIntimationModel model) {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spInsertClaimIntimation")
				.registerStoredProcedureParameter("vID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vLineofBusinesId", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfInitmation", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfRegistration", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfDeath", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCauseOfDeathID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDeathOfMemberOrSpouseID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vMPHPayment", BigDecimal.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vNomineePayment", BigDecimal.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTotalAmount", BigDecimal.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAccountNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vInvoiceNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vInvoiceDate", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDIR", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCSIP", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPincode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vNomineePhoneNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfLoss", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vReservedAmount", BigDecimal.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vApplicationID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vGroupTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vInsuredID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vClaimReportedBy", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vRelationshipID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDescription", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vSalutationID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPolicyNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vBeneficiaryName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsExistingInjuryDisablility", String.class, ParameterMode.IN)
				
				.registerStoredProcedureParameter("curOut", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("vID", model.getvID())
				.setParameter("vLineofBusinesId", model.getvLineofBusinesId())
				.setParameter("vTypeID", model.getvTypeID())
				.setParameter("vClaimID", model.getvClaimID())
				.setParameter("vDateOfInitmation", model.getvDateOfInitmation())
				.setParameter("vDateOfRegistration", model.getvDateOfRegistration())
				.setParameter("vDateOfDeath", model.getvDateOfDeath())
				.setParameter("vCauseOfDeathID", model.getvCauseOfDeathID())
				.setParameter("vInvoiceNumber", model.getvInvoiceNumber())
				.setParameter("vMPHPayment", model.getvMPHPayment())
				.setParameter("vNomineePayment", model.getvNomineePayment())
				.setParameter("vTotalAmount", model.getvTotalAmount())
				.setParameter("vAccountNumber", model.getvAccountNumber())
				.setParameter("vInvoiceNumber", model.getvInvoiceNumber())
				.setParameter("vInvoiceDate", model.getvInvoiceDate())
				.setParameter("vDIR", model.getvDIR())
				.setParameter("vCSIP", model.getvCSIP())
				.setParameter("vPincode", model.getvPincode())
				.setParameter("vNomineePhoneNumber", model.getvNomineePhoneNumber())
				.setParameter("vDateOfLoss", model.getvDateOfLoss())
				.setParameter("vReservedAmount", model.getvReservedAmount())
				.setParameter("vApplicationID", model.getvApplicationID())
				.setParameter("vGroupTypeID", model.getvGroupTypeID())
				.setParameter("vCreatedBy", model.getvCreatedBy())
				.setParameter("vCreatedOn", model.getvCreatedOn())
				.setParameter("vInsuredID", model.getvInsuredID())
				.setParameter("vClaimReportedBy", model.getvClaimReportedBy())
				.setParameter("vRelationshipID", model.getvRelationshipID())
				.setParameter("vDescription", model.getvDescription())
				.setParameter("vSalutationID", model.getvSalutationID())
				.setParameter("vPolicyNumber", model.getvPolicyNumber())
				.setParameter("vBeneficiaryName", model.getvBeneficiaryName());

		query.execute();
		return (String) query.getOutputParameterValue("curOut");

	}

	public List<SearchClaimDetailsModel> getSearchDetailForClaimIntimation(String pMasterPolicyNo) {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetSearchDetailForClaimIntimation")
				.registerStoredProcedureParameter("pContactTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pMasterPolicyNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCertificateNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pFirstName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pEmployeeID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pMemberID", String.class, ParameterMode.IN)

				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR)
				
				.setParameter("pMasterPolicyNo", pMasterPolicyNo);
		/*
		 * .setParameter("pContactTypeID",
		 * model.getpContactTypeID()).setParameter("pTypeID", model.getpTypeID())
		 * .setParameter("pMasterPolicyNo", model.getpMasterPolicyNo())
		 * .setParameter("pCertificateNo", model.getpCertificateNo())
		 * .setParameter("pFirstName",
		 * model.getpFirstName()).setParameter("pEmployeeID", model.getpEmployeeID())
		 * .setParameter("pMemberID", model.getpMemberID());
		 */

		query.execute();

		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<SearchClaimDetailsModel> accProcessList = list
				.stream().map(o -> new SearchClaimDetailsModel((Number) o[0], (Number) o[1], (String) o[2],
						(String) o[3], (String) o[4], (String) o[5], (String) o[6]))
				.collect(Collectors.toList());

		return accProcessList;
	}
	
	
	
	public List<HashMap> getSearchDetailForClaimIntimation(String pMasterPolicyNo, String pCertificateNo, String pFirstName, String pMemberID){
		List<HashMap> ListObj = new ArrayList();
		
		
		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetSearchDetailForClaimIntimation(?,?,?,?,?,?,?,?) ");

			//cstm.setInt(1, pClaimID);
			cstm.setString(1, null);
			cstm.setString(2, null);
			cstm.setString(3, pMasterPolicyNo);
			cstm.setString(4, pCertificateNo);
			cstm.setString(5, pFirstName);
			cstm.setString(6, null);
			cstm.setString(7, pMemberID);
			
			cstm.registerOutParameter(8, OracleTypes.CURSOR);
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(8);
			
		
			
			if (result != null) {
				ListObj = ResourceManager.resultSetToArrayList(result);

			}
			
			

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			closeConnection();

		}
		
		
		return ListObj;
	}
	public void closeConnection() {
		try {
			//cstm.close();
			ResourceManager.freeConnection(conn);
			//cstm = null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<SearchClaimDetailsModel> getInsuredDetailsForGroupByApplicationID(SearchClaimDetailsModel model) {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetSearchDetailForClaimIntimation")
				.registerStoredProcedureParameter("pContactTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pMasterPolicyNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCertificateNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pFirstName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pEmployeeID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pMemberID", String.class, ParameterMode.IN)
				
				
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR)
				.setParameter("pContactTypeID", model.getpContactTypeID())
		        .setParameter("pTypeID", model.getpTypeID())
		        .setParameter("pMasterPolicyNo", model.getpMasterPolicyNo())
		        .setParameter("pCertificateNo", model.getpCertificateNo())
		        .setParameter("pFirstName", model.getpFirstName())
		        .setParameter("pEmployeeID", model.getpEmployeeID())
		        .setParameter("pMemberID", model.getpMemberID());
		
		query.execute();
		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<SearchClaimDetailsModel> accProcessList = list
				.stream().map(o -> new SearchClaimDetailsModel((Number) o[0], (Number) o[1], (String) o[2],
						(String) o[3], (String) o[4], (String) o[5], (String) o[6]))
				.collect(Collectors.toList());

		return accProcessList;
	}
	 

	
	public List<ClaimsRelationShipModel> getAllClaimsRelationship( ) {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllClaimsRelationship")
				//.registerStoredProcedureParameter("vRelationshipID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR);
				//.setParameter("vRelationshipID", relationShipId);
		query.execute();
		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<ClaimsRelationShipModel> accProcessList = list.stream()
				.map(o -> new ClaimsRelationShipModel((Number) o[0], (String) o[1]))
				.collect(Collectors.toList());

		return accProcessList;
	}

	public List<ClaimsCauseOFDeathModel> getAllCauseOfDeath() {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllCauseOfDeath")
			//	.registerStoredProcedureParameter("vCauseOfDeathID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR);
			//	.setParameter("vRelationshipID", causeOfDeathId);
		query.execute();
		//return (Integer) query.getOutputParameterValue("oBRANCH");

		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<ClaimsCauseOFDeathModel> accList = list.stream()
				.map(o -> new ClaimsCauseOFDeathModel((Number) o[0], (String) o[1])).collect(Collectors.toList());

		return accList;
	}

	  
	  public Integer getIsClaimsPolicyNoExist(Integer insuredID) {
	  StoredProcedureQuery query =
	  em.createStoredProcedureQuery("spIsClaimsPolicyNoExist")
	  .registerStoredProcedureParameter("vInsuredID", Integer.class, ParameterMode.IN)
	  .registerStoredProcedureParameter("vDateofLoss", Date.class, ParameterMode.IN)
	  .registerStoredProcedureParameter("vApplicationID", Integer.class, ParameterMode.IN)
	  .registerStoredProcedureParameter("vTypeID", Integer.class,ParameterMode.IN)
	  
	  .registerStoredProcedureParameter("vExistCount", Integer.class,
	  ParameterMode.OUT) 
	  .setParameter("vInsuredID", insuredID); 
		/*
		 * .setParameter("vDateofLoss",vDateofLoss); .setParameter("vApplicationID",
		 * vApplicationID); .setParameter("vTypeID",vDateofLoss);
		 */

	  query.execute(); return (Integer)
	  query.getOutputParameterValue("vExistCount");
	  
	  }
	 

	public String getValidateDate(Integer applicationID,Date date) {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spValidateDate")
				.registerStoredProcedureParameter("pApplicationID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pDateValue", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pRESULT", String.class, ParameterMode.OUT)

				.setParameter("pApplicationID", applicationID)
				.setParameter("pDateValue", date);

		query.execute();
		return (String) query.getOutputParameterValue("pRESULT");
	}

	public List<ClaimsIntimationSaultationModel> getAllSalutation() {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllSalutation")
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR);

		query.execute();
		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<ClaimsIntimationSaultationModel> accList = list.stream()
				.map(o -> new ClaimsIntimationSaultationModel((Number) o[0], (String) o[1], (String) o[2]))
				.collect(Collectors.toList());

		return accList;

	}

	/*
	 * public List<ClaimsIntimationDropDownModel> getAllPaymentMode() {
	 * StoredProcedureQuery query =
	 * em.createStoredProcedureQuery("spGetAllPaymentMode")
	 * .registerStoredProcedureParameter("oBRANCH", Class.class,
	 * ParameterMode.REF_CURSOR);
	 * 
	 * query.execute();
	 * 
	 * List<Object[]> list = (List<Object[]>) query.getResultList();
	 * List<ClaimsIntimationDropDownModel> accList = list.stream() .map(o -> new
	 * ClaimsIntimationDropDownModel((Number) o[0], (String)
	 * o[1])).collect(Collectors.toList());
	 * 
	 * return accList; }
	 */
	
	public List getAllPaymentMode(){
		List<Object> ListObj = new ArrayList();
		
		
		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllPaymentMode(?) ");

		
			cstm.registerOutParameter(1, OracleTypes.CURSOR);
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(1);
			
			
			
			if (result != null) {
				ListObj = ResourceManager.resultSetToArrayList(result);

			}
		

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			//closeConnection();

		}

		return ListObj;
	}

	
	public List<ClaimIntimationCoverageModel> getInsuredDetailsForGroupByPartyID() {

		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllPaymentMode")
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR);

		query.execute();

		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<ClaimIntimationCoverageModel> accProcessList = list.stream()
				.map(o -> new ClaimIntimationCoverageModel((Number) o[0], (String) o[1])).collect(Collectors.toList());
		return accProcessList;

	}
	 
}

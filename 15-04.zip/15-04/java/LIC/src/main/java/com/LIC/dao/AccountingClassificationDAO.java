package com.LIC.dao;



import java.util.*;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.LIC.model.AccountingClassificationModel;
import com.LIC.model.GetAccountingClassificationModel;



@Repository
@SuppressWarnings("unchecked") 
public class AccountingClassificationDAO {
	@Autowired
	private EntityManager em;
	
 
	public String GetDuplicateAccountingClassification(AccountingClassificationModel Accmodel) {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("GetDuplicateAccountingClassification")
               .registerStoredProcedureParameter("vCode", String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("Vdescription", String.class, ParameterMode.IN)
               .registerStoredProcedureParameter("Vdupid", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("RESULT1", String.class, ParameterMode.OUT)
               .setParameter("vCode", Accmodel.getCode())
               .setParameter("Vdescription", Accmodel.getDescription())
               .setParameter("Vdupid", Accmodel.getAccountClassificationID());
   	query.execute();
   	 return (String)query.getOutputParameterValue("RESULT1");
   	
	}
	
	public int CreateAccountingClassification(AccountingClassificationModel Accmodel) {
     	 StoredProcedureQuery query = em
                 .createStoredProcedureQuery("InsertorUpdateAccountingClassification")
                 .registerStoredProcedureParameter("vAccountClassificationID", Integer.class, ParameterMode.IN)
                 .registerStoredProcedureParameter("VCode", String.class, ParameterMode.IN)
                 .registerStoredProcedureParameter("VDescription", String.class, ParameterMode.IN)
                 .registerStoredProcedureParameter("VCreatedBy", Integer.class, ParameterMode.IN)
                 .registerStoredProcedureParameter("VIsactive", Integer.class, ParameterMode.IN)
                 .registerStoredProcedureParameter("VRESULT", Integer.class, ParameterMode.OUT)
                 .setParameter("vAccountClassificationID", Accmodel.getAccountClassificationID())
                 .setParameter("VCode", Accmodel.getCode())
                 .setParameter("VDescription", Accmodel.getDescription())
                 .setParameter("VCreatedBy", Accmodel.getCreatedBy())
                 .setParameter("VIsactive", Accmodel.getIsactive());
     	query.execute();
     	 return (int)query.getOutputParameterValue("VRESULT");
     	
	}
	
	public List<GetAccountingClassificationModel> GetAllAccountingClassifications() {
    	 StoredProcedureQuery query = em
                .createStoredProcedureQuery("spGetAccountingClassificationCodeDesc")
                .registerStoredProcedureParameter("oAC", Class.class, ParameterMode.REF_CURSOR);
    	 query.execute();
      	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
    	 List<GetAccountingClassificationModel> accList = list.stream().map(
                 o -> new GetAccountingClassificationModel((Number) o[0], (String) o[1], (String) o[2] ,(Number) o[3]  ,(Number) o[4])).collect(Collectors.toList());
    	 
     	return accList;
	}
	
	public List<GetAccountingClassificationModel> SearchAccountingClassification(int AccountClassificationID,int Code,int  Description) {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("GetSearchAccountingClassification")
               .registerStoredProcedureParameter("vid", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vCode", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vDescription", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oAG", Class.class, ParameterMode.REF_CURSOR)
			    .setParameter("vid", AccountClassificationID)
			    .setParameter("vCode", Code)
			    .setParameter("vDescription",Description);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
   	 List<GetAccountingClassificationModel> accList = list.stream().map(
                o -> new GetAccountingClassificationModel((Number) o[0], (String) o[1]  ,(String) o[2],(Number) o[3],(Number) o[4],(String) o[5],(Number) o[6],(String) o[7])).collect(Collectors.toList());
   	 
    	return accList;
	}
	
	

	
}

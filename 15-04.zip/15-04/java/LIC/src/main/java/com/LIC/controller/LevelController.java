package com.LIC.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.Response;
import com.LIC.model.TransactionContext;
import com.LIC.service.LevelService;

@RestController
public class LevelController  {

	@Autowired
	private ResponseGenerator responseGenerator;
	@Autowired
	LevelService 	level
;private static final Logger logger = Logger.getLogger(LevelController.class);
	
	
	@GetMapping(value = "/getAllLevel", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllLevel(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
		
			return responseGenerator.successResponse(context, level.getAllLevel(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
}















































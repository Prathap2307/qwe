package com.LIC.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsIntimationDAO;
import com.LIC.model.ClaimIntimationCoverageModel;
import com.LIC.model.ClaimsCauseOFDeathModel;
import com.LIC.model.ClaimsIntimationDropDownModel;
import com.LIC.model.ClaimsIntimationModel;
import com.LIC.model.ClaimsIntimationSaultationModel;
import com.LIC.model.ClaimsRelationShipModel;
//import com.LIC.model.SearchClaimDetailsModel;
import com.LIC.model.SearchClaimDetailsModel;

@RestController
public class ClaimsIntimationController {

	@Autowired
	private ClaimsIntimationDAO claimsIntimationDAO;

	@PostMapping("/createClaimIntimation")
	public String saveClaimsIntimation(@RequestBody ClaimsIntimationModel cmodel) {
		return claimsIntimationDAO.createClaimIntimation(cmodel);
	}

	
	@GetMapping("/searchClaimDetails/{pMasterPolicyNo}")
	public List<SearchClaimDetailsModel> getSearchClaimDetails(@PathVariable String pMasterPolicyNo) {
		return claimsIntimationDAO.getSearchDetailForClaimIntimation(pMasterPolicyNo);
	}
	
	@GetMapping("/GetSearchDetailForClaimIntimation/{pMasterPolicyNo}/{pCertificateNo}/{pFirstName}/{pMemberID}")
	public List GetSearchDetailForClaimIntimation(@PathVariable String pMasterPolicyNo, 
			@PathVariable String pCertificateNo, 
			@PathVariable String pFirstName, 
			@PathVariable String pMemberID) {
		return claimsIntimationDAO.getSearchDetailForClaimIntimation(pMasterPolicyNo, pCertificateNo, pFirstName, pMemberID);
	}

	
	@PostMapping("/InsuredDetailsForGroupByApplicationID")
	public List<SearchClaimDetailsModel> getInsuredDetailsForGroupByApplicationID(@RequestBody SearchClaimDetailsModel model) {
		return claimsIntimationDAO.getInsuredDetailsForGroupByApplicationID(model);
	}

	
	@GetMapping("/relationshipDetails")
	public List<ClaimsRelationShipModel> getAllClaimsRelationship() {
		return claimsIntimationDAO.getAllClaimsRelationship();
	}

	@GetMapping("/GetAllCauseOfDeath")
	public List<ClaimsCauseOFDeathModel> getAllCauseOfDeath() {
		return claimsIntimationDAO.getAllCauseOfDeath();
	}

	
	@GetMapping("/IsClaimsPolicyNoExist/{insuredID}")
	public Integer getIsClaimsPolicyNoExist(@PathVariable Integer insuredID) {
		return claimsIntimationDAO.getIsClaimsPolicyNoExist(insuredID);
	}

	@GetMapping("/ValidateDate/{applicationId}/{date}")
	public String getValidateDate(@PathVariable("applicationId") Integer applicationID, @PathVariable("date") Date date) {
		return claimsIntimationDAO.getValidateDate(applicationID,date);
	}

	
	@GetMapping("/GetAllSalutation")
	public List<ClaimsIntimationSaultationModel> getAllSalutation() {
		return claimsIntimationDAO.getAllSalutation();
	}
	 
	
	@GetMapping("/GetAllPaymentMode")
	public List getAllPaymentMode() {
		return claimsIntimationDAO.getAllPaymentMode();
	}
	
	@GetMapping("/InsuredDetailsForGroupByPartyID")
	public List<ClaimIntimationCoverageModel> getInsuredDetailsForGroupByPartyID() {
		return claimsIntimationDAO.getInsuredDetailsForGroupByPartyID();
	}
	 
}

package com.LIC.bl;

import org.apache.log4j.Logger;

import com.LIC.model.PasswordPolicyModal;
import com.LIC.utils.dataobject.ValueObject;
public class PasswordPolicyBL {
	
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryBL.class);
	
	public PasswordPolicyModal createpasswordpolicymodelInfoDtoI(ValueObject object) throws Exception {
		PasswordPolicyModal passwordpolicy	= null;
		try {
			passwordpolicy = new PasswordPolicyModal();
			passwordpolicy.setPasswordPolicyId(object.getLong("passwordPolicyID",0));
			passwordpolicy.setOrgId(object.getLong("organisationID",0));
			passwordpolicy.setMinPasswordLength(object.getInt("minPasswordLength",0));
			passwordpolicy.setMaxPasswordLength(object.getInt("maxPasswordLength",0));
			passwordpolicy.setNoOfAttempts(object.getInt("noOfAttempts",0));
			passwordpolicy.setPasswordHistoryCount(object.getInt("passwordHistoryCount",0));
			passwordpolicy.setPasswordAge(object.getInt("passwordAge",0));
			passwordpolicy.setAlertMsgDay(object.getInt("alertMsgDay",0));
			passwordpolicy.setIsDigitsReq(object.getShort("isDigitsReq",(short)0));
			passwordpolicy.setIsCapitalletterReq(object.getShort("isCapitalletterReq",(short)0));
			passwordpolicy.setIsSmallletterReq(object.getShort("isSmallletterReq",(short)0));
			passwordpolicy.setIsSpecialcharReq(object.getShort("isSpecialcharReq",(short)0));
			passwordpolicy.setIsPasswordsameasUserID(object.getShort("isPasswordsameasUserID",(short)0));
			passwordpolicy.setIsActive(object.getShort("isActive",(short)1));
		
		} catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}
		return passwordpolicy;
	}
}

package com.LIC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.MemberAdditionUploadDAO;
import com.LIC.model.MemberAdditionModel;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;

import org.springframework.web.bind.annotation.RequestParam;
@RestController
public class MemberAdditionUploadController {
@Autowired
	private MemberAdditionUploadDAO endrosement;
	
@PostMapping ("/MemberAdditionUpload")
	public void ExcelUpload(@RequestBody MemberAdditionModel NBmodel)
	{
		try {
			endrosement.BulkInsert(NBmodel);
		} 
		catch (Exception e) {
	}
	
	
	}
	@GetMapping ("/CheckMemberAdditionHeaderFileExist")
	public int CheckGNBUHeaderFileExist(@RequestBody MemberAdditionModel NBmodel) 
	{
		return	endrosement.CheckMemberAdditionUHeaderFileExist(NBmodel);
	}
	
	

    @PostMapping ("/MemberAdditionValidateExcelFile")
    public String ValidateExcelFile(@RequestBody MemberAdditionModel NBmodel){
           try {
                  return endrosement.ValidateExcelFile(NBmodel);
           } 
           catch (Exception e) {return "";}
    }
    
    @PostMapping(value = "/SaveUploadedFileAddition")
    public MemberAdditionModel SaveUploadedFile(@RequestParam("file") MultipartFile file) throws IOException {
           return endrosement.SaveUploadedFile(file);
    }
    
    @PostMapping ("/migrationGNB")
    public List<MemberAdditionModel> getMigrationGNBMemberAdditionEndorsementDataUpload(@RequestBody MemberAdditionModel NBmodel) 
    {
           return endrosement.MigrationGNBMemberAdditionEndorsementDataUpload(NBmodel);
    }

}

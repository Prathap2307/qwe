package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsSettlementDao;
import com.LIC.model.AccountingProcessModel;
import com.LIC.model.ClaimsProofDocumentModel;
import com.LIC.model.ClaimsSettlementModel;
import com.LIC.model.SaveClaimsSettlementModel;
import com.LIC.model.SearchClaimsSettlementModel;

@RestController
public class ClaimsSettlementController {

	@Autowired
	private ClaimsSettlementDao claimsSettlementDao;
	
	@GetMapping("/getAllClaimsForSettlement/{pClaimID}/{pPolicyNumber}/{pFirstName}/{pLastName}/{pAgentCode}/{pServiceBranch}")
	public List<SearchClaimsSettlementModel> getAllClaimsForSettlement(@PathVariable String pClaimID,
			@PathVariable String pPolicyNumber, @PathVariable String pFirstName, @PathVariable String pLastName,
			@PathVariable String pAgentCode, @PathVariable String pServiceBranch) {
		return claimsSettlementDao.getAllClaimsForSettlement(pClaimID, pPolicyNumber, pFirstName,pLastName,pAgentCode,pServiceBranch);
	}
	
	@RequestMapping(value = "/insertClaimsSettlement", method = RequestMethod.POST)
	public void insertClaimsSettlement(@RequestBody SaveClaimsSettlementModel saveClaimsSettlementModel) {

	}
	
	@RequestMapping(value = "/deleteClaimsSettlementPaymentDetails/{pClaimID}", method = RequestMethod.DELETE)
	public void deleteClaimsSettlementPaymentDetails(@PathVariable int pClaimID) {
		claimsSettlementDao.deleteClaimsSettlementPaymentDetails(pClaimID);
	}
	
	@PostMapping("/insertClaimsSettlementPayment")
	public int insertClaimsSettlementPayment(@RequestBody ClaimsSettlementModel claimsSettlementModel) {
		return claimsSettlementDao.insertClaimsSettlementPayment(claimsSettlementModel);
	}
	
	@RequestMapping(value = "/getClaimNumberByClaimID/{pClaimID}", method = RequestMethod.GET)
	public List<SaveClaimsSettlementModel> getClaimNumberByClaimID(@PathVariable int pClaimID) {
		return claimsSettlementDao.getClaimNumberByClaimID(pClaimID);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/beneficiary/{claimId}")
    public List<ClaimsSettlementModel> getAllBeneficiaryDetails(@PathVariable int claimId) {
                return     claimsSettlementDao.getBeneficiary(claimId);
	}
}
	
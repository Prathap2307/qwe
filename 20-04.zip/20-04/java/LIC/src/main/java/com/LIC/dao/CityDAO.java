
package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.City;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class CityDAO implements ICityDAO {
	
	static final Logger LOGGER = LogManager.getLogger(CityDAO.class);
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(City obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateCity(?,?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getDistrictId());
		  callableStatement.setInt(2, obj.getCityId());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setString(4, obj.getShortDescription());
		  callableStatement.setInt(5, obj.getCreatedBy());
		  callableStatement.setString(6, obj.getRemarks());
		  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateCity executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateCity executed successfully.");
	}
	  
	@Override
	public void delete(Integer id, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteCity(?,?); END;");
		  callableStatement.setInt(1, id);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteCity executed successfully.");
		  LOGGER.info("SP>spDeleteCity executed successfully.");
	} 
	
	@Override
	public List<City> getAll(City filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<City> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllCity(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, filterObj.getDistrictId());
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
			  City obj = null;
			  list = new ArrayList<City>();
		      while (rs.next()) {
		        obj = new City();
		        obj.setCityId(rs.getInt("CityID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setShortDescription(rs.getString("shortDescription"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllCity executed successfully.");
			  LOGGER.info("SP>spGetAllCity executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllCitys exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public City get(Integer id) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  City obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetCityByID(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, id);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new City();
		        obj.setCityId(rs.getInt("CityID"));
		        obj.setDescription(rs.getString("Description"));
		        obj.setShortDescription(rs.getString("shortDescription"));
		      }
			  System.out.println("SP>spGetCityByID executed successfully.");
			  LOGGER.info("SP>spGetCityByID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetCityByID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	}  
	 
}

package com.LIC.controller;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.InsurerModal;
import com.LIC.model.Response;
import com.LIC.model.TransactionContext;
import com.LIC.service.BranchService;
import com.LIC.service.ContactAddressService;
import com.LIC.service.InsurerService;
import com.LIC.utils.dataobject.ValueObject;


@RestController
public class InsurerController {
	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(InsurerController.class);
	
	@Autowired
	public InsurerController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	@Autowired 	BranchService 			branchService;
	@Autowired 	InsurerService 			insurerService;
	@Autowired 	ContactAddressService 	contactAddressService;
	
	//Insurer
	
	/*@RequestMapping(value = "/InsertOrUpdateInsurer", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public ResponseEntity<Response> InsertOrUpdateInsurer(@RequestHeader HttpHeaders httpHeader,	@RequestBody InsurerModal insurerModal) {
	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);

		try {
				
			return responseGenerator.successResponse(context, insurerService.InsertOrUpdateInsurer(insurerModal).getHtData(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			//return responseGenerator.errorResponse(null, e, HttpStatus.BAD_REQUEST);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}*/
		
		@RequestMapping(value = "/InsertOrUpdateInsurer", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
		public ResponseEntity<Response> InsertOrUpdateInsurer(@RequestHeader HttpHeaders httpHeader,	@RequestBody  HashMap<Object, Object> allRequestParams) {
			
			TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
			ValueObject	object	= null;
			try {
				object	= new ValueObject(allRequestParams);
				System.out.println("InsertOrUpdateInsurer >>> "+object.toString());
				return responseGenerator.successResponse(context, insurerService.InsertOrUpdateInsurer(object).getHtData(), HttpStatus.OK);
				
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage(), e);
				//return responseGenerator.errorResponse(null, e, HttpStatus.BAD_REQUEST);
				return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
			}
			
	}
	
	@GetMapping(value = "/GetLineOfBusinssMapByUserId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetLineOfBusinssMapByUserId(@RequestHeader HttpHeaders httpHeaders,	@RequestParam("UserID") long UserID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {

			return responseGenerator.successResponse(context, insurerService.GetLineOfBusinssMapByUserId(UserID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/getAllInsurer", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllInsurer(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			//return insurerService.getAllInsurer();
			return responseGenerator.successResponse(context, insurerService.getAllInsurer(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@GetMapping(value = "/GetInsurerByID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetInsurerByID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("InsurerID") long InsurerID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			System.out.println("InsurerID >>>>>>>>>> "+InsurerID);
			return responseGenerator.successResponse(context, insurerService.GetInsurerByID(InsurerID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetInsurerNew", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetInsurerNew(@RequestHeader HttpHeaders httpHeaders,@RequestParam("InsurerID") long InsurerID,@RequestParam("LineOBusinessID") long LineOBusinessID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, insurerService.GetInsurerNew(InsurerID,LineOBusinessID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsInsurerExist", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsInsurerExist(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, insurerService.IsInsurerExist(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/DeleteInsurer", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> DeleteInsurer(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, insurerService.DeleteInsurer(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetLineOfBusiness", produces = MediaType.APPLICATION_JSON_VALUE , method = RequestMethod.GET)
	public ResponseEntity<Response> GetAllLineOfBusiness(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			return responseGenerator.successResponse(context, insurerService.GetAllLineOfBusiness(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	//end of isurer
	
	@RequestMapping(value = "/getLineOfBusinessCategory", produces = MediaType.APPLICATION_JSON_VALUE , method = RequestMethod.GET)
	public ResponseEntity<Response> getLineOfBusinessCategory(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			return responseGenerator.successResponse(context, insurerService.getLineOfBusinessCategory(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
}

package com.LIC.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.BankMasterModel;

import com.LIC.model.GetBankMasterModel;





@Repository
public class BankMasterDAO {
	

	@Autowired
	private EntityManager em;
	
	
@SuppressWarnings("unchecked")

	
	
	
public List<GetBankMasterModel> getAllBankInfo() {
    
    
    StoredProcedureQuery query = em
                 .createStoredProcedureQuery("spGetAllBank")
                 .registerStoredProcedureParameter(
                     1,
                     Class.class,
                     ParameterMode.REF_CURSOR
                 );
                // .setParameter(1, 1L);
  //  return query.execute() ? query.getResultList() : null;
    
    List<Object[]> list  =  (List<Object[]>)query.getResultList();
    List<GetBankMasterModel> accList = list.stream().map(
            o -> new GetBankMasterModel((Number) o[0], (String) o[1], (String) o[2])).collect(Collectors.toList());
    
   return accList;
}




@SuppressWarnings("unchecked")
public List<GetBankMasterModel> getBankInfoByDescription(String bankName) {
    StoredProcedureQuery query = em
        .createStoredProcedureQuery("spGETBANKDETAILSBYNAME")
        .registerStoredProcedureParameter(
            1,
            String.class,
            ParameterMode.IN
        )
        .registerStoredProcedureParameter(
            2,
            Class.class,
            ParameterMode.REF_CURSOR
        )
        .setParameter(1, bankName);
    query.execute();
// return query.execute() ? query.getResultList() : null;
    
    
    
    List<Object[]> list  =  (List<Object[]>)query.getResultList();
       List<GetBankMasterModel> branchList = list.stream().map(
               o -> new GetBankMasterModel((Number) o[0], (String) o[1], (String) o[2],(Number) o[3],(Date) o[4], (Number) o[5], (Date) o[6],(Number) o[7],(Date) o[8],(Number) o[9])).collect(Collectors.toList());
       
      return branchList;
   }
    
    

	 
	 






	
	
	
	
	public void createBankInfo(BankMasterModel model) {

		StoredProcedureQuery addBankStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdate");
		addBankStoredProcedure.setParameter("vBankID", model.getBankId());
		addBankStoredProcedure.setParameter("vDescription", model.getBankName());
		addBankStoredProcedure.setParameter("vShortDescription", model.getBankShortName());
		addBankStoredProcedure.setParameter("vCreatedBy", model.getCreatedBy());
		addBankStoredProcedure.setParameter("vCreatedOn", model.getCreatedOn());
		addBankStoredProcedure.getParameter("vResult");
		
		addBankStoredProcedure.execute();
		
		
		
		

	}
	
	public void deleteBankInfo(BankMasterModel model) {

		StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteBank");
				query.setParameter("pBankID",model.getBankId());
				
				query.setParameter("paraDELETEDBY",model.getDeletedBy());
				query.setParameter("paraDELETEDON",model.getDeletedOn());
				
		        query.execute();
	}
	
	

}

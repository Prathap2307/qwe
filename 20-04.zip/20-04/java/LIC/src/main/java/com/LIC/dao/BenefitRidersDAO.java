package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.BenefitRiders;
import com.LIC.model.VariantBenefitRider;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class BenefitRidersDAO implements IBenefitRidersDAO {
	
	static final Logger LOGGER = LogManager.getLogger(BenefitRidersDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	
	@Override
	public List<BenefitRiders> getAll(BenefitRiders filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<BenefitRiders> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllCoverage(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  BenefitRiders obj = null;
			  list = new ArrayList<BenefitRiders>();
		      while (rs.next()) {
		        obj = new BenefitRiders();
		        obj.setCoverageId(rs.getInt("COVERAGEID"));
		        obj.setCoverageName(rs.getString("COVERAGENAME"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllCoverage executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllCoverage exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
		  }
		  return list;
	} 
	
	
	@Override
	public List<VariantBenefitRider> getCoverageByProductID(Integer lineofBusinessId, Integer productId, Integer isSelectable, Integer isBaseCoverage) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<VariantBenefitRider> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllBaseOrSelectableCoverageByProductID(?,?,?,?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, lineofBusinessId);
			  callableStatement.setInt(2, productId);
			  callableStatement.setInt(3, isSelectable);
			  callableStatement.setInt(4, isBaseCoverage);
			  callableStatement.registerOutParameter(5, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(5);
			  VariantBenefitRider obj = null;
			  list = new ArrayList<VariantBenefitRider>();
		      while (rs.next()) {
		        obj = new VariantBenefitRider();
		        obj.setId(rs.getInt("COVERAGEID"));
		        obj.setDescription(rs.getString("COVERAGENAME"));
		        System.out.println(" coverage "+obj);
		        System.out.println(" rs.getInt(\"COVERAGEID\") "+rs.getInt("COVERAGEID"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllBaseOrSelectableCoverageByProductID executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllBaseOrSelectableCoverageByProductID exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
		  }
		  return list;
	} 
	 
	@Override
	public BenefitRiders saveOrUpdateBenefitRider(BenefitRiders filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  BenefitRiders obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateCoverageNew(?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, filterObj.getCoverageId());
			  callableStatement.setString(2, filterObj.getCoverageName());
			  callableStatement.setString(3, filterObj.getDescription());
			  callableStatement.setInt(4, filterObj.getCoverageHouseHoldLimitPerYear());
			  callableStatement.setInt(5, filterObj.getLineOfBusiness());
			  callableStatement.setInt(6, filterObj.getSectionId());
			  callableStatement.setInt(7, (filterObj.getCreatedBy()!=null && filterObj.getCreatedBy()!=0)?filterObj.getCreatedBy():1);
			  callableStatement.setTimestamp(8, null);
			  callableStatement.setInt(9, filterObj.getIsActive());
			  callableStatement.setString(10, String.valueOf(filterObj.getCoverageId()));
			  callableStatement.setInt(11, filterObj.getType());
			  callableStatement.setDouble(12, filterObj.getAmount());
			  callableStatement.registerOutParameter(13, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(13);
		      while (rs.next()) {
		        obj = new BenefitRiders();
		        obj.setCoverageId(rs.getInt("COVERAGEID"));
		        obj.setCoverageName(rs.getString("COVERAGENAME"));
		      }
			  LOGGER.info("SP>spGetAllCoverage executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllCoverage exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
		  }
		  return obj;
	} 
}

package com.LIC.constant;

public class Constant {

	public static final String ERROR							= "error";
	public static final String SUCCESS							= "success";
	public static final String MESSAGE							= "message";
}

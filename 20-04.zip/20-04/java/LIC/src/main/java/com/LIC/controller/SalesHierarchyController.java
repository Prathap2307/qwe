package com.LIC.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.Response;
import com.LIC.model.SalesHierarchyModal;
import com.LIC.model.TransactionContext;
import com.LIC.service.SalesHierarchyService;

@RestController
public class SalesHierarchyController {

	@Autowired 	private SalesHierarchyService 	salesHierarchyService;
	@Autowired 	private ResponseGenerator 		responseGenerator;

	private static final Logger logger = Logger.getLogger(SalesHierarchyController.class);
	
	@RequestMapping(value = "/InsertOrUpdateSalesHierarchy", produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Response> InsertUpdate(@RequestHeader HttpHeaders httpHeader,
				@RequestBody SalesHierarchyModal allRequestParams) {
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			System.out.println("SalesHierarchyModal>>"+allRequestParams);
			
			//return salesHierarchyService.InsertOrUpdate(allRequestParams);
			return responseGenerator.successResponse(context, salesHierarchyService.InsertOrUpdate(allRequestParams).getHtData(), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			//return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		return null;
	}
	

	
	@GetMapping(value = "/GetAllSalesHierarchyBySearch", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllSalesHierarchy(@RequestHeader HttpHeaders httpHeaders,@RequestParam("LineOfBusinessID") long LineOfBusinessID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, salesHierarchyService.getAllSalesHierarchyBySearch(LineOfBusinessID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetSalesHierarchyByID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetGroupByGroupID(@RequestHeader HttpHeaders httpHeaders,
			@RequestParam("SalesHierarchyID") long salesHierarchyID,
			@RequestParam("LineOfBusinessID") long lineOfBusinessID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, salesHierarchyService.getSalesHierarchyByID(salesHierarchyID,lineOfBusinessID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
}

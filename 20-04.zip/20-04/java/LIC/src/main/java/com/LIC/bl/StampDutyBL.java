package com.LIC.bl;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.LIC.constant.Constant;
import com.LIC.model.StampDutyModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

public class StampDutyBL {
	
	private static final Logger logger = Logger.getLogger(StampDutyBL.class);

	public StampDutyModal createStampDutyDto(ValueObject object, ValueObject outObject) throws Exception {
           
		try {
			
			StampDutyModal	stampDuty	= new StampDutyModal();
			 	
			stampDuty.setStampDutyID(object.getLong("stampDutyID",0));
			stampDuty.setProductID(object.getLong("productID",0));
			stampDuty.setCoverageID(object.getLong("coverageID",0));
			stampDuty.setStampDutyAmount(object.getDouble("stampDutyAmount",0));
			if(object.getString("mudrakNumber","").equals("")){
				outObject.put(Constant.ERROR, "Mudrank Number Should not empty !");
			}
			stampDuty.setMudrakNumber(object.getString("mudrakNumber",""));
			stampDuty.setPayOrderNumber(object.getString("payOrderNumber",""));
			stampDuty.setReceiptNumber(object.getString("receiptNumber",""));
			stampDuty.setBalanceStampDutyAmount(object.getDouble("balanceStampDutyAmount",0));
			stampDuty.setTriggerAmount(object.getDouble("triggerAmount",0));
			stampDuty.setCreatedBy(object.getLong("createdBy",0));
			stampDuty.setType(object.getLong("type",0));
			stampDuty.setTriggerAmount(object.getDouble("triggerAmount",0));
			stampDuty.setProductID(object.getLong("productID",0));
			stampDuty.setCoverageID(object.getLong("coverageID",0));
			stampDuty.setAdvanceDepositAmount(object.getDouble("stampDutyAdvanceDepositAmount",0));
			
			if(object.get("challanDate") != null  && !object.get("challanDate").equals("")) {
				stampDuty.setPaymentDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("challanDate")));
			} 
			System.out.println("challanDate"+object.get("challanDate"));
			System.out.println("challanEndDate"+object.get("challanEndDate"));
			if(object.get("challanEndDate") != null  && !object.get("challanEndDate").equals("")) {
				stampDuty.setChallanEndDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("challanEndDate")));
			} 
			if(object.get("defaceDate") != null  && !object.get("defaceDate").equals("")) {
				stampDuty.setDefaceDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("defaceDate")));
			} 
			if(object.get("certificateDate") != null  && !object.get("certificateDate").equals("")) {
				stampDuty.setCertificateDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("certificateDate")));
			} 
			stampDuty.setDefaceNumber(object.getString("defaceNumber",""));
			stampDuty.setCertificateNumber(object.getString("certificateNumber",""));
			stampDuty.setIntimationEmailAddress(object.getString("intimationEmailaddress",""));
			stampDuty.setIntimationMobileNumber(object.getString("intimationMobileNumber",""));
			
			return stampDuty;
		} catch (Exception e) {
			e.printStackTrace();
			outObject.put(Constant.ERROR, e.getLocalizedMessage());
			logger.info("error :"+e.getLocalizedMessage());
		} 
		return null;
	}
}

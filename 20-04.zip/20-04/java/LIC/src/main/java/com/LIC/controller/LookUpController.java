package com.LIC.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.AccountType;
import com.LIC.model.AccountTypeHistory;
import com.LIC.model.AddressType;
import com.LIC.model.AddressTypeHistory;
import com.LIC.model.AnnualIncome;
import com.LIC.model.AnnualIncomeHistory;
import com.LIC.model.BankCity;
import com.LIC.model.BankCityHistory;
import com.LIC.model.BenefitType;
import com.LIC.model.BenefitTypeHistory;
import com.LIC.model.BusinessType;
import com.LIC.model.BusinessTypeHistory;
import com.LIC.model.City;
import com.LIC.model.CityHistory;
import com.LIC.model.Country;
import com.LIC.model.CountryHistory;
import com.LIC.model.Currency;
import com.LIC.model.CurrencyHistory;
import com.LIC.model.District;
import com.LIC.model.DistrictHistory;
import com.LIC.model.DocumentCategory;
import com.LIC.model.DocumentCategoryHistory;
import com.LIC.model.DocumentType;
import com.LIC.model.DocumentTypeHistory;
import com.LIC.model.ErrorDto;
import com.LIC.model.Lookup;
import com.LIC.model.MaritalStatus;
import com.LIC.model.MaritalStatusHistory;
import com.LIC.model.MedicalTest;
import com.LIC.model.MedicalTestHistory;
import com.LIC.model.Occupation;
import com.LIC.model.OccupationHistory;
import com.LIC.model.PaymentFrequency;
import com.LIC.model.PaymentFrequencyHistory;
import com.LIC.model.PaymentMode;
import com.LIC.model.PaymentModeHistory;
import com.LIC.model.PostOffice;
import com.LIC.model.PostOfficeHistory;
import com.LIC.model.Profession;
import com.LIC.model.ProfessionHistory;
import com.LIC.model.Region;
import com.LIC.model.RegionHistory;
import com.LIC.model.Relationship;
import com.LIC.model.RelationshipHistory;
import com.LIC.model.ResidenceType;
import com.LIC.model.ResidenceTypeHistory;
import com.LIC.model.Salutation;
import com.LIC.model.State;
import com.LIC.model.StateHistory;
import com.LIC.service.IAccountTypeHistoryService;
import com.LIC.service.IAccountTypeService;
import com.LIC.service.IAddressTypeHistoryService;
import com.LIC.service.IAddressTypeService;
import com.LIC.service.IAnnualIncomeService;
import com.LIC.service.IAnnualIncomeServiceHistory;
import com.LIC.service.IBankCityHistoryService;
import com.LIC.service.IBankCityService;
import com.LIC.service.IBenefitTypeHistoryService;
import com.LIC.service.IBenefitTypeService;
import com.LIC.service.IBusinessTypeHistoryService;
import com.LIC.service.IBusinessTypeService;
import com.LIC.service.ICityHistoryService;
import com.LIC.service.ICityService;
import com.LIC.service.ICountryHistoryService;
import com.LIC.service.ICountryService;
import com.LIC.service.ICurrencyHistoryService;
import com.LIC.service.ICurrencyService;
import com.LIC.service.IDistrictHistoryService;
import com.LIC.service.IDistrictService;
import com.LIC.service.IDocumentCategoryHistoryService;
import com.LIC.service.IDocumentCategoryService;
import com.LIC.service.IDocumentTypeHistoryService;
import com.LIC.service.IDocumentTypeService;
import com.LIC.service.ILookupService;
import com.LIC.service.IMaritalStatusHistoryService;
import com.LIC.service.IMaritalStatusService;
import com.LIC.service.IMedicalTestHistoryService;
import com.LIC.service.IMedicalTestService;
import com.LIC.service.IOccupationHistoryService;
import com.LIC.service.IOccupationService;
import com.LIC.service.IPaymentFrequencyHistoryService;
import com.LIC.service.IPaymentFrequencyService;
import com.LIC.service.IPaymentModeHistoryService;
import com.LIC.service.IPaymentModeService;
import com.LIC.service.IPostOfficeHistoryService;
import com.LIC.service.IPostOfficeService;
import com.LIC.service.IProfessionHistoryService;
import com.LIC.service.IProfessionService;
import com.LIC.service.IRegionHistoryService;
import com.LIC.service.IRegionService;
import com.LIC.service.IRelationshipHistoryService;
import com.LIC.service.IRelationshipService;
import com.LIC.service.IResidenceTypeHistoryService;
import com.LIC.service.IResidenceTypeService;
import com.LIC.service.ISalutationService;
import com.LIC.service.IStateHistoryService;
import com.LIC.service.IStateService;
import com.LIC.utils.TextUtil;

@CrossOrigin
@RestController
@RequestMapping("/lookup")
public class LookUpController {

	@Autowired(required=true)
	IAccountTypeService accountTypeService;
	
	@Autowired(required=true)
	IAccountTypeHistoryService accountTypeHistoryService;
	
	@Autowired
	IRelationshipService relationshipService;
	
	@Autowired
	IRelationshipHistoryService relationshipHistoryService;
	
	@Autowired
	IAddressTypeService addressTypeService;
	
	@Autowired
	IAnnualIncomeService annualIncomeService;
	
	@Autowired
	IBenefitTypeService benefitTypeService;
	
	@Autowired
	IMaritalStatusHistoryService maritalStatusHistoryService;
	
	@Autowired
	IMaritalStatusService maritalStatusService;
	
	@Autowired
	IOccupationService occupationService;
	
	@Autowired
	IOccupationHistoryService occupationHistoryService;
	
	@Autowired
	IBenefitTypeHistoryService benefitTypeHistoryService;
	
	@Autowired
	IAccountTypeHistoryService accountoTypeHistoryService;
	
	@Autowired
	IDocumentTypeService documentTypeService;
	
	@Autowired
	IDocumentCategoryService documentCategoryService;
	
	@Autowired
	IAddressTypeHistoryService addressTypeHistoryService;
	
	@Autowired
	IAnnualIncomeServiceHistory annualIncomeServiceHistory;

	@Autowired
	IDocumentTypeHistoryService documentTypeHistoryService;
	
	@Autowired
	IDocumentCategoryHistoryService documentCategoryHistoryService;
	
	@Autowired
	IPaymentModeService paymentModeService;
	
	@Autowired
	IPaymentModeHistoryService paymentModeHistoryService;
	
	@Autowired
	IRegionHistoryService regionHistoryService;
	
	@Autowired
	IRegionService regionService;
	
	@Autowired(required=true)
	IBusinessTypeService businessTypeService;
	
	@Autowired(required=true)
	IBusinessTypeHistoryService businessTypeHistoryService;
	
	@Autowired(required=true)
	IResidenceTypeService residenceTypeService;
	
	@Autowired(required=true)
	IResidenceTypeHistoryService residenceTypeHistoryService;
	
	@Autowired(required=true)
	ISalutationService salutationService;
	
	@Autowired(required=true)
	IProfessionService professionService;
	
	@Autowired(required=true)
	IProfessionHistoryService professionHistoryService;
	
	@Autowired(required=true)
	IMedicalTestService medicalTestService;
	
	@Autowired(required=true)
	IMedicalTestHistoryService medicalTestHistoryService;

	@Autowired(required=true)
	IPaymentFrequencyHistoryService paymentFrequencyHistoryService;
	
	@Autowired(required=true)
	IPaymentFrequencyService paymentFrequencyService;
	
	@Autowired
	ICountryService countryService;
	
	@Autowired
	ICountryHistoryService countryHistoryService;
	
	@Autowired
	IStateService stateService;
	
	@Autowired
	IStateHistoryService stateHistoryService;
	
	
	@Autowired(required=true)
	ICurrencyService currencyService;
	
	@Autowired(required=true)
	ICurrencyHistoryService currencyHistoryService;
	
	@Autowired
	IDistrictService districtService;
	
	@Autowired
	IDistrictHistoryService districtHistoryService;
	
	@Autowired
	IPostOfficeService postOfficeService;
	
	@Autowired
	IPostOfficeHistoryService postOfficeHistoryService;
	
	@Autowired
	IBankCityHistoryService bankCityHistoryService;
	
	@Autowired
	IBankCityService bankCityService;
	
	@Autowired
	ICityHistoryService cityHistoryService;
	
	@Autowired
	ICityService cityService;
	@Autowired
	ILookupService lookupService;
	
	@RequestMapping(value = "/lookup/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllLookup() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Lookup> lookUpList = lookupService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("lookUpList", lookUpList); 
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public ResponseEntity<?> just() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		accountTypeService.saveOrUpdate(null);
		response.put("status", 1);
		response.put("message","Account type stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	 
	
	@RequestMapping(value = "/account-type/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateAccountType(@RequestBody AccountType accountType) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == accountType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != accountType.getAccountTypeId()) {
			accountType.setCreatedOn(new Date());
		}else {
			accountType.setAccountTypeId(0);
			accountType.setCreatedOn(new Date());
			accountType.setIsActive(1);
		}
		accountTypeService.saveOrUpdate(accountType);
		response.put("status", 1);
		response.put("message","Account type stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/account-type/delete/{accounttypeId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteAccountType(@PathVariable Integer accounttypeId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == accounttypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Account Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		AccountType accountType = accountTypeService.get(accounttypeId);
		if(null == accountType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Account Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		accountTypeService.delete(accounttypeId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/account-type/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllAccountTypes() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<AccountType> accountList = accountTypeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("accountList", accountList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/account-type/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchAccountType(@RequestBody AccountType filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<AccountType> accountList = accountTypeService.getAll(filterObj);
		List<AccountType> fliteredList = null;
		if(null != accountList && !accountList.isEmpty()) {
			fliteredList = accountList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("accountList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/account-type/get/{accounttypeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAccountType(@PathVariable Integer accounttypeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == accounttypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Account Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		AccountType accountType = accountTypeService.get(accounttypeId);
		if(null == accountType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Account Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<AccountTypeHistory> historyList = accountTypeHistoryService.getAll(accounttypeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("accountType", accountType);
		response.put("acctTypeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/address-type/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateAddressType(@RequestBody AddressType addressType) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == addressType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != addressType.getAddressTypeID()) {
			addressType.setIsActive(1);
		}else {
			addressType.setAddressTypeID(0);
			addressType.setIsActive(1);
		}
	
		addressType.setCreatedOn(new Date());
		addressTypeService.saveOrUpdate(addressType);
		response.put("status", 1);
		response.put("message","Address type stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/address-type/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> getAllAddressType(@RequestBody AddressType filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<AddressType> addressTypeList = addressTypeService.getAll(filterObj);
		List<AddressType> fliteredList = null;
		if(null != addressTypeList && !addressTypeList.isEmpty()) {
			fliteredList = addressTypeList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("addressTypeList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/address-type/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllAddressTypes() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<AddressType> addressTypeList = addressTypeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("addressTypeList", addressTypeList); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/address-type/get/{addressTypeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAddressType(@PathVariable Integer addressTypeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == addressTypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Account Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		AddressType addressType = addressTypeService.get(addressTypeId);
		if(null == addressType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Address Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<AddressTypeHistory> historyList = addressTypeHistoryService.getAll(addressTypeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("addressType", addressType);
		response.put("addressTypeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
 
	
	@RequestMapping(value = "/address-type/delete/{addressTypeID}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteAddressType(@PathVariable Integer addressTypeID, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == addressTypeID) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Address Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		AddressType addressType = addressTypeService.get(addressTypeID);
		if(null == addressType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Address Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		addressTypeService.delete(addressTypeID, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/annual-income/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateAnnualIncome(@RequestBody AnnualIncome annualIncome) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == annualIncome) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != annualIncome.getAnnualIncomeID()) {
			
		}else {
			annualIncome.setAnnualIncomeID(0);
			annualIncome.setIsActive(1);
		}
		annualIncome.setCreatedOn(new Date());
		annualIncomeService.saveOrUpdate(annualIncome);
		response.put("status", 1);
		response.put("message","Annual Income updated successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/annual-income/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> getAllAnnualIncome(@RequestBody AnnualIncome filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<AnnualIncome> annualIncomeList = annualIncomeService.getAll(filterObj);
		List<AnnualIncome> fliteredList = null;
		if(null != annualIncomeList && !annualIncomeList.isEmpty()) {
			fliteredList = annualIncomeList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("annualIncomeList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/annual-income/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllAnnualIncome() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<AnnualIncome> annualIncomeList = annualIncomeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("annualIncomeList", annualIncomeList); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/annual-income/get/{annualIncomeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAnnualIncome(@PathVariable Integer annualIncomeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == annualIncomeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Annual Income ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		AnnualIncome annualIncome = annualIncomeService.get(annualIncomeId);
		if(null == annualIncome) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Annual Income  ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<AnnualIncomeHistory> historyList = annualIncomeServiceHistory.getAll(annualIncomeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("annualIncome", annualIncome);
		response.put("annualIncomeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
 
	
	@RequestMapping(value = "/annual-income/delete/{annualIncomeId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteAnnualIncome(@PathVariable Integer annualIncomeId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == annualIncomeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Annual Income ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		AnnualIncome annualIncome = annualIncomeService.get(annualIncomeId);
		if(null == annualIncome) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Annual Income  ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		annualIncomeService.delete(annualIncomeId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/benefit-type/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateBenefit(@RequestBody BenefitType benefitType) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == benefitType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != benefitType.getBenefitTypeId()) {
			benefitType.setCreatedOn(new Date());
		}else {
			benefitType.setBenefitTypeId(0);
			benefitType.setCreatedOn(new Date());
			benefitType.setIsActive(1);
		}
		benefitTypeService.saveOrUpdate(benefitType);
		response.put("status", 1);
		response.put("message","Benefit Type stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/benefit-type/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllBenefitType() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<BenefitType> benefitList = benefitTypeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("benefitList", benefitList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/benefit-type/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchBenefitType(@RequestBody BenefitType filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<BenefitType> benefitList = benefitTypeService.getAll(filterObj);
		System.out.println("benefitList "+benefitList);
		List<BenefitType> fliteredList = null;
		if(null != benefitList && !benefitList.isEmpty()) {
			fliteredList = benefitList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		
		response.put("status", 1);
		response.put("message","Success");
		response.put("benefitList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/benefit-type/get/{benefittypeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getBenefitType(@PathVariable Integer benefittypeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == benefittypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Benefit Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		BenefitType benefitType = benefitTypeService.get(benefittypeId);
		if(null == benefitType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Benefit Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<BenefitTypeHistory> historyList = benefitTypeHistoryService.getAll(benefittypeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("benefitType", benefitType);
		response.put("benefitTypeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/benefit-type/delete/{benefittypeId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteBenefitType(@PathVariable Integer benefittypeId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == benefittypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Benefit Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		BenefitType benefitType = benefitTypeService.get(benefittypeId);
		if(null == benefitType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Benefit Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		benefitTypeService.delete(benefittypeId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}

	@RequestMapping(value = "/marital-status/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateMaritalStatus(@RequestBody MaritalStatus maritalStatus) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == maritalStatus) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != maritalStatus.getMaritalStatusId()) {
			maritalStatus.setCreatedOn(new Date());
			maritalStatus.setIsActive(1);
		}else {
			maritalStatus.setMaritalStatusId(0);
			maritalStatus.setCreatedOn(new Date());
			maritalStatus.setIsActive(1);
		}
		maritalStatusService.saveOrUpdate(maritalStatus);
		response.put("status", 1);
		response.put("message","Marital Status stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/marital-status/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllMaritalStatus() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MaritalStatus> maritalStatusList = maritalStatusService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("maritalStatusList", maritalStatusList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/marital-status/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchMaritalStatus(@RequestBody MaritalStatus filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MaritalStatus> maritalStatusList = maritalStatusService.getAll(null);
		List<MaritalStatus> fliteredList = null;
		if(null != maritalStatusList && !maritalStatusList.isEmpty()) {
			fliteredList = maritalStatusList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("maritalStatusList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/marital-status/get/{maritalStatusId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getMaritalStatus(@PathVariable Integer maritalStatusId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == maritalStatusId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Marital Status  ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		MaritalStatus maritalStatus = maritalStatusService.get(maritalStatusId);
		if(null == maritalStatus) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Marital Status ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<MaritalStatusHistory> historyList = maritalStatusHistoryService.getAll(maritalStatusId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("maritalStatus", maritalStatus);
		response.put("maritalStatusHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/marital-status/delete/{maritalStatusId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteMaritalStatus(@PathVariable Integer maritalStatusId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == maritalStatusId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Marital Status ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		MaritalStatus maritalStatus = maritalStatusService.get(maritalStatusId);
		if(null == maritalStatus) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Marital Status ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		maritalStatusService.delete(maritalStatusId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/occupation/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateOccupation(@RequestBody Occupation occupation) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == occupation) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != occupation.getOccupationId()) {
			occupation.setCreatedOn(new Date());
			occupation.setIsActive(1);
		}else {
			occupation.setOccupationId(0);
			occupation.setCreatedOn(new Date());
			occupation.setIsActive(1);
		}
		occupationService.saveOrUpdate(occupation);
		response.put("status", 1);
		response.put("message","Occupation stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/occupation/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllOccupation() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Occupation> occupationList = occupationService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("occupationList", occupationList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/occupation/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchOccupation(@RequestBody Occupation filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Occupation> occupationList = occupationService.getAll(filterObj);
		
		List<Occupation> fliteredList = null;
		if(null != occupationList && !occupationList.isEmpty()) {
			fliteredList = occupationList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		
		response.put("status", 1);
		response.put("message","Success");
		response.put("occupationList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/occupation/get/{occupationId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getOccupation(@PathVariable Integer occupationId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == occupationId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Occupation ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Occupation occupation = occupationService.get(occupationId);
		if(null == occupation) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Occupation  ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<OccupationHistory> historyList = occupationHistoryService.getAll(occupationId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("occupation", occupation);
		response.put("occupationHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/occupation/delete/{occupationId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteOccupation(@PathVariable  Integer occupationId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == occupationId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage(" Occupation ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Occupation occupation = occupationService.get(occupationId);
		if(null == occupation) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Occupation ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		occupationService.delete(occupationId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/document-type/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateDocumentType(@RequestBody DocumentType documentType) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == documentType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != documentType.getDocumentTypeId()) {
			documentType.setCreatedOn(new Date());
			documentType.setIsActive(1);
		}else {
			documentType.setDocumentTypeId(0);
			documentType.setCreatedOn(new Date());
			documentType.setIsActive(1);
		}
		documentTypeService.saveOrUpdate(documentType);
		response.put("status", 1);
		response.put("message","Document Type stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-type/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllDocumentType() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<DocumentType> documentList = documentTypeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("documentList", documentList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-type/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchDocument(@RequestBody DocumentType filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<DocumentType> documentList = documentTypeService.getAll(filterObj);
		List<DocumentType> fliteredList = null;
		if(null != documentList && !documentList.isEmpty()) {
			fliteredList = documentList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("documentList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-type/get/{documentTypeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getDocument(@PathVariable Integer documentTypeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == documentTypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Document  ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		DocumentType documentType = documentTypeService.get(documentTypeId);
		if(null == documentType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Document Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<DocumentTypeHistory> historyList = documentTypeHistoryService.getAll(documentTypeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("documentType", documentType);
		response.put("documentTypeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-type/delete/{documentTypeId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteDocument(@PathVariable Integer documentTypeId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == documentTypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Document Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		DocumentType documentType = documentTypeService.get(documentTypeId);
		if(null == documentType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Country ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		documentTypeService.delete(documentTypeId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-category/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateDocumentCategory(@RequestBody DocumentCategory documentCategory) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == documentCategory) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != documentCategory.getDocumentCategoryId()) {
			documentCategory.setCreatedOn(new Date());
		}else {
			documentCategory.setDocumentCategoryId(0);
			documentCategory.setCreatedOn(new Date());
			documentCategory.setIsActive(1);
		}
		documentCategoryService.saveOrUpdate(documentCategory);
		response.put("status", 1);
		response.put("message","Document Category stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-category/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllDocumentCategory() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<DocumentCategory> documentCategoryList = documentCategoryService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("documentCategoryList", documentCategoryList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-category/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchDocumentCategory(@RequestBody DocumentCategory filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<DocumentCategory> documentCategoryList = documentCategoryService.getAll(filterObj);
		List<DocumentCategory> fliteredList = null;
		if(null != documentCategoryList && !documentCategoryList.isEmpty()) {
			fliteredList = documentCategoryList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("documentCategoryList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-category/get/{documentCategoryId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getDocumentCategory(@PathVariable Integer documentCategoryId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == documentCategoryId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Document Category ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		DocumentCategory documentCategory = documentCategoryService.get(documentCategoryId);
		if(null == documentCategory) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Document Category  ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<DocumentCategoryHistory> historyList = documentCategoryHistoryService.getAll(documentCategoryId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("documentCategory", documentCategory);
		response.put("documentCategoryHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/document-category/delete/{documentCategoryId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteDocumentCategory(@PathVariable  Integer documentCategoryId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == documentCategoryId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Document Category  ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		DocumentCategory documentCategory = documentCategoryService.get(documentCategoryId);
		if(null == documentCategory) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Document Category  ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		documentCategoryService.delete(documentCategoryId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/paymentMode/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdatePaymentMode(@RequestBody PaymentMode paymentMode) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == paymentMode) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != paymentMode.getPaymentModeId()) {
			paymentMode.setCreatedOn(new Date());
		}else {
			paymentMode.setPaymentModeId(0);
			paymentMode.setCreatedOn(new Date());
			paymentMode.setIsActive(1);
		}
		paymentModeService.saveOrUpdate(paymentMode);
		response.put("status", 1);
		response.put("message","Payment stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/paymentMode/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllPaymentMode() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PaymentMode> paymentList = paymentModeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("paymentList", paymentList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/paymentMode/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchPaymentMode(@RequestBody PaymentMode filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PaymentMode> paymentList = paymentModeService.getAll(filterObj);
		List<PaymentMode> fliteredList = null;
		if(null != paymentList && !paymentList.isEmpty()) {
			fliteredList = paymentList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("paymentList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/paymentMode/get/{paymentModeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getPaymentMode(@PathVariable Integer paymentModeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == paymentModeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Payment Mode ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PaymentMode paymentMode = paymentModeService.get(paymentModeId);
		if(null == paymentMode) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Payment Mode ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<PaymentModeHistory> historyList = paymentModeHistoryService.getAll(paymentModeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("paymentMode", paymentMode);
		response.put("paymentModeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/paymentMode/delete/{paymentModeId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deletePaymentMode(@PathVariable  Integer paymentModeId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == paymentModeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Payment Mode ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PaymentMode paymentMode = paymentModeService.get(paymentModeId);
		if(null == paymentMode) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Payment Mode  ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		paymentModeService.delete(paymentModeId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/region/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateRegion(@RequestBody Region region) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == region) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != region.getRegionId()) {
			region.setCreatedOn(new Date());
		}else {
			region.setRegionId(0);
			region.setCreatedOn(new Date());
			region.setIsActive(1);
		}
		regionService.saveOrUpdate(region);
		response.put("status", 1);
		response.put("message","Region stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/region/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllRegion() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Region> regionList = regionService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("regionList", regionList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/region/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchRegion(@RequestBody Region filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Region> regionList = regionService.getAll(filterObj);
		List<Region> fliteredList = null;
		if(null != regionList && !regionList.isEmpty()) {
			fliteredList = regionList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		
		
		response.put("status", 1);
		response.put("message","Success");
		response.put("regionList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/region/get/{regionId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getRegion(@PathVariable Integer regionId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == regionId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Region ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Region region = regionService.get(regionId);
		if(null == region) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Region ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<RegionHistory> historyList = regionHistoryService.getAll(regionId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("region", region);
		response.put("regionHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/region/delete/{regionId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteRegion(@PathVariable  Integer regionId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == regionId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Region  ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Region region = regionService.get(regionId);
		if(null == region) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Region ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		regionService.delete(regionId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/relationship/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateRelationship(@RequestBody Relationship relationship) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == relationship) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != relationship.getRelationshipId()) {
			relationship.setCreatedOn(new Date());
			relationship.setIsActive(1);
		}else {
			relationship.setRelationshipId(0);
			relationship.setCreatedOn(new Date());
			relationship.setIsActive(1);

		}
		relationshipService.saveOrUpdate(relationship);
		response.put("status", 1);
		response.put("message","Relationship stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/relationship/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllRelationship() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Relationship> relationshipList = relationshipService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("relationshipList", relationshipList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/relationship/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchRelationship(@RequestBody Relationship filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Relationship> relationshipList = relationshipService.getAll(filterObj);
		List<Relationship> fliteredList = null;
		if(null != relationshipList && !relationshipList.isEmpty()) {
			fliteredList = relationshipList.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("relationshipList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/relationship/get/{relationshipId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getRelationship(@PathVariable Integer relationshipId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == relationshipId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Relationship  ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Relationship relationship = relationshipService.get(relationshipId);
		if(null == relationship) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Relationship ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<RelationshipHistory> historyList = relationshipHistoryService.getAll(relationshipId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("relationship", relationship);
		response.put("relationshipHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/relationship/delete/{relationshipId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteRelationship(@PathVariable Integer relationshipId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == relationshipId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Relationship ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Relationship relationship = relationshipService.get(relationshipId);
		if(null == relationship) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Relationship ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		relationshipService.delete(relationshipId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	 
	@RequestMapping(value = "/business-type/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateBusinessType(@RequestBody BusinessType businessType) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == businessType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != businessType.getBusinessTypeId()) {
			businessType.setCreatedOn(new Date());
		}else {
			businessType.setBusinessTypeId(0);
			businessType.setIsActive(1);
		}
		businessTypeService.saveOrUpdate(businessType);
		response.put("status", 1);
		response.put("message","Business type stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/business-type/delete/{businesstypeId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteBusinessType(@PathVariable Integer businesstypeId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == businesstypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Business Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		BusinessType businessType = businessTypeService.get(businesstypeId);
		if(null == businessType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Business Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		businessTypeService.delete(businesstypeId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/business-type/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllBusinessTypes() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<BusinessType> list = businessTypeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("businessList", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/business-type/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchBusinessType(@RequestBody BusinessType filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<BusinessType> list = businessTypeService.getAll(filterObj);
		List<BusinessType> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) &&  
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("businessList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/business-type/get/{businesstypeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getBusinessType(@PathVariable Integer businesstypeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == businesstypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Business Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		BusinessType obj = businessTypeService.get(businesstypeId);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Business Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<BusinessTypeHistory> historyList = businessTypeHistoryService.getAll(businesstypeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("businessType", obj);
		response.put("businessTypeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	 
	
	@RequestMapping(value = "/residence-type/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateResidenceType(@RequestBody ResidenceType residenceType) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == residenceType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != residenceType.getResidenceTypeId()) {
			residenceType.setCreatedOn(new Date());
		}else {
			residenceType.setResidenceTypeId(0);
			residenceType.setIsActive(1);
		}
		residenceTypeService.saveOrUpdate(residenceType);
		response.put("status", 1);
		response.put("message","Residence type stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	

	@RequestMapping(value = "/residence-type/delete/{residenceId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteResidenceType(@PathVariable Integer residenceId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == residenceId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Residence Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		ResidenceType residenceType = residenceTypeService.get(residenceId);
		if(null == residenceType) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Residence Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		residenceTypeService.delete(residenceId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/residence-type/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllResidenceTypes() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<ResidenceType> list = residenceTypeService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("residenceList", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/residence-type/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchResidenceType(@RequestBody ResidenceType filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<ResidenceType> list = residenceTypeService.getAll(filterObj);
		List<ResidenceType> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) &&  
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		
		response.put("status", 1);
		response.put("message","Success");
		response.put("residenceList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/residence-type/get/{residencetypeId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getResidenceType(@PathVariable Integer residencetypeId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == residencetypeId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Residence Type ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		ResidenceType obj = residenceTypeService.get(residencetypeId);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Residence Type ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<ResidenceTypeHistory> historyList = residenceTypeHistoryService.getAll(residencetypeId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("residenceType", obj);
		response.put("residenceTypeHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/salutation/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateSalutation(@RequestBody Salutation salutation) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == salutation) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != salutation.getSalutationId()) {
		}else {
			salutation.setSalutationId(0);
			salutation.setIsActive(1);
		}
		salutationService.saveOrUpdate(salutation);
		response.put("status", 1);
		response.put("message","Salutation stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/salutation/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllSalutations() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Salutation> list = salutationService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("salutationList", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/salutation/get/{salutationId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getSalutationType(@PathVariable Integer salutationId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == salutationId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Salutation ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Salutation obj = salutationService.get(salutationId);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Salutation ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("salutation", obj);
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/salutation/delete/{salutationId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteSalutation(@PathVariable Integer salutationId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == salutationId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Salutation ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Salutation salutation = salutationService.get(salutationId);
		if(null == salutation) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Salutation ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		salutationService.delete(salutationId);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/salutation/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchSalutation(@RequestBody Salutation filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Salutation> list = salutationService.getAll(filterObj);
		List<Salutation> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
                                 return true;
                             }
                			 return false;
	                	 } 
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("salutationList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/medicaltest/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateMedicalTest(@RequestBody MedicalTest requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != requestObj.getId()) {
			requestObj.setCreatedOn(new Date());
		}else {
			requestObj.setId(0);
			requestObj.setIsActive(1);
		}
		medicalTestService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","Medical test stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/medicaltest/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteMedicalTest(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("MedicalTest ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		MedicalTest medicalTest = medicalTestService.get(id);
		if(null == medicalTest) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid MedicalTest ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		medicalTestService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/medicaltest/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllMedicalTest() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MedicalTest> list = medicalTestService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/medicaltest/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchMedicalTest(@RequestBody MedicalTest filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<MedicalTest> list = medicalTestService.getAll(filterObj);
		List<MedicalTest> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) &&  
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/medicaltest/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getMedicalTest(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Profession ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		MedicalTest obj = medicalTestService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Profession ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<MedicalTestHistory> historyList = medicalTestHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj);
		response.put("list", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/profession/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateProfession(@RequestBody Profession requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != requestObj.getProfessionId()) {
			requestObj.setCreatedOn(new Date());
		}else {
			requestObj.setProfessionId(0);
			requestObj.setIsActive(1);
		}
		professionService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","Profession stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/profession/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteProfession(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Profession ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Profession profession = professionService.get(id);
		if(null == profession) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Profession ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		professionService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/profession/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllProfessionTypes() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Profession> list = professionService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("professionList", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/profession/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchProfessionType(@RequestBody Profession filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Profession> list = professionService.getAll(filterObj);
		List<Profession> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) &&  
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("professionList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/profession/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getProfessionType(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Profession ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Profession obj = professionService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Profession ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<ProfessionHistory> historyList = professionHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("profession", obj);
		response.put("professionHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/payment-frequency/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdatePaymentFrequency(@RequestBody PaymentFrequency paymentFrequency) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == paymentFrequency) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != paymentFrequency.getFrequencyId()) {
			paymentFrequency.setCreatedOn(new Date());
		}else {
			paymentFrequency.setFrequencyId(0);
			paymentFrequency.setCreatedOn(new Date());
			paymentFrequency.setIsActive(1);
		}
		paymentFrequencyService.saveOrUpdate(paymentFrequency);
		response.put("status", 1);
		response.put("message","Payment Frequency stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/payment-frequency/delete/{frequencyId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deletePaymentFrequency(@PathVariable Integer frequencyId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == frequencyId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Payment Frequency ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PaymentFrequency faymentFrequency = paymentFrequencyService.get(frequencyId);
		if(null == faymentFrequency) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Payment Frequency ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		paymentFrequencyService.delete(frequencyId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/payment-frequency/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllPaymentFrequency() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PaymentFrequency> paymentFrequencyist = paymentFrequencyService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("paymentFrequencyist", paymentFrequencyist); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/payment-frequency/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchPaymentFrequency(@RequestBody PaymentFrequency filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PaymentFrequency> paymentFrequencyList = paymentFrequencyService.getAll(filterObj);
		
		 List<PaymentFrequency> result2 = paymentFrequencyList.stream()
                 .filter(p -> {
                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) &&  
                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
                                 return true;
                             }
                			 return false;
                		 }else {
                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
                                 return true;
                             }
                			 return false;
                		 }
                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
                             return true;
                         }
                		 return false;
                	 }
                     return true;
                 }).collect(Collectors.toList());
		 
		 
		response.put("status", 1);
		response.put("message","Success");
		response.put("paymentFrequencyList", result2); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/payment-frequency/get/{frequencyId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getPaymentFrequency(@PathVariable Integer frequencyId) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == frequencyId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Payment Frequency ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PaymentFrequency paymentFrequency = paymentFrequencyService.get(frequencyId);
		if(null == paymentFrequency) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Payment Frequency ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<PaymentFrequencyHistory> historyList = paymentFrequencyHistoryService.getAll(frequencyId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("paymentFrequency", paymentFrequency);
		response.put("paymentFrequencyHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/country/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateCountry(@RequestBody Country country) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == country) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != country.getCountryId()) {
		}else {
			country.setCountryId(0);
		}
		countryService.saveOrUpdate(country);
		response.put("status", 1);
		response.put("message","Country stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/country/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteCountry(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Country ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Country country = countryService.get(id);
		if(null == country) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Country ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		countryService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/country/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllCountries() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Country> list = countryService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	

	@RequestMapping(value = "/country/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchCountry(@RequestBody Country filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Country> list = countryService.getAll(filterObj);
		List<Country> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) &&  
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/country/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getCountry(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Country ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Country obj = countryService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Country ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<CountryHistory> historyList = countryHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj);
		response.put("list", historyList);
		return ResponseEntity.accepted().body(response);
	}

	
	@RequestMapping(value = "/state/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateState(@RequestBody State requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != requestObj.getStateId()) {
		}else {
			requestObj.setStateId(0);
		}
		stateService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","State stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/state/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteState(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("State ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		State obj = stateService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid State ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		stateService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/state/getbycountry/{countryId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllStatesByCountryID(@PathVariable Integer countryId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == countryId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Country ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		State filterObj = new State();
		filterObj.setCountryId(countryId);
		List<State> list = stateService.getAll(filterObj);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	

	@RequestMapping(value = "/state/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchState(@RequestBody State filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<State> list = stateService.getAll(filterObj);
		List<State> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getTinNumber())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getTinNumber(), filterObj.getTinNumber())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getTinNumber())){
	                		 if (TextUtil.isContains(p.getTinNumber(), filterObj.getTinNumber())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/state/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getState(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("State ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		State obj = stateService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid State ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<StateHistory> historyList = stateHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj);
		response.put("list", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	
	
	@RequestMapping(value = "/currency/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateCurrency(@RequestBody Currency requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		if(null != requestObj.getCurrencyId()) {
			requestObj.setCreatedOn(new Date());
		}else {
			requestObj.setCurrencyId(0);
			requestObj.setIsActive(1);
		}
		currencyService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","Currency stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/currency/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteCurrency(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Currency ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Currency currency = currencyService.get(id);
		if(null == currency) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Currency ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		currencyService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/currency/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllCurrency() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Currency> list = currencyService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("currencyList", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/currency/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchCurrency(@RequestBody Currency filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Currency> list = currencyService.getAll(filterObj);
		List<Currency> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) &&  
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("currencyList", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/currency/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getCurrency(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Currency ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		Currency obj = currencyService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Currency ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<CurrencyHistory> historyList = currencyHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("currency", obj);
		response.put("currencyHistoryList", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	

	@RequestMapping(value = "/district/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateDistrict(@RequestBody District requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null == requestObj.getStateId()) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Please Choose State.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		State state = stateService.get(requestObj.getStateId());
		if(null == state) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid State Selection.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null != requestObj.getDistrictId()) {
		}else {
			requestObj.setDistrictId(0);;
		}
		districtService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","District stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/district/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteDistrict(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("District ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		District obj = districtService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid District ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		districtService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/district/getbystate/{stateId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllDistrictByStateID(@PathVariable Integer stateId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == stateId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("District ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		District filterObj = new District();
		filterObj.setStateId(stateId);
		List<District> list = districtService.getAll(filterObj);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	
	

	@RequestMapping(value = "/district/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchDistrict(@RequestBody District filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<District> list = districtService.getAll(filterObj);
		List<District> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getZipCode())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getZipCode(), filterObj.getZipCode())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getZipCode())){
	                		 if (TextUtil.isContains(p.getZipCode(), filterObj.getZipCode())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/district/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getDistrict(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("District ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		District obj = districtService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid District ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<DistrictHistory> historyList = districtHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj);
		response.put("list", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	

	@RequestMapping(value = "/postoffice/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdatePostoffice(@RequestBody PostOffice requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null == requestObj.getDistrictId()) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Please Choose District.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		District district = districtService.get(requestObj.getDistrictId());
		if(null == district) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid District Selection.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null != requestObj.getPostOfficeId()) {
		}else {
			requestObj.setPostOfficeId(0);;
		}
		postOfficeService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","Postoffice stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/postoffice/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deletePostoffice(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("PostOffice ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PostOffice obj = postOfficeService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid PostOffice ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		postOfficeService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/postoffice/getbydistrict/{districtId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllPostOfficeByDistrictID(@PathVariable Integer districtId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == districtId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("District ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PostOffice filterObj = new PostOffice();
		filterObj.setDistrictId(districtId);
		List<PostOffice> list = postOfficeService.getAll(filterObj);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/postoffice/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchPostOffice(@RequestBody PostOffice filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<PostOffice> list = postOfficeService.getAll(filterObj);
		List<PostOffice> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getZipCode())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getZipCode(), filterObj.getZipCode())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getZipCode())){
	                		 if (TextUtil.isContains(p.getZipCode(), filterObj.getZipCode())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/postoffice/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getPostOffice(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("PostOffice ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		PostOffice obj = postOfficeService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid PostOffice ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<PostOfficeHistory> historyList = postOfficeHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj);
		response.put("list", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
	
	
	@RequestMapping(value = "/bankcity/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateBankCity(@RequestBody BankCity requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null == requestObj.getDistrictId()) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Please Choose District.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		District district = districtService.get(requestObj.getDistrictId());
		if(null == district) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid District Selection.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null != requestObj.getBankCityId()) {
		}else {
			requestObj.setBankCityId(0);
		}
		bankCityService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","BankCity stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/bankcity/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteBankCity(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("BankCity ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		BankCity obj = bankCityService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid BankCity ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		bankCityService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/bankcity/getbydistrict/{districtId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllBankCityByDistrictID(@PathVariable Integer districtId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == districtId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("District ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		BankCity filterObj = new BankCity();
		filterObj.setDistrictId(districtId);
		List<BankCity> list = bankCityService.getAll(filterObj);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/bankcity/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchBankCity(@RequestBody BankCity filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<BankCity> list = bankCityService.getAll(filterObj);
		List<BankCity> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/bankcity/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getBankCity(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("BankCity ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		BankCity obj = bankCityService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid BankCity ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<BankCityHistory> historyList = bankCityHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj);
		response.put("list", historyList);
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/city/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateCity(@RequestBody City requestObj) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == requestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null == requestObj.getDistrictId()) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Please Choose District.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		District district = districtService.get(requestObj.getDistrictId());
		if(null == district) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid District Selection.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		
		if(null != requestObj.getCityId()) {
		}else {
			requestObj.setCityId(0);
		}
		cityService.saveOrUpdate(requestObj);
		response.put("status", 1);
		response.put("message","City stored successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/city/delete/{id}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteCity(@PathVariable Integer id, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("BankCity ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		City obj = cityService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid City ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		cityService.delete(id, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/city/getbydistrict/{districtId}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllCityByDistrictID(@PathVariable Integer districtId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		ErrorDto errorDto = null;
		if (null == districtId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("District ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		City filterObj = new City();
		filterObj.setDistrictId(districtId);
		List<City> list = cityService.getAll(filterObj);
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", list); 
		return ResponseEntity.accepted().body(response);
	}
	

	@RequestMapping(value = "/city/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchCity(@RequestBody City filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<City> list = cityService.getAll(filterObj);
		List<City> fliteredList = null;
		if(null != list && !list.isEmpty()) {
			fliteredList = list.stream()
	                 .filter(p -> {
	                	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	                		 if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())) {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	                					 TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }else {
	                			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                                 return true;
	                             }
	                			 return false;
	                		 }
	                	 }else if(!TextUtil.isEmptyOrNull(filterObj.getShortDescription())){
	                		 if (TextUtil.isContains(p.getShortDescription(), filterObj.getShortDescription())) {
	                             return true;
	                         }
	                		 return false;
	                	 }
	                     return true;
	                 }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/city/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getCity(@PathVariable Integer id) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == id) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("City ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		City obj = cityService.get(id);
		if(null == obj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid City ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<CityHistory> historyList = cityHistoryService.getAll(id);
		response.put("status", 1);
		response.put("message","Success");
		response.put("obj", obj);
		response.put("list", historyList);
		return ResponseEntity.accepted().body(response);
	}
	
}

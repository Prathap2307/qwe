package com.LIC.controller;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.Response;
import com.LIC.model.TransactionContext;
import com.LIC.service.GroupService;
import com.LIC.utils.dataobject.ValueObject;

/**
 * @author Admin
 *
 *2019
 */

@RestController
public class GroupController {
	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(GroupController.class);
	
	@Autowired
	public GroupController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	
	@Autowired 	GroupService	groupService;
	
	@RequestMapping(value = "/InsertOrUpdateGroup", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertOrUpdateGroup(@RequestHeader HttpHeaders httpHeaders,	@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParams);

			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, groupService.InsertOrUpdate(object).getHtData(), HttpStatus.OK);
			 
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/DeleteGroup", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> DeleteGroup(@RequestHeader HttpHeaders httpHeaders,	@RequestParam("GroupID") long GroupID,
			@RequestParam("DeletedBy") long DeletedBy) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {

			return responseGenerator.successResponse(context, groupService.DeleteGroup(GroupID,DeletedBy), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllUsersGroupByOrganisationID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllUsersGroupByOrg(@RequestHeader HttpHeaders httpHeaders,	@RequestParam("OrganisationID") long organisationID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, groupService.GetAllUsersGroupByOrg(organisationID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllGroupsByOrg", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllGroupsByOrganisationId(@RequestHeader HttpHeaders httpHeaders,
			@RequestParam("OrganisationID") long organisationID,
			@RequestParam("Description") String description) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, groupService.GetAllGroupsByOrg(organisationID,description), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetGroupByGroupID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetGroupByGroupID(@RequestHeader HttpHeaders httpHeaders,
			@RequestParam("OrganisationID") long orgID,@RequestParam("GroupID") long groupID
			,@RequestParam("Mode") int mode) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, groupService.GetGroupByGroupID(orgID, groupID, mode), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
}

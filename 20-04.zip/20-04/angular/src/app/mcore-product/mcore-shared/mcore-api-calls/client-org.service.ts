import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';
@Injectable({
  providedIn: 'root'
})
export class ClientOrgService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addClientOrganization(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/client/addClientOrganization/update', data).pipe(tap((response) => response));
  }
  getbyofficercode(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/salesHierarchy/'+data).pipe(tap((response) => response));
  }
  getclientbranch(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/client/branch/get').pipe(tap((response) => response));
  }
  getClientById(groupId: any): Observable<any> {
    return this.http.get(this.baseUrl + `/client/client/${groupId}/${groupId}`).pipe(tap((response) => response));
  }
  search(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/client/client/search',data).pipe(tap((response) => response));
  }
  getALlClientOrg(): Observable<any> {
    return this.http.get(this.baseUrl + '/client/client/get').pipe(tap((response) => response));
  }
}

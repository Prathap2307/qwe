import { TestBed } from '@angular/core/testing';

import { MasterPolicyService } from './master-policy.service';

describe('MasterPolicyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MasterPolicyService = TestBed.get(MasterPolicyService);
    expect(service).toBeTruthy();
  });
});

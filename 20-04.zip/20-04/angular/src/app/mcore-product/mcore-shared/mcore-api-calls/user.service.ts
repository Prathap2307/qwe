import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl = environment.API_URL;
  fname: any;
  timezone: any;
  lastLoginTime: any;
  userID: any;
  userName: any;
  constructor(private http: HttpClient) {
    console.log(this.fname)
    console.log(this.timezone)
   }


  GetLineofBusinessMapByUserID(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetLineofBusinessMapByUserID' + id).pipe(tap((response) => response));
  }


  getAllFeaturesByModuleId(id): Observable<any> {
    return this.http.get(this.baseUrl +'/getAllFeaturesByModuleId?moduleId='+id).pipe(tap((response) => response));
  }

  GetUserModulesFeatureByUserID(id): Observable<any> {
    return this.http.get(this.baseUrl +'/GetEmployeeByID?EmployeeID='+id).pipe(tap((response) => response));
  }
  GetUserGroupModulesFeaturesRolesByID(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetUserGroupModulesFeaturesRolesByID?TypeID=1&UserGroupID=1&DesignationID=1').pipe(tap((response) => response));
  }
  GetAllUnderWritingUserRuleLevel(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllUnderWritingUserRuleLevel' + id).pipe(tap((response) => response));
  }
  GetUserRoles(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetUserRoles' + id).pipe(tap((response) => response));
  }
  InsertPrivileges(data: any){
    console.log(data)
    return this.http.post(this.baseUrl + '/InsertPrivileges', data).pipe(tap((response) => response));
  }

  IsUserExistForDesignation(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/IsUserExistForDesignation' + id).pipe(tap((response) => response));
  }

  InsertOrUpdateGroupDetailsUserMap(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/InsertOrUpdateGroupDetailsUserMap' + data).pipe(tap((response) => response));
  }

  DeleteGroupDetailsUserMAp(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/DeleteGroupDetailsUserMAp' + id).pipe(tap((response) => response));
  }

  VerifyLogin(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/VerifyLogin?userName=' + data.userName + '&password=' + data.password).pipe(tap((response) => response));

  }
  getAllGender(): Observable<any> {
    return this.http.get(this.baseUrl + '/getAllGender').pipe(tap((response) => response));

  }
  IsUserEmployeeExist(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/IsUserEmployeeExist', data).pipe(tap((response) => response));
  }
  IsPasswordExists(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/IsPasswordExists', data).pipe(tap((response) => response));
  }
  UploadEmployeePoto(image: File): Observable<any> {
    const formData = new FormData();

    formData.append('image', image);

    return this.http.post(this.baseUrl +'/SaveUploadedImageFile', image).pipe(tap((response) => response));
  }
  LoggedOut(id: any): Observable<any> {
    console.log("id", id)
    return this.http.get(this.baseUrl + '/UpdateAdminIsLoggedOut?UserID=1').pipe(tap((response) => response));
  }
  InsertUserAndEmployeeDetails(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/InsertUserAndEmployeeDetails', data).pipe(tap((response) => response));
  }
  GetLineOfBusiness(): Observable<any>{
    return this.http.get(this.baseUrl + '/getLineOfBusinessCategory').pipe(tap((response) => response));
  }
  GetAllUserBySearch(data: any): Observable<any> {
    console.log(data)
    return this.http.post(this.baseUrl + '/GetAllUsersBySearch', data).pipe(tap((response) => response));
  }
  getAllLevel(): Observable<any> {
    console.log()
    return this.http.get(this.baseUrl + '/getAllLevel').pipe(tap((response) => response));
  }
  GetSearchUser(data: any): Observable<any> {
    console.log(data)
    return this.http.post(this.baseUrl + '/GetSearchUser', data).pipe(tap((response) => response));
  }
  changepwd(data: any): Observable<any> {
    console.log("data", data)
    return this.http.get(this.baseUrl + '/changePassword?UserID='+data.userID+'&UserName='+data.userName+'&NewPassword='+data.NewPassword+'&OldPassword='+data.OldPassword).pipe(tap((response) => response));
  }
  GetAllSalutation(): Observable<any> {
    return this.http.get(this.baseUrl + '/lookup/salutation/get').pipe(tap((response) => response));
  }
  getTimeZoneByID(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/getTimeZoneByID?TimeZoneID=' +id ).pipe(tap((response) => response));

  }

}

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MemberdeletionService {

 
  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

  postFile(a: any): Observable<any> {
    console.log(a);
    const url = this.baseUrl + '/MemberDeletionUpload';
      return this.http.post<any>(url, a);
  }

  deletionValidateExcelFile(a: any): Observable<any> {
    const url = this.baseUrl + '/deletionValidateExcelFile';

    const requestOptions: Object = {
      /* other options here */
      responseType: 'text'
    }

      return this.http.post<any>(url, a, requestOptions);
  }

  saveFile(a: any): Observable<any> {

    const url = this.baseUrl + '/SaveUploadedFileDeletion';
   
     return this.http.post<any>(url, a);
   }


}

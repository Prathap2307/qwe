export interface Grade {
	description: string;
	gradeId: number;
	organisationId: number;
    createdBy: number;
    createdOn: Date;
    deletedBy:  number;
    deletedOn:  Date;
}	
export class UserGroupPrivileges {
	lineOfBusiness: string;
	type: string;
	listOfUserGroup: string;
	moduleName: string;
}
export interface PolicyViewInformation {
    lineOfBusiness: string;
    groupID: number;
    groupName: string;
    masterPolicyID: number;
    agreementID: number;
    fromDate: Date;
    toDate: Date;
	ploicyHolderName: string;
	employeeID: number;
	certificateNumber: number;
	contactID: number;
}	

export interface PolicyTypeDropDown {
   PolicyTypeDropDownID: number;
   PolicyTypeDropDownText: string;
}
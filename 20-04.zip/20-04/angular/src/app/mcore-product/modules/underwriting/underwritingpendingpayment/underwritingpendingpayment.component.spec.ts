import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderwritingpendingpaymentComponent } from './underwritingpendingpayment.component';

describe('UnderwritingpendingpaymentComponent', () => {
  let component: UnderwritingpendingpaymentComponent;
  let fixture: ComponentFixture<UnderwritingpendingpaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnderwritingpendingpaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderwritingpendingpaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-underwritingpendingpayment',
  templateUrl: './underwritingpendingpayment.component.html',
  styleUrls: ['./underwritingpendingpayment.component.css']
})
export class UnderwritingpendingpaymentComponent implements OnInit {

  dataSource;
  elements: string;
  underwritingPaymentColumns = ['MasterPolicyNo','ApplicationNumber','EmployeeID','FirstName','DateofBirth','Age','UWExcessPremiumAmount']
  constructor() { }

  ngOnInit() {
  }

}

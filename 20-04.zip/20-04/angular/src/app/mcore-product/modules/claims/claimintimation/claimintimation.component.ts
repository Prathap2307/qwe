import { Component, OnInit, ViewChild } from '@angular/core';

import { ClaimassessmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/claimassessment.service';
import { ClaimintimationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/claimintimation.service';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-claimintimation',
  templateUrl: './claimintimation.component.html',
  styleUrls: ['./claimintimation.component.css']
})
export class ClaimintimationComponent implements OnInit {

  dummyObj: string;
  tableColumns1: string[] = ['Select', 'MASTERPOLICYNO', 'GROUPNAME', 'CERTIFICATEHOLDERNAME', 'CERTIFICATENO'];

  tableColumnsOne: string[] = ['delete', 'documentTypeDescription'];
  tableColumnsThree: string[] = ['claimNumber', 'assessor', 'assessorName', 'assessorBranch', 'assessorExpenses', 'assessmentRemarks'];

  constructor(private claimAssessmentService: ClaimassessmentService, private claimIntimationService: ClaimintimationService, private fb: FormBuilder) { }

  divAssessorRemarksDetails: boolean;
  divAssessmentHistory: boolean;

  divCoverageDetails: boolean;
  divTotalPayable: boolean;
  divAssessorSelection: Boolean;
  divProcesses: Boolean;

  TypeClaim: string;
  ClaimForm: FormGroup;
  relationshipObj: any;

  causeOfDeathObj: any;
  paymentModeObj: any;
  selectProcessObj: any = [];
  claimDetailsObj: any;
  get ClaimDetailsGroup() {
    return this.ClaimForm.get('ClaimDetailsGroup') as FormGroup;
  }

  get claimId() {
    return this.ClaimForm.get('claimId') as FormControl;
  }
  get BeneficiaryDetailsGroup() {
    return this.ClaimForm.get('BeneficiaryDetailsGroup') as FormGroup;
  }
  get MandatoryDocumentsGroup() {
    return this.ClaimForm.get('MandatoryDocumentsGroup') as FormGroup;
  }
  beneficiaryGridObj: any = [];
  documentGridObj: any = [];
  beneficiaryDataGridObj = new MatTableDataSource<any>(this.beneficiaryGridObj);
  documentDataGridObj = new MatTableDataSource<any>(this.documentGridObj);
  documentFilterGridObj: any;
  beneficiarySaveDataGridObj = new MatTableDataSource<any>();
  AccountingTaxMappingColumns: string[] = ['Edit', 'Delete', 'beneficiaryName', 'beneficiaryAccountHolderName', 'relationShipID', 'share', 'claimAmountShare'];
  popupDiv: boolean;
  popupBtnClose() {
    this.popupDiv = false;
  }
  popup_message_1: any;
  popup_message_2: any;
  popup_message_3: any;
  claimPopupMessage: any = "";
  allClaimsObj: any;
  allClaimFilteredObj: any;
  allClaimsDataGridObj = new MatTableDataSource<any>(this.allClaimsObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  documentTypeObj: any;


  ngOnInit() {

    this.createDocumentBtn = true;
    this.allClaimsDataGridObj = new MatTableDataSource<any>(this.allClaimsObj);

    this.ClaimForm = this.fb.group({
      claimId: [''],
      selectProcess: ['', Validators.required],
      ClaimDetailsGroup: this.fb.group({

        certificateNumber: [''],
        memberName: [''],
        companyName: [''],
        sumInsured: [''],
        plan: [''],
        dateofJoining: [''],

        dateofEvent: ['', Validators.required],
        claimIntimationDate: ['', Validators.required],
        locationofDeath: ['', Validators.required],
        causeOfDeath: ['', Validators.required],

        applicationId: ['']




      }),
      BeneficiaryDetailsGroup: this.fb.group({
        beneficiaryTempID: [''],
        beneficiaryID: [''],
        beneficiaryName: ['', Validators.required],
        beneficiaryAccountHolderName: ['', Validators.required],
        relationShipID: ['', Validators.required],
        iFSCCode: [''],
        accountType: [''],
        bankName: [''],
        accountNumber: [''],
        contactNo: [''],
        emailID: [''],
        share: ['', Validators.required],
        claimAmountShare: ['', Validators.required]
      }),
      MandatoryDocumentsGroup: this.fb.group({
        documentTempID: [''],
        documentType: ['', Validators.required],
        documentTypeDescription: ['']
      }),

    });

    this.getAllClaimDetails();
    this.getAllCauseOfDeath();
    this.getRelationshipDetails();
    this.getAllPaymentMode();

    this.popupDiv = false;
    this.createBeneficiaryBtn = true;
    this.beneficiaryDataGridObj = new MatTableDataSource<any>(this.beneficiaryGridObj);

    this.documentTypeObj = [{
      "id": 1,
      "description": "Aadhar Card"
    },
    {
      "id": 2,
      "description": "Death Certificate"
    }
      ,
    {
      "id": 3,
      "description": "Degree Certificate"
    }

    ];
  }
  getRelationshipDetails() {
    this.claimAssessmentService.getRelationshipDetails()
      .subscribe(data => {

        this.relationshipObj = data;
      });

  }
  getAllPaymentMode() {
    this.claimAssessmentService.getAllPaymentMode()
      .subscribe(data => {

        this.paymentModeObj = data;
      });

  }




  getAllClaimDetails() {

    let obj: Object = {

      "masterPolicyNumber": null,
      "certificateNumber": null,
      "firstName": null,
      "memberID": null

    }

    this.claimIntimationService.getAllClaimDetails(obj)
      .subscribe(data => {

        this.allClaimsObj = data;
        this.allClaimsDataGridObj = new MatTableDataSource<any>(this.allClaimsObj);
        this.allClaimsDataGridObj.data = this.allClaimsObj = data;
        this.allClaimsDataGridObj.paginator = this.paginator;
      });


  }
  getAllCauseOfDeath() {



    this.claimAssessmentService.getAllCauseOfDeath()
      .subscribe(data => {

        this.causeOfDeathObj = data;

      });


  }
  cfn(a) {
    console.log(a);
  }

  btngvEdit_Click(id) {

    this.allClaimFilteredObj = this.allClaimsObj.filter((unit) => unit.ROW_NUM == id);

    this.ClaimDetailsGroup.patchValue({


      certificateNumber: this.allClaimFilteredObj[0].CERTIFICATENO,
      memberName: this.allClaimFilteredObj[0].CERTIFICATEHOLDERNAME,
      companyName: this.allClaimFilteredObj[0].GROUPNAME,


      applicationId: this.allClaimFilteredObj[0].APPLICATIONID
    });
    // this.ClaimDetailsGroup.disable();

    this.ClaimDetailsGroup.get("certificateNumber").disable();
    this.ClaimDetailsGroup.get("memberName").disable();
    this.ClaimDetailsGroup.get("companyName").disable();
    this.ClaimDetailsGroup.get("sumInsured").disable();
    this.ClaimDetailsGroup.get("plan").disable();
    this.ClaimDetailsGroup.get("dateofJoining").disable();





    this.getClaimDetailsByClaimId(id);
    this.claimId.patchValue(
      this.allClaimFilteredObj[0].CLAIMID
    );

  }

  clearClaim() {



    this.ClaimDetailsGroup.reset({
      certificateNumber: '',
      memberName: '',
      companyName: '',
      sumInsured: '',
      plan: '',
      dateofJoining: '',

      dateofEvent: '',
      claimIntimationDate: '',
      locationofDeath: '',
      causeOfDeath: '',

      applicationId: ''
    });

    this.BeneficiaryDetailsGroup.reset({
      beneficiaryName: '',
      beneficiaryAccountHolderName: '',
      relationShipID: '',
      iFSCCode: '',
      accountType: '',
      bankName: '',
      accountNumber: '',
      contactNo: '',
      emailID: '',
      share: '',
      claimAmountShare: ''
    });


    this.ClaimForm.enable();
  }



  getClaimDetailsByClaimId(id) {


    console.log("claimid", id);
    this.claimAssessmentService.getClaimDetailsByClaimId(id)
      .subscribe(data => {

        this.claimDetailsObj = data;

      });


  }


  createSaveBeneficiary(i): any {

    return {

      claimId: this.claimId.value,
      beneficiaryName: this.beneficiaryGridObj[i].beneficiaryName,
      claimAmountShare: Number(this.beneficiaryGridObj[i].claimAmountShare),
      shares: Number(this.beneficiaryGridObj[i].share),
      emailID: this.beneficiaryGridObj[i].emailID,
      contactNo: this.beneficiaryGridObj[i].contactNo,
      accountNo: this.beneficiaryGridObj[i].accountNumber,
      bankName: this.beneficiaryGridObj[i].bankName,
      accountTypeID: this.beneficiaryGridObj[i].accountType,
      ifscCode: this.beneficiaryGridObj[i].iFSCCode,
      relationshipID: this.beneficiaryGridObj[i].relationShipID,
      accountHolderName: this.beneficiaryGridObj[i].beneficiaryAccountHolderName,
      createdBy: 1,
      createdOn: ""

    };
  }
  saveBtnClick() {

    //this.ClaimForm.markAllAsTouched();

    //  if (this.PlanInformationFormGroup.valid) {



    // this.ClaimForm.markAllAsTouched();
    this.ClaimDetailsGroup.markAllAsTouched();

    if (this.beneficiaryGridObj.length > 0) {




      this.beneficiarySaveDataGridObj.data = [];
      this.beneficiaryGridObj.forEach((fe) => {
        console.log(fe.beneficiaryTempID - 1);

        this.beneficiarySaveDataGridObj.data.push(this.createSaveBeneficiary(fe.beneficiaryTempID - 1));

      });

      console.log("cause of ", this.ClaimDetailsGroup.get("causeOfDeath").value);

      let createIntObj: Object =
      {
        "vID": 0,
        "vLineofBusinesId": 5,
        "vTypeID": 1,
        "vClaimID": 0,
        "vDateOfInitmation": new Date(this.ClaimDetailsGroup.get("claimIntimationDate").value),
        "vDateOfRegistration": "null",
        "vDateOfDeath": new Date(this.ClaimDetailsGroup.get("dateofEvent").value),
        "vCauseOfDeathID": this.ClaimDetailsGroup.get("causeOfDeath").value,
        "vDeathOfMemberOrSpouseID": 1,
        "vMPHPayment": 0,
        "vNomineePayment": 0,
        "vTotalAmount": 0,
        "vAccountNumber": "yes 222",
        "vInvoiceNumber": "in321",
        "vInvoiceDate": "null",
        "vDIR": "",
        "vCSIP": "",
        "vPincode": "",
        "vNomineePhoneNumber": "",
        "vDateOfLoss": "null",
        "vReservedAmount": 0,
        "vApplicationID": this.ClaimDetailsGroup.get("applicationId").value,
        "vGroupTypeID": 2,
        "vCreatedBy": 1,
        "vCreatedOn": "null",
        "vInsuredID": 25,
        "vClaimReportedBy": "null",
        "vRelationshipID": 2,
        "vDescription": "null",
        "vSalutationID": 10,
        "vPolicyNumber": "pol151",
        "vBeneficiaryName": "prathap",
        "vIsExistingInjuryDisablility": 1
      }
      console.log(createIntObj);
      this.claimIntimationService.createClaimIntimation(createIntObj)
        .subscribe(data => {

          this.getAllClaimDetails();

        });



      this.popup_message_1 = true;
      this.popupDiv = true;
      this.claimPopupMessage = "Claim intiated successfully";
      // if (this.ClaimForm.get('selectProcess').value == 1) {

      //   this.claimPopupMessage = "Claim '" + this.allClaimsObj[0].CLAIMNUMBER + "' Saved successfully";
      // } else {

      //   this.claimPopupMessage = "Claim '" + this.allClaimsObj[0].CLAIMNUMBER + "' is hold"
      // }



    } else {
      this.popup_message_2 = true;
      this.popupDiv = true;
      this.claimPopupMessage = "Please add the Beneficiary Details";
    }





  }
  documentFilterTypeObj: any;
  createNewDocument(id: number): any {


    let x = this.MandatoryDocumentsGroup.get("documentType").value;


    this.documentFilterTypeObj = this.documentTypeObj.filter((unit) => unit.id == x);

    return {
      documentTempID: id,
      documentType: this.MandatoryDocumentsGroup.get('documentType').value,
      documentTypeDescription: this.documentFilterTypeObj[0].description,
      image: "View Image"
    };
  }
  addDocumentFn() {
    this.MandatoryDocumentsGroup.markAllAsTouched();

    if (this.createDocumentBtn) {
      if (this.MandatoryDocumentsGroup.valid) {
        this.documentDataGridObj.data.push(this.createNewDocument(this.documentDataGridObj.data.length + 1));
        this.documentDataGridObj.filter = "";


      }
    } else {

      let id = this.MandatoryDocumentsGroup.get('documentTempID').value;




      this.documentDataGridObj.data.forEach((fe) => {
        if (fe.documentTempID == id) {


          fe.documentType = this.MandatoryDocumentsGroup.get('documentType').value;
          fe.documentTypeDescription = this.MandatoryDocumentsGroup.get('documentTypeDescription').value;


        }

      });


    }

    this.createDocumentBtn = true;
    this.clearDocumentFn();

  }

  createDocumentBtn: any;
  btngvDeleteDocument_Click(x) {
    this.documentDataGridObj.data = this.documentDataGridObj.data.filter((unit) => unit.documentTempID !== x);
  }
  btngvEditDocument_Click(x) {

    this.createDocumentBtn = false;
    // this.documentFilterTypeObj = this.documentTypeObj.filter((unit) => unit.id == x);



    this.documentFilterGridObj = this.documentDataGridObj.data.filter((unit) => unit.documentTempID == x);


    let documentTypeId = this.documentFilterGridObj[0].documentType;
    this.documentFilterTypeObj = this.documentTypeObj.filter((unit) => unit.id == documentTypeId);


    console.log(this.documentFilterGridObj[0].documentTypeDescription);
    this.MandatoryDocumentsGroup.patchValue({
      documentTempID: this.documentFilterGridObj[0].documentTempID,
      documentType: this.documentFilterGridObj[0].documentType,
      documentTypeDescription: this.documentFilterTypeObj[0].description
    });

  }
  clearDocumentFn() {
    console.log("clearDocumentFn");
    this.MandatoryDocumentsGroup.reset({
      documentTempID: '',
      documentType: '',
      documentTypeDescription: ''
    });
  }
  
  createBeneficiaryBtn: any;
  addBeneficiaryFn() {
    this.BeneficiaryDetailsGroup.markAllAsTouched();
    if (this.BeneficiaryDetailsGroup.valid) {

      if (this.createBeneficiaryBtn) {
        this.beneficiaryDataGridObj.data.push(this.createNewBeneficiary(this.beneficiaryDataGridObj.data.length + 1));
        this.beneficiaryDataGridObj.filter = "";
      } else {



        let id = this.BeneficiaryDetailsGroup.get('beneficiaryTempID').value;


        this.beneficiaryFilterGridObj = this.beneficiaryGridObj.filter((unit) => unit.beneficiaryTempID == id);

        this.beneficiaryGridObj.forEach((fe) => {
          if (fe.beneficiaryTempID == id) {


            fe.beneficiaryName = this.BeneficiaryDetailsGroup.get('beneficiaryName').value;
            fe.beneficiaryAccountHolderName = this.BeneficiaryDetailsGroup.get('beneficiaryAccountHolderName').value;

            fe.relationShipID = this.BeneficiaryDetailsGroup.get('relationShipID').value;
            fe.iFSCCode = this.BeneficiaryDetailsGroup.get('iFSCCode').value;
            fe.accountType = this.BeneficiaryDetailsGroup.get('accountType').value;
            fe.bankName = this.BeneficiaryDetailsGroup.get('bankName').value;
            fe.accountNumber = this.BeneficiaryDetailsGroup.get('accountNumber').value;
            fe.contactNo = this.BeneficiaryDetailsGroup.get('contactNo').value;
            fe.emailID = this.BeneficiaryDetailsGroup.get('emailID').value;
            fe.share = this.BeneficiaryDetailsGroup.get('share').value;
            fe.claimAmountShare = this.BeneficiaryDetailsGroup.get('claimAmountShare').value;


          }

        });




        //this.dataTaxMap.data = this.accountTaxMappingGridObj;


      }







      this.createBeneficiaryBtn = true;

      this.BeneficiaryDetailsGroup.reset({
        beneficiaryName: '',
        beneficiaryAccountHolderName: '',
        relationShipID: '',
        iFSCCode: '',
        accountType: '',
        bankName: '',
        accountNumber: '',
        contactNo: '',
        emailID: '',
        share: '',
        claimAmountShare: ''
      });



    }


  }

  btngvDeleteBeneficiary_Click(id) {
    this.beneficiaryDataGridObj.data = this.beneficiaryDataGridObj.data.filter((unit) => unit.beneficiaryTempID !== id);
  }
  beneficiaryFilterGridObj: any;
  btngvEditBeneficiary_Click(id) {
    this.createBeneficiaryBtn = false;
    this.beneficiaryFilterGridObj = this.beneficiaryGridObj.filter((unit) => unit.beneficiaryTempID == id);


    this.BeneficiaryDetailsGroup.patchValue({
      beneficiaryTempID: this.beneficiaryFilterGridObj[0].beneficiaryTempID,
      beneficiaryID: this.beneficiaryFilterGridObj[0].beneficiaryID,
      beneficiaryName: this.beneficiaryFilterGridObj[0].beneficiaryName,
      beneficiaryAccountHolderName: this.beneficiaryFilterGridObj[0].beneficiaryAccountHolderName,
      relationShipID: this.beneficiaryFilterGridObj[0].relationShipID,
      iFSCCode: this.beneficiaryFilterGridObj[0].iFSCCode,
      accountType: this.beneficiaryFilterGridObj[0].accountType,
      bankName: this.beneficiaryFilterGridObj[0].bankName,
      accountNumber: this.beneficiaryFilterGridObj[0].accountNumber,
      contactNo: this.beneficiaryFilterGridObj[0].contactNo,
      emailID: this.beneficiaryFilterGridObj[0].emailID,
      share: this.beneficiaryFilterGridObj[0].share,
      claimAmountShare: this.beneficiaryFilterGridObj[0].claimAmountShare
    });







  }
  createNewBeneficiary(id: number): any {
    return {
      beneficiaryTempID: id,

      beneficiaryID: this.BeneficiaryDetailsGroup.get('beneficiaryID').value,
      beneficiaryName: this.BeneficiaryDetailsGroup.get('beneficiaryName').value,
      beneficiaryAccountHolderName: this.BeneficiaryDetailsGroup.get('beneficiaryAccountHolderName').value,
      relationShipID: this.BeneficiaryDetailsGroup.get('relationShipID').value,
      iFSCCode: this.BeneficiaryDetailsGroup.get('iFSCCode').value,
      accountType: this.BeneficiaryDetailsGroup.get('accountType').value,
      bankName: this.BeneficiaryDetailsGroup.get('bankName').value,
      accountNumber: this.BeneficiaryDetailsGroup.get('accountNumber').value,
      contactNo: this.BeneficiaryDetailsGroup.get('contactNo').value,
      emailID: this.BeneficiaryDetailsGroup.get('emailID').value,
      share: this.BeneficiaryDetailsGroup.get('share').value,
      claimAmountShare: this.BeneficiaryDetailsGroup.get('claimAmountShare').value
    };
  }

  allowNumberFn(event) {
    const keyCode = event.keyCode;

    const excludedKeys = [8, 37, 39, 46];

    if (!((keyCode >= 48 && keyCode <= 57) ||
      (keyCode >= 96 && keyCode <= 105) ||
      (excludedKeys.includes(keyCode)))) {

      event.preventDefault();
    }
  }
}

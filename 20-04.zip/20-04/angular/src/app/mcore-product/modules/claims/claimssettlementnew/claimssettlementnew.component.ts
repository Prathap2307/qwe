import { Component, OnInit, ViewChild } from '@angular/core';
import { PaymentMode } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingglconfiguration';
import { AccountingglconfigurationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingglconfiguration.service';
import { Beneficiary, Claimssettlement } from 'src/app/mcore-product/mcore-shared/mcore-entity/claimssettlement';
import { ClaimssettlementService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/claimssettlement.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatTableDataSource, MatPaginator } from '@angular/material';



@Component({
  selector: 'app-claimssettlementnew',
  templateUrl: './claimssettlementnew.component.html',
  styleUrls: ['./claimssettlementnew.component.css']
})
export class ClaimssettlementnewComponent implements OnInit {

  dummyObj: string;
  PaymentModeName: any;
  BeneficiaryName: any;
  ClaimSettlementForm: FormGroup;
  ClaimSettlementFormSearch: FormGroup;
  ClaimSettlementFormAction: FormGroup;
  ClaimSettlementObj: Claimssettlement[];
  ClaimSettlementFiltterObj: Claimssettlement[];

  AccountPaymentModeObj: PaymentMode[];
  claimObj: Beneficiary[];
  tableColumns: string[] = ['Select', 'claimId', 'policyNumber', 'insuredName', 'claimApprovedDate', 'approvedAmount', 'amountPayable', 'status'];

  ClaimSettlementDataSource = new MatTableDataSource<Claimssettlement>(this.ClaimSettlementObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.ClaimSettlementDataSource.paginator = this.paginator;
  }

  constructor(
    private fb: FormBuilder,
    private accountGLConfigService: AccountingglconfigurationService,
    private claimSettlementService: ClaimssettlementService
  ) { }

  ngOnInit() {
    this.Validation();
    this.BeneficiaryDetails(1);
    this.getPaymentModeDetails();
  }
  Validation() {
    this.ClaimSettlementForm = this.fb.group({
      ClaimSettlementFormSearch: this.fb.group({
        searchClaimId: [''],
        searchPolicyNo: [''],
        searchFirstName: [''],
        searchLastName: [''],
        searchAgentCode: [''],
        searchServiceBranch: [''],
      }),
      ClaimSettlementFormAction: this.fb.group({
        ClaimId: [''],
        PolicyNo: [''],
      })
    });
  }

  getPaymentModeDetails() {
    this.accountGLConfigService.getPaymentModeDetails().subscribe(paymentNameVal => { this.AccountPaymentModeObj = paymentNameVal });
  }

  BeneficiaryDetails(claimId: number) {
    console.log(claimId);
    this.claimSettlementService.getBeneficiaryDetails(claimId).subscribe(ClaimVal => { this.claimObj = ClaimVal });
  }

  getAllClaimSettlementTableDataDetails(a, b, c, d, e, f) {
    this.claimSettlementService.getAllClaimSettlementDetails(a, b, c, d, e, f).subscribe(
      ClaimSettlementObj => {
        this.ClaimSettlementDataSource = new MatTableDataSource<Claimssettlement>(this.ClaimSettlementObj);
        this.ClaimSettlementDataSource.data = this.ClaimSettlementObj = ClaimSettlementObj;
        this.ClaimSettlementDataSource.paginator = this.paginator;
      })
  }

  btngvSelect_Click(ClaimId){
    // this.ClaimSettlementFiltterObj = this.pendingClaimsObj.filter((unit) => unit.CLAIMID == ClaimId);

    // this.ClaimDetailsGroup.patchValue({

    //   policyNumber: this.ClaimSettlementFiltterObj[0].POLICYNUMBER,
    //   claimNumber: this.ClaimSettlementFiltterObj[0].CLAIMNUMBER,
    //   policyHolderName: this.ClaimSettlementFiltterObj[0].POLICYHOLDERNAME,
    //   policyInceptionDate: [''],
    //   policyExpiryDate: ['']
    // });
  }
  onBtnSearchClaimSettlement() {
    let a = this.ClaimSettlementForm.get('ClaimSettlementFormSearch.searchClaimId').value;
    let b = this.ClaimSettlementForm.get('ClaimSettlementFormSearch.searchPolicyNo').value;
    let c = this.ClaimSettlementForm.get('ClaimSettlementFormSearch.searchFirstName').value;
    let d = this.ClaimSettlementForm.get('ClaimSettlementFormSearch.searchLastName').value;
    let e = this.ClaimSettlementForm.get('ClaimSettlementFormSearch.searchAgentCode').value;
    let f = this.ClaimSettlementForm.get('ClaimSettlementFormSearch.searchServiceBranch').value;
    console.log(a, b, c, d, e, f);
    if (a == "" || a == null) {
      a = 0;
    }
    if (b == "" || b == null) {
      b = 0;
    }
    if (c == "" || c == null) {
      c = 0;
    }
    if (d == "" || d == null) {
      d = 0;
    }
    if (e == "" || e == null) {
      e = 0;
    }
    if (f == "" || f == null) {
      f = 0;
    }
    console.log(a, b, c, d, e, f);
    this.getAllClaimSettlementTableDataDetails(a, b, c, d, e, f);
  }

  onBtnClearSearchClaimSettlement() {
    this.ClaimSettlementForm.reset();
    this.getAllClaimSettlementTableDataDetails(0, 0, 0, 0, 0, 0);
  }
}

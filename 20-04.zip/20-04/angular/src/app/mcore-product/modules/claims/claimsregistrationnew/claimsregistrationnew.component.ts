import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClaimassessmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/claimassessment.service';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material';
@Component({
  selector: 'app-claimsregistrationnew',
  templateUrl: './claimsregistrationnew.component.html',
  styleUrls: ['./claimsregistrationnew.component.css']
})
export class ClaimsregistrationnewComponent implements OnInit {

  dummyObj: string;
  tableColumns1: string[] = ['Select', 'CLAIMNUMBER', 'POLICYHOLDERNAME', 'POLICYNUMBER'];

  tableColumnsOne: string[] = ['delete', 'documentTypeDescription'];
  tableColumnsThree: string[] = ['claimNumber', 'assessor', 'assessorName', 'assessorBranch', 'assessorExpenses', 'assessmentRemarks'];

  constructor(private activatedRoute: ActivatedRoute, private claimAssessmentService: ClaimassessmentService, private fb: FormBuilder) { }

  divAssessorRemarksDetails: boolean;
  divAssessmentHistory: boolean;

  divCoverageDetails: boolean;
  divTotalPayable: boolean;
  divAssessorSelection: Boolean;
  divProcesses: Boolean;

  TypeClaim: string;
  ClaimForm: FormGroup;
  relationshipObj: any;

  causeOfDeathObj: any;
  paymentModeObj: any;
  selectProcessObj: any = [];
  claimDetailsObj: any;
  get ClaimDetailsGroup() {
    return this.ClaimForm.get('ClaimDetailsGroup') as FormGroup;
  }
  get TotalPayableGroup() {
    return this.ClaimForm.get('TotalPayableGroup') as FormGroup;
  }
  get expiryDetailsGroup() {
    return this.ClaimForm.get('expiryDetailsGroup') as FormGroup;
  }
  get claimId() {
    return this.ClaimForm.get('claimId') as FormControl;
  }
  get BeneficiaryDetailsGroup() {
    return this.ClaimForm.get('BeneficiaryDetailsGroup') as FormGroup;
  }
  get MandatoryDocumentsGroup() {
    return this.ClaimForm.get('MandatoryDocumentsGroup') as FormGroup;
  }
  beneficiaryGridObj: any = [];
  beneficiaryDataGridObj = new MatTableDataSource<any>(this.beneficiaryGridObj);
  beneficiarySaveDataGridObj = new MatTableDataSource<any>();
  AccountingTaxMappingColumns: string[] = ['Edit', 'Delete', 'beneficiaryName', 'beneficiaryAccountHolderName', 'relationShipID', 'share', 'claimAmountShare'];
  popupDiv: boolean;
  popupBtnClose() {
    this.popupDiv = false;
  }
  popup_message_1: any;
  popup_message_2: any;
  popup_message_3: any;
  claimPopupMessage: any = "";
  documentGridObj: any = [];
  documentDataGridObj = new MatTableDataSource<any>(this.documentGridObj);
  documentFilterGridObj: any;
  documentTypeObj: any;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  ngOnInit() {
    this.mainPageDiv = false;
    this.mainTableDiv = true;
    this.createDocumentBtn = true;
    this.popupDiv = false;
    this.createBeneficiaryBtn = true;
    this.beneficiaryDataGridObj = new MatTableDataSource<any>(this.beneficiaryGridObj);

    this.activatedRoute.queryParams.subscribe(params => {
      this.TypeClaim = params['Type'];
      this.claimsPageLoad();
    });

    this.ClaimForm = this.fb.group({
      claimId: [''],
      selectProcess: ['', Validators.required],
      ClaimDetailsGroup: this.fb.group({

        policyNumber: [''],
        claimNumber: [''],
        policyHolderName: [''],
        policyInceptionDate: [''],
        policyExpiryDate: [''],
        customerID: [''],
        plan: [''],
        profession: [''],
        sumInsured: [''],
        claimIntimationDate: [''],
        causeOfDeath: [''],
        dateOfEvent: [''],
      }),
      TotalPayableGroup: this.fb.group({
        amountPayable: ['']
      }),
      BeneficiaryDetailsGroup: this.fb.group({
        beneficiaryTempID: [''],
        beneficiaryID: [''],
        beneficiaryName: ['', Validators.required],
        beneficiaryAccountHolderName: ['', Validators.required],
        relationShipID: ['', Validators.required],
        iFSCCode: [''],
        accountType: [''],
        bankName: [''],
        accountNumber: [''],
        contactNo: [''],
        emailID: [''],
        share: ['', Validators.required],
        claimAmountShare: ['', Validators.required]
      }),
      expiryDetailsGroup: this.fb.group({
        dateOfLoss: [''],
        timeOfLoss: [''],
        placeOfLoss: [''],
        particularsOfLoss: [''],
        doctorNameandAddress: ['']
      }),
      MandatoryDocumentsGroup: this.fb.group({
        documentTempID: [''],
        documentType: ['', Validators.required],
        documentTypeDescription: ['']
      }),
    });

    this.getAllPendingClaims();
    this.getAllCauseOfDeath();
    this.getRelationshipDetails();
    this.getAllPaymentMode();

    this.documentTypeObj = [{
      "id": 1,
      "description": "Aadhar Card"
    },
    {
      "id": 2,
      "description": "Death Certificate"
    }
      ,
    {
      "id": 3,
      "description": "Degree Certificate"
    }

    ];
  }
  getRelationshipDetails() {
    this.claimAssessmentService.getRelationshipDetails()
      .subscribe(data => {

        this.relationshipObj = data;
      });

  }
  getAllPaymentMode() {
    this.claimAssessmentService.getAllPaymentMode()
      .subscribe(data => {

        this.paymentModeObj = data;
      });

  }
  claimsPageLoad() {

    this.mainPageDiv = false;
    this.mainTableDiv = true;
    if (this.TypeClaim.trim() == 'request') {
      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = false;
      this.divCoverageDetails = true;
      this.divTotalPayable = false;
      this.divAssessorSelection = true;
      this.divProcesses = true;


      this.selectProcessObj = [{
        "id": 1,
        "description": "Save"
      },
      {
        "id": 2,
        "description": "Hold"
      }];

    }

    if (this.TypeClaim.trim() == 'Assessment') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = false;
      this.divProcesses = true;

      this.selectProcessObj = [{
        "id": 1,
        "description": "Save"
      },
      {
        "id": 2,
        "description": "Hold"
      },
      {
        "id": 3,
        "description": "Reject"
      }];
    }

    if (this.TypeClaim.trim() == 'Approval') {
      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = false;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = true;
      this.divProcesses = true;

      this.selectProcessObj = [{
        "id": 1,
        "description": "Approve"
      },
      {
        "id": 2,
        "description": "Return"
      },
      {
        "id": 3,
        "description": "Reject"
      }];
    }

    if (this.TypeClaim.trim() == 'View') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = false;
      this.divProcesses = false;
    }

    if (this.TypeClaim.trim() == 'Reopen') {

      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = true;
      this.divProcesses = true;
    }
  }
  pendingClaimsObj: any;
  pendingClaimFilteredObj: any;
  getAllPendingClaimsTestFn() {
    //  this.pendingClaimsObj = [];
    this.pendingClaimsObj = [{
      "CONTACTNUMBER": "9812345678",
      "SHORTNAME": null,
      "CONTACTLASTNAME": "DURAI",
      "CUSTOMERGROUPID": "2000000001",
      "AGREEMENTENDDATE": null,
      "COREBUSINESS": "IT",
      "CONTACTFIRSTNAME": "DEEPAN",
      "GROUPID": 1,
      "GROUPNAME": "DEEPAN D12345",
      "AGREEMENTSTARTDATE": null,
      "SALUTATIONID": 1,
      "CONTACTMIDDLENAME": "SING",
      "MASTERPOLICYAGREEMENT": 0,
      "TNAME": "GRP",
      "FULLNAME": "DEEPANDURAI",
      "BRANCHID": 301
    }];
  }

  getAllPendingClaims() {



    this.claimAssessmentService.getAllPendingClaims(2, "hi", "a", "b", "dd", "ee", "we", 18, 2)
      .subscribe(data => {

        this.pendingClaimsObj = data;



      });

    //  this.getAllPendingClaimsTestFn();
  }


  getAllCauseOfDeath() {



    this.claimAssessmentService.getAllCauseOfDeath()
      .subscribe(data => {

        this.causeOfDeathObj = data;

      });

    //  this.getAllPendingClaimsTestFn();
  }
  cfn(a) {
    console.log(a);
  }
  mainPageDiv: any;
  mainTableDiv: any;
  btngvEdit_Click(id) {
    this.mainPageDiv = true;
    this.mainTableDiv = false;
    this.pendingClaimFilteredObj = this.pendingClaimsObj.filter((unit) => unit.CLAIMID == id);

    this.ClaimDetailsGroup.patchValue({

      policyNumber: this.pendingClaimFilteredObj[0].POLICYNUMBER,
      claimNumber: this.pendingClaimFilteredObj[0].CLAIMNUMBER,
      policyHolderName: this.pendingClaimFilteredObj[0].POLICYHOLDERNAME,
      policyInceptionDate: this.pendingClaimFilteredObj[0].POLICYSTARTDATE,
      policyExpiryDate: this.pendingClaimFilteredObj[0].policyExpiryDate,
      customerID: this.pendingClaimFilteredObj[0].CONTACTID,

      plan: this.pendingClaimFilteredObj[0].QWERTY,
      profession: this.pendingClaimFilteredObj[0].QWERTY,
      sumInsured: this.pendingClaimFilteredObj[0].QWERTY,
      claimIntimationDate: this.pendingClaimFilteredObj[0].QWERTY,
      causeOfDeath: this.pendingClaimFilteredObj[0].QWERTY,
      dateOfEvent: this.pendingClaimFilteredObj[0].QWERTY
    });
    this.ClaimDetailsGroup.disable();
    this.TotalPayableGroup.disable();
    if (this.TypeClaim.trim() != 'request') {
      this.expiryDetailsGroup.disable();
    }

    // this.ClaimDetailsGroup.get('policyNumber').disable();
    // this.ClaimDetailsGroup.get('claimID').disable();
    // this.ClaimDetailsGroup.get('policyHolderName').disable();

    this.getClaimDetailsByClaimId(id);
    this.claimId.patchValue(
      this.pendingClaimFilteredObj[0].CLAIMID
    );

  }

  clearClaim() {
    this.mainPageDiv = false;
    this.mainTableDiv = true;
    this.ClaimDetailsGroup.reset({
      policyNumber: '',
      claimNumber: '',
      policyHolderName: '',
      policyInceptionDate: '',
      policyExpiryDate: '',
      customerID: '',
      plan: '',
      profession: '',
      sumInsured: '',
      claimIntimationDate: '',
      causeOfDeath: '',
      dateOfEvent: ''
    });

    this.TotalPayableGroup.reset({
      amountPayable: ''
    });

    this.ClaimForm.reset({
      amountPayable: ''
    });

    this.ClaimForm.enable();
  }

  // TotalPayableGroup: this.fb.group({
  //   amountPayable: ['']
  // })

  ClaimDetailsByClaimIdPatch() {



    this.TotalPayableGroup.patchValue({
      amountPayable: this.claimDetailsObj[0].SUMINSURED
    });
    this.expiryDetailsGroup.patchValue({
      dateOfLoss: this.claimDetailsObj[0].DATEOFLOSS,
      timeOfLoss: this.claimDetailsObj[0].TIMEOFLOSS,
      placeOfLoss: this.claimDetailsObj[0].PLACEOFLOSS,
      particularsOfLoss: this.claimDetailsObj[0].PARTICULARSOFDEATH,
      doctorNameandAddress: this.claimDetailsObj[0].DOCTORNAMEANDADDRESS,
    });
  }
  getClaimDetailsByClaimId(id) {


    console.log("claimid", id);
    this.claimAssessmentService.getClaimDetailsByClaimId(id)
      .subscribe(data => {

        this.claimDetailsObj = data;

        this.claimDetailsObj.forEach((fe, index) => {


          this.beneficiaryDataGridObj.data.push(this.bindBeneficiary(this.beneficiaryDataGridObj.data.length + 1, index));

        });
        this.beneficiaryDataGridObj = new MatTableDataSource<any>(this.beneficiaryGridObj);
        this.beneficiaryDataGridObj.data = this.beneficiaryGridObj;
          this.beneficiaryDataGridObj.paginator = this.paginator;
        setTimeout(() => {    //<<<---    using ()=> syntax
         
        }, 3000);

        this.ClaimDetailsByClaimIdPatch();
      });


  }
  btngvDeleteBeneficiary_Click(id) {
    this.beneficiaryDataGridObj.data = this.beneficiaryDataGridObj.data.filter((unit) => unit.beneficiaryTempID !== id);
  }
  bindBeneficiary(id: number, i): any {
    // console.log(this.claimDetailsObj);
    return {
      beneficiaryTempID: id,

      beneficiaryID: this.claimDetailsObj[i].BENEFICIARYID,
      beneficiaryName: this.claimDetailsObj[i].BENEFICIARYNAME,
      beneficiaryAccountHolderName: '',
      relationShipID: '',
      iFSCCode: '',
      accountType: '',
      bankName: '',
      accountNumber: '',
      contactNo: '',
      emailID: '',
      share: '',
      claimAmountShare: ''
    };
  }

  createSaveBeneficiary(i): any {

    return {

      claimId: this.claimId.value,
      beneficiaryName: this.beneficiaryGridObj[i].beneficiaryName,
      claimAmountShare: Number(this.beneficiaryGridObj[i].claimAmountShare),
      shares: Number(this.beneficiaryGridObj[i].share),
      emailID: this.beneficiaryGridObj[i].emailID,
      contactNo: this.beneficiaryGridObj[i].contactNo,
      accountNo: this.beneficiaryGridObj[i].accountNumber,
      bankName: this.beneficiaryGridObj[i].bankName,
      accountTypeID: this.beneficiaryGridObj[i].accountType,
      ifscCode: this.beneficiaryGridObj[i].iFSCCode,
      relationshipID: this.beneficiaryGridObj[i].relationShipID,
      accountHolderName: this.beneficiaryGridObj[i].beneficiaryAccountHolderName,
      createdBy: 1,
      createdOn: ""

    };
  }
  saveBtnClick() {

    //this.ClaimForm.markAllAsTouched();

    //  if (this.PlanInformationFormGroup.valid) {


    if (this.TypeClaim.trim() == 'request') {
      // this.ClaimForm.markAllAsTouched();
      this.ClaimForm.get('selectProcess').markAsTouched();
      if (this.ClaimForm.get('selectProcess').valid) {

        if (this.beneficiaryGridObj.length > 0) {


          this.beneficiarySaveDataGridObj.data = [];
          this.beneficiaryGridObj.forEach((fe) => {
            console.log(fe.beneficiaryTempID - 1);

            this.beneficiarySaveDataGridObj.data.push(this.createSaveBeneficiary(fe.beneficiaryTempID - 1));

          });

          console.log(this.beneficiarySaveDataGridObj.data);

          this.claimAssessmentService.insertClaimsBeneficiary(this.beneficiarySaveDataGridObj.data)
            .subscribe(data => { });



          let claimRegisterObj: Object = {
            "vClaimID": this.claimId.value,
            "vDateOfLoss": new Date(this.expiryDetailsGroup.get('dateOfLoss').value),
            "vTimeOfLoss": this.expiryDetailsGroup.get('timeOfLoss').value,
            "vPlaceOfLoss": this.expiryDetailsGroup.get('placeOfLoss').value,
            "vParticularsOfDeath": this.expiryDetailsGroup.get('particularsOfLoss').value,
            "vDoctorNameAndAddress": this.expiryDetailsGroup.get('doctorNameandAddress').value,
            "vPartialAdvanceClaimPayment": 123,
            "vCreatedBy": 1,
            "vCreatedOn": new Date(),
            "vIsActive": 1,
            "vIsAdditionalDcoument": 1,
            "vStatusID": 20,
            "vAssessmentRemarks": "DONE"
          }
          console.log("insertOrUpdateClaimsRegistration");
          console.log(claimRegisterObj);
          this.claimAssessmentService.insertOrUpdateClaimsRegistration(claimRegisterObj)
            .subscribe(data => { });



          this.popup_message_1 = true;
          this.popupDiv = true;
          if (this.ClaimForm.get('selectProcess').value == 1) {

            this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' Saved successfully";
          } else {

            this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' is hold"
          }


          this.mainPageDiv = false;
          this.mainTableDiv = true;
        } else {
          this.popup_message_2 = true;
          this.popupDiv = true;
          this.claimPopupMessage = "Please add the Beneficiary Details";
        }

      }







    }

    if (this.TypeClaim.trim() == 'Assessment') {

      let obj: Object = {
        "vClaimID": this.claimId.value,
        "vIsDeductible": 123,
        "vDeductibleAmount": 100,
        "vAccountBalance": 1100,
        "vAmountDeducted": 2500,
        "vAmountAdded": 5000,
        "vTotalApprovedAmount": 350.00,
        "vTotalAmountPayable": this.TotalPayableGroup.get('amountPayable').value,
        "vPreviousBalanceAmount": 2500,
        "vProfessionalCharges": 25000,
        "vProfessionalServiceTax": 2600,
        "vTotalProfessionalCharges": 28123987,
        "vSurveyorIncidentalCharges": 25422
      }



      this.claimAssessmentService.updateClaimsPayableDetails(obj)
        .subscribe(data => { });

      this.mainPageDiv = false;
      this.mainTableDiv = true;

      this.popup_message_1 = true;
      this.popupDiv = true;
      if (this.ClaimForm.get('selectProcess').value == 1) {

        this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' Assessment completed successfully!";
      } else if (this.ClaimForm.get('selectProcess').value == 2) {

        this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' on hold!"
      } else if (this.ClaimForm.get('selectProcess').value == 3) {

        this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' is Rejected!"
      }


    }


    if (this.TypeClaim.trim() == 'Approval') {

      let obj: Object = {
        "vClaimID": this.claimId.value,
        "vIsDeductible": 123,
        "vDeductibleAmount": 100,
        "vAccountBalance": 1100,
        "vAmountDeducted": 2500,
        "vAmountAdded": 5000,
        "vTotalApprovedAmount": 350.00,
        "vTotalAmountPayable": this.TotalPayableGroup.get('amountPayable').value,
        "vPreviousBalanceAmount": 2500,
        "vProfessionalCharges": 25000,
        "vProfessionalServiceTax": 2600,
        "vTotalProfessionalCharges": 28123987,
        "vSurveyorIncidentalCharges": 25422
      }



      this.claimAssessmentService.updateClaimsPayableDetails(obj)
        .subscribe(data => { });

      this.mainPageDiv = false;
      this.mainTableDiv = true;
      this.popup_message_1 = true;
      this.popupDiv = true;
      if (this.ClaimForm.get('selectProcess').value == 1) {

        this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' has been Approved successfully!";
      } else if (this.ClaimForm.get('selectProcess').value == 2) {

        this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' is Returned!"
      } else if (this.ClaimForm.get('selectProcess').value == 3) {

        this.claimPopupMessage = "Claim '" + this.ClaimDetailsGroup.get('claimNumber').value + "' is Rejected!"
      }

    }

    // if (this.TypeClaim.trim() == 'Reopen') {
    //   let obj: Object = {
    //     "vClaimID": 1,
    //     "vDateOfLoss": 1,
    //     "vTimeOfLoss": 1,
    //     "vPlaceOfLoss": 1,
    //     "vParticularsOfDeath": 1,
    //     "vDoctorNameAndAddress": 1,
    //     "vPartialAdvanceClaimPayment": 1,
    //     "vCreatedBy": 1,
    //     "vCreatedOn": 1,
    //     "vIsActive": 1,
    //     "vIsAdditionalDcoument": 1,
    //     "vStatusID": 1,
    //     "vAssessmentRemarks": 1,
    //     "pApplicationID": 1,
    //     "pID": 1,
    //     "pCount": 1,
    //     "vResult": 1

    //   }



    //   this.claimAssessmentService.updateClaimsPayableDetails(obj)
    //     .subscribe(data => { });

    // }


    //    }

  }
  createBeneficiaryBtn: any;
  addBeneficiaryFn() {
    this.BeneficiaryDetailsGroup.markAllAsTouched();
    if (this.BeneficiaryDetailsGroup.valid) {

      if (this.createBeneficiaryBtn) {
        this.beneficiaryDataGridObj.data.push(this.createNewBeneficiary(this.beneficiaryDataGridObj.data.length + 1));
        this.beneficiaryDataGridObj.filter = "";
      } else {



        let id = this.BeneficiaryDetailsGroup.get('beneficiaryTempID').value;


        this.beneficiaryFilterGridObj = this.beneficiaryGridObj.filter((unit) => unit.beneficiaryTempID == id);

        this.beneficiaryGridObj.forEach((fe) => {
          if (fe.beneficiaryTempID == id) {


            fe.beneficiaryName = this.BeneficiaryDetailsGroup.get('beneficiaryName').value;
            fe.beneficiaryAccountHolderName = this.BeneficiaryDetailsGroup.get('beneficiaryAccountHolderName').value;

            fe.relationShipID = this.BeneficiaryDetailsGroup.get('relationShipID').value;
            fe.iFSCCode = this.BeneficiaryDetailsGroup.get('iFSCCode').value;
            fe.accountType = this.BeneficiaryDetailsGroup.get('accountType').value;
            fe.bankName = this.BeneficiaryDetailsGroup.get('bankName').value;
            fe.accountNumber = this.BeneficiaryDetailsGroup.get('accountNumber').value;
            fe.contactNo = this.BeneficiaryDetailsGroup.get('contactNo').value;
            fe.emailID = this.BeneficiaryDetailsGroup.get('emailID').value;
            fe.share = this.BeneficiaryDetailsGroup.get('share').value;
            fe.claimAmountShare = this.BeneficiaryDetailsGroup.get('claimAmountShare').value;


          }

        });




        //this.dataTaxMap.data = this.accountTaxMappingGridObj;


      }







      this.createBeneficiaryBtn = true;

      this.BeneficiaryDetailsGroup.reset({
        beneficiaryName: '',
        beneficiaryAccountHolderName: '',
        relationShipID: '',
        iFSCCode: '',
        accountType: '',
        bankName: '',
        accountNumber: '',
        contactNo: '',
        emailID: '',
        share: '',
        claimAmountShare: ''
      });



    }


  }


  beneficiaryFilterGridObj: any;
  btngvEditBeneficiary_Click(id) {
    this.createBeneficiaryBtn = false;
    this.beneficiaryFilterGridObj = this.beneficiaryGridObj.filter((unit) => unit.beneficiaryTempID == id);


    this.BeneficiaryDetailsGroup.patchValue({
      beneficiaryTempID: this.beneficiaryFilterGridObj[0].beneficiaryTempID,
      beneficiaryID: this.beneficiaryFilterGridObj[0].beneficiaryID,
      beneficiaryName: this.beneficiaryFilterGridObj[0].beneficiaryName,
      beneficiaryAccountHolderName: this.beneficiaryFilterGridObj[0].beneficiaryAccountHolderName,
      relationShipID: this.beneficiaryFilterGridObj[0].relationShipID,
      iFSCCode: this.beneficiaryFilterGridObj[0].iFSCCode,
      accountType: this.beneficiaryFilterGridObj[0].accountType,
      bankName: this.beneficiaryFilterGridObj[0].bankName,
      accountNumber: this.beneficiaryFilterGridObj[0].accountNumber,
      contactNo: this.beneficiaryFilterGridObj[0].contactNo,
      emailID: this.beneficiaryFilterGridObj[0].emailID,
      share: this.beneficiaryFilterGridObj[0].share,
      claimAmountShare: this.beneficiaryFilterGridObj[0].claimAmountShare
    });







  }
  createNewBeneficiary(id: number): any {
    return {
      beneficiaryTempID: id,

      beneficiaryID: this.BeneficiaryDetailsGroup.get('beneficiaryID').value,
      beneficiaryName: this.BeneficiaryDetailsGroup.get('beneficiaryName').value,
      beneficiaryAccountHolderName: this.BeneficiaryDetailsGroup.get('beneficiaryAccountHolderName').value,
      relationShipID: this.BeneficiaryDetailsGroup.get('relationShipID').value,
      iFSCCode: this.BeneficiaryDetailsGroup.get('iFSCCode').value,
      accountType: this.BeneficiaryDetailsGroup.get('accountType').value,
      bankName: this.BeneficiaryDetailsGroup.get('bankName').value,
      accountNumber: this.BeneficiaryDetailsGroup.get('accountNumber').value,
      contactNo: this.BeneficiaryDetailsGroup.get('contactNo').value,
      emailID: this.BeneficiaryDetailsGroup.get('emailID').value,
      share: this.BeneficiaryDetailsGroup.get('share').value,
      claimAmountShare: this.BeneficiaryDetailsGroup.get('claimAmountShare').value
    };
  }

  allowNumberFn(event) {
    const keyCode = event.keyCode;

    const excludedKeys = [8, 37, 39, 46];

    if (!((keyCode >= 48 && keyCode <= 57) ||
      (keyCode >= 96 && keyCode <= 105) ||
      (excludedKeys.includes(keyCode)))) {

      event.preventDefault();
    }
  }


  documentFilterTypeObj: any;
  createNewDocument(id: number): any {


    let x = this.MandatoryDocumentsGroup.get("documentType").value;


    this.documentFilterTypeObj = this.documentTypeObj.filter((unit) => unit.id == x);

    return {
      documentTempID: id,
      documentType: this.MandatoryDocumentsGroup.get('documentType').value,
      documentTypeDescription: this.documentFilterTypeObj[0].description,
      image: "View Image"
    };
  }
  addDocumentFn() {
    this.MandatoryDocumentsGroup.markAllAsTouched();

    if (this.createDocumentBtn) {
      if (this.MandatoryDocumentsGroup.valid) {
        this.documentDataGridObj.data.push(this.createNewDocument(this.documentDataGridObj.data.length + 1));
        this.documentDataGridObj.filter = "";


      }
    } else {

      let id = this.MandatoryDocumentsGroup.get('documentTempID').value;




      this.documentDataGridObj.data.forEach((fe) => {
        if (fe.documentTempID == id) {


          fe.documentType = this.MandatoryDocumentsGroup.get('documentType').value;
          fe.documentTypeDescription = this.MandatoryDocumentsGroup.get('documentTypeDescription').value;


        }

      });


    }

    this.createDocumentBtn = true;
    this.clearDocumentFn();

  }

  createDocumentBtn: any;
  btngvDeleteDocument_Click(x) {
    this.documentDataGridObj.data = this.documentDataGridObj.data.filter((unit) => unit.documentTempID !== x);
  }
  btngvEditDocument_Click(x) {

    this.createDocumentBtn = false;
    // this.documentFilterTypeObj = this.documentTypeObj.filter((unit) => unit.id == x);



    this.documentFilterGridObj = this.documentDataGridObj.data.filter((unit) => unit.documentTempID == x);


    let documentTypeId = this.documentFilterGridObj[0].documentType;
    this.documentFilterTypeObj = this.documentTypeObj.filter((unit) => unit.id == documentTypeId);


    console.log(this.documentFilterGridObj[0].documentTypeDescription);
    this.MandatoryDocumentsGroup.patchValue({
      documentTempID: this.documentFilterGridObj[0].documentTempID,
      documentType: this.documentFilterGridObj[0].documentType,
      documentTypeDescription: this.documentFilterTypeObj[0].description
    });

  }
  clearDocumentFn() {
    console.log("clearDocumentFn");
    this.MandatoryDocumentsGroup.reset({
      documentTempID: '',
      documentType: '',
      documentTypeDescription: ''
    });
  }

}

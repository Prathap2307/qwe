import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sumassuredendorsement',
  templateUrl: './sumassuredendorsement.component.html',
  styleUrls: ['./sumassuredendorsement.component.css']
})
export class SumassuredendorsementComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}

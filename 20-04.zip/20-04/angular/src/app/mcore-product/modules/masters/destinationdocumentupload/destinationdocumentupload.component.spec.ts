import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestinationdocumentuploadComponent } from './destinationdocumentupload.component';

describe('DestinationdocumentuploadComponent', () => {
  let component: DestinationdocumentuploadComponent;
  let fixture: ComponentFixture<DestinationdocumentuploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestinationdocumentuploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestinationdocumentuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

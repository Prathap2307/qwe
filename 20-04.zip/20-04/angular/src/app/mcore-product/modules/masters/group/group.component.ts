import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { GroupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/group.service';
@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
  GroupForm: FormGroup;
  GroupSearch: FormGroup;
  submitted: boolean;
  groupHeading: string = 'Add New - Group';
  saveBtnMode: boolean = true;
  textSaveBtn: string = 'Save';
  view: boolean = false;
  selectedPersonArray = [];

  isKeyPressed: boolean = false;
  Users =
    [
      {
        userID: '1', First_Name: 'Manufacturer', Last_Name: 'abcd', isActive: '2', Group_Name: 'abc', createdBy: "1",
        createdOn: "21-FEB-20 03.20.58.238000000 PM"
      },
      { id: '2', First_Name: 'Distributor ', Last_Name: 'abcd', isActive: '1', Group_Name: 'abc' },
      { id: '3', First_Name: 'Importer', Last_Name: 'abcd', isActive: '2', Group_Name: 'abc' },
      { id: '4', First_Name: 'Exporter', Last_Name: 'abcd', isActive: '2', Group_Name: 'abc' },
      { id: '5', First_Name: 'Stockist', Last_Name: 'abcd', isActive: '1', Group_Name: 'abc' },
      { id: '6', First_Name: 'Others', Last_Name: 'abcd', isActive: '1', Group_Name: 'abc' },
      { id: '7', First_Name: 'Manufacturer', Last_Name: 'abcd', isActive: '2', Group_Name: 'abc' },
      { id: '8', First_Name: 'Distributor ', Last_Name: 'abcd', isActive: '1', Group_Name: 'abc' },
      { id: '9', First_Name: 'Importer', Last_Name: 'abcd', isActive: '2', Group_Name: 'abc' }
    ]
  FinalSelectedArray = [];
  display: string;
  allgroup: any[];
  getallgroup: any[];
  config: { itemsPerPage: number; currentPage: number; totalItems: number; };
  exist: boolean;
  success: boolean;
  msg: any;
  grpobj: any;
  checked: boolean = true;
  config1: { itemsPerPage: number; currentPage: number; totalItems: number; };
  groupID: any;
  organisationID: string;
  constructor(private fb: FormBuilder, private GroupService: GroupService) { }

  ngOnInit() {
    this.organisationID=localStorage.getItem('organisationID')
    let data = {
      "OrganisationID":  this.organisationID,
      "Description": ""
    }
    this.GetAllGroup(data)
    this.GetAllUsersGroupByOrganisationID()
    this.GroupSearch = this.fb.group({
      id: [''],
      groupName: ['',],
    })
    this.forminit()
  }
  forminit() {
    this.GroupForm = this.fb.group({
      groupID: [],
      groupName: ['', Validators.required],
      isActive: [1,],
      userModalList: this.fb.array([]),
      createdBy: [1,],
      createdOn: [null,]
    })
  }

  get f() { return this.GroupForm.controls; }

  onBtnSaveClick() {
    this.GroupForm.value["organisationID"] =  this.organisationID
    this.FinalSelectedArray = []
    this.submitted = true
    console.log(this.GroupForm.value)
    for (let i = 0; i < this.selectedPersonArray.length; i++) {
      if (this.selectedPersonArray[i]["isselected"] == true) {
        this.FinalSelectedArray.push(this.selectedPersonArray[i]);
      }
    }
    this.FinalSelectedArray = this.FinalSelectedArray.filter((id, i, a) => i === a.indexOf(id))

    console.log(this.selectedPersonArray)
    console.log(this.FinalSelectedArray)
    if (this.GroupForm.valid) {

      this.GroupForm.value["userModalList"] = this.FinalSelectedArray
      console.log(this.GroupForm.value)
      this.GroupService.InsertOrUpdateGroup(this.GroupForm.value)
        .subscribe(result => {
          console.log(result)
          if (result.data.error) {
            this.exist = true
            this.openModalDialog1(result.data.error)
          } else {
            if (result.data.GroupID > 0) {
              this.success = true
              if (this.textSaveBtn === 'Update') {
                let msg = 'Group Updated Successufully'
                this.openModalDialog1(msg)
              }
              else {
                let msg = 'Group Added Successufully'
                this.openModalDialog1(msg)
              }

              let data = {
                "OrganisationID":  this.organisationID,
                "Description": ""
              }
              this.GetAllGroup(data)
              this.cancel()
            }
          }

        })

    }
  }
  setIdDelete(id) {
    this.groupID = id

  }
  delete() {
    this.GroupService.DeleteGroup(this.groupID)
      .subscribe(result => {
        console.log(result)
        let data = {
          "OrganisationID":  this.organisationID,
          "Description": ""
        }
        this.GetAllGroup(data)
      });

  }
  GetAllUsersGroupByOrganisationID() {
    this.GroupService.GetAllUsersGroupByOrganisationID( this.organisationID)
      .subscribe(result => {
        console.log(result)
        this.allgroup = result.data
        if (this.allgroup) {
          this.config1 = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allgroup.length
          }
        }
        console.log(this.allgroup)
        if (this.allgroup && this.allgroup.length > 0) {
          this.selectedPersonArray = this.allgroup
          console.log(this.selectedPersonArray)
          for (let i = 0; i < this.allgroup.length; i++) {
            this.selectedPersonArray["isselected"] = false
          }
        }
      })
  }
  GetAllGroup(data:any) {
    this.GroupService.GetAllGroupsByOrg(data)
      .subscribe(result => {
        console.log(result)
        this.getallgroup = result.data
        if (this.getallgroup) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.getallgroup.length
          }
        }
      })
  }

  GetGroupByGroupID(data: any) {
    this.GroupService.GetGroupByGroupID(data)
      .subscribe(result => {
        console.log(result)
        this.grpobj = result.data
        if (this.grpobj) {
          this.GroupForm = this.fb.group({
            groupID: [{ value: this.grpobj.groupID, disabled: false },],
            groupName: [{ value: this.grpobj.groupName, disabled: false }, Validators.required],
            // isActive: [{ value: this.grpobj.isActive, disabled: false }, ,],

          })
          if (this.grpobj.userModalList) {
            this.selectedPersonArray = this.grpobj.userModalList
          }
          console.log(this.selectedPersonArray)
          for (let i = 0; i < this.grpobj.userModalList.length; i++) {
            if (this.grpobj.userModalList[i]["selected"] === 1) {
              this.grpobj.userModalList[i]["isselected"] = true
            }
            else {
              this.grpobj.userModalList[i]["isselected"] = false
            }

          }
          this.allgroup = this.selectedPersonArray
          if (this.allgroup) {
            this.config1 = {
              itemsPerPage: 10,
              currentPage: 1,
              totalItems: this.allgroup.length
            }
          }
        }


      })
  }

  search() {
    let data = {
      "OrganisationID":  this.organisationID,
      "Description": this.GroupSearch.value["groupName"]
    }
    this.GetAllGroup(data)
    console.log(this.GroupSearch.value)

  }

  clearsearch() {
    this.GroupSearch.reset()
    let data = {
      "OrganisationID":  this.organisationID,
      "Description": ""
    }
    this.GetAllGroup(data)
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  pageChanged1(event: number) {
    this.config1.currentPage = event;
  }
  btngEdit_Click(data) {
    console.log(data)
    this.view = false
    this.groupHeading = 'Edit - Group';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update'
    this.GetGroupByGroupID(data)
  }
  btngView_Click(data) {
    this.groupHeading = 'View - Group';
    this.view = true
    this.saveBtnMode = false;
    this.GetGroupByGroupID(data)
  }
  Search() {
    console.log(this.GroupSearch.value)

  }
  cancel() {
    this.GroupForm.reset()
    this.forminit()
    for (let i = 0; i < this.allgroup.length; i++) {
      this.allgroup[i]["isselected"] = false
    }
    console.log(this.submitted)
    this.submitted = false
    this.groupHeading = 'Add New - Group';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }

  }

  addThisPersonToArray(person) {
    console.log(person)
    person.isselected = !person.isselected
  }

  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }
  openModalDialog1(msg) {
    this.msg = msg
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.exist = false
    this.success = false
  }
}

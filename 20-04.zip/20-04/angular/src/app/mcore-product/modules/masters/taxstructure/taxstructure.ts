export class Taxstructure{
    taxstructurename: string;
    description: string;
    fromdate: Date;
    todate:Date;
    exemptedin: string;
    name: string;
    basedon: string;
    mode: string;
    value:string;
    rownumber:number;
}
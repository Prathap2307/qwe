import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
@Component({
  selector: 'app-fsub-channel',
  templateUrl: './fsub-channel.component.html',
  styleUrls: ['./fsub-channel.component.css']
})
export class FsubChannelComponent implements OnInit {
  SubChannelForm: FormGroup;
  submitted: boolean;
  SubchannelHeading: string = 'Add New - Sub Channel';
  saveBtnMode: boolean = true;
  textSaveBtn: string = 'Save';
  SearchSubChannel: FormGroup;
  checked = true
  view: boolean = false;
  isEntity: boolean = false;
  isblanket: boolean = false;
  isCriterion: boolean = true;
  isDeposit: boolean = false;
  display: string = 'none';
  branch = ["kolkata", "mumbai"]
  BRANCH = [

    { branchID: '23', Name: 'Bangalore' },
    { branchID: '3', Name: 'Kolkata' },
    { branchID: '4', Name: 'Mumbai' }
  ]

  dummyObj =
    [

      { Id: '2', Name: 'Agent' },

    ]

  private defaultSelected = 0
  private selection: number
  subChannelFilteredObj: any;
  allchannel: any;
  allsubchannel: any;
  id: any;
  allbranch: any;
  success: boolean;
  transaction: string;
  exist: boolean;
  present: any;
  fail: boolean;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  subchannelID: any;
  organisationID: string;
  branchError: boolean;

  constructor(private fb: FormBuilder, private BranchService: BranchService, private FchannelService: FchannelService, ) { }

  ngOnInit() {
    this.getallchannel()
    this.organisationID = localStorage.getItem('organisationID')
    this.getallsubchannel()
    this.getallbranches()
    this.SearchSubChannel = this.fb.group({
      ChannelName: ['',],
      ChannelCode: ['',],
    })

    this.SubchannnelformFunction()

  }


  SubchannnelformFunction() {
    this.SubChannelForm = this.fb.group({
      SubChannelID: [''],
      ChannelName: ['', Validators.required],
      ChannelCode: ['', Validators.required],
      MainChannelID: ['', Validators.required],
      IsPhysicalEntry: [0],
      IsCDAccount: [0],
      // branchid: [''],
      BranchID: this.fb.array([]),
      PolicyHolderCode: [''],
      TriggerLimit: [''],
      IsBlanket: [0],
      CreatedBy: ['',],
      CreatedOn: ['',]

    })

    this.IsPhysicalEntry()
    this.IsCDAccount()


  }
  IsPhysicalEntry() {
    this.SubChannelForm.get('IsPhysicalEntry').valueChanges.subscribe((data: number) => {
      console.log(data)
      this.onchangeIsPhysicalentry(data);
      if (data === 0) {
        console.log(data)
        let abc = {
          IsCDAccount: 0,
          IsBlanket: 0,
          PolicyHolderCode: [''],
          TriggerLimit: [''],
          branchid: [''],
        }
        this.SubChannelForm.patchValue({
          IsCDAccount: 0,
        })
      }
    });

  }
  IsCDAccount() {
    this.SubChannelForm.get('IsCDAccount').valueChanges.subscribe((data: number) => {
      this.onchangeISCDACCOUNT(data);
      if (data === 0) {
        console.log(data)
        let abc = {
          PolicyHolderCode: [''],
          TriggerLimit: [''],
          IsBlanket: 0,
        }
        this.SubChannelForm.patchValue(abc)
      }
    });
  }
  onchangeIsPhysicalentry(selected: any) {
    this.isDeposit = false

    console.log(selected);
    // const Branchid = this.SubChannelForm.get('branchid')
    // this.getallbranches()

    if (selected === 1) {
      this.submitted = false

      // Branchid.setValidators(Validators.required);

      this.show();
    }
    else {
      // Branchid.clearValidators();

      this.hide()
    }
    // Branchid.updateValueAndValidity();



  }


  onchangeISCDACCOUNT(selected: any) {
    const TRIGGERLIMIT = this.SubChannelForm.get('TriggerLimit')
    const POLICYHOLDERCODE = this.SubChannelForm.get('PolicyHolderCode')
    // const ISBLANKET =this.SubChannelForm.get('ISBLANKET')

    if (selected === 1) {

      this.submitted = false

      TRIGGERLIMIT.setValidators(Validators.required);
      POLICYHOLDERCODE.setValidators([Validators.required, Validators.minLength(4), Validators.maxLength(4)]);

      this.showDeposit()
    }
    else {

      POLICYHOLDERCODE.clearValidators();
      TRIGGERLIMIT.clearValidators();

      this.hideDeposit()
    }

    TRIGGERLIMIT.updateValueAndValidity();
    POLICYHOLDERCODE.updateValueAndValidity();


  }

  get f() { return this.SubChannelForm.controls; }
  // IsSubChannelExist(data: any) {
  //   this.FchannelService.IsSubChannelExist(this.SubChannelForm.value)
  //     .subscribe(result => {
  //       console.log(result)
  //     });
  // }
  IsSubChannelExist(data: any) {
    this.FchannelService.IsSubChannelExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === "NOTEXIST") {
          this.FchannelService.addfsubchannel(this.SubChannelForm.value)
            .subscribe(result => {
              console.log(result)
              if (result.data.SubChannelId > 0) {
                this.success = true
                if (this.textSaveBtn === 'Save') {
                  this.transaction = "Created"
                }
                else {
                  this.transaction = "Updated"
                }
                this.getallsubchannel()
                this.openModalDialog()
              }
              else {
                this.fail = true
                this.openModalDialog()
                this.getallsubchannel()
              }
              this.cancel()
            });
        }
        else {
          this.exist = true
          this.present = result.data
          this.openModalDialog()
        }

      });
  }
  onCheckChange(event: any) {
    console.log(event)
    console.log(event.source.value)
    if (event.checked) {
      this.branchError=false
      for (let i = 0; i < this.allbranch.length; i++) {
        if (event.source.value.branchId === this.allbranch[i].branchId) {
          this.allbranch[i]["checked"] = true
        }
      }
    }
    else {
      for (let i = 0; i < this.allbranch.length; i++) {
        if (event.source.value.branchId === this.allbranch[i].branchId) {
          this.allbranch[i]["checked"] = false
        }
      }
    }
    console.log(this.allbranch)

  }

  onBtnSaveClick() {

    this.submitted = true
    this.SubChannelForm.value['BranchID'] = []
    for (let i = 0; i < this.allbranch.length; i++) {
      if (this.allbranch[i]["checked"] === true) {
        console.log(this.allbranch[i])
        this.SubChannelForm.value['BranchID'].push(this.allbranch[i]);
      }
    }
    if(this.isEntity && this.SubChannelForm.value['BranchID'].length==0 ){
      this.branchError=true
    }
    else{
    console.log(this.SubChannelForm.value['BranchID'].length)
    console.log(this.SubChannelForm.controls)
    if (this.SubChannelForm.valid) {
      console.log(this.SubChannelForm.value)
      this.SubChannelForm.value['CategroyID'] = 1
      this.SubChannelForm.value['CreatedBy'] = 1
      this.IsSubChannelExist(this.SubChannelForm.value)
    }
  }

  }
  getallchannel() {
    this.FchannelService.GetAllMainChannel()
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        console.log(this.allchannel)
      });
  }
  search() {
    this.FchannelService.GetAllSubChannel(this.SearchSubChannel.value)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        console.log(this.allsubchannel)
      });
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  getallsubchannel() {
    let abc = {
      "ChannelName": "",
      "ChannelCode": ""
    }

    this.FchannelService.GetAllSubChannel(abc)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        if (this.allsubchannel && this.allsubchannel.length > 0) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allsubchannel.length
          }
        }
        console.log(this.allsubchannel)
      });
  }
  getallbranches() {
    let branch = {
      "OrganisationID": this.organisationID,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
        if (this.allbranch) {
          console.log(this.allbranch)
          for (let k = 0; k < this.allbranch.length; k++) {
            this.allbranch[k]["checked"] = false

          }
        }
      }
      );
  }
  btngEdit_Click(a) {

    this.SubchannelHeading = 'Edit - Sub Channel';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.id = a
    this.getSubChannelById(a)
  }
  btngView_Click(a) {
    this.SubchannelHeading = 'View - Sub Channel';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.getSubChannelById(a)
  }
  cancel() {
    this.SubChannelForm.reset()
    this.getallbranches()
    this.SubchannnelformFunction()
    console.log(this.submitted)
    this.submitted = false
    this.SubchannelHeading = 'Add New - Sub Channel';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }

  }
  setIdDelete(id) {
    this.subchannelID = id

  }
  deleteSubchannel() {

    this.FchannelService.DeleteSubChannel(this.subchannelID)
      .subscribe(result => {
        console.log(result)
        this.getallsubchannel()
      });
  }

  getSubChannelById(a) {
    this.FchannelService.GetSubChannelById(a)
      .subscribe(result => {
        console.log(result)
        this.subChannelFilteredObj = result.data[0]
        console.log(this.subChannelFilteredObj)
        if (this.subChannelFilteredObj) {
          this.SubChannelForm = this.fb.group({
            SubChannelID: [{ value: this.subChannelFilteredObj.subChannelID, disabled: false }],
            ChannelName: [{ value: this.subChannelFilteredObj.channelName, disabled: false }, Validators.required],
            ChannelCode: [{ value: this.subChannelFilteredObj.channelCode, disabled: false }, Validators.required],
            MainChannelID: [{ value: this.subChannelFilteredObj.mainChannelID, disabled: false }, Validators.required],
            IsPhysicalEntry: [{ value: this.subChannelFilteredObj.isPhysicalEntry, disabled: false }],
            IsCDAccount: [{ value: this.subChannelFilteredObj.isCDAccount, disabled: false }],
            branchid: ['',],
            PolicyHolderCode: [{ value: this.subChannelFilteredObj.policyHolderCode, disabled: false }],
            TriggerLimit: [{ value: this.subChannelFilteredObj.triggerLimit, disabled: false }],
            IsBlanket: [{ value: this.subChannelFilteredObj.isBlanket, disabled: false }],
          })
          if (this.subChannelFilteredObj.branchModalList) {
            for (let i = 0; i < this.subChannelFilteredObj.branchModalList.length; i++) {
              for (let k = 0; k < this.allbranch.length; k++) {
                if (this.subChannelFilteredObj.branchModalList[i]['branchId'] === this.allbranch[k]["branchId"]) {
                  console.log(this.allbranch[k])
                  console.log(true)
                  this.allbranch[k].checked = true

                }
              }
            }
          }
          if (this.subChannelFilteredObj.isPhysicalEntry) {
            this.onchangeIsPhysicalentry(this.subChannelFilteredObj.isPhysicalEntry)
          }
          if (this.subChannelFilteredObj.isCDAccount) {
            this.onchangeISCDACCOUNT(this.subChannelFilteredObj.isCDAccount);
          }
          this.SubChannelForm.get('IsCDAccount').valueChanges.subscribe((data: string) => {
            this.onchangeISCDACCOUNT(data);

          });
          this.SubChannelForm.get('IsPhysicalEntry').valueChanges.subscribe((data: string) => {
            console.log(data)
            this.onchangeIsPhysicalentry(data);

          });

          console.log(this.SubChannelForm.value)
        }
      })
  }
  show() {
    this.isEntity = true
    console.log(this.isEntity)
  }
  hide() {
    this.isEntity = false
  }
  showDeposit() {
    this.isDeposit = true
    console.log(this.isEntity)
  }
  hideDeposit() {
    this.isDeposit = false
  }
  cancelSearch() {
    this.SearchSubChannel.reset()
    this.getallsubchannel()
  }
  CodeValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 3) {
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }

    }
  }
  shortnumValidate(event: any) {

    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 15) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }

  nameCodeValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if ((keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)
        event.preventDefault();
      }
    }
  }

  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.exist = false
    this.success = false
    this.fail = false
  }
  get branches() {
    if (this.SubChannelForm.controls['BranchID'].hasError('required')) {
      return 'Please Select Branch.';
    }
  }

  get trigger() {
    if (this.SubChannelForm.controls['TriggerLimit'].hasError('required')) {
      return 'Please enter the TRIGGER LIMIT.';
    }
  }

  get codeerror() {
    if (this.SubChannelForm.controls['PolicyHolderCode'].hasError('minlength') || this.SubChannelForm.controls['PolicyHolderCode'].hasError('maxlength')) {
      return 'Please enter the 4 digits.';
    }
  }
}

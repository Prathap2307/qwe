import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Product, ProductCategory } from 'src/app/mcore-product/mcore-shared/mcore-entity/product';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { TooltipPosition } from '@angular/material/tooltip';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  // Product Variable Declaration
  createProduct: boolean;
  fieldDisable: boolean;
  Categoryname: string;
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  productObj: Product[];
  productObjs: [];
  ProductCategoryObj: ProductCategory[];
  productFilteredObj: Product[] = [];
  productColumns: string[] = ['View', 'Edit', 'Delete', 'planName', 'shortName'];
  dropDownMode: Boolean;
  productForm: FormGroup;
  productFormAction: FormGroup;
  productHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  productSource = new MatTableDataSource<Product>(this.productObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  lob: any;
  deleteid: any;
  userId: any;
  view: boolean;
  branchFilteredObj:any
  // config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  ngAfterViewInit() {
    this.productSource.paginator = this.paginator;
  }
  AlreadyProductNameExist: number;
  AlreadyEditProductNameExist: number;
  constructor(
    private user: UserService,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private productService: ProductService,
    private changeDetectorRefs: ChangeDetectorRef
  ) { }
  disableEvent(e) {
    e.preventDefault();
    return false;
  }
  RestrictSplChar(event) {
    let k;
    k = event.charCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
  }
  ngOnInit() {
    this.createProduct = true;
    this.productHeading = 'Add New - Product';
    this.btnSaveText = 'Save';
    this.userId = JSON.parse(localStorage.getItem('userID'));
    this.getAllCategory(1);
    this.getLOb();


    this.getProductDetails();
    this.ValidateProductDataForm();
    this.ngAfterViewInit();
  }
  getAllCategory(lobId: number) {
    console.log(lobId)
    this.productService.GetAllCategory(lobId).subscribe(categoryNameVal => this.ProductCategoryObj = categoryNameVal)
  }

  getLOb() {


    this.user.GetLineOfBusiness()
      .subscribe(result => {
        console.log(result)
        this.lob = result.data
        console.log(this.lob)
      })
  }
  // Search Events Product
  onBtnSearchProductClick() {
    this.getProductBySearch();
  }
  onBtnSearchClearProductClick() {
    this.productForm.reset();
    this.getProductDetails();
  }
  // Save Events Product
  onBtnSaveProductClick() {
    //this.SaveProductDetailData();
   
    if (this.createProduct) {
      this.productForm.get('productFormAction.planId').patchValue('');
      this.AlreadyProductNameExist = 0;
      let desc = this.productForm.get('productFormAction.planName').value;
      // this.productObj.forEach((fe) => {
      //   if (fe.planName == desc) {
      //     this.AlreadyProductNameExist = 1;
      //   }
      // });
      if (this.productObj) {
        let arrlength = this.productObj.length;
        for (let i = 0; i < arrlength; i++) {
          if (this.productObj[i]['planName'] == desc) {
            this.AlreadyProductNameExist = 1;
          }

        }
      }

      if (this.AlreadyProductNameExist == 0) {
        this.SaveProductDetailData();
      }
      else {
        console.log('else test');
        console.log(this.AlreadyProductNameExist);
        if (this.AlreadyProductNameExist == 1) {
          window.alert('Product Name already exists');
          this.ClearProductDetails();
          return false;
        }
      }
    }
    else {
      let id = this.productForm.get('productFormAction.planId').value;
      let descEdit = this.productForm.get('productFormAction.planName').value;
      this.AlreadyEditProductNameExist = 0;

      let arrlength = this.productObj.length;
      for (let i = 0; i < arrlength; i++) {
        if(this.productObj[i]['planId']!= id)
        {
         
       
        if (this.productObj[i]['planName'] == descEdit) {
          this.AlreadyProductNameExist = 1;
        }
      }

      }


      // this.productObj.forEach((fe) => {
      //   if (fe.planId != id) {
      //     if (fe.planName == descEdit) {
      //       this.AlreadyEditProductNameExist = 1;
      //     }
      //   }
      // });
      if (this.AlreadyEditProductNameExist == 0) {
        this.SaveProductDetailData();
      }
      else {
        window.alert('Product Name already exists');
        this.ClearProductDetails();
      }
    }
  }
  onBtnClearProductClick() {
    this.ClearProductDetails();
  }
  // Grid View Button Events
  btngvView_Click(a) {
    this.productHeading = 'View - Product';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.productFilteredObj = this.productObj.filter((unit) => unit.planId == a);
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: this.productFilteredObj[0].planId,
        planName: this.productFilteredObj[0].planName,
        shortName: this.productFilteredObj[0].shortName,
        category: this.productFilteredObj[0].category,
        productTypeId: this.productFilteredObj[0].productTypeId,
        // description: this.productFilteredObj[0].description,
        createdBy: this.productFilteredObj[0].createdBy,
        createdOn: this.productFilteredObj[0].createdOn,
        isActive: this.productFilteredObj[0].isActive,
      })
    });
  }
  // Grid Edit Button Events
  btngvEdit_Click(a) {
    this.createProduct = false;
    this.productHeading = 'Edit - Product';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.productFilteredObj = this.productObj.filter((unit) => unit.planId == a);
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: this.productFilteredObj[0].planId,
        planName: this.productFilteredObj[0].planName,
        shortName: this.productFilteredObj[0].shortName,
        category: this.productFilteredObj[0].category,
        productTypeId: this.productFilteredObj[0].productTypeId,
        // description: this.productFilteredObj[0].description,
        createdBy: this.productFilteredObj[0].createdBy,
        createdOn: this.productFilteredObj[0].createdOn,
        isActive: this.productFilteredObj[0].isActive,
      })
    });
  }
  // Grid Delete Button Events
  btngvDelete_Click(a) {
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: { value: a, disabled: false },
        planName: { value: '', disabled: false },
        shortName: { value: '', disabled: false },
        category: { value: '', disabled: false },
        productTypeId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        createdBy: 1,
        createdOn: new Date(),
        deletedBy: 1,
        deletedOn: new Date(),
        isActive: 0,
        organisationId: 1,
        modifiedBy: 0,
        modifiedOn: null



   
       



      })
    });
    let v = this.productForm.get('productFormAction').value;
    console.log(v);
    // this.productService.deleteProduct(v).subscribe(result => { console.log(result); this.getProductDetails() });
  }
  // Methods
  ValidateProductDataForm() {
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        organizationId: ['5'],
        lobId: ['5'],
        planId: ['5'],
        planName:
          [ '',[Validators.required] ],
        shortName:
          [
            '',
            [Validators.required]
          ],
        category: ['', [Validators.required]],
        productTypeId: ['1'],
         
        description: ['1'],
        createdBy: [1],
        createdOn: [new Date()],
        isActive: [1],
      })
    });
  }
  SaveProductDetailData() {
    // this.productForm.get('productFormAction').patchValue({
    //   lobId: '1',
    //   createdBy: '1',
    //   createdOn: new Date(),
    //   isActive: '1',
    // });
    // this.productForm.controls.productFormAction.markAllAsTouched();
    // if (this.productForm.controls.productFormAction.valid) {
    //   let a = this.productForm.controls.productFormAction.value;
    //   this.productService.addProduct(a).subscribe(result => { this.getProductDetails() });
    //   //this.productForm.controls.productFormAction.reset();
    //   this.ClearProductDetails();
    // }

    this.productForm.controls.productFormAction.markAllAsTouched();
    if (this.productForm.get('productFormAction').valid) {
      console.log('valid');
      if (this.createProduct) {
        this.productForm.get('productFormAction').patchValue({
          lobId: '1',
          createdBy: '1',
          createdOn: new Date(),
          isActive: '1',
        });
      }
      else {
        this.productForm.get('productFormAction').patchValue({
          createdBy: '1',
          createdOn: new Date(),
        });
      }
      let a = this.productForm.controls.productFormAction.value;
      console.log(a);
      this.productService.addProduct(a).subscribe(result => { this.getProductDetails() });
      this.ClearProductDetails();
    }
  }
  ClearProductDetails() {
    this.dropDownMode = false;
    this.productForm.controls.productFormAction.reset();
    this.productHeading = 'Add New - Product';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: { value: '', disabled: false },
        planName: { value: '', disabled: false },
        shortName: { value: '', disabled: false },
        category: { value: '', disabled: false },
        productTypeId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
        isActive: { value: '', disabled: false },
      })
    });
  }
  // Get Product Details





  getproductById(a) {


    console.log(a)

    for(let i=0;i<this.productObj.length;i++)
    {
      if(this.productObj[i]['planId']==a.planId)
      {
        //console.log(this.productObj[i]);
        this.branchFilteredObj=this.productObj[i]

        console.log(this.branchFilteredObj);
      }
    }
    // console.log(a);
    // this.productService.editProduct(a.planId).subscribe(result => {
    // console.log('success',result);});
    // this.ClearProductDetails();



    // this.BranchService.get_branchByid(a)
    //   .subscribe(result => {
    //     console.log(result)
    //     this.branchFilteredObj = result.data
    //     console.log(this.branchFilteredObj)
        // if (this.branchFilteredObj) {
        //   this.GetAllStates(this.branchFilteredObj.countryID)
        //   this.GetAllDistricts(this.branchFilteredObj.stateID)
        //   this.GetTaluk(this.branchFilteredObj.districtID)
        //   console.log(this.BranchForm.value)
        //   console.log(this.branchFilteredObj.branchName)

       

        this.productForm = this.fb.group({
          searchPlanName: [''],
          productFormAction: this.fb.group({
            planId: [{ value: this.branchFilteredObj.planId, disabled: false }],
            organisationId: [{ value: this.branchFilteredObj.organisationId, disabled: false }],
            shortName: [{ value: this.branchFilteredObj.shortName, disabled: false }],
            planName: [{ value: this.branchFilteredObj.planName, disabled: false }],
            ShortName: [{ value: this.branchFilteredObj.shortName, disabled: false }],
            isActive: [{ value: this.branchFilteredObj.isActive, disabled: false }],
            category: [{ value: this.branchFilteredObj.category, disabled: false }],
            productTypeId: [{ value: this.branchFilteredObj.productTypeId, disabled: false }],
            description: [{ value: this.branchFilteredObj.description, disabled: false }],
            createdBy: [{ value: this.branchFilteredObj.createdBy, disabled: false }],
            createdOn: [{ value: this.branchFilteredObj.createdOn, disabled: false }],
            deletedBy: { value: this.branchFilteredObj.deletedBy, disabled: false },
            deletedOn: [{ value: this.branchFilteredObj.deletedOn, disabled: false }],
            modifiedBy: [{ value: this.branchFilteredObj.modifiedBy, disabled: false }],
            modifiedOn: [{ value: this.branchFilteredObj.modifiedOn, disabled: false }],
         



            // planId:31,
            // organisationId:0,
            // shortName:"no",
            // planName:"vandana",
            // isActive:1,
            // category:1,
            // productTypeId:1,
            // description:null,
            // createdBy:1,
            // createdOn:'2020-02-03',
            // deletedBy:'null',
            // deletedOn:'null',
            //  modifiedBy:1,
            // modifiedOn:'2020-02-04'


          })
        })
          console.log(this.productForm.value)
       

  }















  btngEdit_Click(a) {
    console.log(a);
    this.productHeading = 'Edit - Product';
    this.btnModeSave = true;
    this.btnSaveText = 'Update'
    this.view = false
    this.fieldDisable = false;
      this.getproductById(a)

  }
  btngView_Click(a) {
    this.view = true
    this.productHeading = 'View - Product';
    this.btnModeSave = false;
    this.fieldDisable = true;
    this.getproductById(a)
  }




  getProductDetails(): void {
    this.productService.getProductDetails().subscribe(
      productObj => {

     
       
        console.log(productObj['getProductModelList'])
     this.productObj=productObj['getProductModelList']

        // this.productSource = new MatTableDataSource<Product>(this.productObj['getProductModelList']);
        // this.productSource.data = this.productObj = productObj;
        // this.productSource.paginator = this.paginator;
        console.log( this.productObj)
        if (this.productObj) {
          this.config = {
            itemsPerPage: 5,
            currentPage: 1,
            totalItems: this.productObj.length
          }
        }
      })
  }


  pageChanged(event) {
    this.config.currentPage = event;
}
  // Search Section
  getProductBySearch(): void {
    if (this.productForm.controls.searchPlanName.valid) {
      let searchValue = this.productForm.controls.searchPlanName.value;
      console.log(searchValue);
      this.productService.getProductBySearch(searchValue).subscribe(
        productObj => {

         
          console.log("wait ",productObj)
          console.log(productObj['data'])
          this.productObj=productObj['data']
     
     
             console.log( this.productObj)
             if (this.productObj) {
               this.config = {
                 itemsPerPage: 10,
                 currentPage: 1,
                 totalItems: this.productObj.length
               }
             }
        });
      // val => { this.productObj = val });
    }
    else {
    }
  }



  DeleteProduct(data)
  {
    this.deleteid=data

  }


  DeleteProduct1()
  {
   
   
  // let deleted={}
  // deleted[' planId']=this.deleteid
  //   deleted['deletedBy']=1
  //   deleted['deletedOn']='2020-04-01'

  this.deleteid['deletedBy']=this.userId
  this.deleteid['deletedOn']=this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd')
 
  console.log(this.deleteid)

  this.productService.deleteProduct(this.deleteid).subscribe(result => { console.log(result); this.getProductDetails() });
 
  }



  onsavebutton()
  {
 
 
    if(this.btnSaveText == 'Save')
    {
 
      this.addproduct();
     console.log('add')
 
    }
 
   else if(this.btnSaveText == 'Update')
 
    {
      this.updateproduct()
      console.log('update')
    }
   
  }
 
 
  addproduct()
  {
    // this.addproduct();
    console.log(this.productForm.get('productFormAction').value)
    this.productForm.get('productFormAction').patchValue({
   
      planId: 0,
      organisationId: 1,
   
      productTypeId:1 ,
   
      isActive:1 ,
      createdBy: this.userId,
      createdOn: this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd'),
      deletedBy: 0,
      deletedOn: null,
      modifiedBy: 0,
      modifiedOn: null
    })
 
    if(this.productForm.get('productFormAction').valid)
    {
    // this.productForm.get('productFormAction.createdOn').patchValue('2020-04-01');
    console.log(this.productForm.get('productFormAction').value)
    let a = this.productForm.controls.productFormAction.value;
    console.log(a);
    this.productService.addProduct(a).subscribe(result => {
      this.getProductDetails() ;
    console.log('success',result);
    this.ClearProductDetails();});
  }
  }
 
  updateproduct()
  {
   
    console.log(this.productForm.get('productFormAction').value)
    this.productForm.get('productFormAction').patchValue({
   
   
      modifiedBy: this.userId,
      modifiedOn: this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd'),
    })
    if(this.productForm.get('productFormAction').valid)
    {
    // this.productForm.get('productFormAction.createdOn').patchValue('2020-04-01');
    console.log(this.productForm.get('productFormAction').value)
    let a = this.productForm.controls.productFormAction.value;
    console.log(a);
    this.productService.addProduct(a).subscribe(result => {
      this.getProductDetails() ;
    console.log('success',result);});
    this.ClearProductDetails();
  }
}

}


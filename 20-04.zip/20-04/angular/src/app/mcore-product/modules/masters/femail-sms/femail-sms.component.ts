import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { FemailSmsService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/femail-sms.service';

@Component({
  selector: 'app-femail-sms',
  templateUrl: './femail-sms.component.html',
  styleUrls: ['./femail-sms.component.css']
})
export class FemailSmsComponent implements OnInit {

  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Enter text here...',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      ['bold', 'italic'],
      ['fontSize']
    ]
  };
  template: FormGroup;
  isSms: boolean;
  isEmail: boolean;
  isWhatsapp: boolean;
  allTemplates: any;
  features: any;
  templateheading: string;
  saveBtnMode: boolean;
  view: boolean;
  textSaveBtn: string;
  id: any;
  templateObj: any;
  transaction: string;
  display: string;
  constructor(private fb: FormBuilder, private FemailSmsService: FemailSmsService) { }

  ngOnInit() {
    this.addtaxdetailsform()
    this.GetAllMessageTemplates()
    this.GetAllFeaturesForSMSEmail()
  }

  addtaxdetailsform() {
    this.template = this.fb.group({
      // taxstructuredetailsID: [''],
      // taxstructureID: [''],
      messageTemplatesID: [''],
      featureID: [''],
      templateDescription: [],
      smsTemplates: [''],
      smsIsActive: [],
      emailIsActive: [''],
      emailTemplates: [''],
      emailSMSTypeID: ['',],
      subject: [''],
      templateTypeId: [''],
      whatsAppTemplates: [''],
      whatsAppIsActive: [''],
      createdBy: [1],
      createdOn: [null],
    })
    this.template.get('emailSMSTypeID').valueChanges.subscribe((data: string) => {
      console.log(data)
      this.onchangeemailSMSTypeID(data);

    });
  }

  onchangeemailSMSTypeID(selected: any) {
    const emailIsActiveControl = this.template.get('emailIsActive');
    const smsIsActiveControl = this.template.get('smsIsActive');
    const whatsAppIsActiveyControl = this.template.get('whatsAppIsActive');
    const emailTemplatesControl = this.template.get('emailTemplates');
    const whatsAppTemplatesControl = this.template.get('whatsAppTemplates');
    const smsTemplatesControl = this.template.get('smsTemplates');

    console.log(selected)
    if (selected === 1) {
      this.isSms = true
      this.isEmail = false
      this.isWhatsapp = false
      smsIsActiveControl.setValidators(Validators.required)
      smsTemplatesControl.setValidators(Validators.required)
      emailIsActiveControl.clearValidators()
      whatsAppIsActiveyControl.clearValidators();
      whatsAppTemplatesControl.clearValidators();
      emailTemplatesControl.clearValidators();
      this.template.patchValue({
        emailIsActive: 0,
        whatsAppIsActive: 0,
      });
      // this.template = this.fb.group({
      //   emailIsActive: [{ value: 0, disabled: false }],
      //   whatsAppIsActive: [{ value: 0, disabled: false }],
      // })
    }
    else if (selected === 2) {
      this.isSms = false
      this.isEmail = true
      this.isWhatsapp = false
      emailIsActiveControl.setValidators(Validators.required)
      emailTemplatesControl.setValidators(Validators.required)
      smsIsActiveControl.clearValidators()
      whatsAppIsActiveyControl.clearValidators();
      whatsAppTemplatesControl.clearValidators();
      smsTemplatesControl.clearValidators();
      this.template.patchValue({
        smsIsActive: 0,
        whatsAppIsActive: 0,
      });
      // this.template = this.fb.group({
      //   smsIsActive: [{ value: 0, disabled: false }],
      //   whatsAppIsActive: [{ value: 0, disabled: false }],
      // })
    }
    else if (selected === 3) {
      this.isSms = false
      this.isEmail = false
      this.isWhatsapp = true
      whatsAppIsActiveyControl.setValidators(Validators.required)
      whatsAppTemplatesControl.setValidators(Validators.required)
      emailIsActiveControl.clearValidators()
      smsIsActiveControl.clearValidators();
      smsTemplatesControl.clearValidators();
      emailTemplatesControl.clearValidators();
      this.template.patchValue({
        emailIsActive: 0,
        smsIsActive: 0,
      });
      // this.template = this.fb.group({
      //   emailIsActive: [{ value: 0, disabled: false }],
      //   smsIsActive: [{ value: 0, disabled: false }],
      // })
    }
    emailIsActiveControl.updateValueAndValidity();
    smsIsActiveControl.updateValueAndValidity();
    whatsAppIsActiveyControl.updateValueAndValidity();
    emailTemplatesControl.updateValueAndValidity();
    whatsAppTemplatesControl.updateValueAndValidity();
    emailTemplatesControl.updateValueAndValidity();

  }

  addtemplate() {
    console.log(this.template.value)
    this.template["messageTemplatesID"] = 0
    this.template["featureID"] = 0
    this.FemailSmsService.insert(this.template.value)
      .subscribe(result => {
        console.log(result)
        if(result.data=="Inserted"){
          this.transaction='Created'
          this.openModalDialog() 
        }
        else{
          this.transaction='Updated'
          this.openModalDialog() 
        }
        // this.allchannel = result.data
        // console.log(this.allchannel)
      });
  }
  btngEdit_Click(a) {
    this.templateheading = 'Edit - Sub Channel';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.id = a
    this.GetAllMessageTemplatesByTemplateID(a)
  }
  btngView_Click(a) {
    this.templateheading = 'View - Sub Channel';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.GetAllMessageTemplatesByTemplateID(a)
  }

  GetAllMessageTemplatesByTemplateID(a) {
    console.log(a)
    this.FemailSmsService.GetAllMessageTemplatesByTemplateID(a)
      .subscribe(result => {
        console.log(result)
        this.templateObj = result.data[0]
        console.log(this.templateObj)
        if (this.templateObj) {
          this.template = this.fb.group({
            messageTemplatesID: [{ value: this.templateObj.messageTemplatesID, disabled: false }],
            featureID:  [{ value: this.templateObj.featureID, disabled: false }],
            templateDescription:  [{ value: this.templateObj.templateDescription, disabled: false }],
            smsTemplates:  [{ value: this.templateObj.smsTemplates, disabled: false }],
            smsIsActive:  [{ value: this.templateObj.smsIsActive, disabled: false }],
            emailIsActive:  [{ value: this.templateObj.emailIsActive, disabled: false }],
            emailTemplates:  [{ value: this.templateObj.emailTemplates, disabled: false }],
            emailSMSTypeID:  [{ value: this.templateObj.emailSMSTypeID, disabled: false }],
            subject:  [{ value: this.templateObj.subject, disabled: false }],
            templateTypeId: [{ value: this.templateObj.templateTypeId, disabled: false }],
            whatsAppTemplates:  [{ value: this.templateObj.whatsAppTemplates, disabled: false }],
            whatsAppIsActive:  [{ value: this.templateObj.whatsAppIsActive, disabled: false }],
          })    
        }
      })
  }

  GetAllMessageTemplates() {
    this.FemailSmsService.GetAllMessageTemplates()
      .subscribe(result => {
        console.log(result)
        this.allTemplates = result.data
        console.log(this.allTemplates)
      });
  }
  GetAllFeaturesForSMSEmail() {
    this.FemailSmsService.GetAllFeaturesForSMSEmail(this.template.value)
      .subscribe(result => {
        console.log(result)
        this.features = result.data
        console.log(this.features)
      });
  }
  openModalDialog() {
    this.display = 'block'; //Set block css
    // this.submitted = false
    // this.SubChannelForm.reset()
  }
  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
  }
}

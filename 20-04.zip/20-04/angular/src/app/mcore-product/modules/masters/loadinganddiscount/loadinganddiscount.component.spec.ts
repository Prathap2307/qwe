import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadinganddiscountComponent } from './loadinganddiscount.component';

describe('LoadinganddiscountComponent', () => {
  let component: LoadinganddiscountComponent;
  let fixture: ComponentFixture<LoadinganddiscountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadinganddiscountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadinganddiscountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

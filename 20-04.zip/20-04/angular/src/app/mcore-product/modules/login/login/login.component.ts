import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { McoreCommunicationService } from 'src/app/mcore-product/mcore-shared/mcore-communication/communicationService';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  msg: string;
  error: boolean=false;

  constructor(private router: Router,private mcom :McoreCommunicationService, private user: UserService) { }

  ngOnInit() {
  }

  LoginForm = new FormGroup({

    userName: new FormControl("", [Validators.required]),
    password: new FormControl("", [Validators.required])


  });

  onSubmit() {

    if (this.LoginForm.valid) {
      let userCredential = this.LoginForm.value;
      console.log(userCredential)
      this.user.VerifyLogin(userCredential)
        .subscribe(result => {
          console.log("result",result)
        
          if(result && result.data.message == 'SuccessfullLogin'){
            this.user.getTimeZoneByID(1)
            .subscribe(result => {
              console.log(result)
              console.log(result.data.description)
              this.mcom.sendData(result.data.description)
              // localStorage.setItem('timezone',result.data.description);
            })
            this.router.navigate(['/account/dashboard']);
            console.log(result.data["UserProfileModal"])
            localStorage.setItem('organisationID',result.data.UserProfileModal.organisationID);
            localStorage.setItem('fname',result.data.UserProfileModal.firstName);
            localStorage.setItem('lastLoginTime',result.data.UserProfileModal.lastLoginTime);
            localStorage.setItem('userID',result.data.UserProfileModal.userID);
            localStorage.setItem('userName',result.data.UserProfileModal.userName);
            this.user.fname=result.data.UserProfileModal.firstName
            this.user.userID=result.data.UserProfileModal.userID
            this.user.userName=result.data.UserProfileModal.userName
          
          
          } else {
            this.error=true
            this.msg=result.data.message
            console.log('mm',result.data.message)
          }
        
        })
      
        
      // console.log(userCredential);
    }
  }


}

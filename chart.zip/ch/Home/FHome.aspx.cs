﻿using BL.Masters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BE;
using BL;
using BE.Masters;
using Utilities.Common;
using BL.Party;
using BE.UsersAndPermissions;
using BL.UsersAndPermissions;
namespace PFS.Web.Account
{
    public partial class FHome : System.Web.UI.Page
    {
        BE.UserProfileInfo oUser = null;
        PFS.Web.InsuranceUser MIUser;


        

        protected void Page_Load(object sender, EventArgs e)
        {

            string strPreviousPage = string.Empty;
            
            if (Request.UrlReferrer != null)
            {
                strPreviousPage = Request.UrlReferrer.Segments[Request.UrlReferrer.Segments.Length - 1];
            }

            if (strPreviousPage == "")
            {
                Response.Redirect("~/Default.aspx");
            }

            DisablePageCaching();
            if (!IsPostBack && !IsCallback)
            {
                #region "Bind the Information in the Master Page"

                try
                {

                    MIUser = (PFS.Web.InsuranceUser)Context.User;

                    oUser = MIUser.oUser;
                }
                catch (Exception ex)
                {

                    return;
                }

                #endregion
                //ddlInsurer.SelectedIndex = ddlInsurer.Items.IndexOf(ddlInsurer.Items.FindByValue("5"));
                //ddlInsurer.SelectedValue = "5";
                //  ddlInsurer.SelectedItem.Value = "5";
                tab_Motor.Visible = true;
                BindInsurer();
                BindLineOfBusiness();
                BindAgentDashboard();
                // Summaryforsixmonths();
              
                //GetAllClientDetails();
                GetAllClientDetailsLoad();
                clientSummaryforsixmonths();
                // ddlLineOfBusiness.SelectedValue = "4";

            }



        }

        public void BindLineOfBusiness()
        {
            ddlLineOfBusiness.Items.Clear();
            using (DataTable dtZone = new CDashboard().GetAllLineOfBusiness())
            {
                if ((dtZone != null) && (dtZone.Rows.Count > 0))
                {
                    ddlLineOfBusiness.DataSource = dtZone;
                    ddlLineOfBusiness.DataTextField = "Description";
                    ddlLineOfBusiness.DataValueField = "LOBID";
                    ddlLineOfBusiness.DataBind();

                }
            }
            ddlLineOfBusiness.Items.Insert(0, new ListItem("All", "0"));
            ddlLineOfBusiness.SelectedIndex = 0;
        }

        //public void Summaryforsixmonths()
        //{
        //    string strType;
        //    // DataSet _dSet = new CDashboard().GetAllLOBSummaryforsixmonthsVariation(4);
        //    DataSet _dSet = new CDashboard().GetAllLOBandInsurerSummaryforsixmonthsVariation(Convert.ToInt32(ddlInsurer.SelectedValue), 4);
        //    if ((_dSet != null) && (_dSet.Tables.Count > 0))
        //    {

        //        for (int iCount = 0; iCount < _dSet.Tables.Count; iCount++)
        //        {
        //            if (_dSet.Tables[iCount].Rows.Count > 0)
        //            {
        //                strType = _dSet.Tables[iCount].Rows[0].ItemArray[(_dSet.Tables[iCount].Rows[0].ItemArray.Length) - 1].ToString();
        //                switch (strType)
        //                {
        //                    case "IMA":

        //                        for (int i = 0; i < _dSet.Tables[iCount].Rows.Count; i++)
        //                        {
        //                            if (i == 0)
        //                            {
        //                                month0.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
        //                                monthTotalCustomers0.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
        //                                monthTotalPolicies0.Text = _dSet.Tables[iCount].Rows[i]["TotalPolicies"].ToString();
        //                                monthTotalSumInsured0.Text = _dSet.Tables[iCount].Rows[i]["TotalSumInsured"].ToString();
        //                                monthTotalPremium0.Text = _dSet.Tables[iCount].Rows[i]["TotalPremium"].ToString();
        //                                monthClaimIntimated0.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
        //                                monthClaimSettled0.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
        //                            }
        //                            else if (i == 1)
        //                            {
        //                                month1.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
        //                                monthTotalCustomers1.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
        //                                monthTotalPolicies1.Text = _dSet.Tables[iCount].Rows[i]["TotalPolicies"].ToString();
        //                                monthTotalSumInsured1.Text = _dSet.Tables[iCount].Rows[i]["TotalSumInsured"].ToString();
        //                                monthTotalPremium1.Text = _dSet.Tables[iCount].Rows[i]["TotalPremium"].ToString();
        //                                monthClaimIntimated1.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
        //                                monthClaimSettled1.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
        //                            }
        //                            else if (i == 2)
        //                            {
        //                                month2.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
        //                                monthTotalCustomers2.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
        //                                monthTotalPolicies2.Text = _dSet.Tables[iCount].Rows[i]["TotalPolicies"].ToString();
        //                                monthTotalSumInsured2.Text = _dSet.Tables[iCount].Rows[i]["TotalSumInsured"].ToString();
        //                                monthTotalPremium2.Text = _dSet.Tables[iCount].Rows[i]["TotalPremium"].ToString();
        //                                monthClaimIntimated2.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
        //                                monthClaimSettled2.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
        //                            }
        //                            else if (i == 3)
        //                            {
        //                                month3.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
        //                                monthTotalCustomers3.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
        //                                monthTotalPolicies3.Text = _dSet.Tables[iCount].Rows[i]["TotalPolicies"].ToString();
        //                                monthTotalSumInsured3.Text = _dSet.Tables[iCount].Rows[i]["TotalSumInsured"].ToString();
        //                                monthTotalPremium3.Text = _dSet.Tables[iCount].Rows[i]["TotalPremium"].ToString();
        //                                monthClaimIntimated3.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
        //                                monthClaimSettled3.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
        //                            }
        //                            else if (i == 4)
        //                            {
        //                                month4.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
        //                                monthTotalCustomers4.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
        //                                monthTotalPolicies4.Text = _dSet.Tables[iCount].Rows[i]["TotalPolicies"].ToString();
        //                                monthTotalSumInsured4.Text = _dSet.Tables[iCount].Rows[i]["TotalSumInsured"].ToString();
        //                                monthTotalPremium4.Text = _dSet.Tables[iCount].Rows[i]["TotalPremium"].ToString();
        //                                monthClaimIntimated4.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
        //                                monthClaimSettled4.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
        //                            }
        //                            else if (i == 5)
        //                            {
        //                                month5.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
        //                                monthTotalCustomers5.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
        //                                monthTotalPolicies5.Text = _dSet.Tables[iCount].Rows[i]["TotalPolicies"].ToString();
        //                                monthTotalSumInsured5.Text = _dSet.Tables[iCount].Rows[i]["TotalSumInsured"].ToString();
        //                                monthTotalPremium5.Text = _dSet.Tables[iCount].Rows[i]["TotalPremium"].ToString();
        //                                monthClaimIntimated5.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
        //                                monthClaimSettled5.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
        //                            }
        //                        }
        //                        break;
        //                    default:
        //                        break;

        //                }

        //            }

        //        }
        //    }

        //}


        public void BindAgentDashboard()
        {
            lblMotorTotalPolicies.Text = "0";
            lblMotorTotalCustomers.Text = "0";
            lblMotorTotalSumInsured.Text = "0";
            lblMotorTotalPremium.Text = "0";
            lblMotorClaimIntimated.Text = "0";
            lblMotorClaimSettled.Text = "0";

            string strType;
            var Fromdate = txtFromDate.Text == "" ? Convert.ToDateTime("01/01/1800") : Convert.ToDateTime(txtFromDate.Text);
            var Todate = txtToDate.Text == "" ? DateTime.Now : Convert.ToDateTime(txtToDate.Text);
            // DataSet _dSet = new CDashboard().GetAllLOBBusinessSummary(0, Convert.ToInt32(ddlLineOfBusiness.SelectedValue), Fromdate, Todate);
            DataSet _dSet = new CDashboard().GetAllLOBandInsurerBusinessSummary(Convert.ToInt32(ddlInsurer.SelectedValue), 0, Convert.ToInt32(ddlLineOfBusiness.SelectedValue), Fromdate, Todate);
            if ((_dSet != null) && (_dSet.Tables.Count > 0))
            {

                for (int iCount = 0; iCount < _dSet.Tables.Count; iCount++)
                {
                    if (_dSet.Tables[iCount].Rows.Count > 0)
                    {

                        //lblTotalClientCreated.Text = _dSet.Tables[0].Rows[0]["TotalClientCreated"].ToString();
                        //lblTotalPoliciesCreated.Text = _dSet.Tables[1].Rows[0]["TotalPoliciesCreated"].ToString();
                        //lblTotalSumAssured.Text = _dSet.Tables[1].Rows[0]["TotalSumAssured"].ToString();
                        //lblTotalPremiumAmount.Text = _dSet.Tables[1].Rows[0]["TotalPremiumAmount"].ToString();

                        //lblClaimIntimated.Text = _dSet.Tables[1].Rows[0]["ClaimIntimated"].ToString();
                        //lblClaimSettled.Text = _dSet.Tables[1].Rows[0]["ClaimSettled"].ToString();


                        strType = _dSet.Tables[iCount].Rows[0].ItemArray[(_dSet.Tables[iCount].Rows[0].ItemArray.Length) - 1].ToString();
                        switch (strType)
                        {
                            case "IMA":
                                lblMotorTotalPolicies.Text = _dSet.Tables[iCount].Rows[0]["TotalCustomers"].ToString();
                                lblMotorTotalCustomers.Text = _dSet.Tables[iCount].Rows[0]["TotalPolicies"].ToString();
                                lblMotorTotalSumInsured.Text = _dSet.Tables[iCount].Rows[0]["TotalSumInsured"].ToString();
                                lblMotorTotalPremium.Text = _dSet.Tables[iCount].Rows[0]["TotalPremium"].ToString();
                                lblMotorClaimIntimated.Text = _dSet.Tables[iCount].Rows[0]["ClaimIntimated"].ToString();
                                lblMotorClaimSettled.Text = _dSet.Tables[iCount].Rows[0]["ClaimSettled"].ToString();
                                break;
                            default:
                                break;

                        }

                    }

                }
            }
        }

        protected void Search_Click(object sender, EventArgs e)
        {
            if (txtToDate.Text == "" && txtFromDate.Text == "")
            {
                BindAgentDashboard();
                //  Summaryforsixmonths();
            }

            if (txtToDate.Text != "" || txtFromDate.Text != "")
            {
                if (dateValidation())
                {
                    BindAgentDashboard();
                    //  Summaryforsixmonths();
                }
            }
        }

        public bool dateValidation()
        {
            if (txtFromDate.Text != "" && txtToDate.Text == "")
            {
                MessageBox.ShowErrorMessage("Please Select To Date", "txtToDate");
                return false;
            }
            else if (txtToDate.Text != "" && txtFromDate.Text == "")
            {
                MessageBox.ShowErrorMessage("Please Select From Date", "txtFromDate");
                return false;
            }
            else if (txtFromDate.Text != "" && txtToDate.Text != "")
            {
                if (Convert.ToDateTime(txtFromDate.Text) > Convert.ToDateTime(txtToDate.Text))
                {
                    MessageBox.ShowErrorMessage("To date should be greater than from date ", "txtToDate");
                    txtToDate.Text = "";
                    return false;
                }
            }



            return true;
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            ClearSearch();
            BindAgentDashboard();
        }
        public void ClearSearch()
        {
            ddlInsurer.SelectedIndex = -1;
            ddlLineOfBusiness.SelectedIndex = -1;
            txtFromDate.Text = string.Empty;
            txtToDate.Text = string.Empty;
        }



        protected void btnMotorInsurance_Click(object sender, EventArgs e)
        {
            ClearSearch();
            ddlLineOfBusiness.SelectedIndex = ddlLineOfBusiness.Items.IndexOf(ddlLineOfBusiness.Items.FindByValue("4"));
            BindAgentDashboard();
            btnMotorInsurance.CssClass = "tab_button active";
            btnHealthInsurance.CssClass = "tab_button";
            tab_Motor.Visible = true;
            tab_Health.Visible = false;
        }

        protected void btnHealthInsurance_Click(object sender, EventArgs e)
        {
            ClearSearch();
            ddlLineOfBusiness.SelectedIndex = ddlLineOfBusiness.Items.IndexOf(ddlLineOfBusiness.Items.FindByValue("1"));

            btnHealthInsurance.CssClass = "tab_button active";
            btnMotorInsurance.CssClass = "tab_button";
            tab_Motor.Visible = false;
            tab_Health.Visible = true;
            BindAgentDashboard();
        }


        #region "Bind Insurer New"
        /// <summary>
        /// Bind Insurer New
        /// </summary>
        public void BindInsurer()
        {
            using (DataTable _dt = new Insurer().GetInsurer())
            {
                if (_dt != null && _dt.Rows.Count > 0)
                {
                    ddlInsurer.DataSource = _dt;
                    ddlInsurer.DataTextField = "InsurerName";

                    ddlInsurer.DataValueField = "InsurerID";
                    ddlInsurer.DataBind();
                    ddlInsurer.Items.Insert(0, new ListItem("---Select---", "0"));
                    if (_dt.Rows.Count == 1)
                        ddlInsurer.SelectedIndex = 1;

                }
                else
                {
                    ddlInsurer.Items.Insert(0, new ListItem("---Select---", "0"));
                    ddlInsurer.SelectedIndex = 0;
                }

            }


        }
        #endregion

        #region"Disable Page Caching"
        /// <summary>
        /// Disable Page Caching
        /// </summary>
        public static void DisablePageCaching()
        {
            //Used for disabling page caching
            HttpContext.Current.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            HttpContext.Current.Response.Cache.SetValidUntilExpires(false);
            HttpContext.Current.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Cache.SetNoStore();

            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.Expires = 0;
            HttpContext.Current.Response.ExpiresAbsolute = DateTime.UtcNow.AddDays(-1);

        }
        #endregion

        private void GetAllClientDetailsLoad()
        {
            //if (ddlGroupName.SelectedValue == "0")
            //{
            //    divTotalClientCreated.Visible = true;
            //}
            //else
            //{
            //    divTotalClientCreated.Visible = false;
            //}


            DataSet _dSet = new CDashboard().GetAllDetailsByClientLoad(Convert.ToInt32(hdnGroupID.Value));
            if ((_dSet != null) && (_dSet.Tables.Count > 0))
            {

                for (int iCount = 0; iCount < _dSet.Tables.Count; iCount++)
                {
                    if (_dSet.Tables[iCount].Rows.Count > 0)
                    {

                        lblTotalClientCreated.Text = _dSet.Tables[iCount].Rows[0]["TotalClientCreated"].ToString();
                        lblTotalPoliciesCreated.Text = _dSet.Tables[iCount].Rows[0]["TotalPoliciesCreated"].ToString();
                        lblTotalSumAssured.Text = _dSet.Tables[iCount].Rows[0]["TotalSumAssured"].ToString();
                        lblTotalPremiumAmount.Text = _dSet.Tables[iCount].Rows[0]["TotalPremiumAmount"].ToString();

                        lblClaimIntimated.Text = _dSet.Tables[iCount].Rows[0]["ClaimIntimated"].ToString();
                        lblClaimSettled.Text = _dSet.Tables[iCount].Rows[0]["ClaimSettled"].ToString();

                    }

                }
            }
        }


        private void GetAllClientDetails()
        {
            //if (ddlGroupName.SelectedValue == "0")
            //{
            //    divTotalClientCreated.Visible = true;
            //}
            //else
            //{
            //    divTotalClientCreated.Visible = false;
            //}


            DataSet _dSet = new CDashboard().GetAllDetailsByClient(Convert.ToInt32(hdnGroupID.Value));
            if ((_dSet != null) && (_dSet.Tables.Count > 0))
            {

                for (int iCount = 0; iCount < _dSet.Tables.Count; iCount++)
                {
                    if (_dSet.Tables[iCount].Rows.Count > 0)
                    {

                        lblTotalClientCreated.Text = _dSet.Tables[iCount].Rows[0]["TotalClientCreated"].ToString();
                        lblTotalPoliciesCreated.Text = _dSet.Tables[iCount].Rows[0]["TotalPoliciesCreated"].ToString();
                        lblTotalSumAssured.Text = _dSet.Tables[iCount].Rows[0]["TotalSumAssured"].ToString();
                        lblTotalPremiumAmount.Text = _dSet.Tables[iCount].Rows[0]["TotalPremiumAmount"].ToString();

                        lblClaimIntimated.Text = _dSet.Tables[iCount].Rows[0]["ClaimIntimated"].ToString();
                        lblClaimSettled.Text = _dSet.Tables[iCount].Rows[0]["ClaimSettled"].ToString();

                    }

                }
            }
        }

        private void GetAllClientDetailsData()
        {
            //if (ddlGroupName.SelectedValue == "0")
            //{
            //    divTotalClientCreated.Visible = true;
            //}
            //else
            //{
            //    divTotalClientCreated.Visible = false;
            //}


            //DataSet _dSet = new CDashboard().GetAllDetailsByClientData(Convert.ToInt32(hdnGroupID.Value), ddlMasterPolicyAgreementNumber.SelectedValue);
            DataSet _dSet = new CDashboard().GetAllDetailsByClientData(Convert.ToInt32(hdnGroupID.Value), txtAgreementNumber.Text);
            if ((_dSet != null) && (_dSet.Tables.Count > 0))
            {

                for (int iCount = 0; iCount < _dSet.Tables.Count; iCount++)
                {
                    if (_dSet.Tables[iCount].Rows.Count > 0)
                    {

                        lblTotalClientCreated.Text = _dSet.Tables[iCount].Rows[0]["TotalClientCreated"].ToString();
                        lblTotalPoliciesCreated.Text = _dSet.Tables[iCount].Rows[0]["TotalPoliciesCreated"].ToString();
                        lblTotalSumAssured.Text = _dSet.Tables[iCount].Rows[0]["TotalSumAssured"].ToString();
                        lblTotalPremiumAmount.Text = _dSet.Tables[iCount].Rows[0]["TotalPremiumAmount"].ToString();

                        lblClaimIntimated.Text = _dSet.Tables[iCount].Rows[0]["ClaimIntimated"].ToString();
                        lblClaimSettled.Text = _dSet.Tables[iCount].Rows[0]["ClaimSettled"].ToString();

                    }

                }
            }
        }

        //protected void txtAgreementNumber_TextChanged(object sender, EventArgs e)
        //{
        //    DataTable _dt = new HealthGroup().GetSearchGroupDetailsByAgreementNo(hdnGroupID.Value == "" ? 0 : Convert.ToInt32(hdnGroupID.Value), txtAgreementNumber.Text);
        //    if (_dt != null && _dt.Rows.Count > 0)
        //    {
        //        txtGroupName.Text = _dt.Rows[0]["GroupName"].ToString();
        //        txtSearchCompany.Text = _dt.Rows[0]["GroupName"].ToString();
        //        hdnGroupID.Value = _dt.Rows[0]["GroupID"].ToString();
        //        hdnAgreementNo.Value = _dt.Rows[0]["MasterPolicyID"].ToString();
        //    }
        //    else
        //    {
        //        txtSearchCompany.Text = "";
        //        txtGroupName.Text = "";
        //        txtAgreementNumber.Text = "";
        //        hdnGroupID.Value = "0";
        //        hdnAgreementNo.Value = "0";
        //    }
        //    clearcontrols("Search");
        //    GroupNameSelectedIndexChanged();
        //}

        protected void ddlGroupName_SelectedIndexChanged(object sender, EventArgs e)
        {

            GetAllClientDetails();
            clientSummaryforsixmonths();
            ScriptManager.RegisterStartupScript(Page, GetType(), "amountInWordsFn", "<script>amountInWordsFn()</script>", false);
        }

        public void clientSummaryforsixmonths()
        {
            DataSet _dSet = new CDashboard().GetAllClientSummaryforsixmonths(Convert.ToInt32(hdnGroupID.Value));
            if ((_dSet != null) && (_dSet.Tables.Count > 0))
            {

                for (int iCount = 0; iCount < _dSet.Tables.Count; iCount++)
                {
                    if (_dSet.Tables[iCount].Rows.Count > 0)
                    {

                        for (int i = 0; i < _dSet.Tables[iCount].Rows.Count; i++)
                        {
                            if (iCount == 0)
                            {
                                if (i == 0)
                                {
                                    month0.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    //  monthTotalCustomers0.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
                                   // monthTotalMasterPolicy0.Text = _dSet.Tables[iCount].Rows[i]["TotalMasterPolicyCreated"].ToString();
                                    monthTotalPolicies0.Text = _dSet.Tables[iCount].Rows[i]["TotalPoliciesCreated"].ToString();
                                    monthTotalSumInsured0.Text = _dSet.Tables[iCount].Rows[i]["TotalSumAssured"].ToString();
                                    monthTotalPremium0.Text = _dSet.Tables[iCount].Rows[i]["TotalPremiumAmount"].ToString();
                                    monthClaimIntimated0.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
                                    monthClaimSettled0.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
                                }
                                else if (i == 1)
                                {
                                    month1.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    //  monthTotalCustomers1.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
                                 //   monthTotalMasterPolicy1.Text = _dSet.Tables[iCount].Rows[i]["TotalMasterPolicyCreated"].ToString();
                                    monthTotalPolicies1.Text = _dSet.Tables[iCount].Rows[i]["TotalPoliciesCreated"].ToString();
                                    monthTotalSumInsured1.Text = _dSet.Tables[iCount].Rows[i]["TotalSumAssured"].ToString();
                                    monthTotalPremium1.Text = _dSet.Tables[iCount].Rows[i]["TotalPremiumAmount"].ToString();
                                    monthClaimIntimated1.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
                                    monthClaimSettled1.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
                                }
                                else if (i == 2)
                                {
                                    month2.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    //  monthTotalCustomers2.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
                                 //   monthTotalMasterPolicy2.Text = _dSet.Tables[iCount].Rows[i]["TotalMasterPolicyCreated"].ToString();
                                    monthTotalPolicies2.Text = _dSet.Tables[iCount].Rows[i]["TotalPoliciesCreated"].ToString();
                                    monthTotalSumInsured2.Text = _dSet.Tables[iCount].Rows[i]["TotalSumAssured"].ToString();
                                    monthTotalPremium2.Text = _dSet.Tables[iCount].Rows[i]["TotalPremiumAmount"].ToString();
                                    monthClaimIntimated2.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
                                    monthClaimSettled2.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
                                }
                                else if (i == 3)
                                {
                                    month3.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    //  monthTotalCustomers3.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
                                 //   monthTotalMasterPolicy3.Text = _dSet.Tables[iCount].Rows[i]["TotalMasterPolicyCreated"].ToString();
                                    monthTotalPolicies3.Text = _dSet.Tables[iCount].Rows[i]["TotalPoliciesCreated"].ToString();
                                    monthTotalSumInsured3.Text = _dSet.Tables[iCount].Rows[i]["TotalSumAssured"].ToString();
                                    monthTotalPremium3.Text = _dSet.Tables[iCount].Rows[i]["TotalPremiumAmount"].ToString();
                                    monthClaimIntimated3.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
                                    monthClaimSettled3.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
                                }
                                else if (i == 4)
                                {
                                    month4.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    //  monthTotalCustomers4.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
                                  //  monthTotalMasterPolicy4.Text = _dSet.Tables[iCount].Rows[i]["TotalMasterPolicyCreated"].ToString();
                                    monthTotalPolicies4.Text = _dSet.Tables[iCount].Rows[i]["TotalPoliciesCreated"].ToString();
                                    monthTotalSumInsured4.Text = _dSet.Tables[iCount].Rows[i]["TotalSumAssured"].ToString();
                                    monthTotalPremium4.Text = _dSet.Tables[iCount].Rows[i]["TotalPremiumAmount"].ToString();
                                    monthClaimIntimated4.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
                                    monthClaimSettled4.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
                                }
                                else if (i == 5)
                                {
                                    month5.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    // monthTotalCustomers5.Text = _dSet.Tables[iCount].Rows[i]["TotalCustomers"].ToString();
                                 //   monthTotalMasterPolicy5.Text = _dSet.Tables[iCount].Rows[i]["TotalMasterPolicyCreated"].ToString();
                                    monthTotalPolicies5.Text = _dSet.Tables[iCount].Rows[i]["TotalPoliciesCreated"].ToString();
                                    monthTotalSumInsured5.Text = _dSet.Tables[iCount].Rows[i]["TotalSumAssured"].ToString();
                                    monthTotalPremium5.Text = _dSet.Tables[iCount].Rows[i]["TotalPremiumAmount"].ToString();
                                    monthClaimIntimated5.Text = _dSet.Tables[iCount].Rows[i]["ClaimIntimated"].ToString();
                                    monthClaimSettled5.Text = _dSet.Tables[iCount].Rows[i]["ClaimSettled"].ToString();
                                }
                            }
                            if (iCount == 1)
                            {
                                if (i == 0)
                                {
                                    month0.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    monthTotalCustomers0.Text = _dSet.Tables[iCount].Rows[i]["TotalClientCreated"].ToString();
                                }
                                if (i == 1)
                                {
                                    month1.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    monthTotalCustomers1.Text = _dSet.Tables[iCount].Rows[i]["TotalClientCreated"].ToString();
                                }
                                if (i == 2)
                                {
                                    month2.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    monthTotalCustomers2.Text = _dSet.Tables[iCount].Rows[i]["TotalClientCreated"].ToString();
                                }
                                if (i == 3)
                                {
                                    month3.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    monthTotalCustomers3.Text = _dSet.Tables[iCount].Rows[i]["TotalClientCreated"].ToString();
                                }
                                if (i == 4)
                                {
                                    month4.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    monthTotalCustomers4.Text = _dSet.Tables[iCount].Rows[i]["TotalClientCreated"].ToString();
                                }
                                if (i == 5)
                                {
                                    month5.Text = _dSet.Tables[iCount].Rows[i]["MonthsName"].ToString();
                                    monthTotalCustomers5.Text = _dSet.Tables[iCount].Rows[i]["TotalClientCreated"].ToString();
                                }
                            }

                        }

                    }

                }
            }

        }

        #region "FetchHealthGroupDetails"
        private void FetchHealthGroupDetails()
        {
            System.Data.DataTable _dtHealthGroupDtls = new HealthGroup().GetHealthGroupByGroupId(hdnGroupID.Value.ToString());
            if (_dtHealthGroupDtls != null && _dtHealthGroupDtls.Rows.Count > 0)
            {
                txtGroupName.Text = _dtHealthGroupDtls.Rows[0]["OrganisationName"].ToString();
               

            }
        }

        #endregion

        //public void BindMasterAgreementNumber(Int32 GroupID)
        //{
        //    using (System.Data.DataTable _dt = new BL.Masters.HealthGroup().GetMasterAgreementNumberByLOB(GroupID, 5, 1))
        //    {
        //        // ddlMasterPolicyNumber.SelectedIndex = 0;
        //        ddlMasterPolicyAgreementNumber.Items.Clear();

        //        if (_dt != null && _dt.Rows.Count > 0)
        //        {

        //            ddlMasterPolicyAgreementNumber.DataSource = _dt;
        //            ddlMasterPolicyAgreementNumber.DataTextField = "InsurerMasterAgreementNo";
        //            ddlMasterPolicyAgreementNumber.DataValueField = "InsurerMasterAgreementNo";
        //            ddlMasterPolicyAgreementNumber.DataBind();
        //            ddlMasterPolicyAgreementNumber.Items.Insert(0, new ListItem("--Select--", "0"));
        //            if (_dt.Rows.Count == 1)
        //            {
        //                ddlMasterPolicyAgreementNumber.SelectedIndex = 1;
        //            }
        //            else
        //            {
        //                ddlMasterPolicyAgreementNumber.SelectedIndex = 0;
        //            }
        //        }
        //        else
        //        {
        //            ddlMasterPolicyAgreementNumber.Items.Insert(0, new ListItem("--Select--", "0"));
        //            ddlMasterPolicyAgreementNumber.SelectedIndex = 0;
        //        }
        //    }
        //}

        #region"Group Name Text Changed"
        /// <summary>
        /// Group Name Text Change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void txtGroupName_TextChanged(object sender, EventArgs e)
        {
            if (txtGroupName.Text != "")
            {
                //FetchHealthGroupDetails();
                GetAllClientDetails();
                //HMode.Value = "";
                //BindMasterAgreementNumber(Convert.ToInt32(hdnGroupID.Value));
            }
            else
            {
                hdnGroupID.Value = "0";

            }
        }
        #endregion

        protected void lnkClearClientName_Click(object sender, EventArgs e)
        {
            txtGroupName.Text = "";
            hdnGroupID.Value = "0";
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
        }

        protected void ddlMasterPolicyAgreementNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ddlMasterPolicyAgreementNumber.Focus();
            GetAllClientDetailsData();
        }

        protected void txtAgreementNumber_TextChanged(object sender, EventArgs e)
        {
            DataTable _dt = new HealthGroup().GetSearchGroupDetailsByAgreementNo(hdnGroupID.Value == "" ? 0 : Convert.ToInt32(hdnGroupID.Value), txtAgreementNumber.Text);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                txtGroupName.Text = _dt.Rows[0]["GroupName"].ToString();
                hdnGroupID.Value = _dt.Rows[0]["GroupID"].ToString();
            }
            else
            {
                txtGroupName.Text = "";
                txtAgreementNumber.Text = "";
                hdnGroupID.Value = "0";
            }
            GroupNameSelectedIndexChanged();
        }

        private void GroupNameSelectedIndexChanged()
        {
            String groupID = hdnGroupID.Value;
            if (groupID.Length == 0)
                groupID = "0";
            GetAllClientDetailsData();
        }
    }
}
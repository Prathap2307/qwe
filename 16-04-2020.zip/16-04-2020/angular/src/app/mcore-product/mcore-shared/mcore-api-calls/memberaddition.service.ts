import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MemberadditionService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }


  postFile(a: any): Observable<any> {
    console.log(a);
    const url = this.baseUrl + '/MemberAdditionUpload';
      return this.http.post<any>(url, a);
  }

  memberAdditionValidateExcelFile(a: any): Observable<any> {
    const url = this.baseUrl + '/MemberAdditionValidateExcelFile';

    const requestOptions: Object = {
      /* other options here */
      responseType: 'text'
    }

      return this.http.post<any>(url, a, requestOptions);
  }

  saveFile(a: any): Observable<any> {

    const url = this.baseUrl + '/SaveUploadedFileAddition';
   
     return this.http.post<any>(url, a);
   }

   migrationGNB(a: any): Observable<any> {
     console.log(a);
    const url = this.baseUrl + '/migrationGNB';
      return this.http.post<any>(url, a);
    }

  
}

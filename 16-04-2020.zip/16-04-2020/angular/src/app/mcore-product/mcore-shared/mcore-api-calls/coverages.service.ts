import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class CoveragesService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }
  

    IsCoverageExistNew(data:any): Observable<any>{
      return this.http.post(this.baseUrl + '/IsCoverageExistNew', data).pipe(tap((response) => response));
    }
    GetLineOfBusiness(): Observable<any>{
      return this.http.get(this.baseUrl + '/getLineOfBusinessCategory').pipe(tap((response) => response));
    }
    // getSearchCoverageDetails(data:any): Observable<any>{
    //   return this.http.get(this.baseUrl + '/getSearchCoverageDetails?coverageName=' + data.benefits+'&description='+data.description).pipe(tap((response) => response));
    // }
    getSearchCoverageDetails(data:any): Observable<any>{
      return this.http.post(this.baseUrl + '/getSearchCoverageDetails',data).pipe(tap((response) => response));
    }
    GetAllCoveragesByLineOfBusiness(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetAllCoveragesByLineOfBusiness?LineOfBusinessId=' + id).pipe(tap((response) => response));
    }

    GetCoverageExclusionByCoverageID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetCoverageExclusionByCoverageID' + id).pipe(tap((response) => response));
    }

    GetAllCoverageUINMapByCoverageID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetAllCoverageUINMapByCoverageID' + id).pipe(tap((response) => response));
    }

    InsertOrUpdateCoverageNew(data:any): Observable<any>{
      console.log("data cove >>",data);
      return this.http.post(this.baseUrl + '/InsertOrUpdateCoverage' , data).pipe(tap((response) => response));
    }

 
    DeleteCoverage(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/DeleteCoverage?CoverageID='+ id+'&DeletedBy=1').pipe(tap((response) => response));
    }

    GetCoverageByCoverageID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetCoverageByID?CoverageID=' + id).pipe(tap((response) => response));
    }
   

   
    
  //   GetLineofBusinessMapByUserID
  //   GetAllProviderType
  //   GetNatureOfServiceByCoverageID


    
    
    
}

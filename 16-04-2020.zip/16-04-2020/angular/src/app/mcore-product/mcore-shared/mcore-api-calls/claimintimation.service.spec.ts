import { TestBed } from '@angular/core/testing';

import { ClaimintimationService } from './claimintimation.service';

describe('ClaimintimationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClaimintimationService = TestBed.get(ClaimintimationService);
    expect(service).toBeTruthy();
  });
});

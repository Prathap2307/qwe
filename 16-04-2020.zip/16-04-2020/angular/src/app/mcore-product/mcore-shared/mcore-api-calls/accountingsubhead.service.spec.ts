import { TestBed } from '@angular/core/testing';

import { AccountingsubheadService } from './accountingsubhead.service';

describe('AccountingsubheadService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AccountingsubheadService = TestBed.get(AccountingsubheadService);
    expect(service).toBeTruthy();
  });
});

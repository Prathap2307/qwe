import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { AddressStructure } from 'src/app/mcore-product/mcore-shared/mcore-entity/addressstructure';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class AddressstructureService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }
  addressStructureUrl = this.baseUrl + '/address';
  // Get Address Structure Details
  getAddressStructureDetails(): Observable<AddressStructure[]> {
    return this.http.get<AddressStructure[]>(this.addressStructureUrl).pipe();
  }
  // Create & Update Address Structure Details
  createAddressStructureUrl = this.baseUrl + '/createAddress';
  addAddressStructureDetails(addStructure: AddressStructure): Observable<AddressStructure> {
    return this.http.post<AddressStructure>(this.createAddressStructureUrl, addStructure);
  }
  // Delete AddressStructure
  deleteAddressStructureDetails(): Observable<{}> {
    const deleteAddressStructureUrl = this.baseUrl + '/deleteAddress';
    return this.http.delete(deleteAddressStructureUrl).pipe();
  }
  
}

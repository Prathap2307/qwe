import { TestBed } from '@angular/core/testing';

import { MemberdeletionService } from './memberdeletion.service';

describe('MemberdeletionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MemberdeletionService = TestBed.get(MemberdeletionService);
    expect(service).toBeTruthy();
  });
});

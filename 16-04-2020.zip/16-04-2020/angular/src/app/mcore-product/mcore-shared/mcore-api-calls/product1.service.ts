import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Product } from 'src/app/mcore-product/mcore-shared/mcore-entity/product1';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private baseUrl = environment.API_URL;
   
    //insurer
    private _getInsurer = this.baseUrl+ '//configuration/insurer/get';

    //benefit-riders
    private _getBenefitRiders = this.baseUrl+ '//configuration/benefit-riders/get';

    //product-type
    private _getProductType = this.baseUrl+ '//product/product-type/get';

    //question
    private _getquestion = this.baseUrl+ '//configuration/question/get';

    //tax-structure
    private _getTaxStructure = this.baseUrl+ '//configuration/tax-structure/get';

    //product-age-proof-document
    private _addProductAgeProofDocument = this.baseUrl+ '//product/product-age-proof-document/save';

    //MasterProduct
    private _getMasterProduct = this.baseUrl+ '//product/master/get';

    //ConfigurationProduct
    private _getConfigurationProduct = this.baseUrl+ '//configuration/product/get';


    //ConfigurationQuestion
    private _getConfigurationQuestion = this.baseUrl+ '//configuration/question/get';
    // this.baseUrl+ '//configuration/question/get';

    //LoadingDiscount
    private _addLoadDiscount = this.baseUrl+ '//configuration/loading-discounting/update';
    private _getLoadDiscount = this.baseUrl+ '//configuration/loading-discounting/get';
    private _deleteLoadDiscount =this.baseUrl+ '//configuration/loading-discounting/delete';
    private _getSingleLoadDiscount =this.baseUrl+ '//configuration/loading-discounting/get';
    private _searchLoadDiscount =this.baseUrl+ '//configuration/loading-discounting/search';



    //riders-factor
    private _getRidersFactor = this.baseUrl+ '/configuration/riders-factor/get';

    //Product
    private _getProduct = this.baseUrl+ '/configuration/line-of-business/get';

    //product-premium-type
    private _getProductPremiumType = this.baseUrl+ '/configuration/product-premium-type/get';
    private _getProductBenefitDiders = this.baseUrl+ '/configuration/product-benefit-riders/get';
    private _searchPremium = this.baseUrl+ '/configuration/premium/get';
    private _addPremium = this.baseUrl+ '/configuration/premium/update';
    private _getSinglePremium = this.baseUrl+ '/configuration/premium/get';
    private _deletePremium = this.baseUrl+ '/configuration/premium/delete';

    //Payment Frequency
    private _addPaymentFreq =this.baseUrl+ '/configuration/premium-payment-frequency/update';
    private _getPaymentFreq =this.baseUrl+ '/configuration/premium-payment-frequency/get';
    private _getSinglePayment =this.baseUrl+ '/configuration/premium-payment-frequency/get';
    private _delPayment =this.baseUrl+ '/configuration/premium-payment-frequency/delete';
    private _searchPayment =this.baseUrl+ '/configuration/premium-payment-frequency/search';

    // Variant
    private _addVariant =this.baseUrl+ '/configuration/product/update';
    private _getVariant =this.baseUrl+ '/configuration/product/get';
    private _getSingleVariant =this.baseUrl+ '/configuration/product/get';
    private _delVariant =this.baseUrl+ '/configuration/product/delete';
    private _searchVariant =this.baseUrl+ '/configuration/product/search';

  constructor(
    private http: HttpClient
  ) { }

  //insurer
  getInsurer()
  {
    return this.http.get<any>(this._getInsurer)
  }

  //benefit-riders
  getBenefitRiders()
  {
    return this.http.get<any>(this._getBenefitRiders)
  }

  //product-type
  getProductType()
  {
    return this.http.get<any>(this._getProductType)
  }

  //question

  getquestion()
  {
    return this.http.get<any>(this._getquestion)
  }

  //tax-structure
  getTaxStructure()
  {
    return this.http.get<any>(this._getTaxStructure)
  }

  //product-age-proof-document
  addProductAgeProofDocument(data){
    return this.http.post<any>(this._addProductAgeProofDocument, data);
  }

  //ConfigurationQuestion
  // getConfProduct()
  // {
  //   return this.http.get<any>(this._getConfigurationProduct)
  // }
  getConfProduct(): Observable<any>{
    return this.http.get(this._getConfigurationProduct);
  }

  //ConfigurationQuestion
  getConfQuestion(data)
  {
    return this.http.get<any>(this._getConfigurationQuestion + '/' + data)
  }

  //LoadingDiscount

  addLoadDiscount(data){
    return this.http.post<any>(this._addLoadDiscount, data);
  }

  getLoadDiscount()
  {
    return this.http.get<any>(this._getLoadDiscount)
  }

  deleteLoadDiscount(id,deletedBy)
  {
    return this.http.delete<any>(this._deleteLoadDiscount + '/' + id + '/' + deletedBy);
   }

  getSingleLoadDiscount(id)
  {
    return this.http.get<any>(this._getSingleLoadDiscount + '/' + id);
  }

  SearchLoadDiscount(data){
    return this.http.post<any>(this._searchLoadDiscount, data);
  }




  //riders-factor
  getRidersFactor()
  {
    return this.http.get<any>(this._getRidersFactor)
  }

   //riders-factor
  //  getProduct()
  //  {
  //    return this.http.get<any>(this._getProduct)
  //  }

   
  productUrl = this.baseUrl + '/configuration/product/getAllProduct';
  getProduct(): Observable<any> {
    console.log(this.productUrl);
    return this.http.get(this.productUrl).pipe();
  }

  //ConfigurationProduct
  getMasterProduct()
  {
    return this.http.get<any>(this._getMasterProduct)
  }

 
  //Payment frequency

    savePayment(data)
    {
      return this.http.post<any>(this._addPaymentFreq,data);
    }

    getPayment()
    {
      return this.http.get<any>(this._getPaymentFreq);
    }

    getSinglePayment(id)
    {
      return this.http.get<any>(this._getSinglePayment + '/' + id);

    }
    deletePayment(id, deletedBy){
      return this.http.delete<any>(this._delPayment + '/' + id + '/' + deletedBy);
    }
   
    searchPayment(data){
      return this.http.post<any>(this._searchPayment, data);
    }


    //ProductPremiumType
    getProductPremiumType(id)
    {
      return this.http.get<any>(this._getProductPremiumType + '/' + id)
    }

    //ProductBenefitDiders
    getProductBenefitDiders(variantId, typeId,lineOfBussinessId)
    {
     
      return this.http.get<any>(this._getProductBenefitDiders + '/' + variantId + '/' + typeId + '/' + lineOfBussinessId);
    }

    //     GetAllCoveragesByLineOfBusiness(id:any): Observable<any>{
    //   return this.http.get(this.baseUrl + '/GetAllCoveragesByLineOfBusiness?LineOfBusinessId=' + id).pipe(tap((response) => response));
    // }

    //Premium
    searchPremium(data)
    {
      return this.http.post<any>(this._searchPremium,data);
    }

  //Premium
  addPremium(data)
  {
    return this.http.post<any>(this._addPremium, data)
  }

    getSinglePremium(id)
    {
      return this.http.get<any>(this._getSinglePremium + '/' + id)
    }

    deletePremium(id, deletedBy){
      return this.http.delete<any>(this._deletePremium + '/' + id + '/' + deletedBy);
    }

  // Variant

  addVariant(data)
  {
    return this.http.post<any>(this._addVariant, data)
  }
  getVariant()
  {
    return this.http.get<any>(this._getVariant);
  }
  getSingleVariant(id)
  {
    return this.http.get<any>(this._getSingleVariant + '/' + id)
  }
  deleteVariant(id, deletedBy){
    return this.http.delete<any>(this._delVariant + '/' + id + '/' + deletedBy);
  }
  searchVariant(data){
    return this.http.post<any>(this._searchVariant, data);
  }




  // productUrl =this.baseUrl+ '//product';

  // createproductUrl =this.baseUrl+ '//createproduct';
  // addProduct(productRow: Product): Observable<Product> {
  //   console.log(this.createproductUrl);
  //   console.log(productRow);
  //   return this.http.post<Product>(this.createproductUrl, productRow);    
  // }

  // getProductDetails(): Observable<Product[]> {
  //   console.log(this.productUrl);
  //   return this.http.get<Product[]>(this.productUrl).pipe();
  // }
   
  // updateProduct(productRow: Product): Observable<void> {
  //   console.log(productRow);
  //   const updateProductUrl = this.baseUrl + `/createproduct/${productRow.productid}`;
  //   console.log(updateProductUrl);
  //   return this.http.put<void>(this.productUrl, productRow).pipe(catchError(this.handleError));
  // }

  // deleteProduct(productid: number): Observable<{}> {
  //   const deleteProductUrl = this.baseUrl + `/productDelete/${productid}`;
  //   return this.http.delete(deleteProductUrl).pipe();
  // }


  // getProductInfoByDescription(description: string): Observable<Product[]> {
  //   const productByIDUrl = this.baseUrl + `/department/${description}`;
  //   console.log(productByIDUrl);
  //   return this.http.get<Product[]>(productByIDUrl).pipe();
  // }

  // getProductInfoByProductName(productname: string): Observable<Product[]> {
  //   const productByIDUrl = this.baseUrl + `/product/${productname}`;
  //   console.log(productByIDUrl);
  //   return this.http.get<Product[]>(productByIDUrl).pipe();
  // }

  // Error Handling
  handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput <any> {
    throw new Error("Method not implemented.");
  }
  consoleLogFn(val) {
    console.log(val);
  }

}


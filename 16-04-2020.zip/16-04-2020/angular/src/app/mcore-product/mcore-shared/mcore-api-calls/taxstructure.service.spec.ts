import { TestBed } from '@angular/core/testing';

import { TaxstructureService } from './taxstructure.service';

describe('TaxstructureService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TaxstructureService = TestBed.get(TaxstructureService);
    expect(service).toBeTruthy();
  });
});

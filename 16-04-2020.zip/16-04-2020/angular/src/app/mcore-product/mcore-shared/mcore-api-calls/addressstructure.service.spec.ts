import { TestBed } from '@angular/core/testing';

import { AddressstructureService } from './addressstructure.service';

describe('AddressstructureService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddressstructureService = TestBed.get(AddressstructureService);
    expect(service).toBeTruthy();
  });
});

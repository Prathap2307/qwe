import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class StampdutyService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }
  GetStampdutybyId(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetStampDutyByStampDutyID?StampDutyID=' + id).pipe(tap((response) => response));
  }

  GetAllStampduty(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllStampDuty').pipe(tap((response) => response));
  }

  IsStampdutyExistForNB(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/IsStampDutyExistForNB' + id).pipe(tap((response) => response));
  }

  IsStampdutyExist(data: any): Observable<any> {
    console.log(data)
    return this.http.post(this.baseUrl + '/IsStampDutyExist',data).pipe(tap((response) => response));
  }

  InsertOrUpdateStampduty(data: any): Observable<any> {
    console.log(data)
    return this.http.post(this.baseUrl + '/InsertUpdateStampDuty' , data).pipe(tap((response) => response));
  }

  DeleteStampDuty(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/DeleteStampDuty?StampDutyID=' + id).pipe(tap((response) => response));
  }



}

export interface DepartmentType {
    departmentId: number;
    description: string;
    shortName: string;
    createdBy: number;
    createdOn: Date;
    deletedBy:  number;
    deletedOn:  Date;
}
// export interface Organization {
// 	organisationId: number,
// 	shortName: string,
// 	organisationName: string,
// 	countryId: string,
// 	countryCode: number,
// 	shortDescription: string,
// 	isDeclined: number,
// 	tinNumber: string,
// 	stateId: number,
// 	description: string,
// 	districtId: number,
// 	zipCode: string,
// 	postOfficeId: number
// }

export interface Organization
{
    organisationId: number,
    shortName: string,
    organisationName: string,
    passwordExpiry: number,
    noOfDays: number,
    address1: string,
    address2: string,
    address3: string,
    countryId: number,
    stateId: number,
    districtId: number,
    talukId: number,
    zipCode: string,
    phoneNo: string,
    mobileNo: string,
    conferenceNo: string,
    faxNo: string,
    email: string,
    isActive: number,
    gstNo: number,
    panNo: number,
    sacCode: string,
    createdBy: number,
    createdOn: Date
}
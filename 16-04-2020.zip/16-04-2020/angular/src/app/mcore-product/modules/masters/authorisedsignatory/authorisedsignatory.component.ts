import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthorizedsignatoryService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/authorizedsignatory.service';
import { DesignationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/designation.service';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
// import { RxwebValidators } from '@rxweb/reactive-form-validators';

@Component({
  selector: 'app-authorisedsignatory',
  templateUrl: './authorisedsignatory.component.html',
  styleUrls: ['./authorisedsignatory.component.css']
})
export class AuthorisedsignatoryComponent implements OnInit {
  SearchAuthorisedsignatory: FormGroup;
  AddAuthorisedSignatory: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  SubchannelHeading: string = "Add New -Authorised Signatory";
  saveBtnMode: boolean = true
  view: boolean = false;
  textSaveBtn: string = "Save";
  display: string;
  BRANCH = [
    { Id: '2', Name: 'Bangalore' },
    { Id: '3', Name: 'Kolkata' },
    { Id: '4', Name: 'Mumbai' }
  ]
  module: any;
  transaction: string;
  success: boolean;
  id: boolean;
  present: any;
  exist: boolean;
  authsign: any;
  authsignobj: any;
  designationDDObj: Designation[];
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  authorisedSignatoryID: any;
  uploaded: boolean;

  constructor(private fb: FormBuilder,private designationService: DesignationService, public AuthoriseService: AuthorizedsignatoryService) { }

  ngOnInit() {
    let auth = {
      "AuthorisedSignatoryID": 0,
      "Name": ""
    }
    this.getDesignationDetails()
    this.getmodule()
    // this.GetAllAuthorisedSignatories()
    this.GetAllAuthorisedSignatory(auth)
    this.SearchAuthorisedsignatory = this.fb.group({
      AuthorisedSignatoryID: [0],
      Name: ['']

    })

    this.AddAuthorisedSignatory = this.fb.group({

      AuthorisedSignatoryID: [''],
      ModuleID: ['', Validators.required],
      Name: ['', Validators.required],
      Designation: ['', Validators.required],
      Email: ['', [Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
      ContactMobileNo: ['', Validators.required],
      IsActive: [''],
      // Signature: ['', [
      //   RxwebValidators.image({ maxHeight: 100, maxWidth: 100 }),
      //   RxwebValidators.extension({ extensions: ["jpeg", "gif"] })
      // ]],
      Signature: ['',],
      // imgSignature  : ['null'], 
      CreatedBy: ['null'],
      // CreatedOn: [''],

      // MODIFIEDBY      NUMBER  Yes
      // MODIFIEDON      TIMESTAMP(6)    Yes
      // DELETEDBY       NUMBER  Yes
      // DELETEDON       TIMESTAMP(6)    Yes
      // ISACTIVE        NUMBER  No\




    })
  }


  //  ================service==========================


  getmodule() {

    this.AuthoriseService.GetAllModules()
      .subscribe(result => {
        console.log(result)
        this.module = result.data
      });
  }

  GetAllAuthorisedSignatories() {
    this.AuthoriseService.GetAllAuthorisedSignatories()
      .subscribe(result => {
        console.log(result)
        this.authsign = result.data
      });

  }

  GetAllAuthorisedSignatory(auth) {
    this.AuthoriseService.GetAllAuthorisedSignatory(auth)
      .subscribe(result => {
        console.log(result)
        this.authsign = result.data
        if (this.authsign && this.authsign.length > 0) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.authsign.length
          }
        }
      });

  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }



  get a() { return this.SearchAuthorisedsignatory.controls; }

  onBtnSearchClick() {
    this.submitted1 = true;
    console.log(this.SearchAuthorisedsignatory.value)
    this.GetAllAuthorisedSignatory(this.SearchAuthorisedsignatory.value)
  }
  clearsearch() {
    this.SearchAuthorisedsignatory.reset()
    let auth = {
      "AuthorisedSignatoryID": 0,
      "Name": ""
    }
    this.GetAllAuthorisedSignatory(auth)
  }
  clear() {
    this.AddAuthorisedSignatory.reset();
    this.SubchannelHeading = 'Add - Authorised Signatory';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }

  get d() { return this.AddAuthorisedSignatory.controls; }

  IsAuthorisedSignatoryExist(data: any) {
    this.AuthoriseService.IsAuthorisedSignatoryExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === "NOTEXIST") {
          this.AuthoriseService.addsignatory(this.AddAuthorisedSignatory.value)
            .subscribe(result => {
              console.log(result)
              this.success = true
              if (this.textSaveBtn === 'Save') {
                this.transaction = "Created"
              } else {
                this.transaction = "Updated"
              }

              let auth = {
                "AuthorisedSignatoryID": 0,
                "Name": ""
              }
              this.GetAllAuthorisedSignatory(auth)
              this.openModalDialog()
              this.AddAuthorisedSignatory.reset()
              this.clear()
            });
        }
        else {
          this.exist = true
          this.present = result.data
          this.openModalDialog()
        }

      });
  }

  onBtnSave() {
    this.submitted = true;
    // this.AddAuthorisedSignatory.value['CreatedOn'] = null
    this.AddAuthorisedSignatory.value['CreatedBy'] = 1
    if (this.id && this.textSaveBtn === 'Update') {
      console.log(this.id)
      this.AddAuthorisedSignatory.value["AuthorisedSignatoryID"] = this.id
    }
    else {
      this.AddAuthorisedSignatory.value['AuthorisedSignatoryID'] = 0
    }
    console.log(this.AddAuthorisedSignatory.value)
    if(this.AddAuthorisedSignatory.valid){
      this.IsAuthorisedSignatoryExist(this.AddAuthorisedSignatory.value)
    }
   
  }
  setIdDelete(data){
    this.authorisedSignatoryID=data.authorisedSignatoryID
  }
  
  delete() {
   
    let auth = {
      "AuthorisedSignatoryID":this.authorisedSignatoryID,
      "CreatedBy": 1
    }
    console.log(auth)
    this.AuthoriseService.DeleteAuthorisedSignatory(auth)
      .subscribe(result => {
        console.log(result)
        let auth = {
          "AuthorisedSignatoryID": 0,
          "Name": ""
        }
        this.GetAllAuthorisedSignatory(auth)
      }
      )
  }
  btngEdit_Click(a) {
    console.log(a)
    this.SubchannelHeading = 'Edit - Authorised Signatory';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.id = a.authorisedSignatoryID
    this.getsignatoryById(a)
  }
  getsignatoryById(a) {
    let auth = {
      "AuthorisedSignatoryID": a.authorisedSignatoryID,
      "Name": a.name
    }
    this.AuthoriseService.GetAllAuthorisedSignatory(auth)
      .subscribe(result => {
        console.log(result)
        this.authsignobj = result.data[0]
        if (this.authsignobj) {
          console.log(this.AddAuthorisedSignatory.value)

          this.AddAuthorisedSignatory = this.fb.group({
            AuthorisedSignatoryID: [{ value: this.authsignobj.authorisedSignatoryID, disabled: false }],
            ModuleID: [{ value: this.authsignobj.moduleID, disabled: false }, Validators.required],
            Name: [{ value: this.authsignobj.name, disabled: false }, Validators.required],
            Designation: [{ value: this.authsignobj.designation, disabled: false }, Validators.required],
            Email: [{ value: this.authsignobj.email, disabled: false }, [Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
            ContactMobileNo: [{ value: this.authsignobj.contactMobileNo, disabled: false }, Validators.required],
            IsActive: [{ value: this.authsignobj.isActive, disabled: false }],
            Signature: [{ value: this.authsignobj.signature, disabled: false }],
            imgSignature: [{ value: this.authsignobj.imgSignature, disabled: false }],

          })
          console.log(this.AddAuthorisedSignatory.value)
        }
      });

  }
  btngView_Click(a) {
    this.SubchannelHeading = 'View - Authorised Signatory';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.id = a
    this.getsignatoryById(a)
  }
  upload() {
    this.uploaded = true
    this.openModalDialog()
  }
  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    this.AddAuthorisedSignatory.reset()
  }

  getDesignationDetails(): void {
    this.designationService.getDesignationDetails(0, null)
      .subscribe(a => {
        console.log(a)
        this.designationDDObj = a;
      });
  }
  mobValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.success=false;
    this.exist=false
  }
  get EmailError() {
    if (this.AddAuthorisedSignatory.controls['Email'].hasError('required')) {
      return 'Please enter the E-Mail ID.';
    } else if (this.AddAuthorisedSignatory.controls['Email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }
}

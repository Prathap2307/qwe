import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxstructureComponent } from './taxstructure.component';

describe('TaxstructureComponent', () => {
  let component: TaxstructureComponent;
  let fixture: ComponentFixture<TaxstructureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaxstructureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxstructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

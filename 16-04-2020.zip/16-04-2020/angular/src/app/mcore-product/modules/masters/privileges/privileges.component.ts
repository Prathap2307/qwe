import { Component, OnInit } from '@angular/core';
import { MatCheckboxChange } from '@angular/material';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { GroupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/group.service';
import { AuthorizedsignatoryService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/authorizedsignatory.service';
@Component({
  selector: 'app-privileges',
  templateUrl: './privileges.component.html',
  styleUrls: ['./privileges.component.css']
})
export class PrivilegesComponent implements OnInit {
  view: boolean;
  search: boolean;
  add: boolean;
  edit: boolean;
  delete: boolean;
  show: boolean = false;
  Privilegesform: FormGroup;
  allfeatures: any;
  getallgroup: any;
  alluser: any;
  module: any;
  organisationID: string;


  constructor(private fb: FormBuilder, public AuthoriseService: AuthorizedsignatoryService,private GroupService: GroupService, private user: UserService) { }

  ngOnInit() {
    console.log(localStorage.getItem('organisationID'))
    this.organisationID=localStorage.getItem('organisationID')
    this.getalllfeatures()
    
    this.Privilegesforminit()
  }
  Privilegesforminit() {

    this.Privilegesform = this.fb.group({
      moduleID: [''],
      type: [''],
      lineOfBusinessID: [''],

    })
  }
  GetAllGroup(data:any) {
    this.GroupService.GetAllGroupsByOrg(data)
      .subscribe(result => {
        console.log(result)
        this.getallgroup = result.data
      })
  }
  getalluser() {
    let data = {
      "organisationID":  this.organisationID,
      "parentBranchID": 0,
      "firstName": "",
      "lastName": "",
      "loginName": "",
      "employeeNo": "",
      "departmentID": 0,
      "designationID": 0,
      "branchID": 0,
      "reportingTo": 0
    }
    this.user.GetAllUserBySearch(data)
      .subscribe(result => {
        console.log(result)
        this.alluser = result.data.GetUserEmployeeModel
        console.log(this.alluser)
      })
  }
  getmodule() {

    this.AuthoriseService.GetAllModules()
      .subscribe(result => {
        console.log(result)
        this.module = result.data
      });
  }
  type(event: any) {
    console.log(event.target.value)
    if (event.target.value === "1") {
      this.getallgroup =[]
      this.getalluser()
      this.getmodule()

    }
    else if(event.target.value === "2") {
      this.alluser=[]
      let data = {
        "OrganisationID":  this.organisationID,
        "Description": ""
      }
      this.GetAllGroup(data)
      this.getmodule()
    }

  }
  onChange(value: { checked: boolean; }, id: any) {
    console.log(value)
    let activate_d = {
      "OrganisationID":  this.organisationID,
      "BranchID": id,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 2
    }
    if (value.checked === true) {
      activate_d["isActive"] = 1
      console.log(1);
    } else {
      activate_d["isActive"] = 0
      console.log(0);
    }
  }
  allowView(event: MatCheckboxChange, featureID): void {
    console.log(event.checked);
    let data = this.allfeatures.find(x => x.featureID === featureID)
    // this.view = event.checked
    if (event.checked) {
      this.view = event.checked
    }
    else {
      data.view = false
      data.search = false
      data.add = false
      data.edit = false
      data.delete = false
    }
  }
  allowSearch(event: MatCheckboxChange, featureID): void {
    console.log(event.checked);
    let data = this.allfeatures.find(x => x.featureID === featureID)
    if (event.checked) {
      data.search = event.checked
      data.view = event.checked
    }
    else {
      data.search = false
      data.add = false
      data.edit = false
      data.delete = false

    }
  }
  allowAdd(event: MatCheckboxChange, featureID): void {
    console.log(event.checked);
    let data = this.allfeatures.find(x => x.featureID === featureID)
    if (event.checked) {
      data.view = event.checked
      data.search = event.checked
      data.add = event.checked
    }
    else {
      data.add = false
      data.edit = false
      data.delete = false
    }
  }
  allowEdit(event: MatCheckboxChange, featureID): void {
    console.log(this.allfeatures.find(x => x.featureID === featureID))
    let data = this.allfeatures.find(x => x.featureID === featureID)
    console.log(event.checked);
    if (event.checked) {
      data.view = event.checked
      data.search = event.checked
      data.add = event.checked
      data.edit = event.checked
    }
    else {
      data.edit = false
      data.delete = false
    }
  }
  allowDelete(event: MatCheckboxChange, featureID: any): void {
    console.log(event.checked);
    let data = this.allfeatures.find(x => x.featureID === featureID)
    if (event.checked) {
      data.view = event.checked
      data.search = event.checked
      data.add = event.checked
      data.edit = event.checked
      data.delete = event.checked
    }
    else {
      data.delete = false
    }
  }
  select() {
    console.log(this.show)
    this.show = true
  }
  getalllfeatures() {
    this.user.GetUserGroupModulesFeaturesRolesByID()
      .subscribe(result => {
        console.log(result)
        this.allfeatures = result.data
        for (let i = 0; i < this.allfeatures.length; i++) {
          if (this.allfeatures[i]["userRoles"] === "11111" || this.allfeatures[i]["groupRoles"] === "11111") {
            this.allfeatures[i]["delete"] = true
            this.allfeatures[i]["edit"] = true
            this.allfeatures[i]["add"] = true
            this.allfeatures[i]["search"] = true
            this.allfeatures[i]["view"] = true
          }
        }
      }
      )
  }
  save() {
    for (let i = 0; i < this.allfeatures.length; i++) {
      if (this.allfeatures[i]["delete"] == true) {
        this.allfeatures[i]["userRoles"] = "11111"
      }
      else if (this.allfeatures[i]["edit"] === true) {
        this.allfeatures[i]["userRoles"] = "0111"
      }
      else if (this.allfeatures[i]["add"] === true) {
        this.allfeatures[i]["userRoles"] = "00111"
      }
      else if (this.allfeatures[i]["search"] === true) {
        this.allfeatures[i]["userRoles"] = "00011"
      }
      else if (this.allfeatures[i]["view"] === true) {
        this.allfeatures[i]["userRoles"] = "00001"
      }
      else {
        this.allfeatures[i]["userRoles"] = "00000"
      }
    }
    console.log(this.allfeatures)
    let data = {
      "privilegesmodalDetails": this.allfeatures
    }
    this.user.InsertPrivileges(data)
      .subscribe(result => {
        console.log(result)
      })
  }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Claimintimation, BeneficiaryDetails, AdditionalDocument, MandatoryDocument, DocumentUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/claimintimation';
import { ClaimintimationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/claimintimation.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';

@Component({
  selector: 'app-claimintimation',
  templateUrl: './claimintimation.component.html',
  styleUrls: ['./claimintimation.component.css']
})
export class ClaimintimationComponent implements OnInit {
  dummyObj: string;
  element: string;
  divDisplay: Boolean;
  groupNameObj: MemberUpload[];
  tableColumns: string[] = ['View', 'policyNumber', 'insuredNumber', 'policyStatus', 'sumInsured'];
  tableColumnsOne: string[] = ['edit', 'delete', 'documentType', 'image'];
  claimIntimationSearchColumns: string[] = ['Select', 'masterPolicyNumber', 'clientName', 'certificateHolderName', 'policyNumber', 'employeeID', 'memberID', 'sumAssured'];
  ClaimIntimationForm: FormGroup;
  //ClaimIntimationFormAction: FormGroup;
  ClaimIntimationObj: any[];
  causeOfDeathObj: any;
  relationshipDeceasedObj: any;
  ClaimIntimationdataSource = new MatTableDataSource<Claimintimation>(this.ClaimIntimationObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.ClaimIntimationdataSource.paginator = this.paginator;
  }

  // get ClaimIntimationFormAction() {
  //   return this.ClaimIntimationForm.get('ClaimIntimationFormAction') as FormGroup;
  // }

  get ClaimIntimationFormSearch() {
    return this.ClaimIntimationForm.get('ClaimIntimationFormSearch') as FormGroup;
  }

  constructor(private fb: FormBuilder, private memberupload: MemberuploadService, private claimIntimationService: ClaimintimationService) { }

  ngOnInit() {
    this.divDisplay = false;
    this.Validation();
    this.getGroupDetails();
    this.getAllCauseOfDeath();
    this.getRelationshipDeceased();
  }

  getGroupDetails() {
    let a = this.ClaimIntimationFormSearch.value;
    this.memberupload.getGroupDetails(a).subscribe(a => {
      this.groupNameObj = a;
    });
  }

  getmasterPolicyDetails() {
    let groupID = this.ClaimIntimationFormSearch.get('groupID').value;
    this.memberupload.getmasterPolicyDetails(groupID).subscribe(a => {
      this.ClaimIntimationObj = a;
    });
  }

  getAllCauseOfDeath() {
    this.claimIntimationService.getAllCauseOfDeath()
      .subscribe(data => {
        this.causeOfDeathObj = data;
      });
  }

  getRelationshipDeceased() {
    this.claimIntimationService.getRelationshipDeceasedDetails()
      .subscribe(data => {
        this.relationshipDeceasedObj = data;
      });
  }

  Validation() {
    this.ClaimIntimationForm = this.fb.group({
      ClaimIntimationFormSearch: this.fb.group({
        groupID: ['', [Validators.required]],
        masterPolicyNumber: ['', [Validators.required]],
        agreementNumber: ['', [Validators.required]],
        // searchgroupID: ['', [Validators.required]],
        // searchMasterPolicyNo: ['', [Validators.required]],
        // searchAgreementNo: ['', [Validators.required]],
        searchPolicyNo: [''],
        searchInsuredFirstName: [''],
        searchEmployeeId: [''],
        searchMemberId: [''],
      }),
      ClaimIntimationFormAction: this.fb.group({
        //   selectClaim: [''],
        //   certificateNo: [''],
        //   memberName: [''],
        //   companyName: [''],
        //   sumAssured: [''],
        //   plan: [''],
        //   dateofJoining: [''],
        //   dateofEvent: [''],
        //   claimIntimationDate: [''],
        //   locationofDeath: [''],
           causeofDeath: [''],

        //   beneficiaryName: [''],
        //   beneficiaryAccountHolderName: [''],
        //   relationshipWithDeceased: [''],
        //   ifscCode: [''],
        //   accountType: [''],
        //   bankName: [''],
        //   accountNo: [''],
        //   contactNo: [''],
        //   emailId: [''],
        //   share: [''],
        //   claimAmountbasedonShare: [''],

        //   newRequirementAdded: [''],
        //   documentName: [''],

        //   checklistofMandatoryDocument: [''],

        //   documentTypeId: [''],
        //   poiuytrewq: [''],
      })
    });
  }

  SearchClaimIntimation() {
    this.ClaimIntimationForm.controls.ClaimIntimationFormSearch.markAllAsTouched();
    if (this.ClaimIntimationForm.get('ClaimIntimationFormSearch').valid) {
      console.log('valid');
      let a = this.ClaimIntimationForm.controls.ClaimIntimationFormSearch.value;
      this.divDisplay = true;
      console.log(a);
      this.ClearSearchClaimIntomation();
    }
  }

  getDefectDataDetails() {
    // let masterPolicyNo = this.ClaimIntimationForm.get('ClaimIntimationFormAction.searchbankId').value;
    // this.getBankBranchCitydetails(bankId);
    // this.claimIntimationService.getSearchClaimIntimationDetails().subscribe(
    //   claimSearchDataObj => {
    //     this.ClaimIntimationdataSource = new MatTableDataSource<Claimintimation>(this.ClaimIntimationObj);
    //   this.ClaimIntimationdataSource.data = this.ClaimIntimationObj = claimSearchDataObj;
    //     this.ClaimIntimationdataSource.paginator = this.paginator;
  }

  SearchClearClaimIntimation() {
    this.ClearSearchClaimIntomation();
  }

  ClearSearchClaimIntomation() {
    this.ClaimIntimationForm.controls.ClaimIntimationFormSearch.reset();
    this.divDisplay = false;
  }
}

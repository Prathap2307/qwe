import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MomentDateModule } from '@angular/material-moment-adapter';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product.service';
import { LookupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/lookup.service';
import { MasterPolicyService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/master-policy.service';

import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import * as moment from 'moment';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
import { GradeService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/grade.service';
import { CommisionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/commision.service';
@Component({
  selector: 'app-masterpolicy',
  templateUrl: './masterpolicy.component.html',
  styleUrls: ['./masterpolicy.component.css']
})
export class MasterpolicyComponent implements OnInit {
  @ViewChild('picker', { static: true }) picker;
  // dummyObj: string[];
  displayedColumns: string[] = ['View', 'Edit', 'Delete', 'MasterPolicyNumber', 'AgreementNumber', 'MasterPolicyInception', 'MasterPolicyExpiry', 'TotalMembers', 'SumAssured', 'MasterPolicyDate', 'Ageing', 'Status'];
  dataSource = ELEMENT_DATA;

  displayedColumnsOne: string[] = ['Edit', 'Delete', 'UnitName', 'PANNumber', 'GSTIN', 'AddressOne', 'AddressTwo', 'AddressThree', 'Country', 'State', 'District', 'PostOffice', 'Pincode'];
  dataSourceOne = ELEMENTS_DATAS;

  displayedColumnsTwo: string[] = ['Edit', 'Delete', 'AddressOne', 'AddressTwo'];
  dataSourceTwo = ELEMENTS_DATA_ONE;

  displayedColumnsThree: string[] = ['View', 'Edit', 'Delete', 'RiderName', 'FreeCoverLimit', 'Description', 'VariantType', 'SumAssured', 'Grade', 'MultipleSalaries', 'MinimumCap', 'MaximumCap', 'BaseBenefit', 'RetirementAge'];
  dataSourceThree;
  displayedColumnsFive: string[] = ['Status', 'Remarks', 'CreatedBy', 'CreatedOn', 'ModifiedBy', 'ModifiedOn', 'ApprovedBy', 'ApprovedOn'];
  dataSourceFive;
  displayedColumnsFour: string[] = ['RuleSetName', 'BaseAdditional', 'InfluentialValue', 'AmountType', 'ActualPremiumValue', 'PremiumValue'];
  dataSourceFour


  MasterPolicyDetailed: FormGroup;
  AddressDetails: FormGroup;
  UnitDetails: FormGroup;
  AddBenefit: FormGroup;
  submitted: boolean;
  AddAdressform: boolean;
  submitted1: boolean;
  AddunitAdressform: boolean = false;
  submitted2: boolean;
  PremiumDetails: FormGroup;
  submitted3: boolean;
  msg: any;
  display: string = 'none';
  AddressDetailsarray = [];
  UnitDetailsarray = [];
  AddBenefitarray = [];
  openOtherBenefits: boolean;
  fieldDisable: boolean = true
  dummyObj =
    [{ ID: '1', Name: 'abc' },
    { ID: '2', Name: 'abcd' },
    { ID: '3', Name: 'abc34' },
    { ID: '4', Name: 'abc4' }
    ];

  client = [{ ID: 1, Name: 'Regular Customer' },
  { ID: 2, Name: 'SEZ Customer' },]
  gst = [{ ID: 1, Name: 'GST' },
  { ID: 2, Name: 'NO GST' },]
  sezgst_ = [{ ID: 3, Name: 'GST Payable ' },
  { ID: 4, Name: 'NO GST Payable' },]
  zone = [{ ID: '1', Name: 'South Zone' },
  { ID: '2', Name: 'West Zone' }];
  varientType = [{ ID: '1', Name: 'Flat Sum Assured' }, { ID: '2', Name: 'Multiple Of Salary' }, { ID: '3', Name: 'Graded Cover' },
  { ID: '4', Name: 'Future Service Gratuity Amount' }, { ID: '5', Name: 'Rider' }, { ID: '6', Name: 'Graded Cover Salary Multiple' }, { ID: '7', Name: 'Customer Defined SA' }]
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  MasterPolicyDetailedarray = [];
  salutation: any;
  productObj: any;
  showgst: { ID: Number; Name: string; }[] = [];
  paymentFrequencyArr: any;
  variantArr: any;
  productPremiumTypeArr: any;
  IsgstType: boolean;
  show: boolean;
  filteredItems: any;
  items: any;
  change: boolean;
  country: any;
  state: any;
  District: any;
  Taluka: any;
  pinobj: any;
  country1: any;
  state1: any;
  District1: any;
  Taluka1: any;
  griddata: any[] = [];
  searchform: FormGroup;
  autocompletedata: any;
  agreementdata: { groupId: any; agreementNumber: any; };
  agreementno: any;
  formobj: any;
  addressType: any;
  typeId: any;
  productBenefitRidersArr: any;
  variantId: any;
  organisationID: string;
  gradeObj: any;
  Flatsum: boolean;
  MultiplesOfSalary: boolean;
  grade: boolean;
  future: boolean;
  basebenefit: boolean;
  gradesalary: boolean;
  customerdefined: boolean;
  unit: boolean;
  salesobj: any;
  allchannel: any;
  allsubchannel: any;
  /* displayedColumnsThree: string[] = ['View', 'Edit', 'Delete', 'RiderName', 'FreeCoverLimit'];
  
  displayedColumnsFour: string[] = ['RuleSetName', 'BaseAdditional ', 'InfluentialValue'];
  
  
  displayedColumnsFive: string[] = ['Status', 'Remarks', 'CreatedBy', 'CreatedOn']; */



  constructor(
    private fb: FormBuilder, private gradeService: GradeService, private CommissionService: CommisionService, private BranchService: BranchService, private fchannelService: FchannelService, private user: UserService, private masterpolicyservice: MasterPolicyService, private _productService: ProductService, private productService: ProductService, private _lookupService: LookupService,
  ) { }

  ngOnInit() {

    console.log(localStorage.getItem('organisationID'))
    this.organisationID = localStorage.getItem('organisationID')
    this.getallchannel()
    this.getFrequency()
    this.getGradeDetails()
    this.getProductDetails()
    this.GetAllSalutation()
    this.getariant()
    this.getaddresstype()
    this.GetAllcountries()
    this.GetAllcountries1()
    this.searchform = this.fb.group({

    })
    this.MasterPolicyDetailed = this.fb.group({
      //  ClientName:['', Validators.required],
      totallives: [''],//
      masterpolicyno: ['',],//
      insurermasteragreementno: ['', Validators.required],//
      description: [''],//
      quotationid: ['', Validators.required],//
      groupid: ['', Validators.required],//
      groupName: ['', Validators.required],//
      clientnameunit: [''],//
      contactpersonfirstname: ['', Validators.required],//
      contactpersonmiddlename: [''],//
      contactpersonlastname: [''],
      contactnumber: ['', Validators.required],//
      emailId: ['', [Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],//
      totalmembers: ['', Validators.required],//
      suminsured: ['', Validators.required],//
      agreementstartdate: ['', Validators.required],//
      agreementenddate: ['', Validators.required],//
      mainchannelid: ['',],//
      subchannelid: ['',],//
      saleshierarcycode: ['',],//
      saleshierarchyid: ['',],//
      productid: ['', Validators.required],
      plancategoryid: ['', Validators.required],
      specialcondition: [''],//
      benefittypeid: ['', Validators.required],//
      agreementtypeid: [''],//
      windowperiod: ['', Validators.required],//
      isnriletterreceived: ['', Validators.required],//
      normalretirementage: [''],//
      nriletterreceiveddate: [''],  //
      panno: ['', [Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]],//
      typeofclient: ['', Validators.required],//
      gsttype: ['', Validators.required],//
      paymentfrequencyid: ['', Validators.required],//
      modalfactors: ['',],//
      ispsuflag: ['', Validators.required],//
      zoneid: ['', Validators.required],//
      addressdifferfromclientorg: [''],//
      activelyatworkclause: [''],//
      issfq: [''],//
      isdeclaration: [''],//
      isadvancedeposit: [''],//
      gstin: ['', Validators.required],//
      IsMasterPolicyAddressdifferent: [''],
      salutationid: [''],//
      // PremiumDetails:[''],
      activelyatworkclauseremarks: [''],//
      // mobileNo: ['', Validators.pattern("[0-9 -()+]+$")],
      // email: ['', [Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
      // gstNo: ['', [Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
      // panNo: ['', [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]]

    });

    this.UnitDetails = this.fb.group({
      unitName: ['', Validators.required],
      panNo: ['', Validators.required],//
      gstNo: ['', Validators.required],
      address1: ['', Validators.required],
      address2: [''],
      address3: [''],
      zipCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
      countryID: ['', Validators.required],
      stateID: ['', Validators.required],
      districtID: ['', Validators.required],
      talukID: [''],
    });

    this.AddressDetails = this.fb.group({
      IsMasterPolicyAddress: [''],
      address1: ['', Validators.required],
      address2: [''],
      address3: [''],
      address4: [''],
      zipCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
      countryID: ['', Validators.required],
      stateID: ['', Validators.required],
      districtID: ['', Validators.required],
      talukID: [''],
      phoneNo: [''],
      addressTypeTypeID: ['']
    });

    this.AddBenefit = this.fb.group({
      coverageId: ['', Validators.required],
      VariantType: ['', Validators.required],
      MaximumCap: ['', Validators.required],
      MinimumCap: ['', Validators.required],
      SumAssured: ['', Validators.required],
      MaxSumAssured: ['', Validators.required],
      RetirementAge: ['', Validators.required],
      FreeCoverLimit: ['', Validators.required],
      BaseBenefit: ['', Validators.required],
      MultiplesOfSalary: [''],
      Grade: ['', Validators.required],
    });

    this.PremiumDetails = this.fb.group({
      PremiumDetailfile: ['', Validators.required],
    });
    this.IsgstTypeId()
    this.VariantType()
  }

  VariantType() {
    this.AddBenefit.get('VariantType').valueChanges.subscribe((data: number) => {
      console.log(data)
      this.onchangeVariantType(data)
    }
    )
  }
  onchangeVariantType(selected: any) {

    console.log(selected);
    const MaximumCap = this.AddBenefit.get('MaximumCap')
    const MinimumCap = this.AddBenefit.get('MinimumCap')
    const SumAssured = this.AddBenefit.get('SumAssured')
    const MaxSumAssured = this.AddBenefit.get('MaxSumAssured')
    const RetirementAge = this.AddBenefit.get('RetirementAge')
    const FreeCoverLimit = this.AddBenefit.get('FreeCoverLimit')
    const BaseBenefit = this.AddBenefit.get('BaseBenefit')
    const MultiplesOfSalary = this.AddBenefit.get('MultiplesOfSalary')
    const Grade = this.AddBenefit.get('Grade')


    if (selected === "1") {
      // this.submitted = false
      SumAssured.setValidators(Validators.required);
      FreeCoverLimit.setValidators(Validators.required);
      this.Flatsum = true;
      this.MultiplesOfSalary = false;
      this.grade = false
      this.future = false
      this.basebenefit = false
      this.gradesalary = false
      this.customerdefined = false
    }
    else if (selected === "2") {
      MultiplesOfSalary.setValidators(Validators.required);
      FreeCoverLimit.setValidators(Validators.required);
      MinimumCap.setValidators(Validators.required);
      MaximumCap.setValidators(Validators.required);
      this.MultiplesOfSalary = true;
      this.Flatsum = false;
      this.grade = false
      this.future = false
      this.basebenefit = false
      this.gradesalary = false
      this.customerdefined = false
    }
    else if (selected === "3") {
      Grade.setValidators(Validators.required);
      SumAssured.setValidators(Validators.required);
      FreeCoverLimit.setValidators(Validators.required);
      MinimumCap.setValidators(Validators.required);
      MaximumCap.setValidators(Validators.required);
      this.grade = true
      this.MultiplesOfSalary = false;
      this.Flatsum = false;
      this.future = false
      this.basebenefit = false
      this.gradesalary = false
      this.customerdefined = false
    }
    else if (selected === "4") {
      RetirementAge.setValidators(Validators.required);
      MaxSumAssured.setValidators(Validators.required);
      FreeCoverLimit.setValidators(Validators.required);
      MinimumCap.setValidators(Validators.required);
      MaximumCap.setValidators(Validators.required);
      this.future = true
      this.grade = false
      this.MultiplesOfSalary = false;
      this.Flatsum = false;
      this.basebenefit = false
      this.gradesalary = false
      this.customerdefined = false
    }
    else if (selected === "5") {
      BaseBenefit.setValidators(Validators.required);
      FreeCoverLimit.setValidators(Validators.required);
      MinimumCap.setValidators(Validators.required);
      MaximumCap.setValidators(Validators.required);
      this.basebenefit = true
      this.future = false
      this.grade = false
      this.MultiplesOfSalary = false;
      this.Flatsum = false;
      this.gradesalary = false
      this.customerdefined = false
    }
    else if (selected === "6") {
      Grade.setValidators(Validators.required);
      MultiplesOfSalary.setValidators(Validators.required);
      FreeCoverLimit.setValidators(Validators.required);
      MinimumCap.setValidators(Validators.required);
      MaximumCap.setValidators(Validators.required);
      this.gradesalary = true
      this.basebenefit = false
      this.future = false
      this.grade = false
      this.MultiplesOfSalary = false;
      this.Flatsum = false;
      this.customerdefined = false
    }
    else if (selected === "7") {
      MultiplesOfSalary.setValidators(Validators.required);
      FreeCoverLimit.setValidators(Validators.required);
      MinimumCap.setValidators(Validators.required);
      MaximumCap.setValidators(Validators.required);
      this.customerdefined = true
      this.gradesalary = false
      this.basebenefit = false
      this.future = false
      this.grade = false
      this.MultiplesOfSalary = false;
      this.Flatsum = false;
    }
    else {
      MaximumCap.clearValidators();
      MinimumCap.clearValidators();
      SumAssured.clearValidators();
      MaxSumAssured.clearValidators();
      RetirementAge.clearValidators();
      FreeCoverLimit.clearValidators();
      BaseBenefit.clearValidators();
      MultiplesOfSalary.clearValidators();
      Grade.clearValidators();
      this.customerdefined = false
      this.gradesalary = false
      this.basebenefit = false
      this.future = false
      this.grade = false
      this.MultiplesOfSalary = false;
      this.Flatsum = false;
    }
    // bankID.updateValueAndValidity();
    // bankBranchID.updateValueAndValidity();
    // instrumentNumber.updateValueAndValidity();
    // instrumentDate.updateValueAndValidity();
  }

  get m() { return this.MasterPolicyDetailed.controls; }
  IsgstTypeId() {
    this.MasterPolicyDetailed.get('gsttype').valueChanges.subscribe((data: number) => {
      console.log(data)
      this.onchangeIsgstTypeId(data)
    }
    )
  }
  getaddresstype() {
    this.fchannelService.getaddresstype()
      .subscribe(result => {
        console.log(result)
        this.addressType = result.addressTypeList
      })
  }
  onchangeIsgstTypeId(selected: any) {
    this.IsgstType = false

    console.log(selected);
    const gstNo = this.MasterPolicyDetailed.get('gstin')


    if (selected === 1 || selected === 3) {
      this.submitted = false

      gstNo.setValidators(Validators.required);

      this.show = true;
    }
    else {
      gstNo.clearValidators();

      this.show = false
    }
    gstNo.updateValueAndValidity();
  }

  onBtnSaveDesignation() {
    console.log(this.MasterPolicyDetailed.value)
    // this.submitted3=true;
    this.MasterPolicyDetailed.markAllAsTouched()

    if (this.MasterPolicyDetailed.value['groupName']) {

      // if(this.MasterPolicyDetailed.valid)
      this.submitted3 = false
      console.log(this.MasterPolicyDetailedarray)
      this.MasterPolicyDetailed.value["agreementenddate"] = new Date(moment(this.MasterPolicyDetailed.value["agreementstartdate"]).add('years', 1).format('L'))
      this.MasterPolicyDetailed.value["masterPolicyUnitAddresses"] = this.AddressDetailsarray
      if (this.UnitDetailsarray && this.UnitDetailsarray.length > 0) {
        for (let i = 0; i < this.UnitDetailsarray.length; i++) {
          this.MasterPolicyDetailed.value["masterPolicyUnitAddresses"].push(this.UnitDetailsarray[i])
        }
      }
      this.MasterPolicyDetailed.value["benefitRiders"] = this.AddBenefitarray
      // this.MasterPolicyDetailed.value["UnitDetails"] = this.UnitDetailsarray

      this.masterpolicyservice.insertMasterpolicy(this.MasterPolicyDetailed.value).subscribe(result => {
        console.log(result)
        this.UnitDetailsarray = []
        this.AddressDetailsarray = []
      })
    }
    else {
      this.openModalDialog1("Please enter Client Name")
    }
  }
  typeof(event: any) {
    this.showgst = []
    console.log(event.value)
    if (event.value === 1) {
      this.showgst = this.gst
      console.log(this.gst)
    }
    else if (event.value === 2) {
      this.showgst = this.sezgst_
      console.log(this.sezgst_)
    }
  }

  GetAllSalutation() {
    this.user.GetAllSalutation()
      .subscribe(result => {
        console.log(result)
        this.salutation = result.salutationList
      })
  }
  assignCopy() {
    this.filteredItems = Object.assign([], this.items);
  }

  //  GetAllmasterpolicy() {

  //   this.masterpolicyservice.GetAllmasterpolicy(data)
  //     .subscribe(result => {
  //       console.log(result)
  //       this.salutation = result.salutationList
  //     })
  // }
  filterItem(value: any) {
    console.log(value)
    // if(!value){
    //     this.assignCopy();
    // } // when nothing has typed
    if (value) {
      this.masterpolicyservice.search(value)
        .subscribe(result => {
          console.log(result)
          this.filteredItems = Object.assign([], result.list).filter(
            item => item.groupName.toLowerCase().indexOf(value.toLowerCase()) > -1
          )
          console.log(this.filteredItems)
        })
    }

    // this.filteredItems = Object.assign([], this.items).filter(
    //    item => item.name.toLowerCase().indexOf(value.toLowerCase()) > -1
    // )
    // this.assignCopy();//when you fetch collection from server.
  }

  final() {

    {
      let Masterpolicy = {}
      Masterpolicy["AddressDetails"] = this.AddressDetailsarray
      Masterpolicy["AddBenefit"] = this.AddBenefitarray
      Masterpolicy["UnitDetails"] = this.UnitDetailsarray
      Masterpolicy["masterPolicyUnitAddresses"] = this.MasterPolicyDetailedarray
      console.log(Masterpolicy)

    }

  }
  selectTypeValue(data) {
    this.typeId = data;
    this.getBenefitRiders();
  }
  getBenefitRiders() {
    let lobId = 1
    console.log(this.MasterPolicyDetailed.value["benefittypeid"], this.MasterPolicyDetailed.value["benefittypeid"])
    this._productService.getProductBenefitDiders(this.variantId, this.typeId, lobId).subscribe(res => {
      console.log(res);
      this.productBenefitRidersArr = res.productBenefitRiders;
    }, err => {
      console.log(err);
    })
  }
  getProductDetails(): void {
    this.productService.getProductDetails().subscribe(
      productObj => {
        console.log(productObj)
        this.productObj = productObj['getProductModelList']
        console.log(this.productObj)
      })
  }
  openModalDialog1(msg) {
    this.display = 'block'; //Set block css
    this.submitted1 = false
    this.msg = msg
  }
  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog

  }
  getallchannel() {
    this.CommissionService.GetAllMainChannel()
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        console.log(this.allchannel)
      });
  }
  Select_channel(event: any) {
    console.log(event.target.value)

    this.GetAllSubChannel(event.target.value);
  }
  GetAllSubChannel(id) {
    this.CommissionService.GetSubChannelByChannelID(id)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        console.log(this.allsubchannel)
      });
  }
  PremiumDetailsform() {
    console.log(this.PremiumDetails.value)
  }
  bindsearchdata(data: any) {
    console.log(data)
    this.autocompletedata = data
    this.masterpolicyservice.getbygroupid(data.groupId).subscribe(res => {
      console.log(res)
      this.formobj = res.masterGroupDetailsList[0]
      if (res.salesHierarchyDetailsList && res.salesHierarchyDetailsList[0]) {
        this.salesobj = res.salesHierarchyDetailsList[0]
      }
      if (res.masterPolicyDetailsList && res.masterPolicyDetailsList.length > 0) {
        this.griddata = res.masterPolicyDetailsList
        console.log(this.griddata)
        if (this.griddata) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.griddata.length
          }
        }
      }
      if (this.salesobj) {
        this.GetAllSubChannel(this.salesobj.MAINCHANNELID);
        let sales = {
          mainchannel: this.salesobj.MAINCHANNELCODE,
          subchannel: this.salesobj.SUBCHANNELCODE,
          mainchannelid: this.salesobj.MAINCHANNELID,
          subchannelid: this.salesobj.SUBCHANNELID,
          saleshierarcycode: this.salesobj.CODE,
        }
        this.MasterPolicyDetailed.patchValue(sales);

      }
      if (this.formobj) {
        // this.masterpolicyservice.getbyofficercode(this.formobj.groupid)
        //   .subscribe(result => {
        //     console.log(result)

        //     let sales = {
        //       mainchannelid: result[0]["FIRSTNAME"],
        //       subchannelid: result[0]["FIRSTNAME"],
        //       saleshierarcycode: result[0]["code"],
        //       saleshierarchyid: result[0]["saleshierarchyid"],
        //       gsttype: result[0]["gstTypeId"],
        //       typeofclient: result[0]["clientTypeId"],
        //     }
        //     this.MasterPolicyDetailed.patchValue(sales);
        //   })
        if (this.formobj.clientTypeId === 1) {
          this.showgst = this.gst
          console.log(this.gst)
        }
        else if (this.formobj.clientTypeId === 2) {
          this.showgst = this.sezgst_
          console.log(this.sezgst_)
        }
        let pin = {
          groupid: this.formobj.groupid,
          groupName: this.formobj.groupName,
          panno: this.formobj.panno,
          gstin: this.formobj.gstin,
          gsttype: this.formobj.gstTypeId,
          typeofclient: this.formobj.clientTypeId,
          saleshierarchyid: this.formobj.saleshierarchyid,


        }
        this.IsgstTypeId()
        this.MasterPolicyDetailed.patchValue(pin);

      }

      // mainchannelid: [{ value: this.formobj.gstNo, disabled: false }, Validators.required],//
      // subchannelid: [{ value: this.formobj.gstNo, disabled: false }, Validators.required],//
      // saleshierarcycode: [{ value: this.formobj.gstNo, disabled: false }, Validators.required],//
      // saleshierarchyid: [{ value: this.formobj.gstNo, disabled: false }, Validators.required],//
      // this.griddata = res.response
      // if (this.griddata) {
      //   this.config = {
      //     itemsPerPage: 10,
      //     currentPage: 1,
      //     totalItems: this.griddata.length
      //   }
      // }
    })
  }
  searchByagreement(event: any) {
    console.log(event.target.value)
    if (this.autocompletedata && this.autocompletedata.groupId) {
      this.agreementdata = {
        groupId: this.autocompletedata.groupId,
        agreementNumber: event.target.value
      }
    }
    else {
      this.agreementdata = {
        groupId: 0,
        agreementNumber: event.target.value
      }
    }

    this.masterpolicyservice.getbyagreementNumber(this.agreementdata).subscribe(res => {
      console.log(res)
      this.agreementno = res.response
      if (this.autocompletedata && this.autocompletedata.groupId) {
        for (let i = 0; i < this.griddata.length; i++) {
          for (let k = 0; k < this.agreementno.length; k++) {
            if (this.griddata[i]["masterPolicyAgreement"] === this.agreementno[k]["insurermasteragreementno"]) {
              this.griddata = this.griddata[i]
            }
            else {
              this.griddata = []
            }
          }
        }
      }
      else {
        this.griddata = this.agreementno
        if (this.griddata) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.griddata.length
          }
        }
      }

    }
    )

    console.log(this.griddata)
  }
  getFrequency() {
    this._lookupService.getFrequency().subscribe(res => {
      console.log(res)
      this.paymentFrequencyArr = res.paymentFrequencyist;
    }, err => {
      console.log(err);
    })
  }

  AddAddressForm() {

    this.AddressDetails.markAllAsTouched()
    console.log(this.AddressDetails.value)
    if (this.AddressDetails.valid) {
      this.AddressDetailsarray.push(this.AddressDetails.value)
      this.AddressDetails.reset()
      this.submitted1 = false
    }
    if (this.AddressDetailsarray) {
      this.config = {
        itemsPerPage: 10,
        currentPage: 1,
        totalItems: this.AddressDetailsarray.length
      }
    }
  }

  open() {
    this.picker.open();
    this.date()

  }
  date() {
    console.log(this.MasterPolicyDetailed.value["agreementstartdate"])
    let date = {
      agreementenddate: moment(this.MasterPolicyDetailed.value["agreementstartdate"], "MM-DD-YYYY").add('days', 364).format('L')
    }

    this.MasterPolicyDetailed.patchValue(date);
    console.log(moment(this.MasterPolicyDetailed.value["agreementstartdate"], "MM-DD-YYYY").add('years', 1).format('L'))
  }

  getariant() {
    this._productService.getVariant().subscribe(res => {
      console.log(res)
      this.variantArr = res.variantRequestList;
    })
  }
  selectValue(data) {
    console.log(data)
    this.variantId = data;
    this.MasterPolicyDetailed.patchValue({ paymentfrequencyid: '' })
    // this.searchPremiumObj.variantPremiumTypeId = "";
    // this.searchPremiumObj.benefitRiderId = "";
    this.getProductPremiumType(data);
  }
  getProductPremiumType(data) {
    this.productService.getProductPremiumType(data).subscribe(res => {
      console.log(res);
      this.productPremiumTypeArr = res.productTypeList;
    }, err => {
      console.log(err);
    })
  }
  AddBenefitForm() {
    console.log(this.AddBenefit.value)

    this.AddBenefit.markAllAsTouched()

    if (this.AddBenefit.valid) {
      this.AddBenefitarray.push(this.AddBenefit.value)
      console.log(this.AddBenefitarray)
      this.AddBenefit.reset()
      this.submitted2 = false
    }

    if (this.AddBenefitarray) {
      this.config = {
        itemsPerPage: 10,
        currentPage: 1,
        totalItems: this.AddBenefitarray.length
      }
    }
  }
  getGradeDetails(): void {

    let obj = {
      "organisationId": this.organisationID,
      "description": ''
    }

    this.gradeService.getGradeDetails(obj)
      .subscribe(a => {
        console.log(a)
        this.gradeObj = a;
      });

  }
  getclientAdressDetail() {
    this.masterpolicyservice.getclientAdressDetail(this.autocompletedata.groupId).subscribe(res => {
      console.log(res)
      if (this.AddAdressform === false) {
        this.AddressDetailsarray = res.response
        if (this.AddressDetailsarray) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.AddressDetailsarray.length
          }
        }
      }
      if (this.AddunitAdressform === false) {
        this.UnitDetailsarray = res.response
        if (this.UnitDetailsarray) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.UnitDetailsarray.length
          }
        }

      }

    })

  }
  varientevent() {
    console.log(this.AddBenefit.value["VariantType"])
    if (this.AddBenefit.value["VariantType"]) {
      this.openOtherBenefits = true
    }

  }

  getmodalfactor() {
    console.log("getmodalfactor")
    console.log(this.MasterPolicyDetailed.value["plancategoryid"])
    if (this.MasterPolicyDetailed.value["plancategoryid"]) {
      let data = {
        variantId: this.MasterPolicyDetailed.value["plancategoryid"],
        frequencyId: this.MasterPolicyDetailed.value["paymentfrequencyid"]
      }
      this.masterpolicyservice.getmodalfactor(data).subscribe(res => {
        console.log(res)
      })
    }
  }
  get u() {
    return this.UnitDetails.controls;
  }
  UnitDetailsform() {
    this.UnitDetails.markAllAsTouched()
    console.log(this.UnitDetails.value)
    this.submitted = true;
    if (this.UnitDetails.valid) {
      this.UnitDetailsarray.push(this.UnitDetails.value)
      this.UnitDetails.reset()
      this.submitted = false
    }

    if (this.UnitDetailsarray) {
      this.config = {
        itemsPerPage: 10,
        currentPage: 1,
        totalItems: this.UnitDetailsarray.length
      }
    }

  }
  IsUnitAddressdifferent(data) {
    console.log(data.value)
    if (data.value == 1) {
      this.unit = true
      this.state = false
      this.UnitDetailsarray = []
      this.AddunitAdressform = true
      console.log(this.AddAdressform)
    }
    else if (data.value == 0) {
      this.unit = false
      this.state = true
      this.getclientAdressDetail()
      this.AddunitAdressform = false
    }
  }


  IsMasterPolicyAddress(data) {
    console.log(data.value)
    if (data.value == 1) {
      this.AddressDetailsarray = []
      this.AddAdressform = true
      console.log(this.AddAdressform)
    }
    else if (data.value == 0) {
      this.getclientAdressDetail()
      this.AddAdressform = false
    }
  }

  Select_country(event: any) {
    console.log(event.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);

    this.GetAllStates(event.value);
  }
  Select_state(event: any) {
    console.log(event.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetAllDistricts(event.value);
  }

  Select_district(event: any) {
    console.log(event.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetTaluk(event.value);
  }
  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data
        // this.country1 = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
        // this.state1 = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
        // this.District1 = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
        // this.Taluka1 = result.data
      });
  }




  Select_country1(event: any) {
    console.log(event.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);

    this.GetAllStates1(event.value);
  }
  Select_state1(event: any) {
    console.log(event.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetAllDistricts1(event.value);
  }

  Select_district1(event: any) {
    console.log(event.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetTaluk1(event.value);
  }
  GetAllcountries1() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country1 = result.data

        console.log(this.country)
      });
  }
  GetAllStates1(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state1 = result.data
      });
  }
  GetAllDistricts1(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District1 = result.data
      });
  }
  GetTaluk1(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka1 = result.data
      });
  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();

        }
        console.log(event.keyCode)
        // event.target.value = event.target.value.slice(0, 5).replace(/[^a-zA-Z]/g, "");
      }
      else if (l >= 5 && l <= 8) {

        console.log(l)
        console.log(charCode)
        // console.log(event.target.value.slice(5,9))
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l >= 8 && l <= 9) {
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  getdetailsbypin(a) {
    console.log(a)
    this.BranchService.GetAllDetailsByZipCode(a)
      .subscribe(result => {
        console.log(result)
        if (result.data.length > 0) {
          this.pinobj = result.data[0]
          this.GetAllStates(this.pinobj.countryID)
          this.GetAllDistricts(this.pinobj.stateID)

          let pin = {
            countryID: this.pinobj.countryID,
            stateID: this.pinobj.stateID,
            districtID: this.pinobj.districtID,

          }

          this.AddressDetails.patchValue(pin);
        }
        else {
          let pin = {
            countryID: '',
            stateID: '',
            districtID: '',
          }

          this.AddressDetails.patchValue(pin);
        }

      });
  }

  detectpin(event: any) {
    console.log(event.target.value.length);
    if (event.target.value.length === 6) {
      this.getdetailsbypin(this.AddressDetails.value["zipCode"])
    }
  }

  detectpin1(event: any) {
    console.log(event.target.value.length);
    if (event.target.value.length === 6) {
      this.getdetailsbypin1(this.UnitDetails.value["zipCode"])
    }
  }
  getdetailsbypin1(a) {
    console.log(a)
    this.BranchService.GetAllDetailsByZipCode(a)
      .subscribe(result => {
        console.log(result)
        if (result.data.length > 0) {
          this.pinobj = result.data[0]
          this.GetAllStates1(this.pinobj.countryID)
          this.GetAllDistricts1(this.pinobj.stateID)

          let pin = {
            countryID: this.pinobj.countryID,
            stateID: this.pinobj.stateID,
            districtID: this.pinobj.districtID,

          }

          this.UnitDetails.patchValue(pin);
        }
        else {
          let pin = {
            countryID: '',
            stateID: '',
            districtID: '',
          }

          this.UnitDetails.patchValue(pin);
        }

      });
  }
  pinValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)

          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  get PanError() {
    // return this.email.hasError('required') ? 'You must enter a value' :
    //     this.email.hasError('email') ? 'Not a valid email' :
    //         '';
    if (this.MasterPolicyDetailed.controls['panno'].hasError('pattern')) {
      return 'Please enter valid PAN Number';
    } else if (this.MasterPolicyDetailed.controls['panno'].hasError('minlength')) {
      return 'Please Enter 10 digits of PAN Number.';
    }
  }
}

export interface PeriodicElement {
  MasterPolicyNumber: string;
  AgreementNumber: string;
  MasterPolicyInception: string;
  MasterPolicyExpiry: string;
  TotalMembers: number;
  SumAssured: number;
  MasterPolicyDate: string;
  Ageing: number;
  Status: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { MasterPolicyNumber: '120520129311', AgreementNumber: 'QWERTY2012SF', MasterPolicyInception: '31/1/2020', MasterPolicyExpiry: '30/1/2023', TotalMembers: 100, SumAssured: 500000000, MasterPolicyDate: '31/1/2020', Ageing: 81, Status: 'Approved' },
  { MasterPolicyNumber: '170519960824', AgreementNumber: 'ASDFG1234F', MasterPolicyInception: '28/1/2020', MasterPolicyExpiry: '27/1/2022', TotalMembers: 100, SumAssured: 1000000000, MasterPolicyDate: '28/1/2020', Ageing: 81, Status: 'Approved' }
];

export interface Address {
  UnitName: string;
  PANNumber: string;
  GSTIN: string;
  AddressOne: string;
  AddressTwo: string;
  AddressThree: string;
  Country: string;
  State: string;
  District: string;
  PostOffice: string;
  Pincode: number;
}

const ELEMENTS_DATAS: Address[] = [
  { UnitName: 'Postal', PANNumber: 'QWERT9874Y', GSTIN: '21WERWETR13', AddressOne: '14, First Floor', AddressTwo: 'RK Mutt Road', AddressThree: 'Mylapore', Country: 'India', State: 'Tamil Nadu', District: 'Chennai', PostOffice: 'Mylapore', Pincode: 600004 },
  { UnitName: 'Postal', PANNumber: 'ZXCVA6548E', GSTIN: '65QWERTS987', AddressOne: '104, First Floor', AddressTwo: 'VC Garden Street', AddressThree: 'Mylapore', Country: 'India', State: 'Tamil Nadu', District: 'Chennai', PostOffice: 'Mandaveli', Pincode: 600004 }
];


export interface PeriodicElementType {
  AddressOne: string;
  AddressTwo: string;
}

const ELEMENTS_DATA_ONE: PeriodicElementType[] = [
  { AddressOne: '14 First Floor', AddressTwo: 'RK Mutt Road' },
  { AddressOne: '104 First Floor', AddressTwo: 'VC Garden Street' }
];


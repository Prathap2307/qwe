import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedepositreceiptingComponent } from './advancedepositreceipting.component';

describe('AdvancedepositreceiptingComponent', () => {
  let component: AdvancedepositreceiptingComponent;
  let fixture: ComponentFixture<AdvancedepositreceiptingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvancedepositreceiptingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvancedepositreceiptingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

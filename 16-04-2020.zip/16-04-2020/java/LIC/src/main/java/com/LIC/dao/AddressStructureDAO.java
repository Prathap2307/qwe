package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.AddressStructureModel;
import com.LIC.model.GetAddressStructure;


@Repository
public class AddressStructureDAO {
	
	@Autowired
	
	private EntityManager em;
	
	public List<GetAddressStructure> getAllAddressInfo() {
	    
	    
	    StoredProcedureQuery query = em
	                 .createStoredProcedureQuery("spGetAllAddressStructure")
	                 
	                 .registerStoredProcedureParameter(
	                     1,
	                     
	                     Class.class,
	                     ParameterMode.REF_CURSOR
	                 );
	                
	  //  return query.execute() ? query.getResultList() : null;
	    
	    List<Object[]> list  =  (List<Object[]>)query.getResultList();
	    List<GetAddressStructure> AddressList = list.stream().map(
	            o -> new GetAddressStructure((Number) o[0], (String) o[1])).collect(Collectors.toList());
	    
	   return AddressList;
	}
	
	
	
	
	
	public void createAddressStructure(AddressStructureModel model) {

		StoredProcedureQuery addAddressStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateAddressStructure");
		addAddressStoredProcedure.setParameter("vStructureID", model.getStructureId());
		addAddressStoredProcedure.setParameter("vDescription", model.getDescription());
		addAddressStoredProcedure.setParameter("vCreatedBy", model.getCreatedBy());
		addAddressStoredProcedure.setParameter("vCreatedOn", model.getCreatedOn());
		addAddressStoredProcedure.setParameter("visActive", 1);
		addAddressStoredProcedure.execute();
}
	
	
	public void deleteAddress(AddressStructureModel model) {

		StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteAddress");
		query.setParameter("vStructureID",model.getStructureId());
		
		query.setParameter("vDeletedBy",model.getDeletedBy());
		query.setParameter("vDeletedOn",model.getDeletedOn());
		query.getParameter("RESULT1");
        query.execute();
	}
	
	
}


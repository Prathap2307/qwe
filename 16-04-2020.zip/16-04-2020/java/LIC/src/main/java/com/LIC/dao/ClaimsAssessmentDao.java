package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.LIC.model.DropdownClaimsAssessmentModel;
import com.LIC.model.OnSelectionOfGridClaimsAssessmentModel;
import com.LIC.model.OnSelectionOfGridPIDClaimsAssessmentModel;
import com.LIC.model.SaveClaimsAssessmentModel;
import com.LIC.model.SearchClaimsAssessmentModel;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

/*
 * @Author = "671621"
 */
@Repository
@SuppressWarnings("unchecked")
public class ClaimsAssessmentDao {

	@Autowired
	private EntityManager entityManager;
	
	Connection conn = null;
	CallableStatement cstm = null;
	@Autowired
	private JDBCConnection jdbcConnection;
	
	public List<HashMap> getAllPendingClaims(int pLineOfBusinessID,
			String pClaimNumber, String pFirstName, String pLastName,
			 String pPolicyNumber, String pContactID, String pAgeing,
			 int pStatusID, int pAssessorID){
		List<HashMap> clientDetailsList = new ArrayList();
		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetAllPendingClaims(?,?,?,?,?,?,?,?,?,?) ");

			cstm.setInt(1, pLineOfBusinessID);
			cstm.setString(2, pClaimNumber);
			cstm.setString(3, pFirstName);
			cstm.setString(4, pLastName);
			cstm.setString(5, pPolicyNumber);
			cstm.setString(6, pContactID);
			cstm.setString(7, pAgeing);
			cstm.setInt(8, pStatusID);
			cstm.setInt(9, pAssessorID);
			cstm.registerOutParameter(10, OracleTypes.CURSOR);
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(10);

			if (result != null) {
				clientDetailsList = ResourceManager.resultSetToArrayList(result);

			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			closeConnection();

		}
		//clientDetailsList.forEach(action);
		
		for (HashMap a : clientDetailsList) {
			
		a.put("POLICYSTARTDATE", a.get("POLICYSTARTDATE").toString());
		a.put("DATEOFLOSS", a.get("DATEOFLOSS").toString());
	
		}
		
		return clientDetailsList;
	}
	
	private void closeConnection() {
		try {
			//cstm.close();
			ResourceManager.freeConnection(conn);
			//cstm = null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	/*
	 * public List<SearchClaimsAssessmentModel> getAllPendingClaims(int
	 * pLineOfBusinessID, String pClaimNumber, String pFirstName, String pLastName,
	 * String pPolicyNumber, String pContactID, String pAgeing, int pStatusID, int
	 * pAssessorID) { StoredProcedureQuery storedProcedureQuery =
	 * entityManager.createStoredProcedureQuery("spGetAllPendingClaims")
	 * 
	 * .registerStoredProcedureParameter("pLineOfBusinessID", Integer.class,
	 * ParameterMode.IN) .registerStoredProcedureParameter("pClaimNumber",
	 * String.class, ParameterMode.IN)
	 * .registerStoredProcedureParameter("pFirstName", String.class,
	 * ParameterMode.IN) .registerStoredProcedureParameter("pLastName",
	 * String.class, ParameterMode.IN)
	 * .registerStoredProcedureParameter("pPolicyNumber", String.class,
	 * ParameterMode.IN) .registerStoredProcedureParameter("pContactID",
	 * String.class, ParameterMode.IN) .registerStoredProcedureParameter("pAgeing",
	 * String.class, ParameterMode.IN)
	 * .registerStoredProcedureParameter("pStatusID", Integer.class,
	 * ParameterMode.IN) .registerStoredProcedureParameter("pAssessorID",
	 * Integer.class, ParameterMode.IN)
	 * 
	 * .registerStoredProcedureParameter("oBRANCH", Class.class,
	 * ParameterMode.REF_CURSOR)
	 * 
	 * .setParameter("pLineOfBusinessID", pLineOfBusinessID)
	 * .setParameter("pClaimNumber", pClaimNumber) .setParameter("pFirstName",
	 * pFirstName) .setParameter("pLastName", pLastName)
	 * .setParameter("pPolicyNumber", pPolicyNumber) .setParameter("pContactID",
	 * pContactID) .setParameter("pAgeing", pAgeing) .setParameter("pStatusID",
	 * pStatusID) .setParameter("pAssessorID", pAssessorID);
	 * 
	 * storedProcedureQuery.execute();
	 * 
	 * List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();
	 * 
	 * List<SearchClaimsAssessmentModel> allPendingClaimsList = list.stream() .map(o
	 * -> new SearchClaimsAssessmentModel((int) o[0], (int)
	 * o[1])).collect(Collectors.toList()); return allPendingClaimsList; }
	 */

	public List<DropdownClaimsAssessmentModel> getAllCoveragesByClaimId(int pClaimID) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetAllCoveragesByClaimID")
				
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pClaimID", pClaimID);

		storedProcedureQuery.execute();

		List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();

		List<DropdownClaimsAssessmentModel> getAllCoveragesList = list.stream()
				.map(o -> new DropdownClaimsAssessmentModel((String) o[0], (int) o[1])).collect(Collectors.toList());
		return getAllCoveragesList;
	}

	
	  public List<DropdownClaimsAssessmentModel> getClaimDocumentsByClaimId(int
	  pClaimID) { StoredProcedureQuery storedProcedureQuery =
	  entityManager.createStoredProcedureQuery("spGetClaimDocumentsByClaimID")
	  
	  .registerStoredProcedureParameter("pClaimID", Integer.class,
	  ParameterMode.IN)
	  
	  .registerStoredProcedureParameter("oBRANCH", Class.class,
	  ParameterMode.REF_CURSOR)
	  
	  .setParameter("pClaimID", pClaimID);
	  
	  storedProcedureQuery.execute();
	  
	  List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();
	  
	  List<DropdownClaimsAssessmentModel> getClaimDocumentsList = list.stream()
	  .map(o -> new DropdownClaimsAssessmentModel((int) o[0], (String) o[1],
	  (String) o[2])).collect(Collectors.toList()); return getClaimDocumentsList; }
	 
	
	public List getClaimDetailsByClaimId(int pClaimID){
		List<Object> ListObj = new ArrayList();
		
		List<Object> ListObj5 = new ArrayList();
		try {

			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spGetClaimDetailsByClaimID(?,?,?,?,?) ");

			cstm.setInt(1, pClaimID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.registerOutParameter(5, OracleTypes.CURSOR);
			cstm.execute();

			ResultSet result = ((OracleCallableStatement) cstm).getCursor(2);
			
			ResultSet result5 = ((OracleCallableStatement) cstm).getCursor(5);

			
			
			
			if (result != null) {
				ListObj = ResourceManager.resultSetToArrayList(result);

			}
			
			if (result5 != null) {
				ListObj5 = ResourceManager.resultSetToArrayList(result5);

			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.info(e.getMessage());

		} finally {
			//closeConnection();

		}
		
		System.out.println("test ListObj");
		System.out.println(ListObj);
		ListObj.addAll(ListObj5);
		return ListObj;
	}

	/*
	 * public List<OnSelectionOfGridClaimsAssessmentModel>
	 * getClaimDetailsByClaimId(int pClaimID) { StoredProcedureQuery
	 * storedProcedureQuery =
	 * entityManager.createStoredProcedureQuery("spGetClaimDetailsByClaimID")
	 * 
	 * .registerStoredProcedureParameter("pClaimID", Integer.class,
	 * ParameterMode.IN)
	 * 
	 * .registerStoredProcedureParameter("oCur1", Class.class,
	 * ParameterMode.REF_CURSOR) .registerStoredProcedureParameter("oCur2",
	 * Class.class, ParameterMode.REF_CURSOR)
	 * .registerStoredProcedureParameter("oCur3", Class.class,
	 * ParameterMode.REF_CURSOR) .registerStoredProcedureParameter("oCur4",
	 * Class.class, ParameterMode.REF_CURSOR)
	 * 
	 * .setParameter("pClaimID", pClaimID);
	 * 
	 * storedProcedureQuery.execute();
	 * 
	 * List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();
	 * 
	 * List<OnSelectionOfGridClaimsAssessmentModel> getClaimDetailsList =
	 * list.stream() .map(o -> new OnSelectionOfGridClaimsAssessmentModel((int)
	 * o[0])).collect(Collectors.toList()); return getClaimDetailsList; }
	 */

	public List<OnSelectionOfGridClaimsAssessmentModel> getClaimProductTransactionDetails(int pApplicationID, int pProductID) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetClaimProductTransactionDetails")
				
				.registerStoredProcedureParameter("pApplicationID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pProductID", Integer.class, ParameterMode.IN)
				
				.registerStoredProcedureParameter("oBRANCH", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pApplicationID", pApplicationID)
				.setParameter("pProductID", pProductID);

		storedProcedureQuery.execute();

		List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();

		List<OnSelectionOfGridClaimsAssessmentModel> getClaimProductTransactionList = list.stream()
				.map(o -> new OnSelectionOfGridClaimsAssessmentModel((int) o[0], (int) o[1], (int) o[2], (int) o[3], (int) o[4])).collect(Collectors.toList());
		return getClaimProductTransactionList;
	}
	
	public List<OnSelectionOfGridPIDClaimsAssessmentModel> getClaimsDocument(int pID) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetClaimsDocument")
				
				.registerStoredProcedureParameter("pID", Integer.class, ParameterMode.IN)
				
				.registerStoredProcedureParameter("oCUR", Class.class, ParameterMode.REF_CURSOR)
				.registerStoredProcedureParameter("oCUR1", Class.class, ParameterMode.REF_CURSOR)
				.registerStoredProcedureParameter("oCUR2", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pID", pID);

		storedProcedureQuery.execute();

		List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();

		List<OnSelectionOfGridPIDClaimsAssessmentModel> getClaimsDocumentList = list.stream()
				.map(o -> new OnSelectionOfGridPIDClaimsAssessmentModel()).collect(Collectors.toList());
		return getClaimsDocumentList;
	}
	 
	public List<OnSelectionOfGridClaimsAssessmentModel> getAssessmentHistory(int pClaimID) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spGetAssessmentHistory")
				
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				
				.registerStoredProcedureParameter("oBANK", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pClaimID", pClaimID);

		storedProcedureQuery.execute();

		List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();

		List<OnSelectionOfGridClaimsAssessmentModel> getAssessmentHistoryList = list.stream()
				.map(o -> new OnSelectionOfGridClaimsAssessmentModel((int) o[0], (int) o[1], (String) o[2], (int) o[3],
						(int) o[4], (int) o[5], (Date) o[6], (int) o[7], (int) o[8], (int) o[9], (String) o[10],
						(String) o[11], (String) o[12], (String) o[13], (String) o[14], (String) o[15]))
				.collect(Collectors.toList());
		return getAssessmentHistoryList;
	}
	
	public int isClaimExistOrNot(SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("IsClaimExsistOrNot")
				
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPolicyNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfLoss", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vLineOfBusinessID", Integer.class, ParameterMode.IN)
				
				.registerStoredProcedureParameter("vExistCount", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", saveClaimsAssessmentModel.getvClaimID())
				.setParameter("vPolicyNumber", saveClaimsAssessmentModel.getvPolicyNumber())
				.setParameter("vDateOfLoss", saveClaimsAssessmentModel.getvDateOfLoss())
				.setParameter("vLineOfBusinessID", saveClaimsAssessmentModel.getvLineOfBusinessID());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vExistCount");
	}
	
	public int insertOrUpdateClaimsRegistration(SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spInsertOrUpdateClaimRegistration")
				
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDateOfLoss", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTimeOfLoss", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPlaceOfLoss", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vParticularsOfDeath", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDoctorNameAndAddress", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPartialAdvanceClaimPayment", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsAdditionalDcoument", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vStatusID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAssessmentRemarks", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", saveClaimsAssessmentModel.getvClaimID())
				.setParameter("vDateOfLoss", saveClaimsAssessmentModel.getvDateOfLoss())
				.setParameter("vTimeOfLoss", saveClaimsAssessmentModel.getvTimeOfLoss())
				.setParameter("vPlaceOfLoss", saveClaimsAssessmentModel.getvPlaceOfLoss())
				.setParameter("vParticularsOfDeath", saveClaimsAssessmentModel.getvParticularsOfDeath())
				.setParameter("vDoctorNameAndAddress", saveClaimsAssessmentModel.getvDoctorNameAndAddress())
				.setParameter("vPartialAdvanceClaimPayment", saveClaimsAssessmentModel.getvPartialAdvanceClaimPayment())
				.setParameter("vCreatedBy", saveClaimsAssessmentModel.getvCreatedBy())
				.setParameter("vCreatedOn", saveClaimsAssessmentModel.getvCreatedOn())
				.setParameter("vIsActive", saveClaimsAssessmentModel.getvIsActive())
				.setParameter("vIsAdditionalDcoument", saveClaimsAssessmentModel.getvIsAdditionalDcoument())
				.setParameter("vStatusID", saveClaimsAssessmentModel.getvStatusID())
				.setParameter("vAssessmentRemarks", saveClaimsAssessmentModel.getvAssessmentRemarks());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public void deleteClaimCoverageMap(int pClaimID) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spDeleteClaimCoverageMap")
				
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)

				.setParameter("pClaimID", pClaimID);

		storedProcedureQuery.execute();
	}

	public void deleteClaimDocuments(int vClaimID) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spDeleteClaimsDocuments")
				
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)

				.setParameter("vClaimID", vClaimID);

		storedProcedureQuery.execute();
	}
	
	public int insertClaimsCoverageMap(SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("spInsertClaimCoverageMap")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCoverageID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", saveClaimsAssessmentModel.getvClaimID())
				.setParameter("vCoverageID", saveClaimsAssessmentModel.getvCoverageID())
				.setParameter("vTypeID", saveClaimsAssessmentModel.getvTypeID());

		storedProcedureQuery.execute();
		return (int)storedProcedureQuery.getOutputParameterValue("vResult");
	}
	
	public int insertClaimsProofOfDocument(SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spInsertClaimsProofOfDocument")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vImageName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsAdditionDocument", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", saveClaimsAssessmentModel.getvClaimID())
				.setParameter("vDocumentTypeID", saveClaimsAssessmentModel.getvDocumentTypeID())
				.setParameter("vDocumentNumber", saveClaimsAssessmentModel.getvDocumentNumber())
				.setParameter("vImageName", saveClaimsAssessmentModel.getvImageName())
				.setParameter("vIsAdditionDocument", saveClaimsAssessmentModel.getvIsAdditionDocument())
				.setParameter("vIsActive", saveClaimsAssessmentModel.getvIsActive());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

	public int insertClaimsMandatoryDocumentMap(SaveClaimsAssessmentModel saveClaimsAssessmentModel) {
		StoredProcedureQuery storedProcedureQuery = entityManager
				.createStoredProcedureQuery("spInsertClaimsMandatoryDocumentMap")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDocumentNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vImageName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsAdditionDocument", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsActive", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", saveClaimsAssessmentModel.getvClaimID())
				.setParameter("vDocumentTypeID", saveClaimsAssessmentModel.getvDocumentTypeID())
				.setParameter("vDocumentNumber", saveClaimsAssessmentModel.getvDocumentNumber())
				.setParameter("vImageName", saveClaimsAssessmentModel.getvImageName())
				.setParameter("vIsAdditionDocument", saveClaimsAssessmentModel.getvIsAdditionDocument())
				.setParameter("vIsActive", saveClaimsAssessmentModel.getvIsActive());

		storedProcedureQuery.execute();
		return (int) storedProcedureQuery.getOutputParameterValue("vResult");
	}

}

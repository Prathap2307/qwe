package com.LIC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsSettlementDao;
import com.LIC.model.ClaimsSettlementModel;

@RestController
public class ClaimsSettlementController {

	@Autowired
	private ClaimsSettlementDao claimsSettlementDao;
	
	@RequestMapping(path = "/getAllClaimsForSettlement", method = RequestMethod.GET)
	public int getAllClaimsForSettlement(@RequestBody ClaimsSettlementModel claimsSettlementModel) {
		return claimsSettlementDao.getAllClaimsForSettlement(claimsSettlementModel);
	}
	
	@RequestMapping(path = "/insertClaimsSettlement", method = RequestMethod.POST)
	public int insertClaimsSettlement(@RequestBody ClaimsSettlementModel claimsSettlementModel) {
		return claimsSettlementDao.insertClaimsSettlement(claimsSettlementModel);
	}
	
	@RequestMapping(path = "/deleteClaimsSettlementPaymentDetails", method = RequestMethod.DELETE)
	public int deleteClaimsSettlementPaymentDetails(@RequestBody ClaimsSettlementModel claimsSettlementModel) {
		return claimsSettlementDao.deleteClaimsSettlementPaymentDetails(claimsSettlementModel);
	}
	
	@RequestMapping(path = "/insertClaimsSettlementPayment", method = RequestMethod.POST)
	public int insertClaimsSettlementPayment(@RequestBody ClaimsSettlementModel claimsSettlementModel) {
		return claimsSettlementDao.insertClaimsSettlementPayment(claimsSettlementModel);
	}
	
	@RequestMapping(path = "/getClaimNumberByClaimID", method = RequestMethod.GET)
	public int getClaimNumberByClaimID(@RequestBody ClaimsSettlementModel claimsSettlementModel) {
		return claimsSettlementDao.getClaimNumberByClaimID(claimsSettlementModel);
	}

}
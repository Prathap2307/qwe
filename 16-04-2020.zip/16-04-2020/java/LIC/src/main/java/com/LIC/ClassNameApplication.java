package com.LIC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
@ComponentScan(basePackages="com.LIC")
@EnableJpaRepositories("com.LIC.dao")
@EnableAutoConfiguration
public class ClassNameApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(ClassNameApplication.class, args);
	}
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ClassNameApplication.class);
    }
	
	@Configuration

    @EnableWebMvc

    public class CorsConfiguration implements WebMvcConfigurer

    {

        @Override

        public void addCorsMappings(CorsRegistry registry) {

            registry.addMapping("/**")

                    .allowedMethods("GET", "POST", "PUT", "DELETE");

        }

    }
}

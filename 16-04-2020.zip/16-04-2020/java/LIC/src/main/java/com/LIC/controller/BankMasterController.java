package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.LIC.dao.BankMasterDAO;
import com.LIC.model.BankMasterModel;

import com.LIC.model.GetBankMasterModel;


@RestController
public class BankMasterController {

	@Autowired

	private BankMasterDAO bank;

	@GetMapping(value="/bank", produces= {"application/json"})
	public List<GetBankMasterModel> getBank() {
		return	bank.getAllBankInfo();
	}

	
	
	@GetMapping("/bank/{bankName}")
	public List<GetBankMasterModel> findBankInfoBy(@PathVariable String bankName) {
		return bank.getBankInfoByDescription(bankName);
	}

	
	
	
	
	
	@PostMapping("/createBank")
	public void postBank(@RequestBody BankMasterModel model) {
		bank.createBankInfo(model);

	}
	
	

	@RequestMapping(method = RequestMethod.PUT, value = "/deleteBank")
	public void deleteBank(@RequestBody BankMasterModel model) {

		bank.deleteBankInfo(model);
	}
	


}

package com.LIC.bl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.LIC.model.EmployeeModal;
import com.LIC.model.LineOfBusiness;
import com.LIC.model.UnderWritingUserRuleLevelModel;
import com.LIC.model.UserModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;
public class UserBL {

	private static final Logger logger = Logger.getLogger(MessageTemplateBL.class);
	
	@SuppressWarnings("unchecked")
	public  UserModal createUserModal(ValueObject object) throws Exception {
		List<Object> 		lineOfBusinessObj			= null;
		ValueObject			objectMapper				= null;
		UserModal 			usermodal					= null;
		LineOfBusiness lineOfBusinessModal			= null;
		List<LineOfBusiness>	 lineOfBusinessModalList			= null;
		
		try {
			usermodal	 = new UserModal();
			
			usermodal.setUserID(object.getLong("userID",0));
			usermodal.setOrganisationID(object.getLong("organisationID",0));
			usermodal.setBranchID(object.getLong("branchID",0));
			usermodal.setEmployeeID(object.getLong("employeeID",0));
			usermodal.setUserName(object.getString("userName",""));
			usermodal.setPassword(object.getString("password",""));
			usermodal.setIsAdmin(object.getShort("isAdmin",(short)0));
			usermodal.setIsSuperUser(object.getShort("isSuperUser",(short)0));
			usermodal.setIsUnderWriter(object.getShort("isUnderWriter",(short)0));
			
			if(object.get("pWDModifiedOn") != null && !object.get("pWDModifiedOn").equals("")) {
				usermodal.setpWDModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("pWDModifiedOn")));
			}
			
			usermodal.setDefaultLineofBusiness(object.getLong("defaultLineofBusiness",0));
			usermodal.setUserTypeID(object.getLong("userTypeID",0));
			usermodal.setSalesHierarchyID(object.getLong("salesHierarchyID",0));
			usermodal.setCreatedBy(object.getLong("createdBy",0));
			usermodal.setModifiedBy(object.getLong("modifiedBy",0));
			usermodal.setDeletedBy(object.getLong("deletedBy",0));
			
			if(object.get("currentLoginTime") != null) {
				usermodal.setCurrentLoginTime((Timestamp) DateTimeUtility.getTimeStamp(object.getString("currentLoginTime")));
			} else {
				usermodal.setCurrentLoginTime(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("lastLoginTime") != null) {
				usermodal.setLastLoginTime((Timestamp) DateTimeUtility.getTimeStamp(object.getString("lastLoginTime")));
			} else {
				usermodal.setLastLoginTime(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("createdOn") != null) {
				usermodal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				usermodal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			if(object.get("modifiedOn") != null) {
				usermodal.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("modifiedOn")));
			} 
			
			if(object.get("deletedOn") != null) {
				usermodal.setDeletedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("deletedOn")));
			}
			usermodal.setIsActive(object.getShort("isActive",(short)1));
			usermodal.setUserType(object.getShort("userType",(short)0)); 
			usermodal.setMainChannelID(object.getLong("channelID",0));
			usermodal.setSubChannelID(object.getLong("subChannelID",0));
			usermodal.setAgentID(object.getLong("agentID",0));
			usermodal.setUsageID(object.getLong("usageID",0));
			usermodal.setGroupID(object.getLong("groupID",0));
			usermodal.setTPAID(object.getLong("tPAId",0));
			usermodal.setIsLoggedIn(object.getShort("isLoggedIn",(short)1));
			usermodal.setInvalidLoginCount(object.getInt("invalidLoginCount",0));
			usermodal.setModuleID(object.getLong("moduleID",0));
			usermodal.setFeatureID(object.getLong("featureID",0));
			usermodal.setRole(object.getLong("role",0));
			
			lineOfBusinessObj	= (List<Object>) object.get("lineOfBusiness",null);
			System.out.println("branchObjects >>"+lineOfBusinessObj);
			if(lineOfBusinessObj != null) {
				
				lineOfBusinessModalList	= new ArrayList<LineOfBusiness>();
				
				for(Object obj : lineOfBusinessObj) {
					
					objectMapper = new ValueObject((HashMap<Object, Object>) obj);
					System.out.println("objectMapper >>"+objectMapper);
					lineOfBusinessModal	= new LineOfBusiness();
					
					if(objectMapper != null) {
						lineOfBusinessModal.setLineOfBusinessId(objectMapper.getInt("Id",0));
						lineOfBusinessModal.setDescription(objectMapper.getString("value",""));
						lineOfBusinessModal.setCreatedBy(Integer.parseInt(usermodal.getCreatedBy()+""));
						lineOfBusinessModal.setCreatedOn(usermodal.getCreatedOn());
					
						lineOfBusinessModalList.add(lineOfBusinessModal);
					}
				}
			}
			usermodal.setLineOfBusinessModelList(lineOfBusinessModalList);
			return usermodal;
		} catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}

		return null;
	}
	
	public EmployeeModal createEmployeeModal(ValueObject object) throws Exception {
		
		try {
			EmployeeModal employeeModal = new EmployeeModal();
			
			 employeeModal.setOrganisationID(object.getLong("organisationID",0));               
			 employeeModal.setBranchID(object.getLong("branchID",0));               
			 employeeModal.setDepartmentID(object.getLong("departmentID",0));             
			 employeeModal.setGradeID(object.getLong("gradeID",0));                    
			 employeeModal.setDesignationID(object.getLong("designationID",0));           
			 employeeModal.setEmployeeID(object.getLong("employeeID",0));                 
			 employeeModal.setEmployeeNo(object.getString("employeeNo",""));                 
			 employeeModal.setSalutationID(object.getLong("salutationID",0));             
			 employeeModal.setFirstName(object.getString("firstName",""));                   
			 employeeModal.setLastName(object.getString("lastName",""));                       
			 employeeModal.setInitial(object.getString("initial",""));                     
			 employeeModal.setGender(object.getInt("gender",0));                      
			 employeeModal.setMaritalStatus(object.getInt("maritalStatus",0));           
			 employeeModal.setReportingTo(object.getLong("reportingTo",0));  
			 employeeModal.setReportingTypeID(object.getLong("reportingTypeID",0));       
			 employeeModal.setSelectAllBranch(object.getShort("selectAllBranch",(short)0));       
			 employeeModal.setGroupID(object.getLong("groupID",0));                     
			 employeeModal.setEducationID(object.getLong("educationID",0));               
			 employeeModal.setPhoneNo(object.getString("phoneNo",""));                     
			 employeeModal.setPhotos(object.getString("photos",""));                      
			 employeeModal.setMobileNo(object.getString("mobileNo",""));                    
			 employeeModal.setConferenceNo(object.getString("conferenceNo",""));             
			 employeeModal.setFaxNo(object.getString("faxNo",""));                       
			 employeeModal.setEmail(object.getString("email",""));                       
			 employeeModal.setIsUnderWriter(object.getShort("isUnderWriter",(short)0));           
			 employeeModal.setLevelID(object.getLong("levelID",0));                     
			 employeeModal.setAddress(object.getString("address",""));                     
			 employeeModal.setCreatedBy(object.getLong("createdBy",0));                   
			 employeeModal.setIsActive(object.getShort("isActive",(short)1));            
			       
			
			 if(object.get("createdOn") != null) {
				 employeeModal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			 } else {
				 employeeModal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			 }
			if(object.get("dateOfBirth") != null) {
				employeeModal.setDateOfBirth((Timestamp) DateTimeUtility.getTimeStamp(object.getString("dateOfBirth")));
			} else {
				 employeeModal.setDateOfBirth(new Timestamp(System.currentTimeMillis()));
			 }
			if(object.get("dateOfJoin") != null) {
				employeeModal.setDateOfJoin((Timestamp) DateTimeUtility.getTimeStamp(object.getString("dateOfJoin")));
			} else {
				 employeeModal.setDateOfJoin(new Timestamp(System.currentTimeMillis()));
			 }
			
			return employeeModal;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public  List<UserModal> createUserList(ValueObject object) throws Exception {
		
		List<Object> 		userObjList			= null;
		ValueObject			objectMapper		= null;
		UserModal 			usermodal			= null;
		List<UserModal>	 userModalList			= null;
		
		try {
			userObjList	= (List<Object>) object.get("userModalList",null);
			
			System.out.println("branchObjects >>"+userObjList);
			if(userObjList != null) {
				
				userModalList	= new ArrayList<UserModal>();
				
				for(Object obj : userObjList) {
					
					objectMapper = new ValueObject((HashMap<Object, Object>) obj);
					System.out.println("objectMapper >>"+objectMapper);
					usermodal	= new UserModal();
					
					if(objectMapper != null) {
						usermodal.setUserID(objectMapper.getLong("userID",0));
						usermodal.setGroupID(objectMapper.getLong("groupID",0));
						usermodal.setCreatedBy(objectMapper.getLong("createdBy",0));
						
						if(objectMapper.get("createdOn") != null && !objectMapper.get("createdOn").equals("")) {
							usermodal.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(objectMapper.getString("createdOn")));
						} else {
							usermodal.setCreatedOn(new Timestamp(System.currentTimeMillis()));
						}
					
						System.out.println(usermodal.getUserID());
						userModalList.add(usermodal);
					}
				}
			}
			return userModalList;
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<UnderWritingUserRuleLevelModel> createUserUnderWritingList(ValueObject object) {
		List<Object> 							branchObjects		= null;
		ValueObject								objectMapper		= null;
		UnderWritingUserRuleLevelModel		 	branchInfo			= null;
		List<UnderWritingUserRuleLevelModel>	branchInfoList		= null;
		
		try {
			
			branchObjects	= (List<Object>) object.get("underWriter",null);
			System.out.println("branchObjects >>"+branchObjects);
			if(branchObjects != null) {
				
				branchInfoList	= new ArrayList<UnderWritingUserRuleLevelModel>();
				
				for(Object obj : branchObjects) {
					
					objectMapper = new ValueObject((HashMap<Object, Object>) obj);
					System.out.println("objectMapper >>"+objectMapper);
					branchInfo	= new UnderWritingUserRuleLevelModel();
					
					if(objectMapper != null) {
						branchInfo.setUnderWritingLevelID(objectMapper.getLong("levelID",0));
						branchInfo.setIsActive(objectMapper.getShort("isActive",(short)1));
						
						branchInfoList.add(branchInfo);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		}
		
		return branchInfoList;
	}
}

package com.LIC.dao;

import java.security.SecureRandom;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ApplicationPremiumDetails;
import com.LIC.model.Bank;
import com.LIC.model.BankBranch;
import com.LIC.model.BenefitRiders;
import com.LIC.model.ClientAddressDetails;
import com.LIC.model.Country;
import com.LIC.model.District;
import com.LIC.model.MasterBranch;
import com.LIC.model.MasterDedupe;
import com.LIC.model.MasterGrade;
import com.LIC.model.MasterGroupDetails;
import com.LIC.model.MasterModule;
import com.LIC.model.MasterPartyDetails;
import com.LIC.model.MasterPolicyNo;
import com.LIC.model.MasterPolicyUnitAddress;
import com.LIC.model.PartyReceiptDetails;
import com.LIC.model.PolicyAccountStatement;
import com.LIC.model.QuestionMap;
import com.LIC.model.State;
import com.LIC.model.Variant;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.exception.ExceptionProcess;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class ClientOrganizationDAO implements IClientOrganizationDAO {
	
	static final Logger LOGGER = LogManager.getLogger(ClientOrganizationDAO.class);
	private static final String		TRACE_ID = ClientOrganizationDAO.class.getName();
	
	@Autowired 	private JDBCConnection jdbcConnection;
	
	@Autowired	DistrictDao districtDAO;
	
	@Autowired 	StateDao StateDao;
	
	@Autowired CountryDao countryDAO;
	

	@Override
	public void saveOrUpdate(MasterGroupDetails obj) throws SQLException {
		 
		Connection 		connection 		= 		null;
		 ResultSet 		rs 				=	 	null;
		 int 			id				= 		0;
		  
		  try {
			  
				  connection = jdbcConnection.getConnection();
				  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateGroupDetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  callableStatement.setInt(1, obj.getGroupId());
				  callableStatement.setString(2, obj.getGroupName());
				  callableStatement.setString(3, obj.getCustomerGroupId());
				  callableStatement.setString(4, obj.getCoreBusiness());
				  callableStatement.setInt(5, obj.getSalutationId());
				  callableStatement.setString(6,obj.getContactFirstName());
				  callableStatement.setString(7,obj.getContactMiddleName());
				  callableStatement.setString(8,obj.getContactLastName());
				  callableStatement.setString(9,obj.getContact());
				  callableStatement.setInt(10,obj.getMasterPolicyAgreement());
				  callableStatement.setDate(11,obj.getAgreementStartDate());
				  callableStatement.setDate(12,obj.getAgreementEndDate());
				  callableStatement.setInt(13,obj.getBranchId());
				  callableStatement.setString(14,obj.getEmail());
				  callableStatement.setString(15,obj.getEmployeeURLKey());
				  callableStatement.setString(16,obj.getPassword());
				  callableStatement.setBytes(17, null);
				  callableStatement.setInt(18, 1);
				  callableStatement.setDate(19, currentDate());
				  callableStatement.setInt(20, 1);
				  callableStatement.setInt(21, obj.getIsSms());
				  callableStatement.setInt(22,0);
				  callableStatement.setString(23,obj.getShortName());
				  callableStatement.setInt(24, obj.getRiskCategoryId());
				  callableStatement.setInt(25, obj.getTurnOver());
				  callableStatement.setInt(26, obj.getSalesHierarchyId());
				  callableStatement.setInt(27, obj.getIsParentGroup());
				  callableStatement.setInt(28, obj.getParentGroupId());
				  callableStatement.setInt(29, obj.getHierarchyId());
				  callableStatement.setString(30, obj.getPanNo());
				  callableStatement.setString(31, obj.getGstNo());
				  callableStatement.setInt(32, obj.getClientTypeId());
				  callableStatement.setInt(33, obj.getGstTypeId());
				  callableStatement.setString(34, obj.getSacCode());
				  callableStatement.registerOutParameter(35, OracleTypes.CURSOR); 
				  callableStatement.executeUpdate();
			  
				  	rs = ((OracleCallableStatement)callableStatement).getCursor(35);
			  
				  	while (rs.next()) {
				  		id = rs.getInt("GROUPID");
				  	}
				  	System.out.println("SP>spInsertOrUpdateGroupDetails executed successfully. >>" + id);
				  	LOGGER.info("SP>spInsertOrUpdateGroupDetails executed successfully.");
				  	System.out.println("obj.getClientAddressDetails() "+obj.getClientAddressDetails());
				  	if(null != obj.getClientAddressDetails() && !obj.getClientAddressDetails().isEmpty()) {
				  		for(ClientAddressDetails address : obj.getClientAddressDetails()) {
				  			address.setGroupId(id);
				  			saveOrUpdateAddress(address);
				  }
			  }
				  	if(null != obj.getMasterGrades() && !obj.getMasterGrades().isEmpty()) {
				  		for(MasterGrade grade : obj.getMasterGrades()) {
				  			grade.setGroupId(id);
				  			gradeSave(grade);
				  }
			  }
		  } catch (Exception e) {
			  e.printStackTrace();
		  }
	}

	@Override
	public ClientAddressDetails saveOrUpdateAddress(ClientAddressDetails obj) throws SQLException {
		
		 Connection 	connection 		= 		null;
		 ResultSet 		rs 				=	 	null;
		try {
			  connection = jdbcConnection.getConnection();
			  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateGroupAddressDetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, obj.getAddressId());
			  callableStatement.setString(2, obj.getAddress1());
			  callableStatement.setString(3, obj.getAddress2());
			  callableStatement.setString(4, obj.getAddress3());
			  callableStatement.setString(5, obj.getAddress4());
			  callableStatement.setString(6, obj.getAddress5());
			  callableStatement.setInt(7, obj.getCountryId()); 
			  callableStatement.setInt(8, obj.getStateId()); 
			  callableStatement.setInt(9, obj.getDistrictId()); 
			  callableStatement.setInt(10, obj.getTalukaId());
			  callableStatement.setLong(11, obj.getZipCode());
			  callableStatement.setInt(12, obj.getAddressTypeId());
			  callableStatement.setLong(13, obj.getPhoneNo());
			  callableStatement.setLong(14, obj.getMobileNo());
			  callableStatement.setLong(15, obj.getConferenceNo());
			  callableStatement.setLong(16, obj.getFaxNo());
			  callableStatement.setString(17, obj.getEmail());
			  callableStatement.setString(18, obj.getPersonalEmailId());
			  callableStatement.setInt(19, obj.getCreatedBy());
			  callableStatement.setDate(20, currentDate());
			  callableStatement.setInt(21, obj.getIsActive());
			  callableStatement.setString(22, obj.getTehsil());
			  callableStatement.setString(23, obj.getGstNo());
			  callableStatement.setString(24, obj.getPanNo());
			  callableStatement.registerOutParameter(25, OracleTypes.CURSOR);
			  callableStatement.executeUpdate();
			   rs = ((OracleCallableStatement)callableStatement).getCursor(25);
				  while (rs.next()) {
				          obj.setAddressId(rs.getInt("ADDRESSID"));
				         obj.setAddress1(rs.getString("ADDRESS1"));
				         obj.setAddress2(rs.getString("ADDRESS2"));
				         obj.setAddress3(rs.getString("ADDRESS3"));
				         obj.setAddress4(rs.getString("ADDRESS4"));
				      //   obj.setAddress5(rs.getString("ADDRESS5"));
				         obj.setCountryId(rs.getInt("COUNTRYID"));
				         obj.setStateId(rs.getInt("STATEID"));
				         obj.setDistrictId(rs.getInt("DISTRICTID"));
				         obj.setTalukaId(rs.getInt("TALUKID"));
				         obj.setZipCode(rs.getInt("ZIPCODE"));
				         obj.setAddressTypeId(rs.getInt("ADDRESSTYPEID"));
				         obj.setPhoneNo(rs.getInt("PHONENO"));
				         obj.setConferenceNo(rs.getInt("CONFERENCENO"));
				         obj.setFaxNo(rs.getInt("FAXNO"));
				         obj.setEmail(rs.getString("EMAIL"));
				         obj.setPersonalEmailId(rs.getString("PERSONALEMAILID"));
				         obj =  getDistrictStateCountryById(obj.getDistrictId(), obj.getStateId(), obj.getCountryId(), obj);
				         obj.setDistrictName(obj.getDistrictName());
				         obj.setStateName(obj.getStateName());
				         obj.setCountryName(obj.getCountryName());
				      }
			  System.out.println("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
			  LOGGER.info("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
			  if(obj.getGroupId() != 0) {
				  saveGroupAddressDetailsMap(obj.getGroupId(), obj.getAddressId());
			  }
		}catch(Exception e) {
			e.printStackTrace();
		}
		return obj;
			}

	@Override
	public void deleteGroupGrade(Integer gradeId) throws SQLException {
		
		Connection 	connection 		= 		null;
		
		try {
			
			connection = jdbcConnection.getConnection();
			CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteGrade(?,?,?,?); END;");
			callableStatement.setInt(1, gradeId);
			callableStatement.setInt(2, 0);
			callableStatement.setDate(3,  currentDate());
			callableStatement.setInt(4, 0);
			callableStatement.executeUpdate();
			System.out.println("SP>spDeleteGrade executed successfully.");
			LOGGER.info("SP>spDeleteGrade executed successfully.");
		
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
		
	
	@Override
	public List<MasterBranch> getAll(MasterBranch masterBranch) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<MasterBranch> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllBranchValues(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  MasterBranch obj = null;
			  list = new ArrayList<MasterBranch>();
		      while (rs.next()) {
		        obj = new MasterBranch();
		        obj.setBranchName(rs.getString("Description"));
		        obj.setBranchCode(rs.getString("ID"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllLookup executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllLookup exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	}


	/*@Override
	public List<MasterGroupDetails> searchBranch(MasterGroupDetails masterGroupDetails) throws SQLException {
		  Connection 					connection = null;
		  ResultSet 					rs = null;
		  CallableStatement 			callableStatement = null;
		  List<MasterGroupDetails> 		list = null;
		  MasterGroupDetails 			masterGroupDetailsModel = null;
		  try {
				 
			  		connection = jdbcConnection.getConnection();
			  		
			  	  //callableStatement = connection.prepareCall("BEGIN spGetSearchGroupDetails(?,?,?,?,?,?,?,?); END;");
				  callableStatement = connection.prepareCall("BEGIN spGetSearchGroupDetails(?,?,?,?,?,?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  callableStatement.setString(1, masterGroupDetails.getGroupName()!=null ?masterGroupDetails.getGroupName():"");
				  callableStatement.setString(2, masterGroupDetails.getContactFirstName()!=null?masterGroupDetails.getContactFirstName():"");
				  callableStatement.setString(3, masterGroupDetails.getContactLastName()!=null?masterGroupDetails.getContactLastName():"");
				  callableStatement.setString(4, (String.valueOf(masterGroupDetails.getGroupId())!=null && masterGroupDetails.getGroupId()!=0)?String.valueOf(masterGroupDetails.getGroupId()):"");
				  callableStatement.setString(5, (String.valueOf(masterGroupDetails.getBranchId())!=null && masterGroupDetails.getBranchId()!=0)?String.valueOf(masterGroupDetails.getBranchId()):"");
				  callableStatement.setInt(6, new Integer(10));
				  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
	   		     // callableStatement.registerOutParameter(8, OracleTypes.CURSOR); 
				  callableStatement.execute();
				  rs = ((OracleCallableStatement)callableStatement).getCursor(7);
				  if(rs==null)
				  {
					  rs=((OracleCallableStatement)callableStatement).getCursor(8);
				  }
						  
				  masterGroupDetailsModel = null;
				  list = new ArrayList<MasterGroupDetails>();
			     if(rs != null) {
					  while (rs.next()) {
				    	  masterGroupDetailsModel = new MasterGroupDetails();
				    	  
				    	  masterGroupDetailsModel.setGroupName(rs.getString("GroupName"));
				    	  masterGroupDetailsModel.setGroupId(rs.getInt("PartyID"));
				    	  masterGroupDetailsModel.setCoreBusiness(rs.getString("CoreBusiness"));
				    	  masterGroupDetailsModel.setContactFirstName(rs.getString("ContactFirstName"));
				    	  
				    	  list.add(masterGroupDetailsModel);
				      }
				  }
				  LOGGER.info("SP>spGetAllLookup executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllLookup exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	}*/
	
	@Override
	public List<MasterGroupDetails> searchBranch(MasterGroupDetails masterGroupDetails) throws Exception {
		  Connection 					connection 				= null;
		  ResultSet 					rs 						= null;
		  CallableStatement 			callableStatement 		= null;
		  List<MasterGroupDetails> 		list 					= null;
		  MasterGroupDetails 			masterGroupDetailsModel = null;
		  try {
				 
			  		connection = jdbcConnection.getConnection();
			  		
				  callableStatement = connection.prepareCall("BEGIN spGetSearchGroupDetails(?,?,?,?,?,?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  
				  callableStatement.setString(1, masterGroupDetails.getGroupName()!=null ?	masterGroupDetails.getGroupName():"");
				  callableStatement.setString(2, masterGroupDetails.getContactFirstName()!=null	? masterGroupDetails.getContactFirstName():"");
				  callableStatement.setString(3, masterGroupDetails.getContactLastName()!=null ? masterGroupDetails.getContactLastName():"");
				  callableStatement.setString(4, masterGroupDetails.getCustomerGroupId() != null ? masterGroupDetails.getCustomerGroupId() : "");
				  callableStatement.setInt(5, masterGroupDetails.getBranchId());
				  callableStatement.setLong(6, masterGroupDetails.getCreatedBy());
				  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
				  callableStatement.execute();
				
				  rs = ((OracleCallableStatement)callableStatement).getCursor(7);
				  
						  
				  masterGroupDetailsModel = null;
				  list = new ArrayList<MasterGroupDetails>();
				  if(rs != null) {
					  while (rs.next()) {
				    	  masterGroupDetailsModel = new MasterGroupDetails();
				    	  
				    	  masterGroupDetailsModel.setGroupName(rs.getString("GroupName"));
				    	  masterGroupDetailsModel.setGroupId(rs.getInt("PartyID"));
				    	  masterGroupDetailsModel.setCoreBusiness(rs.getString("CoreBusiness"));
				    	  masterGroupDetailsModel.setContactFirstName(rs.getString("ContactFirstName"));
				    	  System.out.println("masterGroupDetailsModel "+masterGroupDetailsModel);
				    	  list.add(masterGroupDetailsModel);
				      }
				  }
				  LOGGER.info("SP>spGetSearchGroupDetails executed successfully.");
				  return list;
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetSearchGroupDetails exception occured."+e.getMessage());
			  e.printStackTrace();
			  throw ExceptionProcess.execute(e, TRACE_ID);
		  }finally {
			  rs.close();
			  callableStatement.close();
		  }
		 
	}


	@Override
	public List<MasterGroupDetails> getAllCient(MasterGroupDetails masterGroupDetails) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<MasterGroupDetails> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllMasterGroupDetails(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  MasterGroupDetails obj = null;
			  list = new ArrayList<MasterGroupDetails>();
		      while (rs.next()) {
		        obj = new MasterGroupDetails();
		        obj.setGroupName(rs.getString("GroupName"));
		        obj.setGroupId(rs.getInt("GroupId"));
		        obj.setCoreBusiness(rs.getString("CoreBusiness"));
		        obj.setContactFirstName(rs.getString("ContactFirstName"));
		        obj.setShortName(rs.getString("ShortName"));
//		        obj.setBranchCode(rs.getString("ID"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllLookup executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllLookup exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	}


	@Override
	public MasterGroupDetails getClientById(Integer clientId) throws SQLException {

		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  ResultSet rs2 = null;
//		  ResultSet rs3 = null;
//		  ResultSet rs4 = null;
//		  ResultSet rs5 = null;
//		  ResultSet rs6 = null;
//		  ResultSet rs7 = null;
		  ResultSet rs8 = null;
		  CallableStatement callableStatement = null;
		  MasterGroupDetails obj = null;	
		  List<ClientAddressDetails> clientAddressDetailsList=null;
		  List<MasterGrade>masterGradesList=null;
		  try {
			  if(clientId!=null)
			  {
			  callableStatement = connection.prepareCall("BEGIN spGetGroupDetailsByGroupID(?,?,?,?,?,?,?,?,?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1,clientId);
			  callableStatement.setInt(2,new Integer(1));
			  callableStatement.registerOutParameter(3, OracleTypes.CURSOR); 
			  callableStatement.registerOutParameter(4, OracleTypes.CURSOR); 
			  callableStatement.registerOutParameter(5, OracleTypes.CURSOR); 
			  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
			  callableStatement.registerOutParameter(7, OracleTypes.CURSOR); 
			  callableStatement.registerOutParameter(8, OracleTypes.CURSOR); 
			  callableStatement.registerOutParameter(9, OracleTypes.CURSOR); 
			  callableStatement.registerOutParameter(10, OracleTypes.CURSOR); 
			  
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(3);
			  rs2 = ((OracleCallableStatement)callableStatement).getCursor(4);
//			  rs3 = ((OracleCallableStatement)callableStatement).getCursor(5);
//			  rs4 = ((OracleCallableStatement)callableStatement).getCursor(6);
//			  rs5 = ((OracleCallableStatement)callableStatement).getCursor(7);
//			  rs6 = ((OracleCallableStatement)callableStatement).getCursor(8);
//			  rs7 = ((OracleCallableStatement)callableStatement).getCursor(9);
			  rs8 = ((OracleCallableStatement)callableStatement).getCursor(10);
			  
		      while (rs.next()) {
		        obj = new MasterGroupDetails();
		        clientAddressDetailsList=new ArrayList<ClientAddressDetails>();
		        masterGradesList=new ArrayList<MasterGrade>();
		        obj.setCoreBusiness(rs.getString("CoreBusiness"));
		        obj.setGroupId(rs.getInt("GroupId"));
		        obj.setGroupName(rs.getString("GroupName"));
		        obj.setCustomerGroupId(rs.getString("CustomerGroupID"));
		        obj.setSalutationId(rs.getInt("SalutationID"));
		        obj.setContactFirstName(rs.getString("ContactFirstName"));
		        obj.setContactLastName(rs.getString("ContactLastName"));
		        obj.setContactMiddleName(rs.getString("ContactMiddleName"));
		        obj.setContact(rs.getString("ContactNumber"));
		        obj.setMasterPolicyAgreement(rs.getInt("MasterPolicyAgreement"));
		        obj.setShortName(rs.getString("ShortName"));
		        obj.setTurnOver(rs.getInt("TurnOver"));
		        obj.setRiskCategoryId(rs.getInt("RiskCategoryID"));
		        obj.setAgreementStartDate(rs.getDate("AgreementStartDate"));
		        obj.setAgreementEndDate(rs.getDate("AgreementEndDate"));
		        obj.setBranchId(rs.getInt("BranchID"));
		        obj.setIsSms(rs.getShort("IsSmsAplicable"));
		        obj.setIsEmail(rs.getShort("IsEmailAplicable"));
		        //obj.setLogo(rs.getString("Logo"));
		        obj.setEmail(rs.getString("Email"));
		        obj.setEmployeeURLKey(rs.getString("EmployeeURLKey"));
		        obj.setSalesHierarchyId(rs.getInt("SalesHierarchyID"));
		        obj.setParentGroupId(rs.getInt("ParentGroupID"));
		        obj.setHierarchyId(rs.getInt("HierarchyID"));
		        obj.setPanNo(rs.getString("PANNo"));
		        obj.setGstNo(rs.getString("GSTNo"));
		        obj.setIsParentGroup(rs.getInt("IsParentGroup"));
		        obj.setClientTypeId(rs.getInt("ClientTypeID"));
		        obj.setGstTypeId(rs.getInt("GSTTypeID"));
		        obj.setSacCode(rs.getString("SACCode"));
		        
		        while(rs2.next())
		        {
		        	ClientAddressDetails clientAddressDetails=new ClientAddressDetails();
		        	clientAddressDetails.setAddressId(rs2.getInt("AddressID"));
		        	clientAddressDetails.setAddress1(rs2.getString("Address1"));
		        	clientAddressDetails.setAddress2(rs2.getString("Address1"));
		        	clientAddressDetails.setAddress3(rs2.getString("Address3"));
		        	clientAddressDetails.setAddress4(rs2.getString("Address4"));
		        	clientAddressDetails.setCountryId(rs2.getInt("CountryID"));
		        	clientAddressDetails.setCountryName(rs2.getString("Country"));
		        	clientAddressDetails.setTehsil(rs2.getString("Tehsil"));
		        	clientAddressDetails.setDistrictId(rs2.getInt("DistrictID"));
		        	clientAddressDetails.setDistrictName(rs2.getString("District"));
		        	clientAddressDetails.setTalukaId(rs2.getInt("TalukID"));
		        	clientAddressDetails.setTalukaName(rs2.getString("Taluk"));
		        	clientAddressDetails.setZipCode(rs2.getInt("ZipCode"));
		        	clientAddressDetails.setAddressTypeId(rs2.getInt("AddressTypeID"));
		        	clientAddressDetails.setPhoneNo(rs2.getLong("PhoneNo"));
		        	clientAddressDetails.setMobileNo(rs2.getLong("MobileNo"));
		        	clientAddressDetails.setConferenceNo(rs2.getLong("ConferenceNo"));
		        	clientAddressDetails.setFaxNo(rs2.getLong("FaxNo"));
		        	clientAddressDetails.setEmail(rs2.getString("Email"));
		        	clientAddressDetails.setGstNo(rs2.getString("GSTNo"));
		        	clientAddressDetails.setPanNo(rs2.getString("PANNo"));
		        	clientAddressDetailsList.add(clientAddressDetails);
		        }
		        
		        while(rs8.next())
		        {
		        	MasterGrade masterGrade =new MasterGrade();
		        	masterGrade.setGradeId(rs8.getInt("GRADEID"));
		        	masterGrade.setDescription(rs8.getString("DESCRIPTION"));
		        	masterGradesList.add(masterGrade);
		        }
		       
		        obj.setClientAddressDetails(clientAddressDetailsList);
		        obj.setMasterGrades(masterGradesList);
		        
//		        obj.setBranchName(rs.getString("Description"));
//		        obj.setBranchCode(rs.getString("ID"));	
		      }
			  LOGGER.info("SP>spGetAllLookup executed successfully.");
		  }
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllLookup exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	@Override
	public MasterGrade gradeSave(MasterGrade masterGrade) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  MasterGrade obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateGrade(?,?,?,?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, 1);
			  callableStatement.setInt(2, masterGrade.getGradeId());
			  callableStatement.setString(3, masterGrade.getDescription());
			  callableStatement.setInt(4, 1);
     		  callableStatement.registerOutParameter(5, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(5);
			 
		      while (rs.next()) {
		        obj = new MasterGrade();
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setGradeId(rs.getInt("GRADEID"));
		      }
		      if(masterGrade.getGroupId() != 0) {
		    	  saveGroupGradeDetailsMap(masterGrade.getGroupId(), obj.getGradeId(), obj.getDescription());
		      }
			  LOGGER.info("SP>spGetAllLookup executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllLookup exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	}

	@Override
	public void deleteAddressDetails(Integer addressId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteGroupAddress(?); END;");
		callableStatement.setInt(1, addressId);
		  callableStatement.execute();
		  System.out.println("SP>spDeleteAddress executed successfully.");
		  LOGGER.info("SP>spDeleteAddress executed successfully.");
	}

	public void saveGroupAddressDetailsMap(int groupId, int addressId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection
				.prepareCall("BEGIN spInsertGroupAddressDetailsMap(?,?,?,?,?); END;");
		callableStatement.setInt(1, groupId);
		callableStatement.setInt(2, addressId);
		callableStatement.setInt(3, 1);
		callableStatement.setDate(4, currentDate());
		callableStatement.setInt(5, 0);
		callableStatement.execute();
		System.out.println("SP>spInsertGroupAddressDetailsMap executed successfully.");
		LOGGER.info("SP>spInsertGroupAddressDetailsMap executed successfully.");
	}
	
	public void saveGroupGradeDetailsMap(int groupId, int gradeId, String description) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection
				.prepareCall("BEGIN spInsertOrUpdateGroupGradeDetails(?,?,?,?,?,?); END;");
		callableStatement.setInt(1, groupId);
		callableStatement.setInt(2, gradeId);
		callableStatement.setString(3, description);
		callableStatement.setInt(4, groupId);
		callableStatement.setDate(5, null);
		callableStatement.setInt(6, 0);
		callableStatement.execute();
		System.out.println("SP>spInsertOrUpdateGroupGradeDetails executed successfully.");
		LOGGER.info("SP>spInsertOrUpdateGroupGradeDetails executed successfully.");
	}

	@Override
	public MasterPolicyUnitAddress saveOrUpdateMasterPolicyUnitAddress(MasterPolicyUnitAddress obj)
			throws SQLException {

		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateMasterPolicyUnitAddress(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		  callableStatement.setInt(1, obj.getAddressId());
		  callableStatement.setString(2, obj.getAddress1());
		  callableStatement.setString(3, obj.getAddress2());
		  callableStatement.setString(4, obj.getAddress3());
		  callableStatement.setString(5, obj.getAddress4());
		  callableStatement.setString(6, obj.getAddress5());
		  callableStatement.setInt(7, obj.getCountryId()); 
		  callableStatement.setInt(8, obj.getStateId()); 
		callableStatement.setInt(9, obj.getDistrictId()); 
		  callableStatement.setInt(10, obj.getTalukaId());
		  callableStatement.setLong(11, obj.getZipCode());
		  callableStatement.setInt(12, obj.getAddressTypeId());
		  callableStatement.setLong(13, obj.getPhoneNo());
		  callableStatement.setLong(14, obj.getMobileNo());
		  callableStatement.setLong(15, obj.getConferenceNo());
		  callableStatement.setLong(16, obj.getFaxNo());
		  callableStatement.setString(17, obj.getEmail());
		  callableStatement.setString(18, obj.getPersonalEmailId());
		  callableStatement.setInt(19, obj.getCreatedBy());
		  callableStatement.setDate(20, currentDate());
		  callableStatement.setInt(21, 1);
		  callableStatement.setString(22, obj.getTehsil());
		  callableStatement.setString(23, obj.getUnitName());
		  callableStatement.setString(24, obj.getGstNo());
		  callableStatement.setString(25, obj.getPanNo());
		  callableStatement.setInt(26, obj.getMasterpolicyId());
		  callableStatement.registerOutParameter(27, OracleTypes.CURSOR);
		  callableStatement.executeUpdate();
		   rs = ((OracleCallableStatement)callableStatement).getCursor(27);
			  while (rs.next()) {
			          obj.setAddressId(rs.getInt("ADDRESSID"));
			         obj.setAddress1(rs.getString("ADDRESS1"));
			         obj.setAddress2(rs.getString("ADDRESS2"));
			         obj.setAddress3(rs.getString("ADDRESS3"));
			         obj.setAddress4(rs.getString("ADDRESS4"));
			      //   obj.setAddress5(rs.getString("ADDRESS5"));
			         obj.setCountryId(rs.getInt("COUNTRYID"));
			         obj.setStateId(rs.getInt("STATEID"));
			         obj.setDistrictId(rs.getInt("DISTRICTID"));
			         obj.setTalukaId(rs.getInt("TALUKID"));
			         obj.setZipCode(rs.getInt("ZIPCODE"));
			         obj.setAddressTypeId(rs.getInt("ADDRESSTYPEID"));
			         obj.setPhoneNo(rs.getInt("PHONENO"));
			         obj.setConferenceNo(rs.getInt("CONFERENCENO"));
			         obj.setFaxNo(rs.getInt("FAXNO"));
			         obj.setEmail(rs.getString("EMAIL"));
			         obj.setPersonalEmailId(rs.getString("PERSONALEMAILID"));
			        obj.setUnitName(rs.getString("UNITNAME"));
			      }
		  System.out.println("SP>spInsertOrUpdateMasterPolicyUnitAddress executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateMasterPolicyUnitAddress executed successfully.");
		  return obj; 
	}

	@Override
	public void saveOrUpdateMasterPolicyNo(MasterPolicyNo masterPolicyNo) throws Exception {
		Connection 				connection 			= null;
		CallableStatement 		callableStatement 	= null;
		int masterPolicyId = 0 ;
		try {
				connection = jdbcConnection.getConnection();
				callableStatement = connection.prepareCall(
							"BEGIN spinsertorupdatemastergrouppolicyno(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
			callableStatement = callableStatement.unwrap(CallableStatement.class);
			callableStatement.setInt(1, String.valueOf(masterPolicyNo.getLineofbusinessid())!=null && masterPolicyNo.getLineofbusinessid()!=0?masterPolicyNo.getLineofbusinessid():0);
			callableStatement.setInt(2, masterPolicyNo.getInsurerid());
			callableStatement.setInt(3, masterPolicyNo.getProductid());
			callableStatement.setInt(4, masterPolicyNo.getPlancategoryid());
			callableStatement.setInt(5, masterPolicyNo.getTypeid());
			callableStatement.setInt(6, masterPolicyNo.getAffinitytypeid());
			callableStatement.setString(7, masterPolicyNo.getMasterpolicyno());
			callableStatement.setInt(8, masterPolicyNo.getGroupid());
			callableStatement.setDate(9, masterPolicyNo.getAgreementenddate());
			callableStatement.setDate(10, masterPolicyNo.getAgreementstartdate());
			callableStatement.setInt(11, masterPolicyNo.getTotalmembers());
			callableStatement.setString(12, masterPolicyNo.getSpecialcondition());
			callableStatement.setInt(13, masterPolicyNo.getSuminsured());
			callableStatement.setInt(14, masterPolicyNo.getSaleshierarchyid());
			callableStatement.setString(15, masterPolicyNo.getSaleshierarcycode());
			callableStatement.setInt(16, masterPolicyNo.getBranchid());
			callableStatement.setInt(17, masterPolicyNo.getIsfloter());
			callableStatement.setInt(18, masterPolicyNo.getIsddloading());
			callableStatement.setInt(19, masterPolicyNo.getDdloadingvalue());
			callableStatement.setInt(20, masterPolicyNo.getMainchannelid());
			callableStatement.setInt(21, masterPolicyNo.getSubchannelid());
			callableStatement.setInt(22, masterPolicyNo.getIsadvancedeposit());
			callableStatement.setString(23, masterPolicyNo.getSubchannelsalestype());
			callableStatement.setString(24, masterPolicyNo.getRelationshipids());
			callableStatement.setString(25, masterPolicyNo.getNomineerelationshipids());
			callableStatement.setString(26, masterPolicyNo.getCoefficientids());
			callableStatement.setString(27, masterPolicyNo.getInsurermasteragreementno());
			callableStatement.setInt(28, masterPolicyNo.getGradeid());
			callableStatement.setInt(29, masterPolicyNo.getTpaid());
			callableStatement.setString(30, masterPolicyNo.getTpapolicynumber());
			callableStatement.setInt(31, masterPolicyNo.getCreatedby());
			callableStatement.setDate(32, currentDate());
			callableStatement.setInt(33, masterPolicyNo.getIsactive());
			callableStatement.setString(34, masterPolicyNo.getDescription());
			callableStatement.setInt(35, masterPolicyNo.getAgreementtypeid());
			callableStatement.setInt(36, masterPolicyNo.getCalculationtypeid());
			callableStatement.setInt(37, masterPolicyNo.getTotallives());
			callableStatement.setInt(38, masterPolicyNo.getTotalpremiumamount());
			callableStatement.setInt(39, masterPolicyNo.getFamilysizeid());
			callableStatement.setInt(40, masterPolicyNo.getQuotationid());
			callableStatement.setInt(41, masterPolicyNo.getMasterpolicyid());
			callableStatement.setInt(42, masterPolicyNo.getDatauploadheaderid());
			callableStatement.setInt(43, masterPolicyNo.getBenefittypeid());
			callableStatement.setInt(44, masterPolicyNo.getIsemployee());
			callableStatement.setInt(45, masterPolicyNo.getIscorporate());
			callableStatement.setInt(46, masterPolicyNo.getStatusid());
			callableStatement.setString(47, masterPolicyNo.getRemarks());
			callableStatement.setString(48, masterPolicyNo.getContactnumber());
			callableStatement.setString(49, masterPolicyNo.getEmailId());
			callableStatement.setInt(50, masterPolicyNo.getAddressdifferfromclientorg());
			callableStatement.setString(51, masterPolicyNo.getClientnameunit());
			callableStatement.setString(52, masterPolicyNo.getContactpersonfirstname());
			callableStatement.setString(53, masterPolicyNo.getContactpersonmiddlename());
			callableStatement.setString(54, masterPolicyNo.getContactpersonlastname());
			callableStatement.setString(55, masterPolicyNo.getPanno());
			callableStatement.setInt(56, masterPolicyNo.getTypeofclient());
			callableStatement.setInt(57, masterPolicyNo.getGsttype());
			callableStatement.setString(58, masterPolicyNo.getGstin());
			callableStatement.setInt(59, masterPolicyNo.getWindowperiod());
			callableStatement.setInt(60, masterPolicyNo.getNormalretirementage());
			callableStatement.setInt(61, masterPolicyNo.getIsnriletterreceived());
			callableStatement.setDate(62, masterPolicyNo.getNriletterreceiveddate());
			callableStatement.setInt(63, masterPolicyNo.getPaymentfrequencyid());
			callableStatement.setInt(64, masterPolicyNo.getModalfactors());
			callableStatement.setInt(65, masterPolicyNo.getIspsuflag());
			callableStatement.setInt(66, masterPolicyNo.getZoneid());
			callableStatement.setInt(67, masterPolicyNo.getSalutationid());
			callableStatement.setInt(68, masterPolicyNo.getActivelyatworkclause());
			callableStatement.setString(69, masterPolicyNo.getActivelyatworkclauseremarks());
			callableStatement.setString(70, masterPolicyNo.getQuotationdesc());
			callableStatement.setInt(71, masterPolicyNo.getIsdeclaration());
			callableStatement.setInt(72, masterPolicyNo.getIssfq());
			callableStatement.setString(73, masterPolicyNo.getDescription());
			callableStatement.registerOutParameter(74, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(75, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(76, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(77, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(78, OracleTypes.CURSOR);
			callableStatement.executeUpdate();
			ResultSet  rs = ((OracleCallableStatement)callableStatement).getCursor(78);
			
			  if(rs.next()) {
				  System.out.println("masterpolicyid >>>>>>> "+rs.getInt("masterpolicyid"));
				  masterPolicyNo.setMasterpolicyid(rs.getInt("masterpolicyid"));
				  
				  saveOrUpdateMasterGroupPolicyProductMapping(masterPolicyNo);
				  
				  if(masterPolicyNo.getMasterPolicyUnitAddresses()!=null && masterPolicyNo.getMasterPolicyUnitAddresses().size()>0) {
					  	
					  for(MasterPolicyUnitAddress masterPolicyUnitAddress : masterPolicyNo.getMasterPolicyUnitAddresses()) {
								if(masterPolicyUnitAddress.getUnitName() ==null || masterPolicyNo.getAddressStatus() ==0){
									MasterPolicyUnitAddress masterPolicyUnitAddress1= (MasterPolicyUnitAddress) masterPolicyUnitAddress.clone();
									if(masterPolicyNo.getAddressStatus()==0)
									{
										masterPolicyUnitAddress1	=	saveOrUpdateMasterPolicyAddress(masterPolicyUnitAddress1);
									}
									callableStatement = connection.prepareCall("BEGIN spInsertMasterPolicyAddressDetailsMap(?,?,?,?); END;");
									callableStatement = callableStatement.unwrap(CallableStatement.class);
									callableStatement.setInt(1,rs.getInt("masterpolicyid"));
									callableStatement.setInt(2, masterPolicyUnitAddress1.getAddressId());
									callableStatement.setInt(3, masterPolicyNo.getCreatedby());
									callableStatement.setDate(4,currentDate());
									callableStatement.executeUpdate();
								}
								if(masterPolicyUnitAddress.getUnitName()!=null){
									masterPolicyUnitAddress.setMasterpolicyId(rs.getInt("masterpolicyid"));
									saveOrUpdateMasterPolicyUnitAddress(masterPolicyUnitAddress);
								}
					  	}
				  }	
				 for (BenefitRiders benefitRiders : masterPolicyNo.getBenefitRiders()) {
					 
					 callableStatement = connection.prepareCall("BEGIN spInsertMasterGroupPolicyCoverageMapping(?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
						callableStatement = callableStatement.unwrap(CallableStatement.class);
						
						callableStatement.setInt(1, 0);
						callableStatement.setInt(2,rs.getInt("masterpolicyid"));
						callableStatement.setInt(3, rs.getInt("Productid"));
						callableStatement.setInt(4, benefitRiders.getCoverageId());
						callableStatement.setInt(5, rs.getInt("SUMINSURED"));
						callableStatement.setInt(6, benefitRiders.getType());
						callableStatement.setDouble(7,benefitRiders.getVariantSumAssured());
						callableStatement.setInt(8,benefitRiders.getMultipleOfSalary());
						callableStatement.setDouble(9,benefitRiders.getMinimumSumAssured());
						callableStatement.setDouble(10,benefitRiders.getMaximumSumAssured());
						callableStatement.setInt(11, benefitRiders.getGradeID());
						callableStatement.setDouble(12, benefitRiders.getBaseBenefitPercentage());
						callableStatement.setInt(13, benefitRiders.getRetirementAge());
						callableStatement.executeUpdate();
				}
		          
		      }
		}catch (Exception e) {
			LOGGER.error("saveOrUpdateMasterPolicyNo exception occured."+e.getMessage());
			  e.printStackTrace();
			  throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {
			
		}
	
	}
	
	public void saveOrUpdateMasterGroupPolicyProductMapping(MasterPolicyNo masterPolicyNo) throws Exception {
		Connection 				connection 			= null;
		CallableStatement 		callableStatement 	= null;
		try {
				connection = jdbcConnection.getConnection();
				callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateMasterGroupPolicyProductMapping(?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
				callableStatement = callableStatement.unwrap(CallableStatement.class);
				
				callableStatement.setInt(1, masterPolicyNo.getLineofbusinessid());
				callableStatement.setInt(2,masterPolicyNo.getInsurerid());
				callableStatement.setInt(3,masterPolicyNo.getProductid());
				callableStatement.setInt(4,masterPolicyNo.getPlancategoryid());
				callableStatement.setInt(5, masterPolicyNo.getTypeid());
				callableStatement.setInt(6,masterPolicyNo.getAffinitytypeid());
				callableStatement.setInt(7,masterPolicyNo.getMasterpolicyid());
				callableStatement.setString(8, masterPolicyNo.getRelationshipids());
				callableStatement.setString(9, masterPolicyNo.getNomineerelationshipids());
				callableStatement.setString(10,masterPolicyNo.getCoefficientids());
				callableStatement.setInt(11, masterPolicyNo.getGroupid());
				callableStatement.setInt(12, masterPolicyNo.getCreatedby());
				callableStatement.setDate(13, masterPolicyNo.getCreatedOn());
				callableStatement.executeUpdate();
		} catch (Exception e) {
			LOGGER.error("spInsertOrUpdateMasterGroupPolicyProductMapping exception occured."+e.getMessage());
			  e.printStackTrace();
			  throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {
				  callableStatement.close();
				  connection = null;
		}
	
		}
	
	public ClientAddressDetails getDistrictStateCountryById(Integer id, Integer stateId, Integer countryId, ClientAddressDetails clientAddressDetails) throws SQLException {
		District district = districtDAO.get(id);
		if(null != district) {
			clientAddressDetails.setDistrictName(district.getDescription());
		}
		State state = StateDao.get(stateId);
		if(null != state) {
			clientAddressDetails.setStateName(state.getDescription());
		}
		Country country = countryDAO.get(countryId);
		if(null != country) {
			clientAddressDetails.setCountryName(country.getDescription());
		}
		return clientAddressDetails;
	}

	@Override
	public List<MasterPolicyNo> searchAdvanceDepositReceipt(String clientName, String receiptNo ) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<MasterPolicyNo> masterPolicyNo = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN SPGETSEARCHPARTYRECIEPENTBYRECIEPTNO(?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setString(1, (null!=receiptNo && receiptNo!="0")?receiptNo:"0");
		callableStatement.setString(2, (null!=clientName&& !clientName.isEmpty())?clientName:"");
		callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(3);
		 MasterPolicyNo obj = null;
		  masterPolicyNo = new ArrayList<MasterPolicyNo>();
	      while (rs.next()) {
	        obj = new MasterPolicyNo();
	        obj.setMasterpolicyno(rs.getString("MasterPolicyNo"));
	        obj.setInsurermasteragreementno(rs.getString("InsurerMasterAgreementNo"));
	        obj.setGroupName(rs.getString("GROUPNAME"));
	        obj.setReceiptNo(rs.getString("ReceiptNo"));
	        masterPolicyNo.add(obj);
	      }
		return masterPolicyNo;
	}
	/*
	@Override
	public List<MasterPolicyNo> searchMasterPolicyDetails(String clientName, String ageementNo) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<MasterPolicyNo> masterPolicyNo = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN SPGETSEARCHPARTYRECIEPENTBYRECIEPTNO(?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setString(1, (null!=ageementNo && ageementNo!="0")?ageementNo: null );
		callableStatement.setString(2, null!=clientName?clientName:"");
		callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(3);
		 MasterPolicyNo obj = null;
		  masterPolicyNo = new ArrayList<MasterPolicyNo>();
	      while (rs.next()) {
	        obj = new MasterPolicyNo();
	        obj.setMasterpolicyno(rs.getString("MasterPolicyNo"));
	        obj.setInsurermasteragreementno(rs.getString("InsurerMasterAgreementNo"));
	        obj.setGroupName(rs.getString("GROUPNAME"));
	        obj.setReceiptNo(rs.getString("ReceiptNo"));
	        masterPolicyNo.add(obj);
	      }
		return masterPolicyNo;
	}*/
	
	@Override
	public List<MasterPolicyNo> searchMasterPolicyDetails(long groupId ) throws Exception {
		Connection 				connection 			= null;
		ResultSet 				rs 					= null;
		List<MasterPolicyNo> 	masterPolicyNoList 	= null;
		CallableStatement 		callableStatement  	= null;
		MasterPolicyNo masterPolicyNo = null;
		try {
			connection = jdbcConnection.getConnection();
				callableStatement = connection.prepareCall("BEGIN spGetHealthGroupByGroupId(?,?); END;");
				
				callableStatement = callableStatement.unwrap(CallableStatement.class);
				callableStatement.setLong(1, groupId);
				callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
				callableStatement.execute();
				
				rs = ((OracleCallableStatement)callableStatement).getCursor(2);
				 
				 masterPolicyNoList = new ArrayList<MasterPolicyNo>();
			      while (rs.next()) {
			    	  
			    	    masterPolicyNo = new MasterPolicyNo();
			    	    
			    	    
			    	    masterPolicyNo.setGroupid(rs.getInt("GroupID"));
			    	    masterPolicyNo.setShortName(rs.getString("ShortName"));
			    	    masterPolicyNo.setGroupName(rs.getString("OrganisationName"));
			    	    masterPolicyNo.setContactpersonfirstname(rs.getString("ContactFirstName"));
			    	    masterPolicyNo.setContactpersonlastname(rs.getString("ContactLastName"));
			    	    masterPolicyNo.setContactnumber(rs.getString("ContactNumber"));
			    	    masterPolicyNo.setCoreBusiness(rs.getString("CoreBusiness")); 
			    	    masterPolicyNo.setTotalmembers(rs.getInt("TotalMembersCovered"));
			    	    masterPolicyNo.setAgreementstartdate(rs.getDate("AgreementStartDate"));
			    	    masterPolicyNo.setAgreementenddate(rs.getDate("AgreementEndDate"));
			    	    masterPolicyNo.setSaleshierarchyid(rs.getInt("SalesHierarchyID"));
			    	    masterPolicyNo.setMasterPolicyAgreement(rs.getString("MasterPolicyAgreement"));
			    	    masterPolicyNo.setGstin(rs.getString("GSTNo"));
			    	    masterPolicyNo.setPanno(rs.getString("PANNo"));
			    	    masterPolicyNo.setCustomerGroupId(rs.getString("CustomerGroupID"));
			    	    masterPolicyNo.setGstTypeId(rs.getInt("GSTTypeID"));
			    	    masterPolicyNo.setClientTypeId(rs.getInt("ClientTypeID"));
			    	    masterPolicyNo.setCode(rs.getString("Code"));
			    	  
			        masterPolicyNoList.add(masterPolicyNo);
			      }
				return masterPolicyNoList;
		}catch(Exception e){
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {
			callableStatement.close();
			callableStatement	= null;
  			ResourceManager.freeConnection(connection);
  			connection	= null;
		}
		
	}
	public List<MasterPolicyNo> getMasterPolicyDetailsByGroupId(long groupId,String pageType,long masterPolicyId ) throws Exception {
		Connection 				connection 				= null;
		ResultSet 				resultSet 				= null;
		ResultSet 				resultSet1 				= null;
		List<MasterPolicyNo> 	masterPolicyNoList 		= null;
		CallableStatement 		callableStatement  		= null;
		MasterPolicyNo 			masterPolicyNo 			= null;
		HashMap<Integer, MasterPolicyNo> masterPolicyNoHM 	= null;
		try {
			connection 			= jdbcConnection.getConnection();
			callableStatement 	= connection.prepareCall("BEGIN spGetMasterAgreementDetailsByGroupID(?,?,?,?,?); END;");
			
			callableStatement = callableStatement.unwrap(CallableStatement.class);
			callableStatement.setLong(1, groupId);
			callableStatement.setString(2, pageType);
			callableStatement.setLong(3, masterPolicyId);
			callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
			callableStatement.execute();
			System.out.println("groupId >>"+groupId);
			resultSet 		= ((OracleCallableStatement)callableStatement).getCursor(4);
			System.out.println("resultSet "+resultSet);
	        masterPolicyNoList = new ArrayList<MasterPolicyNo>();
			 while (resultSet.next()) {
				 masterPolicyNo = new MasterPolicyNo();
				 
				 masterPolicyNo.setMasterpolicyno(resultSet.getString("MasterPolicyNo"));
				 masterPolicyNo.setInsurermasteragreementno(resultSet.getString("InsurerMasterAgreementNo"));
				 masterPolicyNo.setMasterpolicyid(resultSet.getInt("MasterPolicyID"));
				 masterPolicyNo.setGroupid(resultSet.getInt("GroupID"));
				 masterPolicyNo.setGroupName(resultSet.getString("GroupName"));
				 masterPolicyNo.setAgreementenddate(resultSet.getDate("AgreementStartDate"));
				 masterPolicyNo.setAgreementenddate(resultSet.getDate("AgreementEndDate"));
				 masterPolicyNo.setTotalmembers(resultSet.getInt("TotalMembers"));
				 masterPolicyNo.setSuminsured(resultSet.getInt("SumInsured"));
				 masterPolicyNo.setSaleshierarchyid(resultSet.getInt("SalesHierarchyID"));
				 masterPolicyNo.setBranchid(resultSet.getInt("BranchID"));
				 masterPolicyNo.setSpecialcondition(resultSet.getString("SpecialConditions"));
				 masterPolicyNo.setLineofbusinessid(resultSet.getInt("LineOfBusinessID"));
				 masterPolicyNo.setPlancategoryid(resultSet.getInt("PlanCategoryID"));
				 masterPolicyNo.setProductid(resultSet.getInt("ProductID"));
				 masterPolicyNo.setAge(resultSet.getInt("Aging"));
				 masterPolicyNo.setCreatedOn(resultSet.getDate("AgreementDate"));
				
				
				masterPolicyNoList.add(masterPolicyNo);
			}
			 resultSet1 = ((OracleCallableStatement)callableStatement).getCursor(4);
			 if(resultSet1 != null) {
				 masterPolicyNoHM = new HashMap<Integer, MasterPolicyNo>();
				while (resultSet.next()) {
					masterPolicyNo = new MasterPolicyNo();
					masterPolicyNo.setMasterpolicyid(resultSet1.getInt("MasterPolicyID"));
					masterPolicyNo.setInsurermasteragreementno(resultSet1.getString("InsurerMasterAgreementNo"));
					masterPolicyNo.setMasterpolicyno(resultSet1.getString("MasterPolicyNo"));
					masterPolicyNo.setSumInsuredAmount(resultSet1.getDouble("SUMINSUREDAMOUNT"));
					masterPolicyNo.setSuminsured(resultSet1.getInt("SumInsuredID"));
					
					masterPolicyNoHM.put(masterPolicyNo.getMasterpolicyid(),masterPolicyNo );
				}
			 }
			 
			 if(masterPolicyNoList != null && masterPolicyNoList.size() > 0 && masterPolicyNoHM != null) {
				 for(MasterPolicyNo masterPolicyNoModel:masterPolicyNoList ) {
					 masterPolicyNo = null;
					 if(masterPolicyNoHM.containsKey(masterPolicyNoModel.getMasterpolicyid())) {
						 masterPolicyNo = masterPolicyNoHM.get(masterPolicyNoModel.getMasterpolicyid());
						 masterPolicyNoModel.setSuminsured(masterPolicyNo.getSuminsured());
						 masterPolicyNoModel.setSumInsuredAmount(masterPolicyNo.getSumInsuredAmount());
					 }
				 }
			 }
			
			
			return masterPolicyNoList;
		}catch(Exception e){
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {
			callableStatement.close();
			callableStatement	= null;
			ResourceManager.freeConnection(connection);
			connection	= null;
		}
		
	}
	
	
	@Override
	public List<MasterPolicyNo> getSearchGroupDetailsByAgreementNo(long groupId,String agreementNumber) throws Exception {
		Connection 				connection 			= null;
		ResultSet 				rs 					= null;
		List<MasterPolicyNo> 	masterPolicyNoList 	= null;
		CallableStatement 		callableStatement  	= null;
		MasterPolicyNo masterPolicyNo = null;
		try {
			connection = jdbcConnection.getConnection();
				callableStatement = connection.prepareCall("BEGIN SpGetSearchGroupDetailsByAgreementNo(?, ?, ?); END;");
				
				callableStatement = callableStatement.unwrap(CallableStatement.class);
				callableStatement.setLong(1, groupId);
				callableStatement.setString(2, agreementNumber);
				callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
				callableStatement.execute();
				
				rs = ((OracleCallableStatement)callableStatement).getCursor(3);
				 
				 masterPolicyNoList = new ArrayList<MasterPolicyNo>();
			      while (rs.next()) {
			    	  masterPolicyNo = new MasterPolicyNo();
			    	  
			    	  masterPolicyNo.setMasterpolicyid(rs.getInt("MasterPolicyID"));
			    	  masterPolicyNo.setInsurermasteragreementno(rs.getString("AgreementNo"));
			    	  masterPolicyNo.setGradeid(rs.getInt("GroupID"));
			    	  masterPolicyNo.setGroupName(rs.getString("GroupName"));
			    	  
			        masterPolicyNoList.add(masterPolicyNo);
			      }
				return masterPolicyNoList;
		}catch(Exception e){
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {
			callableStatement.close();
			callableStatement	= null;
  			ResourceManager.freeConnection(connection);
  			connection	= null;
		}
		
	}

	@Override
	public ApplicationPremiumDetails saveOrUpdateApplicationPremiumDetails(ApplicationPremiumDetails applicationPremiumDetails)
			throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		
		ResultSet rs = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spInsertApplicationPremiumDetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setInt(1, applicationPremiumDetails.getPremiumId());
		callableStatement.setInt(2, applicationPremiumDetails.getOrganisationID());
		callableStatement.setLong(3, applicationPremiumDetails.getPartyID());
		callableStatement.setInt(4, applicationPremiumDetails.getSerialNo());
		callableStatement.setInt(5, applicationPremiumDetails.getPaymentModeID());
		callableStatement.setDate(6, applicationPremiumDetails.getPaymentDate());
		//10 p_PaymentDate
		callableStatement.setInt(7, applicationPremiumDetails.getBankID());
		callableStatement.setInt(8, applicationPremiumDetails.getBankBranchID());
		callableStatement.setString(9, applicationPremiumDetails.getInstrumentNumber());
		callableStatement.setDate(10, applicationPremiumDetails.getInstrumentDate());
		//12p_ChequeDate
		callableStatement.setInt(11, applicationPremiumDetails.getCardTypeID());
		callableStatement.setString(12, applicationPremiumDetails.getCardNo());
		callableStatement.setDate(13, applicationPremiumDetails.getCardExpiryDate());
		//14ENdp_CardExpiryDate
		callableStatement.setString(14, applicationPremiumDetails.getCardExpiryMonth());
		callableStatement.setString(15, applicationPremiumDetails.getCardExpiryYear());
		callableStatement.setInt(16, applicationPremiumDetails.getAmount());
		callableStatement.setString(17, applicationPremiumDetails.getBankBranchName());
		callableStatement.setString(18, applicationPremiumDetails.getBankName());
		callableStatement.setInt(19, applicationPremiumDetails.getAuthCode());
		callableStatement.setInt(20, applicationPremiumDetails.getReceiptID());
		callableStatement.setString(21, applicationPremiumDetails.getSubReceiptNo());
		callableStatement.setInt(22, applicationPremiumDetails.getChequeBounceAmount());
		callableStatement.setString(23,applicationPremiumDetails.getDescription() );
		callableStatement.setInt(24, 1);//createdBy
		callableStatement.setDate(25, currentDate()); //createdDate
		//27p_CreatedOn
		callableStatement.setString(26, applicationPremiumDetails.getFileName());
		callableStatement.setString(27, applicationPremiumDetails.getPathName());
		callableStatement.setLong(28, applicationPremiumDetails.getMasterPolicyID());
		callableStatement.setInt(29, applicationPremiumDetails.getTypeID());
		callableStatement.setInt(30,applicationPremiumDetails.getIsAffinity());
		callableStatement.registerOutParameter(31, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(32, OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		rs = ((OracleCallableStatement)callableStatement).getCursor(31);
		ApplicationPremiumDetails obj = null;
	      while (rs.next()) {
	        obj = new ApplicationPremiumDetails();
	        obj.setPaymentDate(rs.getDate("PaymentDate"));
	        obj.setAmount(rs.getInt("Amount"));
	        obj.setBankName(rs.getString("BankName"));
	        obj.setBankBranchName(rs.getString("BankBranchName"));
	        obj.setCardNo(rs.getString("CardNo"));
	        obj.setCardExpiryDate(rs.getDate("CardExpiryDate"));
	        obj.setDescription(rs.getString("Description"));
	        obj.setPaymentModeID(rs.getInt("PaymentModeID"));
	        obj.setCardTypeID(rs.getInt("CardTypeID"));
	        obj.setPremiumId(rs.getInt("PremiumID"));
	      }
	      rs = ((OracleCallableStatement)callableStatement).getCursor(32);
	     if (null == obj){
	    	  while (rs.next()) {
	  	        obj = null;
	  	      }
	     }
		System.out.println("SP>saveOrUpdateApplicationPremiumDetails executed successfully.");
		LOGGER.info("SP>saveOrUpdateApplicationPremiumDetails executed successfully.");
		return obj;
	}

	@Override
	public List<MasterPolicyNo> getMasterPolicyByGroupId(long groupId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<MasterPolicyNo> masterPolicyNo = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN SPSEARCHMASTERPOLICYNOBYGROUPID(?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setLong(1, groupId);
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		 MasterPolicyNo obj = null;
		 masterPolicyNo = new ArrayList<MasterPolicyNo>();
	      while (rs.next()) {
	        obj = new MasterPolicyNo();
	        obj.setMasterpolicyno(rs.getString("MASTERPOLICYNO"));
	        obj.setInsurermasteragreementno(rs.getString("InsurerMasterAgreementNo"));
	        obj.setMasterpolicyid(rs.getInt("masterpolicyid"));
	        obj.setMasterpolicyid(rs.getInt("masterpolicyid"));
	        obj.setGroupid(rs.getInt("groupId"));
	        System.out.println("obj "+obj);
	        masterPolicyNo.add(obj);
	      }
		System.out.println("SP>getMasterPolicyByGroupId executed successfully.");
		LOGGER.info("SP>getMasterPolicyByGroupId executed successfully.");
		return masterPolicyNo;
	}

	@Override
	public List<ApplicationPremiumDetails> searchApplicationPremiumDetailsByPolicyId(long policyId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<ApplicationPremiumDetails> applicationPremiumDetails = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN SPSEARCHAPPLICATIONPREMIUMDETAILSBYPOLICYID(?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setLong(1, policyId);
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		ApplicationPremiumDetails obj = null;
		applicationPremiumDetails = new ArrayList<ApplicationPremiumDetails>();
	      while (rs.next()) {
	    	  
	        obj = new ApplicationPremiumDetails();
	        obj.setPremiumId(rs.getInt("Amount"));
	        obj.setPaymentDate(rs.getDate("PaymentDate"));
	        obj.setAmount(rs.getInt("Amount"));
	        obj.setBankName(rs.getString("BankName"));
	        obj.setBankBranchName(rs.getString("BankBranchName"));
	        obj.setCardNo(rs.getString("CardNo"));
	        obj.setCardExpiryDate(rs.getDate("CardExpiryDate"));
	        obj.setDescription(rs.getString("Description"));
	        obj.setPaymentType(rs.getString("paymentType"));
	       System.out.println("obj "+obj);
	        applicationPremiumDetails.add(obj);
	      }
		System.out.println("SP>searchApplicationPremiumDetailsByAgreementNoAndPolicyNo executed successfully.");
		LOGGER.info("SP>searchApplicationPremiumDetailsByAgreementNoAndPolicyNo executed successfully.");
		return applicationPremiumDetails;
	}

	@Override
	public ApplicationPremiumDetails searchApplicationPremiumDetailsByAppPemiumId(long premiumId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN GETSEARCHAPPLICATIONPREMIUMDETAILSBYPRIMIUMID(?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setLong(1, premiumId);
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		ApplicationPremiumDetails obj = null;
		 obj = new ApplicationPremiumDetails();
	      while (rs.next()) {
	        obj.setPremiumId(rs.getInt("Amount"));
	        obj.setPaymentDate(rs.getDate("PaymentDate"));
	        obj.setAmount(rs.getInt("Amount"));
	        obj.setBankName(rs.getString("BankName"));
	        obj.setBankBranchName(rs.getString("BankBranchName"));
	        obj.setCardNo(rs.getString("CardNo"));
	        obj.setCardExpiryDate(rs.getDate("CardExpiryDate"));
	        obj.setDescription(rs.getString("Description"));
	        obj.setPaymentType(rs.getString("paymentType"));
	      }
		System.out.println("SP>searchApplicationPremiumDetailsByAgreementNoAndPolicyNo executed successfully.");
		LOGGER.info("SP>searchApplicationPremiumDetailsByAgreementNoAndPolicyNo executed successfully.");
		return obj;
	}

	@Override
	public void saveOrUpdateMasterDedupe(MasterDedupe masterDedupe) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spInsertUpdateDeDupe(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setInt(1, masterDedupe.getDedupeClubbingId());
		callableStatement.setInt(2, masterDedupe.getTypeId());
		callableStatement.setString(3, masterDedupe.getDescription());
		callableStatement.setString(4, masterDedupe.getCriteria());
		callableStatement.setString(5, masterDedupe.getQuery());
		callableStatement.setInt(6, masterDedupe.getPriority());
		callableStatement.setInt(7, masterDedupe.getStatus());
		callableStatement.setInt(8, masterDedupe.getModuleId());
		callableStatement.setString(9, masterDedupe.getGroupByQuery());
		callableStatement.setString(10, masterDedupe.getWhereQuery());
		callableStatement.setString(11, masterDedupe.getGroupByQueryUpload());
		callableStatement.setString(12, masterDedupe.getWhereQueryUpload());
		callableStatement.setString(13, masterDedupe.getColumnsQuery());
		callableStatement.setString(14, masterDedupe.getColumnsQueryUpload());
		callableStatement.setString(15, masterDedupe.getWhereColumnsQuery());
		callableStatement.setString(16, masterDedupe.getWhereColumnsQueryUpload());
		callableStatement.setInt(17, masterDedupe.getCreatedBy());
		callableStatement.setDate(18, currentDate());
		callableStatement.setInt(19, masterDedupe.getIsActive());
		callableStatement.execute();
		System.out.println("SP>spInsertUpdateDeDupe executed successfully.");
		LOGGER.info("SP>spInsertUpdateDeDupe executed successfully.");
		
	}

	@Override
	public List<Bank> getAllBank() throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<Bank> banks = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spGetAllBank(?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(1);
		 Bank obj = null;
		 banks = new ArrayList<Bank>();
	      while (rs.next()) {
	    	  obj = new Bank();
	        obj.setBankId(rs.getInt("BANKID"));
	        obj.setBankName(rs.getString("BANKNAME"));
	        obj.setBankShortName(rs.getString("BANKSHORTNAME"));
	        banks.add(obj);
	      }
		System.out.println("SP>getAllBank executed successfully.");
		LOGGER.info("SP>getAllBank executed successfully.");
		return banks;
	}

	@Override
	public List<BankBranch> getBankBranchByBankId(long bankId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<BankBranch> bankBranch = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spGetAllBankBranchByBankID(?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setLong(1, bankId);
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		BankBranch obj = null;
		bankBranch = new ArrayList<BankBranch>();
	      while (rs.next()) {
	    	  obj = new BankBranch();
	        obj.setDescription(rs.getString("Description"));
	        obj.setBranchId(rs.getInt("BranchID"));
	        bankBranch.add(obj);
	      }
		System.out.println("SP>getBankBranchByBankId executed successfully.");
		LOGGER.info("SP>getBankBranchByBankId executed successfully.");
		return bankBranch;
	}
	
	@Override
	public List<MasterModule> getAllMasterModule() throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<MasterModule> masterModule = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spGetAllModules(?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(1);
		MasterModule obj = null;
		masterModule = new ArrayList<MasterModule>();
	      while (rs.next()) {
	    	  obj = new MasterModule();
	    	  obj.setDescription(rs.getString("Description"));
	    	  obj.setModuleId(rs.getInt("ModuleID"));
	    	  masterModule.add(obj);
	      }
		System.out.println("SP>getAllMasterModule executed successfully.");
		LOGGER.info("SP>getAllMasterModule executed successfully.");
		return masterModule;
	}
	
	@Override
	public List<MasterDedupe> getMasterDedupeByDedupeAndModuleId(String dedupe, long moduleId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<MasterDedupe> masterDedupes= null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spGetAllModules(?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
		callableStatement.execute();
		rs = ((OracleCallableStatement)callableStatement).getCursor(1);
		MasterDedupe obj = null;
		masterDedupes = new ArrayList<MasterDedupe>();
	      while (rs.next()) {
	    	  obj = new MasterDedupe();
	    	  obj.setDescription(rs.getString("Description"));
	    	  obj.setModuleId(rs.getInt("ModuleID"));
	    	  masterDedupes.add(obj);
	      }
		System.out.println("SP>getMasterDedupeByDedupeAndModuleId executed successfully.");
		LOGGER.info("SP>getMasterDedupeByDedupeAndModuleId executed successfully.");
		return masterDedupes;
	}

	@Override
	public String saveOrUpdateMasterPartyDetails(MasterPartyDetails partyDetails) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spInsertOrUpdatePartyDetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setInt(1, partyDetails.getPartyId());
		callableStatement.setInt(2, partyDetails.getTypeId());
		callableStatement.setInt(3, partyDetails.getOrganisationId());
		callableStatement.setInt(4, partyDetails.getSalutationId());
		callableStatement.setString(5, partyDetails.getFirstName());
		callableStatement.setString(6, partyDetails.getInitial());
		callableStatement.setString(7, partyDetails.getLastname());
		callableStatement.setString(8, partyDetails.getContactId());
		callableStatement.setDate(9, partyDetails.getDateOfBirth());
		callableStatement.setDate(10, partyDetails.getdOE());
		callableStatement.setInt(11, partyDetails.getAge());
		callableStatement.setInt(12, partyDetails.getMonths());
		callableStatement.setInt(13, partyDetails.getGender());
		callableStatement.setString(14, partyDetails.getPanNo());
		callableStatement.setString(15, partyDetails.getgSTINNumber());
		callableStatement.setString(16, partyDetails.getMembershipNumber());
		callableStatement.setString(17, partyDetails.getDetailsOfWork());
		callableStatement.setInt(18, partyDetails.getOccupationId());
		callableStatement.setString(19, partyDetails.getOtherProfession());
		callableStatement.setString(20, partyDetails.getRegistrationNumber());
		callableStatement.setDate(21, partyDetails.getRegistrationDate());
		callableStatement.setInt(22, partyDetails.getBusinessAddress());
		callableStatement.setInt(23, partyDetails.getCreatedBy());
		callableStatement.setDate(24, currentDate());
		callableStatement.setInt(25, partyDetails.getModifiedBy());
		callableStatement.setDate(26, partyDetails.getModifiedOn());
		callableStatement.setInt(27, 1);
		callableStatement.setInt(28, partyDetails.getCategoryId());
		callableStatement.setInt(29, partyDetails.getTypeofIndustry());
		callableStatement.setInt(30, partyDetails.getMobileNo());
		callableStatement.setString(31, partyDetails.getEmail());
		callableStatement.setInt(32, partyDetails.getIsDubaiResId());
		callableStatement.setString(33, partyDetails.getAadharNo());
		callableStatement.setInt(34, partyDetails.getIsbothAddressSame());
		callableStatement.setString(35, partyDetails.getFirmName());
		callableStatement.setInt(36, partyDetails.getHaveanyOverseasBranch());
		callableStatement.setString(37, partyDetails.getOverseasBranchDetails());
		callableStatement.setInt(38, partyDetails.getHaveanyClientsinUSA());
		callableStatement.setString(39, partyDetails.getuSAClientDetails());
		callableStatement.setInt(40, partyDetails.getCityId());
		callableStatement.setInt(41, partyDetails.getStateId());
		callableStatement.setString(42, partyDetails.getPincode());
		callableStatement.setDate(43, partyDetails.getDateOfJoiningScheme());
		callableStatement.setDate(44, partyDetails.getRiskCommencementDate());
		callableStatement.setInt(45, partyDetails.getBasicSalary());
		callableStatement.setString(46, partyDetails.getEmployeeId());
		callableStatement.registerOutParameter(47, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(48, OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		rs = ((OracleCallableStatement)callableStatement).getCursor(47);
		String rendom  = null;
		MasterPartyDetails obj = null;
		if(rs != null) {
		  while (rs.next()) {
	    	  obj = new MasterPartyDetails();
	    	  obj.setPartyId(rs.getInt("PartyId"));
	    	  obj.setTypeId(rs.getInt("TYPEID"));
	      }
		  if(obj != null) {
		  PartyReceiptDetails partyReceiptDetails = new PartyReceiptDetails();
		  partyReceiptDetails.setPartyId(obj.getPartyId());
		  partyReceiptDetails.setMasterGroupId(partyDetails.getMasterGroupId());
		  partyReceiptDetails.setMasterPolicyId(partyDetails.getMasterPolicyId());
		  partyReceiptDetails.setReceiptNo(String.valueOf(rendomNumber()));
		  if(partyDetails.getMasterPolicyId() !=  0)
			  partyReceiptDetails.setIsMasterPolicy(1);
		  partyReceiptDetails.setApplicationDetails(partyDetails.getApplicationDetails());
		  rendom = saveOrUpdatePartyReceiptDetails(partyReceiptDetails);
		  }
		  }else {
			  rs = ((OracleCallableStatement)callableStatement).getCursor(48);
			  if(rs != null) {
			  obj = new MasterPartyDetails();
	    	  obj.setPartyId(rs.getInt("PartyId"));
	    	  obj.setTypeId(rs.getInt("TYPEID"));
			  PartyReceiptDetails partyReceiptDetails = new PartyReceiptDetails();
			  partyReceiptDetails.setPartyId(obj.getPartyId());
			  partyReceiptDetails.setMasterGroupId(partyDetails.getMasterGroupId());
			  partyReceiptDetails.setMasterPolicyId(partyDetails.getMasterPolicyId());
			  partyReceiptDetails.setReceiptNo(String.valueOf(rendomNumber()));
			  if(partyDetails.getMasterPolicyId() !=  0)
				  partyReceiptDetails.setIsMasterPolicy(1);
			  partyReceiptDetails.setApplicationDetails(partyDetails.getApplicationDetails());
			  saveOrUpdatePartyReceiptDetails(partyReceiptDetails);
			  }
		  }
		  
		  return rendom;
	}

	@Override
	public String saveOrUpdatePartyReceiptDetails(PartyReceiptDetails partyReceiptDetails) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		CallableStatement callableStatement = connection.prepareCall(
				"BEGIN spInsertOrUpdatePartyReceiptDetails(?,?,?,?,?,?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setString(1, partyReceiptDetails.getCertificateId());
		callableStatement.setLong(2, partyReceiptDetails.getReceiptId());
		callableStatement.setLong(3, partyReceiptDetails.getLineOfBusinessId());
		callableStatement.setLong(4, partyReceiptDetails.getPartyId());
		callableStatement.setString(5, partyReceiptDetails.getReceiptNo());
		callableStatement.setLong(6, partyReceiptDetails.getTypeId());
		callableStatement.setLong(7, partyReceiptDetails.getIsMasterPolicy());
		callableStatement.setLong(8, partyReceiptDetails.getMasterGroupId());
		callableStatement.setLong(9, partyReceiptDetails.getMasterPolicyId());
		callableStatement.setLong(10, 1);
		callableStatement.setDate(11, currentDate());
		callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		rs = ((OracleCallableStatement)callableStatement).getCursor(12);
		String recieptNo = null;
		 while (rs.next()) {
			  partyReceiptDetails.setReceiptNo(rs.getString("ReceiptNo"));
			  recieptNo = partyReceiptDetails.getReceiptNo();
	      }
		 if(null != partyReceiptDetails.getApplicationDetails()) {
			 
			 for(ApplicationPremiumDetails applicationPremiumDetails : partyReceiptDetails.getApplicationDetails()) {
		 applicationPremiumDetails.setMasterPolicyID(partyReceiptDetails.getMasterPolicyId());
		 String subrecieptNo = partyReceiptDetails.getReceiptNo() +"-1";
		 recieptNo = partyReceiptDetails.getReceiptNo();
		 applicationPremiumDetails.setSubReceiptNo(subrecieptNo);
		 applicationPremiumDetails.setPartyID(partyReceiptDetails.getPartyId());
		 saveOrUpdateApplicationPremiumDetails(applicationPremiumDetails);
			 }
		 }
		 return recieptNo;
	}
	
	public int rendomNumber() {
		SecureRandom secureRandom = new SecureRandom();
		int randomWithSecureRandom = secureRandom.nextInt();
		return randomWithSecureRandom;
	}
	
	@Override
	public MasterPolicyUnitAddress saveOrUpdateMasterPolicyAddress(MasterPolicyUnitAddress obj)	throws SQLException {

		Connection 			connection = jdbcConnection.getConnection();
		ResultSet 			rs = null;
		CallableStatement 	callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateMasterPolicyAddressDetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");
		
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		
		callableStatement.setInt(1, (String.valueOf(obj.getAddressId())!=null && obj.getAddressId()!=0)?obj.getAddressId():0);
		callableStatement.setString(2, obj.getAddress1());
		callableStatement.setString(3, obj.getAddress2());
		callableStatement.setString(4, obj.getAddress3());
		callableStatement.setString(5, obj.getAddress4());
		callableStatement.setString(6, obj.getAddress5());
		callableStatement.setInt(7, obj.getCountryId()); 
		callableStatement.setInt(8, obj.getStateId()); 
		callableStatement.setInt(9, obj.getDistrictId()); 
		callableStatement.setInt(10, obj.getTalukaId());
		callableStatement.setString(11, String.valueOf(obj.getZipCode()));
		callableStatement.setInt(12, obj.getAddressTypeId());
		callableStatement.setLong(13, obj.getPhoneNo());
		callableStatement.setString(14, String.valueOf(obj.getMobileNo()));
		callableStatement.setString(15, String.valueOf(obj.getConferenceNo()));
		callableStatement.setString(16, String.valueOf(obj.getFaxNo()));
		callableStatement.setString(17, obj.getEmail());
		callableStatement.setString(18, obj.getPersonalEmailId());
		callableStatement.setInt(19, obj.getCreatedBy());
		callableStatement.setDate(20, currentDate());
		callableStatement.setInt(21, 1);
		callableStatement.setString(22, obj.getTehsil());		 
		callableStatement.registerOutParameter(23, OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		rs = ((OracleCallableStatement)callableStatement).getCursor(23);
		while (rs.next()) {
			obj.setAddressId(rs.getInt("ADDRESSID"));
			obj.setAddress1(rs.getString("ADDRESS1"));
			obj.setAddress2(rs.getString("ADDRESS2"));
			obj.setAddress3(rs.getString("ADDRESS3"));
			obj.setAddress4(rs.getString("ADDRESS4"));
			//    obj.setAddress5(rs.getString("ADDRESS5"));
			obj.setCountryId(rs.getInt("COUNTRYID"));
			obj.setCountryName(rs.getString("CDESCRIPTION"));
			obj.setStateId(rs.getInt("STATEID"));
			obj.setStateName(rs.getString("SDESCRIPTION"));
			obj.setDistrictId(rs.getInt("DISTRICTID"));
			obj.setDistrictName(rs.getString("DDESCRIPTION"));
			obj.setTalukaId(rs.getInt("TALUKID"));
			obj.setZipCode(rs.getInt("ZIPCODE"));
			obj.setAddressTypeId(rs.getInt("ADDRESSTYPEID"));
			obj.setPhoneNo(rs.getInt("PHONENO"));
			obj.setConferenceNo(rs.getInt("CONFERENCENO"));
			obj.setFaxNo(rs.getInt("FAXNO"));
			obj.setEmail(rs.getString("EMAIL"));
			obj.setPersonalEmailId(rs.getString("PERSONALEMAILID"));
			//			         obj.setUnitName(rs.getString("UNITNAME"));
		}
		System.out.println("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		LOGGER.info("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		return obj; 
	}

	@Override
	public List<MasterPolicyNo> searchMasterPolicyNo(MasterPolicyNo masterPolicyNo)
			throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		ResultSet rs1 = null;
		List<MasterPolicyNo> list=null;
		CallableStatement callableStatement = connection.prepareCall("BEGIN spgetmasterpolicynobygroupname(?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		  callableStatement.setString(1,((masterPolicyNo.getInsurermasteragreementno()!=null && !masterPolicyNo.getInsurermasteragreementno().isEmpty())?masterPolicyNo.getInsurermasteragreementno():"0"));
		  callableStatement.setInt(2, masterPolicyNo.getGroupid());	 
		  callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
		  callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
		  callableStatement.executeUpdate();
		   rs = ((OracleCallableStatement)callableStatement).getCursor(3);
		   rs1=((OracleCallableStatement)callableStatement).getCursor(4);
		   list=new ArrayList<MasterPolicyNo>();
		   MasterPolicyNo obj=null;
			  while (rs.next()) {
				  obj=new MasterPolicyNo();
				  obj.setMasterpolicyid(rs.getInt("masterpolicyid"));
				  obj.setMasterpolicyno(rs.getString("masterpolicyno"));
				  obj.setInsurermasteragreementno(rs.getString("insurermasteragreementno"));
				  obj.setAgreementstartdate(rs.getDate("agreementstartdate"));
				  obj.setAgreementenddate(rs.getDate("agreementenddate"));
				  obj.setSuminsured(rs.getInt("suminsured"));
				  obj.setTotalmembers(rs.getInt("totalmembers"));
				  obj.setNormalretirementage(rs.getInt("normalretirementage"));
				  obj.setGroupid(rs.getInt("groupid"));
				  obj.setGroupName(rs.getString("groupName"));
				  list.add(obj);
			      }
			  if(list!=null && list.size()==0)
			  {
				  while (rs1.next()){
				  obj=new MasterPolicyNo();
				  obj.setGroupid(rs1.getInt("groupid"));
				  obj.setGroupName(rs1.getString("groupName"));
				  list.add(obj);
				  }
			  }
		  System.out.println("SP>spgetmasterpolicynobygroupname executed successfully.");
		  LOGGER.info("SP>spgetmasterpolicynobygroupname executed successfully.");
		  return list; 
	}

	@Override
	public void deleteMasterPolicyAddress(Integer addressedid,Integer policyNoId)
			throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection.prepareCall("BEGIN spgetmasterpolicynobygroupname(?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		  callableStatement.setInt(1,policyNoId);
		  callableStatement.setInt(1,addressedid);
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		   
	}
	
	@Override
	public MasterPolicyNo searchMasterPolicyNoDetails(Integer masterPolicyNoId)
			throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		MasterPolicyNo obj=null;
		MasterPolicyUnitAddress address=null;
		CallableStatement callableStatement = connection.prepareCall("BEGIN spgetmasterpolicynobypolicynoid(?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		  callableStatement.setInt(1,masterPolicyNoId);
		  callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		  callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
		  callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
		  callableStatement.executeUpdate();
		   rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		   rs1 = ((OracleCallableStatement)callableStatement).getCursor(3);
		   rs2 = ((OracleCallableStatement)callableStatement).getCursor(4);
			  while (rs.next()) {
				  obj=new MasterPolicyNo();
				  obj.setMasterpolicyid(rs.getInt("masterpolicyid"));
				  obj.setMasterpolicyno(rs.getString("masterpolicyno"));
				  obj.setInsurermasteragreementno(rs.getString("insurermasteragreementno"));
				  obj.setAgreementstartdate(rs.getDate("agreementstartdate"));
				  obj.setAgreementenddate(rs.getDate("agreementenddate"));
				  obj.setSuminsured(rs.getInt("suminsured"));
				  obj.setTotalmembers(rs.getInt("totalmembers"));
				  obj.setNormalretirementage(rs.getInt("normalretirementage"));
				  obj.setShortName(rs.getString("ShortName"));
				  obj.setLineofbusinessid(rs.getInt("masterpolicyid"));
					obj.setInsurerid(rs.getInt("masterpolicyid"));
					obj.setProductid(rs.getInt("Productid"));
					obj.setPlancategoryid(rs.getInt("Plancategoryid"));
					obj.setTypeid(rs.getInt("Typeid"));
					obj.setAffinitytypeid(rs.getInt("Affinitytypeid"));
					obj.setMasterpolicyno(rs.getString("Masterpolicyno"));
				     obj.setGroupid(rs.getInt("Groupid"));
					obj.setAgreementenddate(rs.getDate("Agreementenddate"));
					obj.setAgreementstartdate(rs.getDate("Agreementstartdate"));
					obj.setTotalmembers(rs.getInt("Totalmembers"));
					obj.setSpecialcondition(rs.getString("specialconditions"));
					 obj.setSuminsured(rs.getInt("Suminsured"));
					obj.setSaleshierarchyid(rs.getInt("Saleshierarchyid"));
					obj.setSaleshierarcycode(rs.getString("Saleshierarcycode"));
					obj.setBranchid(rs.getInt("Branchid"));
					obj.setIsfloter(rs.getInt("Isfloter"));
					obj.setIsddloading(rs.getInt("Isddloading"));
					obj.setDdloadingvalue(rs.getInt("Ddloadingvalue"));
					obj.setMainchannelid(rs.getInt("Mainchannelid"));
					obj.setSubchannelid(rs.getInt("Subchannelid"));
					obj.setIsadvancedeposit(rs.getInt("Isadvancedeposit"));
					obj.setSubchannelsalestype(rs.getString("Subchannelsalestype"));
					obj.setRelationshipids(rs.getString("Relationshipids"));
					obj.setNomineerelationshipids(rs.getString("Nomineerelationshipids"));
					obj.setCoefficientids(rs.getString("Coefficientids"));
				    obj.setInsurermasteragreementno(rs.getString("Insurermasteragreementno"));
					obj.setGradeid(rs.getInt("Gradeid"));
					obj.setTpaid(rs.getInt("Tpaid"));
					obj.setTpapolicynumber(rs.getString("Tpapolicynumber"));
					obj.setCreatedby(rs.getInt("Createdby"));
					obj.setCreatedOn(rs.getDate("CreatedOn"));
					obj.setIsactive(rs.getInt("Isactive"));
					obj.setDescription(rs.getString("Description"));
				    obj.setAgreementtypeid(rs.getInt("Agreementtypeid"));
					obj.setCalculationtypeid(rs.getInt("Calculationtypeid"));
					obj.setTotallives(rs.getInt("Totallives"));
					obj.setTotalpremiumamount(rs.getInt("Totalpremiumamount"));
					obj.setFamilysizeid(rs.getInt("Familysizeid"));
					obj.setQuotationid(rs.getInt("Quotationid"));
					obj.setMasterpolicyid(rs.getInt("Masterpolicyid"));
					//obj.setDatauploadheaderid(rs.getInt("Datauploadheaderid"));
					obj.setBenefittypeid(rs.getInt("Benefittypeid"));
					obj.setIsemployee(rs.getInt("Isemployee"));
					obj.setIscorporate(rs.getInt("Iscorporate"));
					obj.setStatusid(rs.getInt("Statusid"));
					obj.setRemarks(rs.getString("Remarks"));
					obj.setContactnumber(rs.getString("Contactnumber"));
					obj.setEmailId(rs.getString("EmailId"));
					obj.setAddressdifferfromclientorg(rs.getInt("Addressdifferfromclientorg"));
					obj.setClientnameunit(rs.getString("Clientnameunit"));
					obj.setContactpersonfirstname(rs.getString("Contactpersonfirstname"));
					obj.setContactpersonmiddlename(rs.getString("Contactpersonmiddlename"));
					obj.setContactpersonlastname(rs.getString("Contactpersonlastname"));
					obj.setPanno(rs.getString("Panno"));
					obj.setTypeofclient(rs.getInt("Typeofclient"));
					obj.setGsttype(rs.getInt("Gsttype"));
				    obj.setGstin(rs.getString("Gstin"));
					obj.setWindowperiod(rs.getInt("Windowperiod"));
					obj.setNormalretirementage(rs.getInt("Normalretirementage"));
					obj.setIsnriletterreceived(rs.getInt("Isnriletterreceived"));
					obj.setNriletterreceiveddate(rs.getDate("Nriletterreceiveddate"));
					obj.setPaymentfrequencyid(rs.getInt("Paymentfrequencyid"));
					obj.setModalfactors(rs.getInt("Modalfactors"));
					obj.setIspsuflag(rs.getInt("Ispsuflag"));
					obj.setZoneid(rs.getInt("Zoneid"));
					obj.setSalutationid(rs.getInt("Salutationid"));
					obj.setActivelyatworkclause(rs.getInt("Activelyatworkclause"));
					obj.setActivelyatworkclauseremarks(rs.getString("Activelyatworkclauseremarks"));
				    obj.setQuotationdesc(rs.getString("Quotationdesc"));
					obj.setIsdeclaration(rs.getInt("Isdeclaration"));
					obj.setIssfq(rs.getShort("Issfq"));
					obj.setDescription(rs.getString("Description"));
					obj.setGroupid(rs.getInt("Groupid"));
					obj.setGroupName(rs.getString("GroupName"));
			      }
			  if(obj!=null)
			  {
				 
			  while (rs2.next()) {
				  address=new MasterPolicyUnitAddress();
				  address.setAddressId(rs.getInt("ADDRESSID"));
				  address.setAddress1(rs.getString("ADDRESS1"));
				  address.setAddress2(rs.getString("ADDRESS2"));
				  address.setAddress3(rs.getString("ADDRESS3"));
				  address.setAddress4(rs.getString("ADDRESS4"));
		      //   obj.setAddress5(rs.getString("ADDRESS5"));
				  address.setCountryId(rs.getInt("COUNTRYID"));
				  address.setCountryName(rs.getString("CDESCRIPTION"));
				  address.setStateId(rs.getInt("STATEID"));
				  address.setStateName(rs.getString("SDESCRIPTION"));
				  address.setDistrictId(rs.getInt("DISTRICTID"));
				  address.setDistrictName(rs.getString("DDESCRIPTION"));
				  address.setTalukaId(rs.getInt("TALUKID"));
				  address.setZipCode(rs.getInt("ZIPCODE"));
				  address.setAddressTypeId(rs.getInt("ADDRESSTYPEID"));
				  address.setPhoneNo(rs.getInt("PHONENO"));
				  address.setConferenceNo(rs.getInt("CONFERENCENO"));
				  address.setFaxNo(rs.getInt("FAXNO"));
				  address.setEmail(rs.getString("EMAIL"));
				  address.setPersonalEmailId(rs.getString("PERSONALEMAILID"));
				  address.setUnitName(rs.getString("UNITNAME"));
				  obj.getMasterPolicyUnitAddresses().add(address);
		      }
			
			  while (rs1.next()) {
				  address=new MasterPolicyUnitAddress();
				  address.setAddressId(rs.getInt("ADDRESSID"));
				  address.setAddress1(rs.getString("ADDRESS1"));
				  address.setAddress2(rs.getString("ADDRESS2"));
				  address.setAddress3(rs.getString("ADDRESS3"));
				  address.setAddress4(rs.getString("ADDRESS4"));
		      //   obj.setAddress5(rs.getString("ADDRESS5"));
				  address.setCountryId(rs.getInt("COUNTRYID"));
				  address.setCountryName(rs.getString("CDESCRIPTION"));
				  address.setStateId(rs.getInt("STATEID"));
				  address.setStateName(rs.getString("SDESCRIPTION"));
				  address.setDistrictId(rs.getInt("DISTRICTID"));
				  address.setDistrictName(rs.getString("DDESCRIPTION"));
				  address.setTalukaId(rs.getInt("TALUKID"));
				  address.setZipCode(rs.getInt("ZIPCODE"));
				  address.setAddressTypeId(rs.getInt("ADDRESSTYPEID"));
				  address.setPhoneNo(rs.getInt("PHONENO"));
				  address.setConferenceNo(rs.getInt("CONFERENCENO"));
				  address.setFaxNo(rs.getInt("FAXNO"));
				  address.setEmail(rs.getString("EMAIL"));
				  address.setPersonalEmailId(rs.getString("PERSONALEMAILID"));
				  obj.getMasterPolicyUnitAddresses().add(address);
				 // address.setUnitName(rs.getString("UNITNAME"));
		      }
			  }
		  System.out.println("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		  return obj; 
	}
	
	
	@Override
	public List<MasterGroupDetails> searchMasterGroupDetailsByName(String groupName)
			throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<MasterGroupDetails> list=null;
		CallableStatement callableStatement = connection.prepareCall("BEGIN spgetallmastergroupdetailsbygroupname(?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		  callableStatement.setString(1,groupName);
		  callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		  callableStatement.executeUpdate();
		   rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		   list=new ArrayList<MasterGroupDetails>();
		   MasterGroupDetails obj=null;
			  while (rs.next()) {
				  obj = new MasterGroupDetails();
			        obj.setGroupName(rs.getString("GroupName"));
			        obj.setGroupId(rs.getInt("GROUPID"));
			        obj.setCoreBusiness(rs.getString("CoreBusiness"));
			        obj.setContactFirstName(rs.getString("ContactFirstName"));
			        list.add(obj);
			  }
			 
		  System.out.println("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateGroupAddressDetails executed successfully.");
		  return list; 
	}

	public void saveOrInsertCashDepositDetails(PolicyAccountStatement policyAccountStatement) throws SQLException{
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection.prepareCall("BEGIN SPINSERTORUPDATECASHDEPOSITDETAILS(?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setLong(1,policyAccountStatement.getGroupId());
		callableStatement.setLong(2,policyAccountStatement.getMasterpolicyId());
		callableStatement.setDouble(3,policyAccountStatement.getBalanceamount());
		callableStatement.setString(4,policyAccountStatement.getDescription());
		callableStatement.setLong(5,policyAccountStatement.getPartyId());
		callableStatement.setInt(6,1);
		callableStatement.setDate(7, policyAccountStatement.getToDate());
		callableStatement.executeUpdate();
	}
	
	public Date currentDate(){
		long d = System.currentTimeMillis();
		Date date = new Date(d);
		return date;
	}
	
	@Override
	public QuestionMap saveQuestionMap(QuestionMap questionMap)
			throws SQLException {
		List<QuestionMap> list=null;
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateMGPSFQMap(?,?,?,?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setInt(1,questionMap.getMasterPolicyId());
		callableStatement.setInt(2,questionMap.getGroupId());
		callableStatement.setInt(3,questionMap.getQuestionId());
		callableStatement.setInt(4,questionMap.getQuestionMapId());
		callableStatement.setInt(5,questionMap.getTypeId());
		callableStatement.setInt(6,questionMap.getIsDiscount());
		callableStatement.setLong(7,questionMap.getAmount());
		callableStatement.setLong(8,1);
		callableStatement.setInt(9,questionMap.getSfqMapId());
		callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		ResultSet rs = ((OracleCallableStatement)callableStatement).getCursor(10);
		QuestionMap obj = null;
		 while (rs.next()) {
			  obj = new QuestionMap();
			  obj.setAmount(rs.getLong("amount"));
		  }
		return obj;
	}

	@Override
	public void deleteQuestionMap(long questionMap, long policyId) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection.prepareCall("BEGIN SPINSERTORUPDATECASHDEPOSITDETAILS(?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
	}

	@Override
	public List<QuestionMap> getAllQuestionMap(long policyId) throws SQLException {
		List<QuestionMap> list=null;
		Connection connection = jdbcConnection.getConnection();
		CallableStatement callableStatement = connection.prepareCall("BEGIN spGetALLMGPSFQMap(?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setInt(1,0);
		callableStatement.setLong(2,policyId);
		callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
		callableStatement.executeUpdate();
		ResultSet rs = ((OracleCallableStatement)callableStatement).getCursor(3);
		QuestionMap obj=null;
		 list=new ArrayList<QuestionMap>();
		 while (rs.next()) {
			 obj = new QuestionMap();
			 obj.setDescription(rs.getString("DESCRIPTION"));
			 obj.setRate(rs.getLong("typeId"));
			 obj.setAmount(rs.getInt("isDiscount"));
			 obj.setGroupId(rs.getInt("groupId"));
			 obj.setQuestionId(rs.getInt("questionId"));
			 obj.setMasterPolicyId(rs.getInt("masterPolicyId"));
		        list.add(obj);
		  }
		
		return list;
	}

	@Override
	public String deleteMasterPolicyNo(long masterPolicyId, long deletedBy) throws Exception {
		Connection 			connection 			= null;
		CallableStatement   callableStatement 	= null;
		ResultSet 			result 				= null;
		String deletedStatus = null;
		try {
				connection 		= jdbcConnection.getConnection();
				callableStatement = connection.prepareCall("BEGIN spDeleteMasterPolicy(?,?,?); END;");
				callableStatement = callableStatement.unwrap(CallableStatement.class);
				callableStatement.setLong(1,masterPolicyId);
				callableStatement.setLong(2, deletedBy);
				callableStatement.registerOutParameter(3, OracleTypes.CURSOR);
				
				callableStatement.executeUpdate();
				result = ((OracleCallableStatement)callableStatement).getCursor(3);
				
				if(result != null) {
					if(result.next()) {
						deletedStatus = result.getString("DeletedStatus");
					}
				}
				System.out.println("SP>deleteMasterPolicyNo executed successfully."+deletedStatus+ " masterpolicyId : "+masterPolicyId);
				LOGGER.info("SP>deleteMasterPolicyNo executed successfully."+deletedStatus+ " masterpolicyId : "+masterPolicyId);
				return deletedStatus;
				
		}catch (Exception e) {
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {
			callableStatement.close();
			callableStatement	= null;
  			ResourceManager.freeConnection(connection);
  			connection	= null;
		}
	}


	@Override
	public List<PolicyAccountStatement> getPolicyAccountStatement(
			PolicyAccountStatement policyAccountStatement) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		ResultSet rs = null;
		List<PolicyAccountStatement> list = null;
		CallableStatement callableStatement = connection.prepareCall("BEGIN spgetconsolidatedpasbymasterpolicy(?,?,?,?,?,?,?); END;");
		callableStatement = callableStatement.unwrap(CallableStatement.class);
		callableStatement.setLong(1,policyAccountStatement.getGroupId());
		callableStatement.setLong(2,policyAccountStatement.getMasterpolicyId());
		callableStatement.setLong(3,policyAccountStatement.getAgreementid());
		if(policyAccountStatement.getFromDate()!=null)
		callableStatement.setString(4,policyAccountStatement.getFromDate().toString());
		else callableStatement.setString(4,currentDate().toString());
		if(policyAccountStatement.getToDate()!=null)
		callableStatement.setString(5,policyAccountStatement.getToDate().toString());
		else callableStatement.setString(5,currentDate().toString());
		callableStatement.setLong(6,10);
		
		callableStatement.registerOutParameter(7, OracleTypes.CURSOR);
		 callableStatement.executeUpdate();
		   rs = ((OracleCallableStatement)callableStatement).getCursor(7);
		   PolicyAccountStatement obj = null;
		   list = new ArrayList<PolicyAccountStatement>();
			  while (rs.next()) {
				  obj = new PolicyAccountStatement();
				  obj.setTotalamount(rs.getDouble("totalAmount"));
				  obj.setBalanceamount(rs.getDouble("Balanceamount"));
				  obj.setApprovedamount(rs.getDouble("Approvedamount"));
				  obj.setGroupName(rs.getString("groupName"));
			        list.add(obj);
			  }
		System.out.println("SP>getPolicyAccountStatement executed successfully.");
		  LOGGER.info("SP>getPolicyAccountStatement executed successfully.");
		return list;
	}

	public List<ClientAddressDetails> getClientAddressDetailsbyGroupId(long groupId) throws Exception {
		  Connection 					connection 					= null;
		  ResultSet 					resultSet 					= null;
		  CallableStatement 			callableStatement 			= null;
		  List<ClientAddressDetails> 	clientAddressDetailsList 	= null;
		  ClientAddressDetails 			clientAddressDetails 	 	= null;
		  try {
				 
			  		connection = jdbcConnection.getConnection();
			  		
				  callableStatement = connection.prepareCall("BEGIN SPGETCLIENTADDRESSDETAILSBYGROUPID(?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  
				  callableStatement.setLong(1, groupId);
				  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
				  callableStatement.execute();
				
				  resultSet 	= ((OracleCallableStatement)callableStatement).getCursor(2);
						  
				  clientAddressDetailsList = new ArrayList<ClientAddressDetails>();
				  if(resultSet != null) {
					  while (resultSet.next()) {
						  
						  
						  clientAddressDetails = new ClientAddressDetails();
						  
						  clientAddressDetails.setGroupId(resultSet.getInt("GroupID"));
						  clientAddressDetails.setAddressId(resultSet.getInt("AddressID"));
						  clientAddressDetails.setAddress1(resultSet.getString("Address1"));
						  clientAddressDetails.setAddress2(resultSet.getString("Address2"));
						  clientAddressDetails.setAddress3(resultSet.getString("Address3"));
						  clientAddressDetails.setAddress4(resultSet.getString("Address4"));
						  clientAddressDetails.setCountryId(resultSet.getInt("CountryID"));
						  clientAddressDetails.setCountryName(resultSet.getString("Country"));
						  clientAddressDetails.setStateId(resultSet.getInt("StateID"));
						  clientAddressDetails.setStateName(resultSet.getString("State"));
						  clientAddressDetails.setTehsil(resultSet.getString("Tehsil"));
						  clientAddressDetails.setDistrictId(resultSet.getInt("DistrictID"));
						  clientAddressDetails.setDistrictName(resultSet.getString("District"));
						  clientAddressDetails.setTalukaId(resultSet.getInt("TalukID"));
						  clientAddressDetails.setTalukaName(resultSet.getString("Taluk"));
						  clientAddressDetails.setZipCode(resultSet.getInt("ZipCode"));
						  clientAddressDetails.setAddressTypeId(resultSet.getInt("AddressTypeID"));
						  clientAddressDetails.setAddressTypeName(resultSet.getString("AddressType"));
						  clientAddressDetails.setPhoneNo(resultSet.getLong("PhoneNo"));
						  clientAddressDetails.setMobileNo(resultSet.getLong("MobileNo"));
						  clientAddressDetails.setConferenceNo(resultSet.getLong("ConferenceNo"));
						  clientAddressDetails.setFaxNo(resultSet.getLong("FaxNo"));
						  clientAddressDetails.setEmail(resultSet.getString("Email"));
						  clientAddressDetails.setPersonalEmailId(resultSet.getString("PersonalEmailID"));
						  
						  clientAddressDetailsList.add(clientAddressDetails);
				      }
					  
				  }
				  LOGGER.info("SP>SPGETCLIENTADDRESSDETAILSBYGROUPID executed successfully.");
				  return clientAddressDetailsList;
		  }catch (Exception e) {
			  LOGGER.error("SP>SPGETCLIENTADDRESSDETAILSBYGROUPID exception occured."+e.getMessage());
			  e.printStackTrace();
			  throw ExceptionProcess.execute(e, TRACE_ID);
		  }finally {
			  resultSet.close();
			  callableStatement.close();
		  }
		 
	}
	
	public int getProductFrequencyBasedModalFactorRate(long variantId, long frequencyId) throws Exception   {
		int modalfactors = 0;
		Connection 					connection 					= null;
		ResultSet 					resultSet 					= null;
		CallableStatement 			callableStatement 			= null;
		try
		{
			connection = jdbcConnection.getConnection();

			callableStatement = connection.prepareCall("BEGIN spGetProductFrequencyBasedModalFactorRate(?,?,?); END;");
			callableStatement = callableStatement.unwrap(CallableStatement.class);

			callableStatement.setLong(1, variantId);
			callableStatement.setLong(2, frequencyId);
			callableStatement.registerOutParameter(3, OracleTypes.CURSOR); 
			callableStatement.execute();

			resultSet 	= ((OracleCallableStatement)callableStatement).getCursor(3);
			if(resultSet != null) {
				if(resultSet.next()) {
					modalfactors = resultSet.getInt("ModalFactor");
				}
			}
			return modalfactors;
		}catch (Exception e){
			LOGGER.error("SP>spGetProductFrequencyBasedModalFactorRate exception occured."+e.getMessage());
			e.printStackTrace();
			throw ExceptionProcess.execute(e, TRACE_ID);
		}finally {
			resultSet.close();
			callableStatement.close();
		}

	}
	
	public List<Variant> getProductbyPlanId(long planId) throws Exception {
		  Connection 					connection 					= null;
		  ResultSet 					resultSet 					= null;
		  CallableStatement 			callableStatement 			= null;
		  List<Variant> 				variantList 				= null;
		  Variant 						variant 	 				= null;
		  try {
				 
			  		connection = jdbcConnection.getConnection();
			  		
				  callableStatement = connection.prepareCall("BEGIN SPGETPRODUCTBYPLANID(?,?); END;");
				  callableStatement = callableStatement.unwrap(CallableStatement.class);
				  
				  callableStatement.setLong(1, planId);
				  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
				  callableStatement.execute();
				
				  resultSet 	= ((OracleCallableStatement)callableStatement).getCursor(2);
						  
				  variantList = new ArrayList<Variant>();
				  if(resultSet != null) {
					  while (resultSet.next()) {
						  
						  
						  variant = new Variant();
						  
						  variant.setProductID(resultSet.getInt("ProductID"));
						  variant.setDescription(resultSet.getString("Description"));
						  variant.setCode(resultSet.getString("Code"));
						  
						  variantList.add(variant);
				      }
					  
				  }
				  LOGGER.info("SP>SPGETPRODUCTBYPLANID executed successfully.");
				  return variantList;
		  }catch (Exception e) {
			  LOGGER.error("SP>SPGETPRODUCTBYPLANID exception occured."+e.getMessage());
			  e.printStackTrace();
			  throw ExceptionProcess.execute(e, TRACE_ID);
		  }finally {
			  resultSet.close();
			  callableStatement.close();
		  }
		 
	}

}
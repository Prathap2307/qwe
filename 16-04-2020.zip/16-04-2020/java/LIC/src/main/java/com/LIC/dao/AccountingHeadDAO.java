package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.AccountTypeModel;
import com.LIC.model.AccountingGroupInfoModel;
import com.LIC.model.AccountingHeadModel;
import com.LIC.model.GetAccountingClassificationModel;

@RestController
@SuppressWarnings("unchecked") 
public class AccountingHeadDAO {
	@Autowired
	private EntityManager em;
	
	// Accounting Classification
	public List<GetAccountingClassificationModel> GetBindAccountingClassification() {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("GetBindAccountingClassification")
               .registerStoredProcedureParameter("oAC", Class.class, ParameterMode.REF_CURSOR);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<GetAccountingClassificationModel> FList = list.stream().map(
             o -> new GetAccountingClassificationModel((Number) o[0], (String) o[1]  ,(String) o[2],(Number) o[3],(Number) o[4],(String) o[5],(Number) o[6],(String) o[7])).collect(Collectors.toList());
	  	 
    	return FList;
	}
	
	// Accounting Group
	public List<AccountingGroupInfoModel> GetAllAccountingGroup() {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("GetBindAccountingGroup")
               .registerStoredProcedureParameter("oAG", Class.class, ParameterMode.REF_CURSOR);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<AccountingGroupInfoModel> FList = list.stream().map(
             o -> new AccountingGroupInfoModel((Number) o[0], (String) o[1]  ,(String) o[2],(Number) o[3],(Number) o[4],(String) o[5],(Number) o[6],(String) o[7],(Number) o[8],(String) o[9])).collect(Collectors.toList());
	  	 
    	return FList;
	}
	
	// Account Type 
			public List<AccountTypeModel> GetAllAccountType() {
		   	 StoredProcedureQuery query = em
		               .createStoredProcedureQuery("GetAllAccountTypeDetails")
		               .registerStoredProcedureParameter("oAT", Class.class, ParameterMode.REF_CURSOR);
		   	 query.execute();
		   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
			 List<AccountTypeModel> FList = list.stream().map(
		             o -> new AccountTypeModel((Number) o[0], (String) o[1])).collect(Collectors.toList());
			  	 
		    	return FList;
			}
	
	// Drop down Account Head Details
	public List<AccountingHeadModel> GetAccountDetails(int AccountClassificationID,int AccountGroupID) {
	   	 StoredProcedureQuery query = em
	               .createStoredProcedureQuery("spGetAccountHeadCodeDesc")
	               .registerStoredProcedureParameter("vAccountClassificationID", Integer.class, ParameterMode.IN)
	   	 		    .registerStoredProcedureParameter("vAccountGroupID", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("oAH", Class.class, ParameterMode.REF_CURSOR)
	               .setParameter("vAccountClassificationID", AccountClassificationID)
	               .setParameter("vAccountGroupID", AccountGroupID);
	   	 query.execute();
	   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
		 List<AccountingHeadModel> FList = list.stream().map(
	             o -> new AccountingHeadModel((Number) o[0], (String) o[1]  ,(String) o[2])).collect(Collectors.toList());
		  	 
	    	return FList;
		}
		
	//Duplicate Check	
	public String GetDuplicateAccountingHead(String Code,String accountname,int AccountHeadID) {
		   	 StoredProcedureQuery query = em
		               .createStoredProcedureQuery("GetDuplicateAccountingHead")
		               .registerStoredProcedureParameter("vcode", String.class, ParameterMode.IN)
		               .registerStoredProcedureParameter("vaccountname", String.class, ParameterMode.IN)
		               .registerStoredProcedureParameter("vdupid", Integer.class, ParameterMode.IN)
		               .registerStoredProcedureParameter("RESULT1", String.class, ParameterMode.OUT)
		               .setParameter("vcode", Code)
		               .setParameter("vaccountname", accountname)
		               .setParameter("vdupid", AccountHeadID);
		   	query.execute();
		   	 return (String)query.getOutputParameterValue("RESULT1");
		   	
			}
		
	//Create Accounting Head
	public int CreateAccountingHead(AccountingHeadModel AccountHeadID) {
    	 StoredProcedureQuery query = em
                .createStoredProcedureQuery("InsertorUpdateAccountingHead")
                .registerStoredProcedureParameter("pAccountingHeadID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pAccountClassificationID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pAccountGroupID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pAccountTypeID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pCode", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pAccountName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pIsControlAC", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pIsManualVoucher", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pCreatedBy", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pisactive", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pRESULT", Integer.class, ParameterMode.OUT)
                .setParameter("pAccountingHeadID", AccountHeadID.getAccountHeadId())
                .setParameter("pAccountClassificationID", AccountHeadID.getAccountClassificationID())
                .setParameter("pAccountGroupID", AccountHeadID.getAccountGroupID())
                .setParameter("pAccountTypeID", AccountHeadID.getAccountTypeID())
                .setParameter("pCode", AccountHeadID.getCode())
                .setParameter("pAccountName", AccountHeadID.getAccountHeadName())
                .setParameter("pIsControlAC", AccountHeadID.getIsControlAC())
                .setParameter("pIsManualVoucher", AccountHeadID.getIsManualVoucher())
                .setParameter("pCreatedBy", AccountHeadID.getCreatedBy())
                .setParameter("pisactive", AccountHeadID.getIsactive());
    	query.execute();
    	 return (int)query.getOutputParameterValue("pRESULT");
    	
	}
	
	//Search Account Head Details
	public List<AccountingHeadModel> SearchAccountHeadDetails(int AccountHeadID,int AccountClassificationID,int AccountGroupID
			,int AccountType,int AccountHeadCode,int AccountHeadName) {
	   	 StoredProcedureQuery query = em
	               .createStoredProcedureQuery("GetSearchAccountHeadDetails")
	               .registerStoredProcedureParameter("vAccountHeadID", Integer.class, ParameterMode.IN)
	   	 		   .registerStoredProcedureParameter("vAccountClassificationID", Integer.class, ParameterMode.IN)
	   	 		   .registerStoredProcedureParameter("vAccountGroupID", Integer.class, ParameterMode.IN)
	   	 		   .registerStoredProcedureParameter("vAccountTypeID", Integer.class, ParameterMode.IN)
	   	 		   .registerStoredProcedureParameter("vCode", Integer.class, ParameterMode.IN)
	   	 		   .registerStoredProcedureParameter("vAccountHeadName", Integer.class, ParameterMode.IN)
	               .registerStoredProcedureParameter("oAH", Class.class, ParameterMode.REF_CURSOR)
	               .setParameter("vAccountHeadID", AccountHeadID)
	               .setParameter("vAccountClassificationID", AccountClassificationID)
				   .setParameter("vAccountGroupID", AccountGroupID)
			       .setParameter("vAccountTypeID", AccountType)
				   .setParameter("vCode", AccountHeadCode)
			       .setParameter("vAccountHeadName", AccountHeadName);
	   	 query.execute();
	   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
		 List<AccountingHeadModel> FList = list.stream().map(
	             o -> new AccountingHeadModel((Number) o[0], (String) o[1]  ,(String) o[2]
	            ,(Number) o[3],(String) o[4],(String) o[5],(Number) o[6]
	            ,(Number) o[7],(Number) o[8],(Number) o[9],(Number) o[10],(Number) o[11])).collect(Collectors.toList());
		  	 
	    	return FList;
		}
}

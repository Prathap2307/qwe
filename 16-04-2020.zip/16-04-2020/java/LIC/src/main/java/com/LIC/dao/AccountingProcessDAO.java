package com.LIC.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.AccountingProcessModel;
import com.LIC.model.GetAllGSTTypeModel;

@Repository
@SuppressWarnings("unchecked")
public class AccountingProcessDAO {

	@Autowired
	private EntityManager em;

	public int createAccountProcessInfo(AccountingProcessModel model) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("InsertorUpdateAccountingProcess")
				.registerStoredProcedureParameter("vProcessID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDescription", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsactive", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsGSTApplicable", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vIsTaxApplicable", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vGSTTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)
				.setParameter("vProcessID", model.getProcessID())
				.setParameter("vCode", model.getCode())
				.setParameter("vDescription", model.getDescription())
				.setParameter("vCreatedBy", model.getCreatedBy())
				.setParameter("vCreatedOn", model.getCreatedOn())
				.setParameter("vIsactive", model.getIsActive())
				.setParameter("vIsGSTApplicable", model.getIsGSTApplicable())
				.setParameter("vIsTaxApplicable", model.getIsTaxApplicable())
				.setParameter("vGSTTypeID", model.getgstTypeID());
		query.execute();
		return (int)query.getOutputParameterValue("vResult");
		

	}
	
	/*
	public void createAccountProcessInfo(AccountingProcessModel model) {

		StoredProcedureQuery addProductStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateAccProcess");
		addProductStoredProcedure.setParameter("vProcessID", model.getProcessID());
		addProductStoredProcedure.setParameter("vCode", model.getCode());
		addProductStoredProcedure.setParameter("vDescription", model.getProcessName());
		addProductStoredProcedure.setParameter("vCreatedBy", model.getCreatedBy());
		addProductStoredProcedure.setParameter("vCreatedOn", model.getCreatedOn());
		addProductStoredProcedure.setParameter("vIsactive", model.getIsActive());
		addProductStoredProcedure.setParameter("vIsGSTApplicable", model.getIsGSTApplicable());
		addProductStoredProcedure.setParameter("vIsTaxApplicable", model.getIsTaxApplicable());
		addProductStoredProcedure.setParameter("vGSTTypeID", model.getgstTypeID());
		addProductStoredProcedure.getParameter("vResult");
		addProductStoredProcedure.execute();
		
		
		
		

	

}*/
	
	
	
	
	
	
	
	
	

	public String getDuplicateAccountingProcess(AccountingProcessModel model) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("GetDuplicateAccountingProcess")
				.registerStoredProcedureParameter("vCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vProcessName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vdupid", Integer.class, ParameterMode.IN)

				.registerStoredProcedureParameter("RESULT1", String.class, ParameterMode.OUT)
				.setParameter("vCode", model.getCode())
				.setParameter("vProcessName", model.getProcessName())
				.setParameter("vdupid", model.getProcessID());

		query.execute();
		return (String) query.getOutputParameterValue("RESULT1");

	}

	public List<AccountingProcessModel> searchAccountingProcess(int accountProcessID, int code, int groupName) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("GetSearchAccountingProcess")
				.registerStoredProcedureParameter("vid", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCode", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vGroupName", Integer.class, ParameterMode.IN)

				.registerStoredProcedureParameter("oAP", Class.class, ParameterMode.REF_CURSOR)
				.setParameter("vid", accountProcessID)
				.setParameter("vCode", code)
				.setParameter("vGroupName", groupName);
		query.execute();
		
		List<Object[]> list = (List<Object[]>) query.getResultList();
		
		/* public AccountingProcessModel(int processID, String code,String processName, int createdBy, Date
				  createdOn,  int modifiedBy, Date modifiedOn, int isActive, int isGSTApplicable, int isTaxApplicable, int
				  gSTTypeID)
		*/
		List<AccountingProcessModel> accProcessList = list
				.stream().map(o -> new AccountingProcessModel((Number) o[0], (String) o[1], (String) o[2],
						(Number) o[3], (Date) o[4], (Number) o[5], (Date) o[6], (Number) o[7],(Number) o[8], (Number) o[9], (Number) o[10]))
				.collect(Collectors.toList());
		return accProcessList;
	}
	
	  public List<AccountingProcessModel> getAllAccountingProcess() {
	  StoredProcedureQuery query = em
	  .createStoredProcedureQuery("spGetAccountingProcessName")
	  .registerStoredProcedureParameter("oAP", Class.class,
	  ParameterMode.REF_CURSOR); query.execute(); List<Object[]> list =
	  (List<Object[]>)query.getResultList(); List<AccountingProcessModel> accList =
	  list.stream().map( o -> new AccountingProcessModel((Number) o[0], (String)
	  o[1], (String) o[2] ,(Number) o[3])).collect(Collectors.toList());
	  
	  return accList; }
	  
	  
	  public List<GetAllGSTTypeModel> GetAllGSTType() {
		  StoredProcedureQuery query = em
		  .createStoredProcedureQuery("GetAllGSTType")
		  .registerStoredProcedureParameter("oGST", Class.class,
		ParameterMode.REF_CURSOR); query.execute(); List<Object[]> list =
		  (List<Object[]>)query.getResultList(); List<GetAllGSTTypeModel> accList =
		  list.stream().map( o -> new GetAllGSTTypeModel((Number) o[0], (String) o[1])).collect(Collectors.toList());
		  
		  return accList; }
	 
}

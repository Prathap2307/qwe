package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.BenefitType;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class BenefitTypeDAO implements IBenefitTypeDAO {
	
	static final Logger LOGGER = LogManager.getLogger(BenefitTypeDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(BenefitType obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateBenefitType(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getBenefitTypeId());
		  callableStatement.setString(2, obj.getDescription());
		  callableStatement.setString(3, obj.getShortDescription());
		  callableStatement.setInt(4, obj.getCreatedBy());
		  callableStatement.setString(5, obj.getRemarks());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  LOGGER.info("SP>spInsertOrUpdateBenefitType executed successfully.");
	}
	
	@Override
	public void delete(Integer benefitTypeID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteBenefitType(?,?,?); END;");
		  callableStatement.setInt(1, benefitTypeID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteBenefitType executed successfully.");
		  LOGGER.info("SP>spDeleteBenefitType executed successfully.");
	} 
	
	@Override
	public List<BenefitType> getAll(BenefitType filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<BenefitType> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllBenefitType(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  BenefitType obj = null;
			  list = new ArrayList<BenefitType>();
		      while (rs.next()) {
		        obj = new BenefitType();
		        obj.setBenefitTypeId(rs.getInt("BENEFITTYPEID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("shortdescription"));
		        list.add(obj);
		      }
			  LOGGER.info("SP>spGetAllBenefitType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllBenefitType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return list;
	} 
	 
	
	@Override
	public BenefitType get(Integer benefitTypeID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  BenefitType obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetBenefitType(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, benefitTypeID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new BenefitType();
		        obj.setBenefitTypeId(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		      }
			  LOGGER.info("SP>spGetAllBenefitType executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllBenefitType exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

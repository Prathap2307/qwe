package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.BankBranchDAO;
import com.LIC.model.BankBranchModel;
import com.LIC.model.GetBankBranch;

@RestController
public class BankBrachController {
	@Autowired
	private BankBranchDAO bankbranch;
/*	
	@RequestMapping(value = "/bankBranch/{branchId}/{bankId}/{bankCityId}/{description}/{ifscCode}/{micrCode}", method = RequestMethod.GET)
	public List<GetBankBranch> getAllBankSearch(@PathVariable Long branchId,@PathVariable Long bankId,@PathVariable Long bankCityId,@PathVariable String description,@PathVariable String ifscCode,@PathVariable String micrCode) {
		return 	bankbranch.GetAllBankBranchSearch(branchId,bankId,bankCityId,description,ifscCode,micrCode);
	}
*/
	
	
	@RequestMapping(path = "/bankBranchbankSearch", method = RequestMethod.POST)
	public List<GetBankBranch> GetBankBranchBank(@RequestBody GetBankBranch model) {
		return	bankbranch.GetAllBankBranchSearch(model);
	}
	
	

	
	
	
	
	@RequestMapping(path = "/bankBranchBank", method = RequestMethod.GET)
	public List<GetBankBranch> getBranchbybankid() {
		return	bankbranch.GetAllBankBranchBankbyBankId();
	}
   

	@RequestMapping(path = "/bankBranchCity/{bankId}", method = RequestMethod.GET)
	public List<GetBankBranch> getBankbranchbycityId(@PathVariable Long bankId) {
		return	bankbranch.GetAllBankBranchBankbyCityId(bankId);
	}
	
	
	

	@PostMapping("/createBankBranch")
	public void postBankBranch(@RequestBody BankBranchModel model) {
		bankbranch.createBankBranchInfo(model);

	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/deleteBankBranch")
	public void deleteBankBranch(@RequestBody BankBranchModel model) {

		bankbranch.deleteBankBranch(model);
	}
	
	
	
	@RequestMapping(value = "/allbankbranch", method = RequestMethod.GET)
	public List<GetBankBranch> AllBankBranchInfo() {

		return bankbranch.GetAllBankBranchInfo();
	}

	

}

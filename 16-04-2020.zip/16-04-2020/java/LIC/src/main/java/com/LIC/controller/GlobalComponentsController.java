package com.LIC.controller;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.DepartmentDAO;
import com.LIC.model.CoverageModal;
import com.LIC.model.Response;
import com.LIC.model.TransactionContext;
import com.LIC.service.AuthorisedSignatoryService;
import com.LIC.service.CommissionService;
import com.LIC.service.CoverageService;
import com.LIC.service.MessageTemplateService;
import com.LIC.service.StampDutyService;
import com.LIC.service.TaxStructureService;
import com.LIC.utils.dataobject.ValueObject;

@RestController
public class GlobalComponentsController {

	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(ConfigurationController.class);
	
	public GlobalComponentsController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	
	@Autowired 	AuthorisedSignatoryService 		authSignatoryService;
	@Autowired 	MessageTemplateService 			messageTemplateService;
	@Autowired 	CommissionService 				commissionService;
	@Autowired 	TaxStructureService 			taxStructureService;
	@Autowired 	StampDutyService 				stampDutyService;
	@Autowired 	CoverageService 				coverageService;
	@Autowired 	DepartmentDAO 					dep;
	
	@RequestMapping(value = "/getAllDepartmentInfo", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> getAllDepartmentInfo(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, dep.getAllDepartmentInfo(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetAllAuthorisedSignatories", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetAllAuthorisedSignatories(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, authSignatoryService.GetAllAuthorisedSignatories(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetAllModules", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetAllModules(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, authSignatoryService.GetAllModules(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsAuthorisedSignatoryExist", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsAuthorisedSignatoryExist(@RequestHeader HttpHeaders httpHeaders,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			return responseGenerator.successResponse(context, authSignatoryService.IsAuthorisedSignatoryExist(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/DeleteAuthorisedSignatory", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> DeleteAuthorisedSignatory(@RequestHeader HttpHeaders httpHeaders,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			return responseGenerator.successResponse(context, authSignatoryService.DeleteAuthorisedSignatory(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetAllAuthorisedSignatory", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> GetAllAuthorisedSignatory(@RequestHeader HttpHeaders httpHeaders,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			return responseGenerator.successResponse(context, authSignatoryService.GetAllAuthorisedSignatory(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/InsertOrUpdateAuthorisedSignatory", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertOrUpdateAuthorisedSignatory(@RequestHeader HttpHeaders httpHeaders,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, authSignatoryService.InsertOrUpdateAuthorisedSignatory(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	//insert data into commission  	started on 09-02-2020
	
	@RequestMapping(value = "/InsertOrUpdateCommision", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public ResponseEntity<Response> InsertOrUpdateCommission(@RequestHeader HttpHeaders httpHeader,
				@RequestBody HashMap<Object, Object> allRequestParams ) {
	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParams);

			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, commissionService.InsertOrUpdateCommision(object), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@RequestMapping(value = "/IsCommssionDetailExists", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsCommssionDetailExists(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :" + object);
			return responseGenerator.successResponse(context, commissionService.IsCommssionDetailExists(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}	
	
	@RequestMapping(value = "/getGetCommissionWithSearch", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> getGetCommissionWithSearch(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :"+object);
			
			return responseGenerator.successResponse(context, commissionService.getGetCommissionWithSearch(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}	
	
	@RequestMapping(value = "/DeleteCommission", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> DeleteCommission(@RequestHeader HttpHeaders httpHeader,@RequestParam("CommissionID") long CommissionID,
			@RequestParam("DeletedBy") int deletedBy ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, commissionService.deleteCommission(CommissionID, deletedBy), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}	
	
	@RequestMapping(value = "/GetCommissionDetailsById", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetCommissionDetailsById(@RequestHeader HttpHeaders httpHeader,@RequestParam("CommissionID") long CommissionID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, commissionService.GetCommissionDetailsById(CommissionID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}	
	
	@RequestMapping(value = "/GetCommissionDetails", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetCommissionDetails(@RequestHeader HttpHeaders httpHeader) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, commissionService.getAllCommissionDetails(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}	
	
	//Tax Structure
	
	@RequestMapping(value = "/InsertOrUpdateTaxStructure", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertOrUpdateTaxStructure(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, taxStructureService.InsertOrUpdateTaxStructure(object).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}	
	
	@RequestMapping(value = "/IsTaxStructureExist", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsTaxStructureExist(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, taxStructureService.IsTaxStructureExist(object).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}	
	
	@RequestMapping(value = "/GetAllTaxStructureBasedonTaxName", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetAllTaxStructureBasedonTaxName(@RequestHeader HttpHeaders httpHeader,@RequestParam("TaxStructureName") String taxStructure) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, taxStructureService.GetAllTaxStructureBasedonTaxName(taxStructure), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}	
	
	@RequestMapping(value = "/DeleteTaxStructure", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> DeleteTaxStructure(@RequestHeader HttpHeaders httpHeader,@RequestParam("TaxStructureID") long TaxStructureID,
			@RequestParam("DeletedBy") int deletedBy ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, taxStructureService.DeleteTaxStructure(TaxStructureID, deletedBy), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}	

	@RequestMapping(value = "/GetTaxStructureWithDetailsById", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetTaxStructureWithDetailsById(@RequestHeader HttpHeaders httpHeader, @RequestParam("TaxStructureID") long taxStructureID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, taxStructureService.GetTaxStructureWithDetailsById(taxStructureID).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}	
	
	@RequestMapping(value = "/GetAllTaxStructureDetailsByTaxStructureID", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetAllTaxStructureDetailsByTaxStructureID(@RequestHeader HttpHeaders httpHeader, @RequestParam("TaxStructureID") long taxStructureID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			System.out.println("GetAllTaxStructureDetailsByTaxStructureID "+taxStructureID);
			return responseGenerator.successResponse(context, taxStructureService.GetAllTaxStructureDetailsByTaxStructureID(taxStructureID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}	

	@RequestMapping(value = "/GetAllTaxStructure", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetAllTaxStructure(@RequestHeader HttpHeaders httpHeader) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, taxStructureService.GetAllTaxStructure(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}	
	
	//Message Templates 
	
	@RequestMapping(value = "/InsertOrUpdateMessageTemplate", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	 public ResponseEntity<Response> InsertOrUpdateMessageTemplate(@RequestHeader HttpHeaders httpHeader,
				@RequestBody HashMap<Object, Object> allRequestParams) {
	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParams);

			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, messageTemplateService.InsertOrUpdatemMessageTemplateObject(object), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
		
	}
		
	@GetMapping(value = "/GetAllMessageTemplates", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllMessageTemplates(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, messageTemplateService.GetAllMessageTemplates(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllFeaturesForSMSEmail", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllFeaturesForSMSEmail(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, messageTemplateService.GetAllFeaturesForSMSEmail(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllMessageTemplatesByTemplateID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllMessageTemplatesByTemplateID(@RequestHeader HttpHeaders httpHeaders,
			@RequestParam("TemplateId") int templateId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, messageTemplateService.GetAllMessageTemplatesByTemplateID(templateId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllMessageTemplatesByFeatureID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllMessageTemplatesByFeatureID(@RequestHeader HttpHeaders httpHeaders,
			@RequestParam("FeatureID") int featureID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, messageTemplateService.GetAllMessageTemplatesByFeatureID(featureID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	//Stamp Duty
	@RequestMapping(value = "/InsertUpdateStampDuty", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertUpdateStampDuty(@RequestHeader HttpHeaders httpHeader, @RequestBody HashMap<Object, Object> allRequestParams) {
	
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;

		try {
			
			object	= new ValueObject(allRequestParams);

			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, stampDutyService.InsertUpdateStampDuty(object).getHtData(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsStampDutyExist", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsStampDutyExist(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, stampDutyService.IsStampDutyExist(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/IsStampDutyExistForNB", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> IsStampDutyExistForNB(@RequestHeader HttpHeaders httpHeaders,@RequestParam("StampDutyID") long stampDutyID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, stampDutyService.IsStampDutyExistForNB(stampDutyID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetStampDutyByStampDutyID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetStampDutyByStampDutyID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("StampDutyID") long stampDutyID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, stampDutyService.GetStampDutyById(stampDutyID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/DeleteStampDuty", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> DeleteStampDuty(@RequestHeader HttpHeaders httpHeaders,@RequestParam("StampDutyID") long stampDutyID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, stampDutyService.DeleteStampDuty(stampDutyID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllStampDuty", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllStampDuty(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, stampDutyService.GetAllStampDuty(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	 
	// Benifit Coverage
	@RequestMapping(value = "/InsertOrUpdateCoverage", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertOrUpdateCoverage(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, coverageService.InsertOrUpdateCoverage(object).getHtData(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsCoverageExistNew", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsCoverageExistNew(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			System.out.println("object :"+object);
			return responseGenerator.successResponse(context, coverageService.IsCoverageExistNew(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllCoveragesByLineOfBusiness", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllCoveragesByLineOfBusiness(@RequestHeader HttpHeaders httpHeaders,@RequestParam("LineOfBusinessId") long lineOfBusinessId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, coverageService.GetAllCoveragesByLineOfBusiness(lineOfBusinessId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetCoverageExclusionByCoverageID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetCoverageExclusionByCoverageID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("CoverageID") long coverageID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, coverageService.GetCoverageExclusionByCoverageID(coverageID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllExclusionByCoverageID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllExclusionByCoverageID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("CoverageID") long coverageID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, coverageService.GetAllExclusionByCoverageID(coverageID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@GetMapping(value = "/GetAllCoverageUINMapByCoverageID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllCoverageUINMapByCoverageID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("CoverageID") long coverageID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, coverageService.GetAllCoverageUINMapByCoverageID(coverageID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetCoverageByID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetCoverageByID(@RequestHeader HttpHeaders httpHeaders,@RequestParam("CoverageID") long coverageID) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, coverageService.GetCoverageByID(coverageID), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/DeleteCoverage", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> DeleteCoverage(@RequestHeader HttpHeaders httpHeaders, @RequestParam("CoverageID") long coverageID
			,@RequestParam("DeletedBy") int deletedBy) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, coverageService.DeleteCoverage(coverageID, deletedBy), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/getSearchCoverageDetails", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Response> getSearchCoverageDetails(@RequestHeader HttpHeaders httpHeader,@RequestBody CoverageModal coverageModal){
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);

		try {

			return responseGenerator.successResponse(context, coverageService.getSearchCoverageDetails(coverageModal.getCoverageName(),coverageModal.getDescription()), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
}

export class Lookup{
    shortDescription: string;
    annualIncome: string;    
    accountType:string;
    addressType:string;
    bankCity:string;
    benefitType:string;
    cityName:string;
    countryName:string;
    currencyName:string;
    districtName:string;
    documentName:string;
    documentCategory:string;
    maritalStatus:string;
    occupationRiskCategory:string;
    paymentMode:string;
    postOffice:string;
    pincode:number;
    premiumPaymentFrequency: string;
    profession: string;
    region: string;
    relationship: string;
    residenceType: string;
    salutation:string;
    statename:string;
    tinNumber:string;
    TypeofBusiness:string;
}
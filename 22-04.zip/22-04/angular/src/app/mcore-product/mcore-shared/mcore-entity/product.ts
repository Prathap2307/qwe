export interface Product {
    organizationId: number;
    lobId: number;
    planId: number;
    searchPlanName: string;    
    planName: string;
    shortName: string;
    category: number;
    productTypeId: number;
    description: string;
    createdBy: number;
    createdOn: Date;
    deletedBy: number;
    deletedOn: Date;
    isActive: number;	
}	

export interface ProductCategory{
    productTypeId: number;
    description: string;
}
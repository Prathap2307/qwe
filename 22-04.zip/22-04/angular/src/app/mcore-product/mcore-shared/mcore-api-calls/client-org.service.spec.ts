import { TestBed } from '@angular/core/testing';

import { ClientOrgService } from './client-org.service';

describe('ClientOrgService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClientOrgService = TestBed.get(ClientOrgService);
    expect(service).toBeTruthy();
  });
});

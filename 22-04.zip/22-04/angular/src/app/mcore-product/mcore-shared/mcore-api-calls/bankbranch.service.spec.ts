import { TestBed } from '@angular/core/testing';

import { BankbranchService } from './bankbranch.service';

describe('BankbranchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BankbranchService = TestBed.get(BankbranchService);
    expect(service).toBeTruthy();
  });
});

import { TestBed } from '@angular/core/testing';

import { AccountingheadService } from './accountinghead.service';

describe('AccountingheadService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AccountingheadService = TestBed.get(AccountingheadService);
    expect(service).toBeTruthy();
  });
});

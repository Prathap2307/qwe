import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class BranchService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }


  
  createbranchUrl = this.baseUrl + '/InsertOrUpdateBranch';
  add(a: any): Observable<any> {
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    console.log(this.createbranchUrl);
    // console.log(departmentRow);
    return this.http.post<any>(this.createbranchUrl, a, { headers: headers });
  }
  DeactivateForZonebyDivision(id:any): Observable<any>{
    return this.http.get(this.baseUrl + '/DeactivateForZonebyDivision' + id).pipe(tap((response) => response));
  }
  DeactivateForDivisionbyBranch(id:any): Observable<any>{
    return this.http.get(this.baseUrl + '/DeactivateForDivisionbyBranch' + id).pipe(tap((response) => response));
  }
  deleteBranchById(data:any): Observable<any>{
    console.log('delete branchid >>',data)
    return this.http.get(this.baseUrl + '/DeleteBranch?BranchId=' + data.BranchId + '&pageTypeID=1'+data.pageTypeID+'&deletedBy=1').pipe(tap((response) => response));
  }
  Activate(data:any): Observable<any>{
    console.log(data)
    return this.http.get(this.baseUrl + '/ActivateBranch?BranchId=' + data).pipe(tap((response) => response));
  }
 
  GetAllBranches(objInfo): Observable<any>{
    console.log(objInfo)
    return this.http.post(this.baseUrl + '/getAllBranches' , objInfo).pipe(tap((response) => response));
  }

  get_branchByid(id: string): Observable<any> {
    return this.http.get(this.baseUrl + '/GetBranchByIdSer?branchId=' + id).pipe(tap((response) => response));
  }
  getAllregion(): Observable<any> {
    return this.http.get(this.baseUrl + '/getAllRegion').pipe(tap((response) => response));
  }
  get_all_countries(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllCountries').pipe(tap((response) => response));
  }
  GetAllDetailsByZipCode(a): Observable<any>{
    console.log(this.http.get(this.baseUrl + '/GetAllDetailsByZipCode?ZipCode='+a).pipe(tap((response) => response)))
    return this.http.get(this.baseUrl + '/GetAllDetailsByZipCode?ZipCode='+a).pipe(tap((response) => response));
  }
  get_states(countryID: any): Observable<any> {
    return this.http.get(this.baseUrl + '/getAllStateByCountryId?CountryId=' + countryID).pipe(tap((response) => response));

  }
  get_districts(stateID: any): Observable<any> {
    return this.http.get(this.baseUrl + '/getAllDistrictsByStaeId?StateId=' + stateID).pipe(tap((response) => response));

  }
  get_taluk(districtID: any): Observable<any> {
    return this.http.get(this.baseUrl + '/getAllTaluksByDistrictId?DistrictId=' + districtID).pipe(tap((response) => response));

  }
  get_pBranch(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetParentBranch?BranchId=0&OrganizationId=1').pipe(tap((response) => response));
  }
  get_zBranch(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllBranchByPageTypeID?PageTypeId=' + id).pipe(tap((response) => response));
  }
  get_dBranch(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllDivisionByZoanlID?ZonalId=' + id).pipe(tap((response) => response));
  }

  GettalukByZipCode(id: any) {
    return this.http.get(this.baseUrl + '/GetAllTaluksByZipCode' + id).pipe(tap((response) => response));
  }
  
  GetDistrictsByZipCode(id: any) {
    return this.http.get(this.baseUrl + '/GetAllDistrictsWithZipCode' + id).pipe(tap((response) => response));
  }
}

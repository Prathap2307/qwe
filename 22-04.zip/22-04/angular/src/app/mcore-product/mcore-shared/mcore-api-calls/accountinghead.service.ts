import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { AccountingGroup, AccountingType, AccountingGrid } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountinghead';

@Injectable({
  providedIn: 'root'
})
export class AccountingheadService {



  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

  allAGUrl = this.baseUrl + '/GetAllAccountingGroup';

  getAccountingGroupDetails(): Observable<AccountingGroup[]> {
    return this.http.get<AccountingGroup[]>(this.allAGUrl)
      .pipe();
  }



  getAccountingTypeDetails(AccountClassificationID: number, AccountGroupID: number): Observable<AccountingType[]> {
    const allATUrl = this.baseUrl + `/GetAllAccountDetails/${AccountClassificationID}/${AccountGroupID}`;
    console.log(allATUrl);
    return this.http.get<AccountingType[]>(allATUrl)
      .pipe();
  }

  getAllAccountType(): Observable<any[]> {
    const url = this.baseUrl + `/GetAllAccountType`;
    return this.http.get<any[]>(url)
      .pipe();
  }

  getGridDetails(AccountHeadID: number, AccountClassificationID: number, AccountGroupID: number, AccountType: number, AccountHeadCode: number, AccountHeadName: number): Observable<AccountingGrid[]> {
    const AGridUrl = this.baseUrl + `/SearchAccountHeadDetails/${AccountHeadID}/${AccountClassificationID}/${AccountGroupID}/${AccountType}/${AccountHeadCode}/${AccountHeadName}`;
    return this.http.get<AccountingGrid[]>(AGridUrl)
      .pipe();
  }


  createAGridUrl = this.baseUrl + '/CreateAccountingHead';
  createAccountingHead(ac: AccountingGrid): Observable<AccountingGrid> {
    return this.http.post<AccountingGrid>(this.createAGridUrl, ac);
  }


}

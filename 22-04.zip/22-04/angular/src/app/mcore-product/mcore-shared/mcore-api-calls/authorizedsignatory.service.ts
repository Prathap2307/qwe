import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class AuthorizedsignatoryService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  // GetAllModulesByOrgID(id: any): Observable<any> {
  //   return this.http.get(this.baseUrl + '/GetAllModulesByOrgID' + id).pipe(tap((response) => response));
  // }
  GetAllModules(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllModules').pipe(tap((response) => response));
  }
  GetAllAuthorisedSignatory(objinfo: any): Observable<any> {
    return this.http.post(this.baseUrl + '/GetAllAuthorisedSignatory' , objinfo).pipe(tap((response) => response));
  }
  GetAllAuthorisedSignatories(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllAuthorisedSignatories').pipe(tap((response) => response));
  }
  addsignatory(a) {
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    // console.log(departmentRow);
    return this.http.post<any>(this.baseUrl + "/InsertOrUpdateAuthorisedSignatory", a, { headers: headers });
  }
  DeleteAuthorisedSignatory(a: any): Observable<any> {
    return this.http.post(this.baseUrl + '/DeleteAuthorisedSignatory', a).pipe(tap((response) => response));
  }
  IsAuthorisedSignatoryExist(a: any): Observable<any> {
    return this.http.post(this.baseUrl + '/IsAuthorisedSignatoryExist', a).pipe(tap((response) => response));
  }

}

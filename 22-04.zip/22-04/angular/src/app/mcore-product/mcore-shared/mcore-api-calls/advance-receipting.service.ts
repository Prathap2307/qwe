import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdvanceReceiptingService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addApplicationPremiumDetails(data:any): Observable<any> {
    return this.http.post(this.baseUrl + 'client/addApplicationPremiumDetails/update',data).pipe(tap((response) => response));
  }
  mastPolicyNoGroupId(groupId:any): Observable<any> {
    return this.http.get(this.baseUrl + `/client/masterPolicyNoByGroupId/${groupId}`).pipe(tap((response) => response));
  }
  getgridbypolicyid(policy:any): Observable<any> {
    return this.http.get(this.baseUrl + `/client/searchAppPremium/${policy}`).pipe(tap((response) => response));
  }
  
}

import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
import { MemberdeletionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberdeletion.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
@Component({
  selector: 'app-memberdeletion',
  templateUrl: './memberdeletion.component.html',
  styleUrls: ['./memberdeletion.component.css']
})
export class MemberdeletionComponent implements OnInit {


  filteredOptions: Observable<any[]>;

  constructor(private fb: FormBuilder, private memberupload: MemberuploadService, private memberdeletionService: MemberdeletionService) { }

  memberDeletionForm: FormGroup;
  get memberDeletionAction() {
    return this.memberDeletionForm.get('memberDeletionAction') as FormGroup;
  }
  groupNameObj: any[] = [];
  groupNameFilterObj: any[] = [];
  mpnObj: MemberUpload[];
  authorizedSignatoryObj: MemberUpload[];
  uploadFileurl: any;
  uploadFiledata: any;
  uploadFileName: any;
  ngOnInit() {


    this.memberDeletionForm = this.fb.group({
      memberDeletionAction: this.fb.group({

        groupID: ['', [Validators.required]],
        masterPolicyNumber: ['', [Validators.required]],
        agreementNumber: ['', [Validators.required]],
        browseBtn: ['']

      })

    });

    this.getGroupDetails();
    // this.filteredOptions = this.myControl.valueChanges
    //   .pipe(
    //     startWith(''),
    //     map((value) => this._filter(value))
    //   );


  }


  private _filter(value): any[] {
    const filterValue = value;

    let r = this.groupNameObj.filter((unit) => unit.groupName == filterValue);

    return this.groupNameObj.filter(option => option.groupName.includes(filterValue));


  }

  filterListCareUnit(val) {
    this.groupNameObj = this.groupNameFilterObj.filter((unit) => unit.groupName.indexOf(val) > -1);
  }


  getGroupDetails() {



    this.memberDeletionAction.addControl('groupName', new FormControl(''));
    this.memberDeletionAction.addControl('contactFirstName', new FormControl(''));
    this.memberDeletionAction.addControl('contactLastName', new FormControl(''));
    this.memberDeletionAction.addControl('customerGroupID', new FormControl(''));
    this.memberDeletionAction.addControl('branchID', new FormControl(0));
    this.memberDeletionAction.addControl('userID', new FormControl(0));

    let a = this.memberDeletionAction.value;

    this.memberupload.getGroupDetails(a).subscribe(a => {
      this.groupNameObj = a;
      this.groupNameFilterObj = a;
    });

  }


  getmasterPolicyDetails() {

    let groupID = this.memberDeletionAction.get('groupID').value;

    this.memberupload.getmasterPolicyDetails(groupID).subscribe(a => {
      this.mpnObj = a;
    });

    this.memberupload.getAllAuthorisedSignatories(groupID).subscribe(a => {
      this.authorizedSignatoryObj = a;
    });

  }
  selectedFile: any;
  formData = new FormData();
  handleFileInput(event: any) {


    this.selectedFile = event.target.files[0];
    console.log(this.selectedFile.name);
    this.uploadFileName = this.selectedFile.name
    this.formData.append("file", this.selectedFile);



  }

  validationMessage: any;

  fileSaveFn() {

    this.memberdeletionService.saveFile(this.formData).subscribe(a => {
      this.uploadFileurl = a;
      console.log(this.uploadFileurl);
      this.uploadFiledata = { 'filePath': this.uploadFileurl.filePath, 'fileName': this.uploadFileName };

      this.memberdeletionService.deletionValidateExcelFile(this.uploadFiledata).subscribe(data => {
        this.validationMessage = data;

        if (this.validationMessage == "") {

          console.log('valid test');
          this.memberdeletionService.postFile(this.uploadFiledata).subscribe(data => {
            // do something, if upload success
            this.onBtnClearAction();
          });
        
        }

      });

     
    });


  }

  uploadFileToActivity() {
    this.memberDeletionAction.markAllAsTouched();
    if (this.memberDeletionAction.valid) {
      this.fileSaveFn();
    }


  }

  onBtnClearAction() {
    this.memberDeletionAction.reset({
      masterPolicyNumber: '',
      agreementNumber: '',
      browseBtn: ''

    });

    this.validationMessage = '';
  }

  cfn(a) {
    console.log(a);
  }


}

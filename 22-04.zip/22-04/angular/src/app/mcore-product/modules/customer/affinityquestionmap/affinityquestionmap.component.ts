import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl } from '@angular/forms';
@Component({
  selector: 'app-affinityquestionmap',
  templateUrl: './affinityquestionmap.component.html',
  styleUrls: ['./affinityquestionmap.component.css']
})
export class AffinityquestionmapComponent implements OnInit {
  dummyObj: string;
  MasterPolicyDetails: FormGroup;
  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit() {

    this.MasterPolicyDetails = this.fb.group({
      ClientName: ['', Validators.required],
      MasterPolicyNumber: ['', Validators.required],
    
    });
  }
  onsubmit()
  {
console.log(this.MasterPolicyDetails.value)
  }
}


import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlconfigurationsComponent } from './glconfigurations.component';

describe('GlconfigurationsComponent', () => {
  let component: GlconfigurationsComponent;
  let fixture: ComponentFixture<GlconfigurationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlconfigurationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlconfigurationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { QuotationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/quotation.service';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MemberUpload, SuccessMessage, UploadFileurl } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MAT_DATE_LOCALE, NativeDateAdapter } from '@angular/material';

import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/mcore-product/modules/masters/quotation/format-datepicker';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product.service';

@Component({
    selector: 'app-quotation',
    templateUrl: './quotation.component.html',
    styleUrls: ['./quotation.component.css'],
    providers: [
        { provide: DateAdapter, useClass: AppDateAdapter },
        { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
    ]

})




export class QuotationComponent implements OnInit {
    tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
    tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);


    filteredClients: Observable<any[]>;

    constructor(private activatedRoute: ActivatedRoute, private quotationService: QuotationService, private fb: FormBuilder, private memberupload: MemberuploadService, private productService: ProductService) {


    }
    TypeQuotation: string;
    divProposalDetails: boolean;

    divPreview: boolean;

    salesHierarchyObj: any;

    quotationForm: FormGroup;
  
    // get quotationForm() {
    //     return this.quotationForm as FormGroup;
    // }

    // get quotationId() {
    //     return this.quotationForm.get('quotationId') as FormControl;
    //   }
    get SalesHierarchyFormGroup() {
        return this.quotationForm.get('SalesHierarchyFormGroup') as FormGroup;
    }
    get ClientDetailsFormGroup() {
        return this.quotationForm.get('ClientDetailsFormGroup') as FormGroup;
    }
    get PlanInformationFormGroup() {
        return this.quotationForm.get('PlanInformationFormGroup') as FormGroup;
    }
    //  clientCtrl = new FormControl();
    productObj: any;
    premiumObj: any;
    variantObj: any;
    premiumGridObj: any;

    tableColumns1: string[] = ['ACTUALPREMIUMVALUE', 'PREMIUMVALUE', 'RULESETNAME', 'INFLUENTIALVALUEDESCRIPTION'];
    generationQuotationId: any;
    sendBacktoMakerDiv: any;
    checkerGridDiv: any;
    makerGridDiv: any;
    sendtoApproverDiv: any;
    sendtoCheckerDiv: any;
    PopupMessage: any;
    ngOnInit() {
        this.popupDiv = false;
        this.sendBacktoMakerDiv = false;
       
        this.sendtoApproverDiv = false;
        this.sendtoCheckerDiv = false;
        this.activatedRoute.queryParams.subscribe(params => {
            this.TypeQuotation = params['Type'];
            this.PageLoad();
        });


        this.quotationForm = this.fb.group({

           
            SalesHierarchyFormGroup: this.fb.group({
                quotationId: [''],
                CODE: [''],
                NAME: [''],
                MAINCHANNELCODE: [''],
                SUBCHANNELCODE: [''],
                BRANCHID: [''],

                ISADVANCEDEPOSIT: [''],
                DEPARTMENTID: [''],
                SALESHIERARCHYID: [''],
                FIRSTNAME: [''],
                SALESTYPE: [''],
                SALESTYPEID: [''],
                CATEGORY: [''],
                MAINCHANNELNAME: [''],
                GENDER: [''],
                LINEOFBUSINESSID: [''],
                TYPE: [''],
                DESIGNATIONID: [''],
                FIRETYPEID: [''],
                SUBCHANNELNAME: [''],
                PARENTHIERARCHYID: [''],
                SUBCHANNELID: [''],
                MAINCHANNELID: [''],
                SALUTATIONID: [''],
                ISCDACCOUNT: ['']

            }),
            ClientDetailsFormGroup: this.fb.group({
                clientCtrl: [''],
                groupID: [''],
                firstName: ['', [Validators.required]],
                middleName: [''],
                lastName: [''],
                tradeBusinessName: [''],
                totalNumberofInsured: [''],
                totalSumInsured: [''],
                contactID: [''],
                UCINumber: ['']
            }),

            PlanInformationFormGroup: this.fb.group({
                product: ['', [Validators.required]],
                variant: ['', [Validators.required]],
                premiumPaymentTerm: [''],
                policyInceptionDate: ['', [Validators.required]],
                policyExpiryDate: ['', [Validators.required]]
            })

        });

        this.filteredClients = this.quotationForm.get('ClientDetailsFormGroup.clientCtrl').valueChanges
            .pipe(
                startWith(''),
                map(unit => unit ? this.filterclientFn(unit) : this.clientObj.slice())
            );
        this.getGroupDetails();
        this.getProduct();
        this.getPremium();
        this.getVariant();
        this.getMakerSearchQuotation();

        this.getChekerSearchQuotation();

        this.ClientDetailsFormGroup.get('UCINumber').disable();
        // this.PlanInformationFormGroup.patchValue({
        //     premiumPaymentTerm : 1
        // });
        // this.PlanInformationFormGroup.get('premiumPaymentTerm').disable();
    }

    getGroupDetails() {

        let a: Object = {
            "groupName": "",
            "contactFirstName": "",
            "contactLastName": "",
            "customerGroupID": "",
            "branchID": 0,
            "userID": 1
        }

        this.memberupload.getGroupDetails(a).subscribe(a => {
            this.clientObj = a;
        });

    }

    change_variant_fn() {
        let id = this.PlanInformationFormGroup.get('variant').value;
        this.quotationService.getPremiumDetails(id).subscribe(a => {
            this.premiumGridObj = a;
        });
    }

    getProduct() {

        this.quotationService.getProduct().subscribe(a => {
            this.productObj = a;
        });

    }

    // getProduct() {

    //     this.productService.getProductDetails().subscribe(a => {
    //         this.productObj = a;
    //     });

    // }

    getPremium() {

        this.quotationService.getPremium().subscribe(a => {
            this.premiumObj = a;
        });

    }
    getVariant() {

        this.quotationService.getVariant(1).subscribe(a => {
            this.variantObj = a;
        });

    }


    saveQuotation() {

        // new Date(this.PlanInformationFormGroup.get('policyInceptionDate').value)
        //  new Date(this.PlanInformationFormGroup.get('policyExpiryDate').value)
        this.PlanInformationFormGroup.markAllAsTouched();

        if (this.PlanInformationFormGroup.valid) {

            let obj: Object = {
                "lineOfBusinessID": 1,
                "branchID": 1,
                "quotationID": 0,
                "quotationDate": "2020-04-01",
                "quotationNo": "",
                "salesHierarchyID": this.SalesHierarchyFormGroup.get('SALESHIERARCHYID').value,
                "subChannelID": 1,
                "mainChannelID": 1,
                "salesType": 1,
                "quotationPartyMapID": 1,
                "productID": this.PlanInformationFormGroup.get('variant').value,
                "planID": this.PlanInformationFormGroup.get('product').value,
                "sumInsured": 10000,
                "policyStartDate": new Date(this.PlanInformationFormGroup.get('policyInceptionDate').value),
                "policyEndDate": new Date(this.PlanInformationFormGroup.get('policyExpiryDate').value),
                "policyIssueDate": "2020-04-01",
                "premiumPaymentTerm": this.PlanInformationFormGroup.get('premiumPaymentTerm').value,
                "policyTerm ": 0,
                "premiumPaymentFrequencyID": 0,
                "basePremium": 0,
                "netPremium": 0,
                "netPayableAmount": 0,
                "discretionaryPercentage": 0,
                "discretionaryDiscountLoading": "1",
                "discretionaryAmount": 0,
                "isServiceTax": "",
                "loanID": "www",
                "outstandingLoanAmt": "",
                "rateOferest": "",
                "eMITypeID": "",
                "loanTenture": "",
                "loanTypeID": "",
                "eMI": "",
                "statusID": 36,
                "createdBy  ": "",
                "createdOn": new Date(),
                "isActive": 1,
                "typeID": "",
                "totalMember ": this.ClientDetailsFormGroup.get('totalNumberofInsured').value,
                "totalSumInsured": this.ClientDetailsFormGroup.get('totalSumInsured').value,
                "fileName": "fhfghfghfghfghfgh",
                "fileHeaderID": "",
                "remarks": "pfghgfhfgh",
                "quotationVersion": "",
                "groupID": this.ClientDetailsFormGroup.get('groupID').value
            }

            console.log(obj);

            this.quotationService.saveQuotation(obj).subscribe(data => {
                this.generationQuotationId = data;
                this.insertPremiumValue();
                this.fileSaveFn();
                this.migrationDataUpload();

            });
        } else {
            console.log("invalid");
        }

        setTimeout(() => {
            this.fileDivUploadMessage = false;
        }, 5000);
    }

    sendtoApproverFn() {
        // this.PlanInformationFormGroup.markAllAsTouched();

        // if (this.PlanInformationFormGroup.valid) {

        let obj: Object = {
            "lineOfBusinessID": 1,
            "branchID": 1,
            "quotationID": this.SalesHierarchyFormGroup.get('quotationId').value,
            "quotationDate": "2020-04-01",
            "quotationNo": "",
            "salesHierarchyID": this.SalesHierarchyFormGroup.get('SALESHIERARCHYID').value,
            "subChannelID": 1,
            "mainChannelID": 1,
            "salesType": 1,
            "quotationPartyMapID": 1,
            "productID": this.PlanInformationFormGroup.get('variant').value,
            "planID": this.PlanInformationFormGroup.get('product').value,
            "sumInsured": 10000,
            "policyStartDate": new Date(this.PlanInformationFormGroup.get('policyInceptionDate').value),
            "policyEndDate": new Date(this.PlanInformationFormGroup.get('policyExpiryDate').value),
            "policyIssueDate": "2020-04-01",
            "premiumPaymentTerm": this.PlanInformationFormGroup.get('premiumPaymentTerm').value,
            "policyTerm ": 5,
            "premiumPaymentFrequencyID": 45,
            "basePremium": 5,
            "netPremium": 5,
            "netPayableAmount": 5,
            "discretionaryPercentage": 5,
            "discretionaryDiscountLoading": "1",
            "discretionaryAmount": 1000,
            "isServiceTax": "",
            "loanID": "www",
            "outstandingLoanAmt": "",
            "rateOferest": "",
            "eMITypeID": "",
            "loanTenture": "",
            "loanTypeID": "",
            "eMI": "",
            "statusID": 9,
            "createdBy  ": "",
            "createdOn": "2020-04-01",
            "isActive": 1,
            "typeID": "",
            "totalMember ": this.ClientDetailsFormGroup.get('totalNumberofInsured').value,
            "totalSumInsured": this.ClientDetailsFormGroup.get('totalSumInsured').value,
            "fileName": "fhfghfghfghfghfgh",
            "fileHeaderID": "",
            "remarks": "pfghgfhfgh",
            "quotationVersion": "",
            "groupID": this.ClientDetailsFormGroup.get('groupID').value
        }

        console.log(obj);

        this.quotationService.saveQuotation(obj).subscribe(data => {


            this.popupDiv = true;
            this.popup_message_1 = true;
            this.PopupMessage = "Quotation Approved!";
        });



    }
    sendBackTestFn(){
        console.log("sendBacktoMakerFn quotationId check",this.SalesHierarchyFormGroup.get('quotationId').value);
    }
    sendBacktoMakerFn() {
      
        let obj: Object = {
            "lineOfBusinessID": 1,
            "branchID": 1,
            "quotationID": this.SalesHierarchyFormGroup.get('quotationId').value,
            "quotationDate": "2020-04-01",
            "quotationNo": "",
            "salesHierarchyID": this.SalesHierarchyFormGroup.get('SALESHIERARCHYID').value,
            "subChannelID": 1,
            "mainChannelID": 1,
            "salesType": 1,
            "quotationPartyMapID": 1,
            "productID": this.PlanInformationFormGroup.get('variant').value,
            "planID": this.PlanInformationFormGroup.get('product').value,
            "sumInsured": 10000,
            "policyStartDate": new Date(this.PlanInformationFormGroup.get('policyInceptionDate').value),
            "policyEndDate": new Date(this.PlanInformationFormGroup.get('policyExpiryDate').value),
            "policyIssueDate": "2020-04-01",
            "premiumPaymentTerm": this.PlanInformationFormGroup.get('premiumPaymentTerm').value,
            "policyTerm ": 0,
            "premiumPaymentFrequencyID": 0,
            "basePremium": 0,
            "netPremium": 0,
            "netPayableAmount": 0,
            "discretionaryPercentage": 0,
            "discretionaryDiscountLoading": "1",
            "discretionaryAmount": 0,
            "isServiceTax": "",
            "loanID": "www",
            "outstandingLoanAmt": "",
            "rateOferest": "",
            "eMITypeID": "",
            "loanTenture": "",
            "loanTypeID": "",
            "eMI": "",
            "statusID": 35,
            "createdBy": "",
            "createdOn": new Date(),
            "isActive": 1,
            "typeID": "",
            "totalMember ": this.ClientDetailsFormGroup.get('totalNumberofInsured').value,
            "totalSumInsured": this.ClientDetailsFormGroup.get('totalSumInsured').value,
            "fileName": "fhfghfghfghfghfgh",
            "fileHeaderID": "",
            "remarks": "pfghgfhfgh",
            "quotationVersion": "",
            "groupID": this.ClientDetailsFormGroup.get('groupID').value
        }

        // let obj: Object = {
        //     "quotationID": this.SalesHierarchyFormGroup.get('quotationId').value,
        //     "statusID": 35
        // }


        console.log(obj);

        this.quotationService.saveQuotation(obj).subscribe(data => {


            this.popupDiv = true;
            this.popup_message_1 = true;
            this.PopupMessage = "Quotation sent to maker!";
        });



    }
    insertPremiumValue() {
        // console.log(this.generationQuotationId[0]);
        let obj: Object = {

            "productID": 1,
            "quotationID": this.generationQuotationId[0],
            "masterPolicyID": 1,
            "groupID": 1,
            "premiumID": 1,
            "coverageID": 1,
            "premiumValue": 1,
            "actualPremiumValue": 1
        }

        //console.log(obj);

        this.quotationService.insertPremiumValue(obj).subscribe(data => {



        });

    }

    PageLoad() {

        if (this.TypeQuotation.trim() == 'M') {

            this.divProposalDetails = true;
            this.divPreview = false;

            this.checkerGridDiv = false;
            this.getMakerSearchQuotation();

            this.clearQuotation();

            this.sendBacktoMakerDiv = false;

            this.sendtoApproverDiv = false;

            this.sendtoCheckerDiv = true;
            this.makerGridDiv = true;
            this.checkerGridDiv = false;

        }

        if (this.TypeQuotation.trim() == 'SA') {
            this.divProposalDetails = true;
            this.divPreview = false;

            this.sendBacktoMakerDiv = true;

            this.makerGridDiv = false;
            this.checkerGridDiv = true;

            this.getChekerSearchQuotation();
            this.clearQuotation();

            this.sendBacktoMakerDiv = true;
            this.sendtoApproverDiv = true;
            this.sendtoCheckerDiv = false;
        }

        if (this.TypeQuotation.trim() == 'A') {
            this.divProposalDetails = false;
            this.divPreview = true;

            this.getSearchQuotation();
            this.clearQuotation();
        }
    }

    tableColumns: string[] = ['BasePremium', 'NetPremium', 'GSTAmount', 'NetPayableAmount', 'DiscretionaryDiscountLoading'];
    table1Columns: string[] = ['View', 'Edit', 'BasePremium', 'NetPremium', 'GSTAmount', 'NetPayableAmount', 'DiscretionaryDiscountLoading'];

    table2Columns: string[] = ['ClientName', 'SumInsured', 'NetInstallmentAmountPayable'];

    approveGridColumns: string[] = ['View', 'GROUPNAME', 'QUOTATIONNO', 'CODE', 'DESCRIPTION'];
    makerGridColumns: string[] = ['Edit', 'GROUPNAME', 'QUOTATIONNO', 'CODE', 'DESCRIPTION'];
    chekerGridColumns: string[] = ['Edit', 'GROUPNAME', 'QUOTATIONNO', 'CODE', 'DESCRIPTION'];
    getSalesHierarchyDetails(e) {



        //this.SalesHierarchyFormGroup.get('MOCode').value;
        if (e.target.value.length > 1) {
            this.quotationService.getSalesHierarchyDetails(e.target.value)
                .subscribe(data => {

                    this.salesHierarchyObj = data;

                    this.salesHierarchyPatch();
                });
        } else {
            this.SalesHierarchyFormGroup.patchValue({
                NAME: ''

            });
        }




    }

    salesHierarchyPatch() {

        if (this.salesHierarchyObj.length > 0) {
            this.SalesHierarchyFormGroup.patchValue({
                NAME: this.salesHierarchyObj[0].NAME,
                MAINCHANNELCODE: this.salesHierarchyObj[0].MAINCHANNELCODE,
                SUBCHANNELCODE: this.salesHierarchyObj[0].SUBCHANNELCODE,
                BRANCHID: this.salesHierarchyObj[0].BRANCHID,

                ISADVANCEDEPOSIT: this.salesHierarchyObj[0].ISADVANCEDEPOSIT,
                DEPARTMENTID: this.salesHierarchyObj[0].DEPARTMENTID,
                SALESHIERARCHYID: this.salesHierarchyObj[0].SALESHIERARCHYID,
                FIRSTNAME: this.salesHierarchyObj[0].FIRSTNAME,
                SALESTYPE: this.salesHierarchyObj[0].SALESTYPE,
                SALESTYPEID: this.salesHierarchyObj[0].SALESTYPEID,
                CATEGORY: this.salesHierarchyObj[0].CATEGORY,
                MAINCHANNELNAME: this.salesHierarchyObj[0].MAINCHANNELNAME,
                GENDER: this.salesHierarchyObj[0].GENDER,
                LINEOFBUSINESSID: this.salesHierarchyObj[0].LINEOFBUSINESSID,
                TYPE: this.salesHierarchyObj[0].TYPE,
                DESIGNATIONID: this.salesHierarchyObj[0].DESIGNATIONID,
                FIRETYPEID: this.salesHierarchyObj[0].FIRETYPEID,
                SUBCHANNELNAME: this.salesHierarchyObj[0].SUBCHANNELNAME,
                PARENTHIERARCHYID: this.salesHierarchyObj[0].PARENTHIERARCHYID,
                SUBCHANNELID: this.salesHierarchyObj[0].SUBCHANNELID,
                MAINCHANNELID: this.salesHierarchyObj[0].MAINCHANNELID,
                SALUTATIONID: this.salesHierarchyObj[0].SALUTATIONID,
                ISCDACCOUNT: this.salesHierarchyObj[0].ISCDACCOUNT

            });
        }


    }

    cfn(a) {
        console.log(a);
    }

    clientObj: any = [];

    filterclientFn(groupName: string) {
        return this.clientObj.filter(unit =>
            unit.groupName.toLowerCase().indexOf(groupName.toLowerCase()) === 0);
    }

    clientDetailsObj: any;
    onEnter(evt: any) {

        if (evt.source.selected) {
            // console.log(evt.source.value);
            let v = evt.source.value;
            let r;
            r = this.clientObj.filter((unit) => unit.groupName == v);

            this.quotationForm.get('ClientDetailsFormGroup.groupID').patchValue(r[0].groupID);

            let id = this.quotationForm.get('ClientDetailsFormGroup.groupID').value;

            this.quotationService.getClientDetails(id, 2).subscribe(data => {

                this.clientDetailsObj = data;

                this.clientDetailsPatch();


            });

            //  alert(evt.source.selected.value);

        }
    }

    clientDetailsPatch() {
        this.ClientDetailsFormGroup.patchValue({



            firstName: this.clientDetailsObj[0].CONTACTFIRSTNAME,
            middleName: this.clientDetailsObj[0].CONTACTMIDDLENAME,
            lastName: this.clientDetailsObj[0].CONTACTLASTNAME,
            tradeBusinessName: this.clientDetailsObj[0].TNAME,

            contactID: this.clientDetailsObj[0].SHORTNAME,
            UCINumber: this.clientDetailsObj[0].CUSTOMERGROUPID

        });
    }

    //events: string[] = [];

    addEvent(type: string, event: MatDatepickerInputEvent<Date>) {


        //this.events.push(`${type}: ${event.value}`);
        let fieldDate = this.PlanInformationFormGroup.get('policyInceptionDate').value;


        if (fieldDate != "") {
            // var arr = start_date.split('/');
            // var arr1 = arr[2] + '/' + arr[1] + '/' + arr[0];

            // var d = new Date(arr1);
            let year = fieldDate.getFullYear();
            let month = fieldDate.getMonth();
            let day = fieldDate.getDate();

            let c = new Date(year + 1, month, day - 1);

            let f = ("0" + c.getDate()).slice(-2) + '/' + ("0" + (c.getMonth() + 1)).slice(-2) + '/' + c.getFullYear();

            // let f = ("0" + (c.getMonth() + 1)).slice(-2) + '/' + ("0" + c.getDate()).slice(-2) + '/' + c.getFullYear();

            //  $('.agreementEnd').val(f);


            this.PlanInformationFormGroup.patchValue({
                policyExpiryDate: f

            });
            console.log("policyEndDate", this.PlanInformationFormGroup.get('policyExpiryDate').value);
            console.log("policyInceptionDate", this.PlanInformationFormGroup.get('policyInceptionDate').value);
            this.PlanInformationFormGroup.get('policyExpiryDate').disable();

        }


    }
    selectedFile: any;
    uploadFileName: any;
    formData = new FormData();
    handleFileInput(event: any) {

        this.selectedFile = event.target.files[0];
        console.log(this.selectedFile.name);
        this.uploadFileName = this.selectedFile.name
        this.formData.append("file", this.selectedFile);

    }

    // uploadFileToActivity() {

    //     this.fileSaveFn();

    // }
    fileDivUploadMessage: boolean;
    fileUploadMessage: any;
    popup_message_1: any;
    popup_message_2: any;
    popup_message_3: any;
    fileSaveFn() {
        console.log(this.generationQuotationId[0]);
        this.quotationService.validateAnyExcelFile(this.formData, this.generationQuotationId[0]).subscribe(data => {
            this.fileUploadMessage = data;
            this.fileDivUploadMessage = true;
            if (this.fileUploadMessage == "Success") {
                this.popupDiv = true;
                this.popup_message_1 = true;
                this.PopupMessage = " Quotation saved successfully";
            } {
                console.log("Success else");
            }

            console.log(this.fileUploadMessage);
        });
    }

    popupDiv: boolean;

    popupBtnClose() {
        this.popupDiv = false;
    }

    successObj: any = [];
    // divsuccessMessage: Boolean;
    migrationDataUpload() {

        let obj: Object = {
            "quotationID": this.generationQuotationId[0],
            "productID": this.PlanInformationFormGroup.get('variant').value
        };


        console.log(obj);

        this.quotationService.migrationDataUpload(obj).subscribe(data => {
            this.successObj = data;

            //  this.divsuccessMessage = true;


        });
    }


    clearQuotation() {
        //   this.quotationForm.reset();
     //   this.quotationId.patchValue('');
        // this.quotationForm.reset({
        //     quotationId: ''
        // });

        this.quotationForm = this.fb.group({

           
            SalesHierarchyFormGroup: this.fb.group({
                quotationId: '',
                CODE: '',
                NAME: '',
                MAINCHANNELCODE: '',
                SUBCHANNELCODE: '',
                BRANCHID: '',

                ISADVANCEDEPOSIT: '',
                DEPARTMENTID: '',
                SALESHIERARCHYID: '',
                FIRSTNAME: '',
                SALESTYPE: '',
                SALESTYPEID: '',
                CATEGORY: '',
                MAINCHANNELNAME: '',
                GENDER: '',
                LINEOFBUSINESSID: '',
                TYPE: '',
                DESIGNATIONID: '',
                FIRETYPEID: '',
                SUBCHANNELNAME: '',
                PARENTHIERARCHYID: '',
                SUBCHANNELID: '',
                MAINCHANNELID: '',
                SALUTATIONID: '',
                ISCDACCOUNT: ''

            }),
            ClientDetailsFormGroup: this.fb.group({
                clientCtrl: '',
                groupID: '',
                firstName: '',
                middleName: '',
                lastName: '',
                tradeBusinessName: '',
                totalNumberofInsured: '',
                totalSumInsured: '',
                contactID: '',
                UCINumber: ''
            }),

            PlanInformationFormGroup: this.fb.group({
                product: '',
                variant: '',
                premiumPaymentTerm: '',
                policyInceptionDate: '',
                policyExpiryDate: ''
            })

        });

      




    }

    approveGridObj: any;

    getSearchQuotation() {

        let obj: Object = {
            "groupName": null,
            "quotationNumber": null,
            "salesHierarchyCode": null,
            "ageing": null,
            "userId": null,
            "statusId": null
        };


        console.log(obj);

        this.quotationService.getSearchQuotation(obj).subscribe(data => {
            this.approveGridObj = data;


        });
    }
    approveFilteredGridObj: any;
    approveBackBtn: any;
    btngvApproveView_Click(id) {
        this.approveBackBtn = true;
        this.divProposalDetails = true;
        this.divPreview = false;
        this.approveFilteredGridObj = this.approveGridObj.filter((unit) => unit.QUOTATIONID == id);


        this.SalesHierarchyFormGroup.patchValue({

            CODE: this.approveFilteredGridObj[0].CODE,
            NAME: this.approveFilteredGridObj[0].SALESNAME,
            MAINCHANNELCODE: this.approveFilteredGridObj[0].MAINCHANNELNAME,
            SUBCHANNELCODE: this.approveFilteredGridObj[0].SUBCHANNELNAME,
            // BRANCHID: '',

            // ISADVANCEDEPOSIT: '',
            // DEPARTMENTID: '',
            // SALESHIERARCHYID: '',
            // FIRSTNAME: '',
            // SALESTYPE: '',
            // SALESTYPEID: '',
            // CATEGORY: '',
            // MAINCHANNELNAME: '',
            // GENDER: '',
            // LINEOFBUSINESSID: '',
            // TYPE: '',
            // DESIGNATIONID: '',
            // FIRETYPEID: '',
            // SUBCHANNELNAME: '',
            // PARENTHIERARCHYID: '',
            // SUBCHANNELID: '',
            // MAINCHANNELID: '',
            // SALUTATIONID: '',
            // ISCDACCOUNT: ''

        });

        //this.approveFilteredGridObj[0].GROUPID

        this.ClientDetailsFormGroup.patchValue({
            clientCtrl: this.approveFilteredGridObj[0].GROUPNAME,
            groupID: this.approveFilteredGridObj[0].GROUPID,
            firstName: this.approveFilteredGridObj[0].CONTACTFIRSTNAME,
            middleName: this.approveFilteredGridObj[0].CONTACTMIDDLENAME,
            lastName: this.approveFilteredGridObj[0].CONTACTLASTNAME,
            tradeBusinessName: this.approveFilteredGridObj[0].TNAME,
            totalNumberofInsured: '',
            totalSumInsured: this.approveFilteredGridObj[0].TOTALSUMINSURED,
            contactID: this.approveFilteredGridObj[0].SHORTNAME,
            UCINumber: this.approveFilteredGridObj[0].CUSTOMERGROUPID
        });

        this.PlanInformationFormGroup.patchValue({
            product: this.approveFilteredGridObj[0].PLANID,
            variant: this.approveFilteredGridObj[0].PRODUCTID,
            premiumPaymentTerm: this.approveFilteredGridObj[0].PREMIUMPAYMENTTERM,
            policyInceptionDate: '',
            policyExpiryDate: ''
        })
        this.quotationForm.disable();

    }

    backToaApprovePage() {
        this.approveBackBtn = false;
        this.divProposalDetails = false;
        this.divPreview = true;
    }

    makerGridObj: any;
    getMakerSearchQuotation() {

        let obj: Object = {
            "groupName": null,
            "quotationNumber": null,
            "salesHierarchyCode": null,
            "ageing": null,
            "userId": null,
            "statusId": 35
        };


        console.log(obj);

        this.quotationService.getSearchQuotation(obj).subscribe(data => {

            this.makerGridObj = data;

        });
    }
    chekerGridObj: any;
    getChekerSearchQuotation() {

        let obj: Object = {
            "groupName": null,
            "quotationNumber": null,
            "salesHierarchyCode": null,
            "ageing": null,
            "userId": null,
            "statusId": 36
        };


        console.log(obj);

        this.quotationService.getSearchQuotation(obj).subscribe(data => {

            this.chekerGridObj = data;

        });
    }

    checkerFilteredGridObj: any;
    btngvCheckerEdit_Click(id) {



        this.checkerFilteredGridObj = this.chekerGridObj.filter((unit) => unit.QUOTATIONID == id);


        //   this.quotationForm.addControl('quotationId', new FormControl(this.checkerFilteredGridObj[0].QUOTATIONID));

        // this.quotationForm.patchValue({
            
        // });

        this.SalesHierarchyFormGroup.patchValue({
            quotationId: this.checkerFilteredGridObj[0].QUOTATIONID,
            CODE: this.checkerFilteredGridObj[0].CODE,
            NAME: this.checkerFilteredGridObj[0].SALESNAME,
            MAINCHANNELCODE: this.checkerFilteredGridObj[0].MAINCHANNELNAME,
            SUBCHANNELCODE: this.checkerFilteredGridObj[0].SUBCHANNELNAME,
        //     BRANCHID: '',

        //     ISADVANCEDEPOSIT: '',
        //     DEPARTMENTID: '',
        //    // SALESHIERARCHYID: this.checkerFilteredGridObj[0].SUBCHANNELNAME,
        //     FIRSTNAME: '',
        //     SALESTYPE: '',
        //     SALESTYPEID: '',
        //     CATEGORY: '',
        //     MAINCHANNELNAME: '',
        //     GENDER: '',
        //     LINEOFBUSINESSID: '',
        //     TYPE: '',
        //     DESIGNATIONID: '',
        //     FIRETYPEID: '',
        //     SUBCHANNELNAME: '',
        //     PARENTHIERARCHYID: '',
        //     SUBCHANNELID: '',
        //     MAINCHANNELID: '',
        //     SALUTATIONID: '',
        //     ISCDACCOUNT: ''

        });
      
        //this.approveFilteredGridObj[0].GROUPID

        this.ClientDetailsFormGroup.patchValue({
            clientCtrl: this.checkerFilteredGridObj[0].GROUPNAME,
            groupID: this.checkerFilteredGridObj[0].GROUPID,
            firstName: this.checkerFilteredGridObj[0].CONTACTFIRSTNAME,
            middleName: this.checkerFilteredGridObj[0].CONTACTMIDDLENAME,
            lastName: this.checkerFilteredGridObj[0].CONTACTLASTNAME,
            tradeBusinessName: this.checkerFilteredGridObj[0].TNAME,
            totalNumberofInsured: '',
            totalSumInsured: this.checkerFilteredGridObj[0].TOTALSUMINSURED,
            contactID: this.checkerFilteredGridObj[0].SHORTNAME,
            UCINumber: this.checkerFilteredGridObj[0].CUSTOMERGROUPID
        });

        this.PlanInformationFormGroup.patchValue({
            product: this.checkerFilteredGridObj[0].PLANID,
            variant: this.checkerFilteredGridObj[0].PRODUCTID,
            premiumPaymentTerm: this.checkerFilteredGridObj[0].PREMIUMPAYMENTTERM,
            policyInceptionDate: this.checkerFilteredGridObj[0].POLICYSTARTDATE,
            policyExpiryDate: this.checkerFilteredGridObj[0].POLICYENDDATE
        })
        this.quotationForm.disable();

    }
    makerFilteredGridObj: any;
    btngvMakerEdit_Click(id) {

        this.makerFilteredGridObj = this.makerGridObj.filter((unit) => unit.QUOTATIONID == id);
// console.log("CODE test", this.makerFilteredGridObj[0]);

        this.SalesHierarchyFormGroup.patchValue({

            CODE: this.makerFilteredGridObj[0].CODE,
            NAME: this.makerFilteredGridObj[0].SALESNAME,
            MAINCHANNELCODE: this.makerFilteredGridObj[0].MAINCHANNELNAME,
            SUBCHANNELCODE: this.makerFilteredGridObj[0].SUBCHANNELNAME,
            // BRANCHID: '',

            // ISADVANCEDEPOSIT: '',
            // DEPARTMENTID: '',
            // SALESHIERARCHYID: '',
            // FIRSTNAME: '',
            // SALESTYPE: '',
            // SALESTYPEID: '',
            // CATEGORY: '',
            // MAINCHANNELNAME: '',
            // GENDER: '',
            // LINEOFBUSINESSID: '',
            // TYPE: '',
            // DESIGNATIONID: '',
            // FIRETYPEID: '',
            // SUBCHANNELNAME: '',
            // PARENTHIERARCHYID: '',
            // SUBCHANNELID: '',
            // MAINCHANNELID: '',
            // SALUTATIONID: '',
            // ISCDACCOUNT: ''

        });

        //this.approveFilteredGridObj[0].GROUPID

        this.ClientDetailsFormGroup.patchValue({
            clientCtrl: this.makerFilteredGridObj[0].GROUPNAME,
            groupID: this.makerFilteredGridObj[0].GROUPID,
            firstName: this.makerFilteredGridObj[0].CONTACTFIRSTNAME,
            middleName: this.makerFilteredGridObj[0].CONTACTMIDDLENAME,
            lastName: this.makerFilteredGridObj[0].CONTACTLASTNAME,
            tradeBusinessName: this.makerFilteredGridObj[0].TNAME,
            totalNumberofInsured: '',
            totalSumInsured: this.makerFilteredGridObj[0].TOTALSUMINSURED,
            contactID: this.makerFilteredGridObj[0].SHORTNAME,
            UCINumber: this.makerFilteredGridObj[0].CUSTOMERGROUPID
        });

        this.PlanInformationFormGroup.patchValue({
            product: this.makerFilteredGridObj[0].PLANID,
            variant: this.makerFilteredGridObj[0].PRODUCTID,
            premiumPaymentTerm: this.makerFilteredGridObj[0].PREMIUMPAYMENTTERM,
            policyInceptionDate: new Date(this.makerFilteredGridObj[0].POLICYSTARTDATE),
            policyExpiryDate: new Date(this.makerFilteredGridObj[0].POLICYENDDATE)
        });
        //  this.quotationForm.disable();

    }
}

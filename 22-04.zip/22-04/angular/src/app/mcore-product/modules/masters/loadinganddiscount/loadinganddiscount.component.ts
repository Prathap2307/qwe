import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product1.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-loadinganddiscount',
  templateUrl: './loadinganddiscount.component.html',
  styleUrls: ['./loadinganddiscount.component.css']
})
export class LoadinganddiscountComponent implements OnInit {

  productArr : any = [];
  questionArr : any = [];
  loadDiscountObj : any = {};
  loadDiscountArr : any = [];
  deleteLoadId : any;
  userId : any
  buttonDisable = false;
  isReadonly = true;
  loadDiscountErrMsg : any;
  viewInput = false;
  editInput = false;
  searchLoadDiscountObj : any = {};
  loadingAndDiscountingPage : any;


  constructor(
    private productService : ProductService,
    private spinner: NgxSpinnerService,
    private _snackBar: MatSnackBar
  ) {
    for (let i = 1; i <= this.loadDiscountArr.length; i++) {
      this.loadDiscountArr.push(`deal ${i}.0`);
    }

    this.getConfQuestion();
   }

  ngOnInit() {
    this.getConfProduct();
    this.getConfQuestion();
    this.getLoadDiscount();
    this.userId = JSON.parse(localStorage.getItem('userID'));

  }

  // LoadDiscountForm

  LoadDiscountForm = new FormGroup({
    description: new FormControl("",[Validators.required]),
    categoryValueId: new FormControl("",[Validators.required]),
    productId: new FormControl("",[Validators.required]),
    questionId: new FormControl(""),
    rangeFrom: new FormControl("",[Validators.required]),
    rangeTo: new FormControl("",[Validators.required]),
    valueSpecificId: new FormControl("",[Validators.required]),
    typeId: new FormControl(""),
    value: new FormControl(""),
    createdBy: new FormControl(""),
    lineOfBusinessId: new FormControl("")
  });

  getConfProduct()
  {
    this.spinner.show();
    this.productService.getConfProduct().subscribe(res => {
      console.log(res);
      this.productArr = res.variantRequestList;
      this.spinner.hide();
      console.log(this.productArr);
    })
  }

  getConfQuestion()
  {
    console.log('question')

   let productId=  this.loadDiscountObj.productId


    this.productService.getConfQuestion(productId).subscribe(res => {
      console.log(res);
      this.questionArr = res.questionList;
      console.log(this.questionArr);
    })
  }


  // getQuestion(){
  //   this._productService.getquestion().subscribe(res =>{
  //     this.questionArr = res.questionList;
  //   },err =>{
  //     console.log(err);
  //   })
  // }
  loadDiscountData()
  {
    if(this.LoadDiscountForm.valid)
    {
      this.loadDiscountObj.lineOfBusinessId = "1";
      this.loadDiscountObj.questionId = "1";
     
      this.loadDiscountObj.createdBy = this.userId;
      console.log(this.loadDiscountObj);
      this.productService.addLoadDiscount(this.loadDiscountObj).subscribe(res => {
      console.log(res)
      this._snackBar.open(res.message, 'Done', {
        duration: 2000,
      });
      this.getLoadDiscount();
    },err => {
      console.log(err)
    })
  }
  }

  getLoadDiscount()
  {
    this.loadingAndDiscountingPage = 1;
    this.buttonDisable = false;
    this.viewInput = false;
    this.editInput = false;
    this.LoadDiscountForm.markAsPristine();
    this.LoadDiscountForm.markAsUntouched();
    this.loadDiscountErrMsg = "";
    this.loadDiscountObj = {};
    this.isReadonly = true;
    this.searchLoadDiscountObj = {};
    this.productService.getLoadDiscount().subscribe(res => {
      console.log(res);
      this.loadDiscountArr = res.list;
      if(this.loadDiscountArr.length == 0)
      {
        this.loadDiscountErrMsg = 'Not Found';
      }
      this.spinner.hide();
  },err => {
    console.log(err);
  })
}

  deleteLoadDiscountId(delLoadId)
  {
    console.log(delLoadId);
    if(this.buttonDisable == false)
    {
    this.deleteLoadId = delLoadId;
    this.LoadDiscountForm.markAsPristine();
    this.LoadDiscountForm.markAsUntouched();
    this.loadDiscountObj = {};
    this.viewInput = false;
    this.editInput = false;
    this.isReadonly = true;
    }
  }

  deleteLoadDiscount()
  {
    console.log(this.deleteLoadId);
    this.productService.deleteLoadDiscount(this.deleteLoadId,this.userId).subscribe(res => {
      console.log(res);
      this.getLoadDiscount();
    },err => {
      console.log(err)
    })
  }

  editLoadDiscount(editLoadId)
  {
    if(this.buttonDisable == false)
    {
      this.spinner.show();
      this.viewInput = false;
      this.editInput = false;
      this.isReadonly = true;
      this.LoadDiscountForm.markAsPristine();
      this.LoadDiscountForm.markAsUntouched();
      this.loadDiscountObj = {};
      this.productService.getSingleLoadDiscount(editLoadId).subscribe(res => {
      console.log(res);
      this.loadDiscountObj = res.obj;
      this.buttonDisable = true;
      this.editInput = true;
      this.isReadonly = true;
      this.spinner.hide();
    },err => {
      console.log(err)
    })
  }
  }

  viewLoadDiscount(Id)
  {
    if(this.buttonDisable == false)
    {
      this.spinner.show();
      this.viewInput = false;
      this.editInput = false;
      this.isReadonly = true;
      this.LoadDiscountForm.markAsPristine();
      this.LoadDiscountForm.markAsUntouched();
      this.loadDiscountObj = {};
      this.productService.getSingleLoadDiscount(Id).subscribe(res => {
      this.loadDiscountObj = res.obj;
      this.buttonDisable = true;
      this.viewInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    },err => {
      console.log(err)
    })
  }
  }

  searchLoadDiscount(){
    this.spinner.show();
    this.loadDiscountErrMsg = '';
    this.viewInput = false;
    this.editInput = false;
    this.buttonDisable = false;
    this.isReadonly = true;
    this.LoadDiscountForm.markAsPristine();
    this.LoadDiscountForm.markAsUntouched();
    this.loadDiscountObj = {};
    this.productService.SearchLoadDiscount(this.searchLoadDiscountObj).subscribe(res =>{
      console.log(res);
      this.loadDiscountArr = res.list;
      if (this.loadDiscountArr && this.loadDiscountArr.length == 0){
        this.loadDiscountErrMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  loadDiscClear(){
    this.spinner.show();
    this.getLoadDiscount();
  }

  valueValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
     
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (  keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)

          event.preventDefault();
        }
     
     
    }
  }
 
 

}



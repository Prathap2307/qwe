import { Component, OnInit, ViewChild } from '@angular/core';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product1.service';
import { LookupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/lookup.service';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import { toBase64String } from '@angular/compiler/src/output/source_map';


@Component({
  selector: 'app-premium',
  templateUrl: './premium.component.html',
  styleUrls: ['./premium.component.css']
})
export class PremiumComponent implements OnInit {
  variantArr: any = [];
  benefitRidersArr: any = [];
  variantId: any;
  productPremiumTypeArr: any = [];
  typeId: any;
  productBenefitRidersArr: any = [];
  benefitRidersObj: any = {};
  searchPremiumObj: any = {};
  tableEnable = false;
  premiumRuleDataObj: any = [];
  premiumDataObj: any = {};
  premiumArr: any = [];
  userId: any;
  token: any;
  errMsg: string;
  buttonDisable = false;
  isReadonly = false;
  deletePremiumID: any;
  premiumPage: any;
  errorMsg: string;
  formvisibke: boolean;
  formvisible: boolean;
  rulesets: any = [];
  premiumRuleDataObj5: {};
  premiumRuleDataObj4: {};
  premiumRuleDataObj3: {};
  premiumRuleDataObj2: {};
  premiumRuleDataObj1: {};

  constructor(
    private spinner: NgxSpinnerService,
    private _productService: ProductService,
    private _lookupService: LookupService,
    private _snackBar: MatSnackBar
  ) {
    for (let i = 1; i <= this.premiumArr.length; i++) {
      this.premiumArr.push(`deal ${i}.0`);
    }
  }

  ngOnInit() {
    this.getVariant();
    this.userId = JSON.parse(localStorage.getItem('userID'));
    this.token = JSON.parse(localStorage.getItem('token'));
  }

  selectValue(data) {
    this.variantId = data;
    // this.searchPremiumObj.variantPremiumTypeId = "";
    // this.searchPremiumObj.benefitRiderId = "";
    this.getProductPremiumType();
  }

  selectTypeValue(data) {
    this.typeId = data;
    this.getBenefitRiders();
  }

  selectbenefitRidersValue(data) {
    this.benefitRidersObj = data;
  }

  getVariant() {
    this.spinner.show();
    this._productService.getConfProduct().subscribe(res => {
      console.log(res);
      this.variantArr = res.variantRequestList;
      this.spinner.hide();
    }, err => {
      console.log(err);
    })
  }

  getProductPremiumType() {
    this._productService.getProductPremiumType(this.variantId).subscribe(res => {
      console.log(res);
      this.productPremiumTypeArr = res.productTypeList;
    }, err => {
      console.log(err);
    })
  }

  getBenefitRiders() {
    let lobId = 1
    console.log(this.variantId, this.typeId, lobId)
    this._productService.getProductBenefitDiders(this.variantId, this.typeId, lobId).subscribe(res => {
      console.log(res);
      this.productBenefitRidersArr = res.productBenefitRiders;
    }, err => {
      console.log(err);
    })
  }

  // Premium

  premiumForm = new FormGroup({
    premiumValue: new FormControl("", [Validators.required]),
    createdBy: new FormControl(""),
    ruleSetName: new FormControl("", [Validators.required]),
    amountTypeId: new FormControl("", [Validators.required]),
    variantId: new FormControl(""),
    variantPremiumTypeId: new FormControl(""),
    benefitRiderId: new FormControl(""),
    premiumDetailsMap1: new FormGroup({
      influencingFactorID: new FormControl(1),
      maximumValue: new FormControl(""),
      maximumValueMonth: new FormControl(""),
      minimumValue: new FormControl(""),
      minimumValueMonth: new FormControl(""),
      specificValuesID: new FormControl(0),
      expressAsID: new FormControl(0),
    }),
    premiumDetailsMap2: new FormGroup({
      influencingFactorID: new FormControl(2),
      maximumValue: new FormControl(0),
      maximumValueMonth: new FormControl(0),
      minimumValue: new FormControl(0),
      minimumValueMonth: new FormControl(0),
      specificValuesID: new FormControl(""),
      expressAsID: new FormControl(0),

    }),
    premiumDetailsMap3: new FormGroup({
      influencingFactorID: new FormControl(3),
      maximumValue: new FormControl(""),
      maximumValueMonth: new FormControl(0),
      minimumValue: new FormControl(""),
      minimumValueMonth: new FormControl(0),
      specificValuesID: new FormControl(0),
      expressAsID: new FormControl(0),
    }),
    premiumDetailsMap4: new FormGroup({
      influencingFactorID: new FormControl(4),
      maximumValue: new FormControl(0),
      maximumValueMonth: new FormControl(0),
      minimumValue: new FormControl(0),
      minimumValueMonth: new FormControl(0),
      specificValuesID: new FormControl(""),
      expressAsID: new FormControl(0),
    }),
    premiumDetailsMap5: new FormGroup({
      influencingFactorID: new FormControl(5),
      maximumValue: new FormControl(""),
      maximumValueMonth: new FormControl(""),
      minimumValue: new FormControl(""),
      minimumValueMonth: new FormControl(""),
      specificValuesID: new FormControl(0),
      expressAsID: new FormControl(0),

    })
  });

  addpremium() {
    this.errorMsg = '';

    // for temporary basis


    if (this.premiumForm.value.premiumDetailsMap1.minimumValue && this.premiumForm.value.premiumDetailsMap1.maximumValue) {
      if (this.premiumForm.value.premiumDetailsMap1.minimumValue >= this.premiumForm.value.premiumDetailsMap1.maximumValue) {
        this.errorMsg = "In Age,Your Maximum Value Is Lower Than Or Equal In Minimum Value";
        this._snackBar.open(this.errorMsg, 'Error', {
          duration: 2000,
        });
      } else {
        this.errorMsg = 'true';

      }
    }

    if (this.premiumForm.value.premiumDetailsMap3.minimumValue && this.premiumForm.value.premiumDetailsMap3.maximumValue) {
      if (this.premiumForm.value.premiumDetailsMap3.minimumValue >= this.premiumForm.value.premiumDetailsMap3.maximumValue) {
        this.errorMsg = " In Sum Assured, Your Maximum Value Is Lower Than Or Equal In Minimum Value";
        this._snackBar.open(this.errorMsg, 'Error', {
          duration: 2000,
        });
      } else {
        this.errorMsg = 'true';

      }
    }


    if (this.premiumForm.value.premiumDetailsMap5.minimumValue && this.premiumForm.value.premiumDetailsMap5.maximumValue) {
      if (this.premiumForm.value.premiumDetailsMap5.minimumValue >= this.premiumForm.value.premiumDetailsMap5.maximumValue) {
        this.errorMsg = " In policy term, Your Maximum Value Is Lower Than Or Equal In Minimum Value";
        this._snackBar.open(this.errorMsg, 'Error', {
          duration: 2000,
        });
      } else {
        this.errorMsg = 'true';

      }

    }


    if (this.premiumForm.valid && this.errorMsg == 'true') {
      // this.premiumRuleDataObj.influencingFactorID = '1';
      // this.premiumRuleDataObj.specificValuesID = '2';
      // this.premiumRuleDataObj.benefitRiderId = '1';

      // this.premiumDataObj.premiumDetailsMap = this.premiumRuleDataObj;

      console.log(this.premiumForm.value.premiumDetailsMap1["influencingFactorID"])


      this.premiumForm.value.premiumDetailsMap1["influencingFactorID"] = 1
      this.premiumForm.value.premiumDetailsMap1["specificValuesID"] = 0
      this.premiumForm.value.premiumDetailsMap1["expressAsID"] = 0


      this.premiumForm.value.premiumDetailsMap2["influencingFactorID"] = 2
      this.premiumForm.value.premiumDetailsMap2["maximumValue"] = 0
      this.premiumForm.value.premiumDetailsMap2["maximumValueMonth"] = 0
      this.premiumForm.value.premiumDetailsMap2["minimumValue"] = 0
      this.premiumForm.value.premiumDetailsMap2["minimumValueMonth"] = 0
      this.premiumForm.value.premiumDetailsMap2["expressAsID"] = 0




      this.premiumForm.value.premiumDetailsMap3["influencingFactorID"] = 3
      this.premiumForm.value.premiumDetailsMap3["maximumValueMonth"] = 0
      this.premiumForm.value.premiumDetailsMap3["minimumValueMonth"] = 0
      this.premiumForm.value.premiumDetailsMap3["expressAsID"] = 0
      this.premiumForm.value.premiumDetailsMap3["specificValuesID"] = 0



      this.premiumForm.value.premiumDetailsMap4["influencingFactorID"] = 4
      this.premiumForm.value.premiumDetailsMap4["maximumValue"] = 0
      this.premiumForm.value.premiumDetailsMap4["maximumValueMonth"] = 0
      this.premiumForm.value.premiumDetailsMap4["minimumValue"] = 0
      this.premiumForm.value.premiumDetailsMap4["minimumValueMonth"] = 0
      this.premiumForm.value.premiumDetailsMap4["expressAsID"] = 0





      this.premiumForm.value.premiumDetailsMap5["influencingFactorID"] = 5
      this.premiumForm.value.premiumDetailsMap5["specificValuesID"] = 0
      this.premiumForm.value.premiumDetailsMap5["expressAsID"] = 0

      console.log(this.premiumForm.value.premiumDetailsMap1)
      this.rulesets[0] = this.premiumForm.value.premiumDetailsMap1;
      this.rulesets[1] = this.premiumForm.value.premiumDetailsMap2;
      this.rulesets[2] = this.premiumForm.value.premiumDetailsMap3;
      this.rulesets[3] = this.premiumForm.value.premiumDetailsMap4;
      this.rulesets[4] = this.premiumForm.value.premiumDetailsMap5;
      console.log(this.rulesets)



      this.premiumDataObj.premiumDetailsMapList = this.rulesets;

      this.premiumDataObj.createdBy = this.userId;
      this.premiumDataObj.variantId = this.searchPremiumObj.variantId;
      this.premiumDataObj.variantPremiumTypeId = this.searchPremiumObj.variantPremiumTypeId;
      this.premiumDataObj.benefitRiderId = this.searchPremiumObj.benefitRiderId;


      // for temporary basis

      // this.premiumDataObj.benefitRiderId = '1';

      console.log(this.premiumDataObj);
      this._productService.addPremium(this.premiumDataObj).subscribe(res => {
        console.log(res);
        this.premiumDataObj = {};
        this.preminumSearch();
        // this.premiumForm.value.premiumDetailsMap1=null
        this.premiumForm.reset()
        this.rulesets = []
        this._snackBar.open(res.message, 'Done', {

          duration: 2000,
        });

      }, err => {
        console.log(err);
        this.rulesets = []
      })
    }
  }

  preminumSearch() {
    this.spinner.show();
    this.errMsg = '';
    this.premiumPage = 1;
    this.premiumDataObj = {};
    this.premiumRuleDataObj = [];
    this.premiumRuleDataObj1 = {};
    this.premiumRuleDataObj2 = {};
    this.premiumRuleDataObj3 = {}
    this.premiumRuleDataObj4 = {}
    this.premiumRuleDataObj5 = {}
    this.premiumForm.markAsPristine();
    this.premiumForm.markAsUntouched();
    this.isReadonly = false;
    this.buttonDisable = false;
    // var premium = this.searchPremiumObj;
    console.log(this.searchPremiumObj)
    if (this.searchPremiumObj.variantId != null && this.searchPremiumObj.variantPremiumTypeId != null &&
      this.searchPremiumObj.benefitRiderId != null) {
      this._productService.searchPremium(this.searchPremiumObj).subscribe(res => {
        console.log(res);
        this.premiumArr = res.list;

        this.tableEnable = true;
        this.formvisible = true
        if (this.premiumArr == 0) {
          this.errMsg = 'Not Found';
          // this.formvisible=false

        }
        else {
          // this.formvisible=true
        }
        this.spinner.hide();
      }, err => {
        console.log(err);
      })
    }
  }

  clearPremium() {
    this.searchPremiumObj = {};
    // this.variantArr = [];
    this.productPremiumTypeArr = [];
    this.productBenefitRidersArr = [];
    this.tableEnable = false;
    this.premiumDataObj = {};
    this.variantId = "";
    this.typeId = "";
    this.premiumRuleDataObj = [];
    this.premiumRuleDataObj1 = {};
    this.premiumRuleDataObj2 = {};
    this.premiumRuleDataObj3 = {}
    this.premiumRuleDataObj4 = {}
    this.premiumRuleDataObj5 = {}
    this.premiumForm.markAsPristine();
    this.premiumForm.markAsUntouched();
    this.isReadonly = false;
    this.buttonDisable = false;
    this.premiumPage = 1;
  }

  viewPremium(id) {
    if (this.buttonDisable == false) {
      this.spinner.show();
      this.premiumDataObj = {};
      this.premiumRuleDataObj = [];
      this.premiumRuleDataObj1 = {};
      this.premiumRuleDataObj2 = {};
      this.premiumRuleDataObj3 = {}
      this.premiumRuleDataObj4 = {}
      this.premiumRuleDataObj5 = {}
      this.isReadonly = false;
      this.buttonDisable = false;
      this.premiumForm.markAsPristine();
      this.premiumForm.markAsUntouched();
      this._productService.getSinglePremium(id).subscribe(res => {
        console.log(res)
        this.premiumDataObj = res.obj;

        console.log(this.premiumDataObj)
        console.log(this.premiumDataObj.premiumDetailsMapList)
        this.premiumRuleDataObj = this.premiumDataObj.premiumDetailsMapList;
        console.log(this.premiumRuleDataObj)
        this.premiumRuleDataObj1 = this.premiumRuleDataObj[0];
        this.premiumRuleDataObj2 = this.premiumRuleDataObj[1];
        this.premiumRuleDataObj3 = this.premiumRuleDataObj[2];
        this.premiumRuleDataObj4 = this.premiumRuleDataObj[3];
        this.premiumRuleDataObj5 = this.premiumRuleDataObj[4];
        this.isReadonly = true;
        this.buttonDisable = true;
        this.spinner.hide();
      }, err => {
        console.log(err);
      })
    }
  }

  cancelPremium() {
    this.premiumDataObj = {};
    this.premiumRuleDataObj = [];
    this.premiumRuleDataObj1 = {};
    this.premiumRuleDataObj2 = {};
    this.premiumRuleDataObj3 = {}
    this.premiumRuleDataObj4 = {}
    this.premiumRuleDataObj5 = {}
    this.premiumForm.markAsPristine();
    this.premiumForm.markAsUntouched();
    this.isReadonly = false;
    this.buttonDisable = false;
    this.premiumPage = 1;
  }

  editPremium(editPremiumId) {
    if (this.buttonDisable == false) {
      this.spinner.show();
      this.premiumDataObj = {};
      this.premiumRuleDataObj = [];
      this.premiumRuleDataObj1 = {};
      this.premiumRuleDataObj2 = {};
      this.premiumRuleDataObj3 = {}
      this.premiumRuleDataObj4 = {}
      this.premiumRuleDataObj5 = {}
      this.isReadonly = false;
      this.buttonDisable = false;
      this.premiumForm.markAsPristine();
      this.premiumForm.markAsUntouched();
      this._productService.getSinglePremium(editPremiumId).subscribe(res => {
        console.log(res);
        this.premiumDataObj = res.obj;
        console.log(this.premiumDataObj)
        console.log(this.premiumDataObj.premiumDetailsMapList)
        this.premiumRuleDataObj = this.premiumDataObj.premiumDetailsMapList;
        console.log(this.premiumRuleDataObj)
        this.premiumRuleDataObj1 = this.premiumRuleDataObj[0];
        this.premiumRuleDataObj2 = this.premiumRuleDataObj[1];
        this.premiumRuleDataObj3 = this.premiumRuleDataObj[2];
        this.premiumRuleDataObj4 = this.premiumRuleDataObj[3];
        this.premiumRuleDataObj5 = this.premiumRuleDataObj[4];
        this.buttonDisable = true;
        this.spinner.hide();
      }, err => {
        console.log(err);
      })
    }
  }

  deletePremiumId(deletePremiumId) {
    if (this.buttonDisable == false) {
      this.premiumDataObj = {};
      this.premiumRuleDataObj = {};
      this.premiumRuleDataObj1 = {};
      this.premiumRuleDataObj2 = {};
      this.premiumRuleDataObj3 = {}
      this.premiumRuleDataObj4 = {}
      this.premiumRuleDataObj5 = {}
      this.isReadonly = false;
      this.buttonDisable = false;
      this.premiumForm.markAsPristine();
      this.premiumForm.markAsUntouched();
      this.deletePremiumID = deletePremiumId;
    }
  }

  deletePremium() {
    if (this.buttonDisable == false) {
      this._productService.deletePremium(this.deletePremiumID, this.userId).subscribe(res => {
        this.preminumSearch();
      }, err => {
        console.log(err);
      })
    }
  }

  valueValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {

      if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)

        event.preventDefault();
      }


    }
  }

}




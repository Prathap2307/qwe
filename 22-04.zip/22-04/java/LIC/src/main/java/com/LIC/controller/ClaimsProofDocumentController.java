package com.LIC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.LIC.dao.ClaimsProofDocumentDAO;
import com.LIC.model.ClaimsProofDocumentModel;


@RestController
public class ClaimsProofDocumentController {


@Autowired

private ClaimsProofDocumentDAO claimsProofDocumentDAO;

@PostMapping("/createClaimsProofDocument")
public int createClaimsProofDocument(@RequestBody ClaimsProofDocumentModel model) {
	return claimsProofDocumentDAO.createClaimsProofDocument(model);
}

@PostMapping("/claimCoverageMap")
public int createClaimCoverageMap(@RequestBody ClaimsProofDocumentModel model) {
	return claimsProofDocumentDAO.createClaimCoverageMap(model);
}

@PostMapping("/claimsMandatoryDocumentMap")
public int createclaimsMandatoryDocumentMap(@RequestBody ClaimsProofDocumentModel model) {
	return claimsProofDocumentDAO.createclaimsMandatoryDocumentMap(model);
}

@PostMapping("/claimsSettlementPaymentDetails")
public int createclaimsSettlementPaymentDetails(@RequestBody ClaimsProofDocumentModel model) {
	return claimsProofDocumentDAO.createclaimsSettlementPaymentDetails(model);
}


}

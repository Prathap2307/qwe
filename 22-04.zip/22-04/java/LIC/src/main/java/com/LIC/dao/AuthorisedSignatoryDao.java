package com.LIC.dao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.LIC.model.AuthorisedSignatoryModal;
import com.LIC.model.ModuleModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class AuthorisedSignatoryDao {

	@Autowired	JdbcTemplate jdbcTemplate;
		
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryDao.class);
	
	public void InsertOrUpdateAuthorisedSignatory(AuthorisedSignatoryModal authorisedSignatory) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null; 
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spInsertOrUpdateAuthorisedSignatory(?,?,?,?,?,?,?,?,?,?)");
			
			cstm.setLong(1, 	authorisedSignatory.getAuthorisedSignatoryID());
			cstm.setLong(2, 	authorisedSignatory.getModuleID());
			cstm.setString(3, 	authorisedSignatory.getName());
			cstm.setString(4, 	authorisedSignatory.getDesignation());
			cstm.setString(5, 	authorisedSignatory.getEmail());
			cstm.setString(6, 	authorisedSignatory.getContactMobileNo());
			cstm.setString(7, 	authorisedSignatory.getSignature());
			cstm.setLong(8, 	authorisedSignatory.getCreatedBy());
			//cstm.setBlob(9, 	authorisedSignatory.getImgSignature());
			cstm.setString(9, 	authorisedSignatory.getSignature());
			cstm.setShort(10, 	authorisedSignatory.getIsActive());
			cstm.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
	}
	
	public List<AuthorisedSignatoryModal> GetAllAuthorisedSignatory(AuthorisedSignatoryModal modal) throws Exception
	{
		CallableStatement				cstm					= null;
		Connection 						conn 					= null;
		ResultSet 						result 					= null;
		AuthorisedSignatoryModal 		authorisedSignatory		= null;
		List<AuthorisedSignatoryModal>	authorisedSignatoryList = null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllAuthorisedSignatory(?,?,?)");
			cstm.setLong(1, modal.getAuthorisedSignatoryID());
			cstm.setString(2, modal.getName());
			cstm.registerOutParameter(3, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);
			
			if(result != null) {
				authorisedSignatoryList	= new ArrayList<AuthorisedSignatoryModal>();
				
				while(result.next()) {
					
					authorisedSignatory = new AuthorisedSignatoryModal();
					authorisedSignatory.setAuthorisedSignatoryID(result.getLong("AuthorisedSignatoryID"));
					authorisedSignatory.setModuleName(result.getString("ModuleName"));
					authorisedSignatory.setName(result.getString("Name"));
					authorisedSignatory.setDesignation(result.getString("Designation"));
					authorisedSignatory.setEmail(result.getString("Email"));
					authorisedSignatory.setContactMobileNo(result.getString("ContactMobileNo"));
					authorisedSignatory.setSignature(result.getString("Signature"));
					authorisedSignatory.setIsActive(result.getShort("IsActive"));
					authorisedSignatory.setModuleID(result.getShort("ModuleID"));
					authorisedSignatoryList.add(authorisedSignatory);
				}
			}
			return authorisedSignatoryList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return authorisedSignatoryList;
	}
	
	public String IsAuthorisedSignatoryExist(AuthorisedSignatoryModal authSignModal) throws Exception {
		CallableStatement				cstm				= null;
		Connection 						conn 				= null;
		ResultSet 						result 				= null;
		String							description			= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spIsAuthorisedSignatoryExist(?,?,?,?,?)");
			
			cstm.setLong(1, 	authSignModal.getAuthorisedSignatoryID());
			cstm.setString(2, 	authSignModal.getName());
			cstm.setString(3, 	authSignModal.getDesignation());
			cstm.setLong(4, 	authSignModal.getModuleID());
			cstm.registerOutParameter(5, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(5);
			
			if(result != null) {
				
				while(result.next()) {
					description	= result.getString("Description");
				}
			}
			return description;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		
		return null;
	}
	
	public String DeleteAuthorisedSignatory(AuthorisedSignatoryModal modal) throws Exception {
		String 					strResult 			= null;
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteAuthorisedSignatory(?,?,?,?) ");	
			
			cstm.setLong(1, 	modal.getAuthorisedSignatoryID());
			cstm.setLong(2, 	modal.getCreatedBy());
			cstm.setTimestamp(3, modal.getCreatedOn());
			cstm.registerOutParameter(4, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(4);
			
			if(result != null) {
				if(result.next()) {
					return result.getString("DeletedStatus");
				}
			}
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return strResult;
		
	}
	
	public List<AuthorisedSignatoryModal> GetAllAuthorisedSignatories() throws Exception {
		CallableStatement				cstm				= null;
		Connection 						conn 				= null;
		ResultSet 						result 				= null;
		AuthorisedSignatoryModal 		authSignModal		= null;
		List<AuthorisedSignatoryModal>	authSignModalList 	= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllAuthorisedSignatories(?) ");
			
			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
            
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				authSignModalList	= new ArrayList<AuthorisedSignatoryModal>();
				while(result.next()) {
					authSignModal = new AuthorisedSignatoryModal();
					authSignModal.setAuthorisedSignatoryID(result.getLong("ID"));
					authSignModal.setName(result.getString("Description"));
					authSignModalList.add(authSignModal);
				}
			}
			return authSignModalList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return authSignModalList;
	}
	
	public List<ModuleModal> GetAllModules() throws Exception {
		CallableStatement				cstm				= null;
		Connection 						conn 				= null;
		ResultSet 						result 				= null;
		ModuleModal 					moduleModal			= null;
		List<ModuleModal>				moduleModalList 	= null;
	
		try {
		     conn   		= ResourceManager.getConnection();
			 cstm 			= conn.prepareCall("call spGetAllModules(?)");
			 cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			 cstm.execute();
			 
             result 		= ((OracleCallableStatement)cstm).getCursor(1);
             
             if(result != null) {
 				
            	 moduleModalList	= new ArrayList<ModuleModal>();
 				 
            	 while(result.next()) {
            		 moduleModal = new ModuleModal();
            		 moduleModal.setModuleId(result.getLong("ID"));
            		 moduleModal.setDescription(result.getString("Description"));
            		 moduleModalList.add(moduleModal);
 				}
 			}
 			return moduleModalList;
	 } catch(Exception e)  {
		    e.printStackTrace();
			logger.error(e.getMessage(), e);	
	 } finally  {
		 cstm.close();
	     cstm = null;
		 ResourceManager.freeConnection(conn);
		 conn	= null; 
	 }
	 return null;
	}
}

package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.AnnualIncome;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;


@Repository
public class AnnualIncomeDAO implements IAnnualIncomeDAO {
	
	static final Logger LOGGER = LogManager.getLogger(AnnualIncomeDAO.class);
	
	@Autowired
	private JDBCConnection jdbcConnection;
	 
	@Override
	public void saveOrUpdate(AnnualIncome obj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spInsertOrUpdateAnnualIncome(?,?,?,?,?,?); END;");
		  callableStatement.setInt(1, obj.getAnnualIncomeID());
		  callableStatement.setString(2, obj.getShortDescription());
		  callableStatement.setString(3, obj.getDescription());
		  callableStatement.setInt(4, obj.getCreatedBy());
		  callableStatement.setString(5, obj.getRemarks());
		  callableStatement.registerOutParameter(6, OracleTypes.CURSOR); 
		  //callableStatement.registerOutParameter(3, Types.VARCHAR);
		  callableStatement.executeUpdate();
		  System.out.println("SP>spInsertOrUpdateAnnualIncome executed successfully.");
		  LOGGER.info("SP>spInsertOrUpdateAnnualIncome executed successfully.");
	}
	
	@Override
	public void delete(Integer annualIncomeID, Integer deleteBy) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  CallableStatement callableStatement = connection.prepareCall("BEGIN spDeleteAnnualIncome(?,?,?); END;");
		  callableStatement.setInt(1, annualIncomeID);
		  callableStatement.setInt(2, deleteBy); 
		  callableStatement.registerOutParameter(3, Types.VARCHAR); 
		  callableStatement.executeUpdate();
		  System.out.println("SP>spDeleteAnnualIncome executed successfully.");
		  LOGGER.info("SP>spDeleteAnnualIncome executed successfully.");
	} 
	
	@Override
	public List<AnnualIncome> getAll(AnnualIncome filterObj) throws SQLException {
		  Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  List<AnnualIncome> list = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAllAnnualIncome(?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.registerOutParameter(1, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(1);
			  AnnualIncome obj = null;
			  list = new ArrayList<AnnualIncome>();
		      while (rs.next()) {
		        obj = new AnnualIncome();
		        obj.setAnnualIncomeID(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		        list.add(obj);
		      }
			  System.out.println("SP>spGetAllAnnualIncome executed successfully.");
			  LOGGER.info("SP>spGetAllAnnualIncome executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllAnnualIncome exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  }
			   
		  }
		  return list;
	} 
	 
	
	@Override
	public AnnualIncome get(Integer annualIncomeID) throws SQLException {
		Connection connection = jdbcConnection.getConnection();
		  ResultSet rs = null;
		  CallableStatement callableStatement = null;
		  AnnualIncome obj = null;
		  try {
			  callableStatement = connection.prepareCall("BEGIN spGetAnnualIncome(?,?); END;");
			  callableStatement = callableStatement.unwrap(CallableStatement.class);
			  callableStatement.setInt(1, annualIncomeID);
			  callableStatement.registerOutParameter(2, OracleTypes.CURSOR); 
			  callableStatement.execute();
			  rs = ((OracleCallableStatement)callableStatement).getCursor(2);
		      while (rs.next()) {
		        obj = new AnnualIncome();
		        obj.setAnnualIncomeID(rs.getInt("ID"));
		        obj.setDescription(rs.getString("DESCRIPTION"));
		        obj.setShortDescription(rs.getString("SHORTDESCRIPTION"));
		      }
			  System.out.println("SP>spGetAllAnnualIncome executed successfully.");
			  LOGGER.info("SP>spGetAllAnnualIncome executed successfully.");
		  }catch (Exception e) {
			  LOGGER.error("SP>spGetAllAnnualIncome exception occured."+e.getMessage());
			  e.printStackTrace();
		  }finally {
			  if(null != rs && !rs.isClosed()) {
				  rs.close();
			  }
			  if(null != callableStatement && !callableStatement.isClosed()) {
				  callableStatement.close();
			  } 
		  }
		  return obj;
	} 
	 
}

package com.LIC.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.BankBranchModel;
import com.LIC.model.GetBankBranch;
import com.LIC.model.GetGlConfigurationModel;

@Repository	
public class BankBranchDAO {

	
	@Autowired
	private EntityManager em;
	
	/*
	
public List<GetBankBranch>GetAllBankBranchSearch(Number branchId,Number bankId,Number bankCityId,String description,String ifscCode,String micrCode) {
       StoredProcedureQuery query = em               .createStoredProcedureQuery("spGetAllBankBranch")
               .registerStoredProcedureParameter("vBranchID",Long.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vBankID", Long.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vBankCityId",Long.class, ParameterMode.IN)
              .registerStoredProcedureParameter("vDescription", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("vIFSCCode",String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("vMICRCode", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("oBB", Class.class, ParameterMode.REF_CURSOR)
                        .setParameter("vBranchID",branchId)
                      .setParameter("vBankID",bankId)
      .setParameter("vBankCityId",bankCityId)
       .setParameter("vDescription",description)
       .setParameter("vIFSCCode",ifscCode)
        .setParameter("vMICRCode",micrCode);
       
       // return query.execute() ? query.getResultList() : null;
      
       
      query.execute();
      List<Object[]> list  =  (List<Object[]>)query.getResultList();
       List<GetBankBranch> accList = list.stream().map(
      		  o -> new GetBankBranch((Number) o[0],(Number) o[1],(Number) o[2],(String) o[3], (String) o[4],(String) o[5])).collect(Collectors.toList());
       
     return accList;
      
        
      }

	*/

	
	
	
	
	public List<GetBankBranch>GetAllBankBranchBankbyBankId() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllBankID")
               .registerStoredProcedureParameter("oBANK", Class.class, ParameterMode.REF_CURSOR);

        
         // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetBankBranch> accList = list.stream().map(
        		  o -> new GetBankBranch((Number) o[0], (String) o[1])).collect(Collectors.toList());
        
       return accList;
       
         
       }
	public List<GetBankBranch>GetAllBankBranchBankbyCityId(Number bankId) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllBankbyBankCityID")
               .registerStoredProcedureParameter("vBankID",Long.class, ParameterMode.IN)
               .registerStoredProcedureParameter("RESULT1", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vBankID",bankId);

        
         // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetBankBranch> accList = list.stream().map(
        		  o -> new GetBankBranch((Number) o[0],(String) o[1],(Number) o[2])).collect(Collectors.toList());
        
       return accList;
       
       
         
       }
	
	
	
	
	public List<GetBankBranch>GetAllBankBranchInfo() {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("GetAllBankBranch")
               .registerStoredProcedureParameter("obank", Class.class, ParameterMode.REF_CURSOR);
                         
        
         // return query.execute() ? query.getResultList() : null;
      
        
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetBankBranch> accList = list.stream().map(
                          o -> new GetBankBranch((Number) o[0],(Number) o[1],(String) o[2],(Number) o[3], (String) o[4],(String) o[5], (String) o[6], (String) o[7], (Number) o[8], (String) o[9])).collect(Collectors.toList());
                          
        
       return accList;
       
      
       }

	
	
	

@SuppressWarnings("unchecked")
	
	public List<GetBankBranch>GetAllBankBranchSearch(GetBankBranch model) {
        StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllBankBranch")
		        .registerStoredProcedureParameter("vBranchID",Integer.class, ParameterMode.IN)
		        .registerStoredProcedureParameter("vBankID",Integer.class, ParameterMode.IN)
		        .registerStoredProcedureParameter("vBankCityId",Integer.class, ParameterMode.IN)
		        .registerStoredProcedureParameter("vDescription",String.class, ParameterMode.IN)
		        .registerStoredProcedureParameter("vIFSCCode",String.class, ParameterMode.IN)
		        .registerStoredProcedureParameter("vMICRCode",String.class, ParameterMode.IN)
        		.registerStoredProcedureParameter("oBB",Class.class, ParameterMode.REF_CURSOR);
        	   query.setParameter("vBranchID", model.getBranchId());
               query.setParameter("vBankID", model.getBankId());
               query.setParameter("vBankCityId",model.getBankCityId());
               query.setParameter("vDescription", model.getDescription());
               query.setParameter("vIFSCCode",model.getIfscCode());
               query.setParameter("vMICRCode",model.getMicrCode());
               query.getParameter("oBB");
        query.execute();
        List<Object[]> list  =  (List<Object[]>)query.getResultList();
        List<GetBankBranch> bankBrankList = list.stream().map(
        		
        		  o -> new GetBankBranch((Number) o[0],(Number) o[1],(Number) o[2],(String) o[3],(String) o[4],(String) o[5],(String) o[6],(String) o[7],(String) o[8],(Number) o[9],(String) o[10])).collect(Collectors.toList());
        
               return bankBrankList;
       
         
       }  
	
@SuppressWarnings("unchecked")
public void createBankBranchInfo(BankBranchModel model) {

	StoredProcedureQuery addDepStoredProcedure = em.createNamedStoredProcedureQuery("createOrUpdateBankBranch");
	addDepStoredProcedure.setParameter("vBranchID", model.getBranchId());
	addDepStoredProcedure.setParameter("vBankID", model.getBankId());
	addDepStoredProcedure.setParameter("vBankCityId", model.getBankCityId());
	addDepStoredProcedure.setParameter("vDescription", model.getDescription());
	addDepStoredProcedure.setParameter("vIFSCCode", model.getIfscCode());
	addDepStoredProcedure.setParameter("vMICRCode", model.getMicrCode());
	addDepStoredProcedure.setParameter("vCreatedBy", model.getCreatedBy());
	addDepStoredProcedure.setParameter("vCreatedOn",model.getCreatedOn() );
	addDepStoredProcedure.execute();
	

}






public void deleteBankBranch(BankBranchModel model) {

	StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteBankBranch");
	query.setParameter("vBranchID",model.getBranchId());
	
	query.setParameter("vDeletedBy",model.getDeletedBy());
	query.setParameter("vDeletedOn",model.getDeletedOn());
	//query.getParameter("RESULT1");
    query.execute();
}


	
}

package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.DepartmentDAO;

import com.LIC.model.DepartmentModel;
import com.LIC.model.GetBankBranch;
import com.LIC.model.GetBankMasterModel;
import com.LIC.model.GetDepartmentModel;

@RestController
public class DepartmentController {


	@Autowired

	private DepartmentDAO dep;
	
	
	

	@GetMapping(value="/department", produces= {"application/json"})
	public List<GetDepartmentModel> getDepartment() {
		return	dep.getAllDepartmentInfo();
	}

	@PostMapping("/createDepartment")
	public void postDepartment(@RequestBody DepartmentModel model) {
		dep.createDepartmentInfo(model);

	}
	

	@RequestMapping(method = RequestMethod.PUT, value = "/deleteDepartment")
	public void deleteDepartment(@RequestBody DepartmentModel model) {

		dep.deleteDepartment(model);
	}
	
	
	
	@GetMapping(path="/department/{departmentId}/{description}")
	public List<GetDepartmentModel> GetDepartmentByDepartMentNames(@PathVariable Long departmentId,@PathVariable String description) {
		return dep.GetDepartmentByDepartMentName(departmentId,description);
	}
	
	
	
	
}

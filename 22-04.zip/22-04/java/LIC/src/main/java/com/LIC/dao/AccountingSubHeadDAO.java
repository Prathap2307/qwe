package com.LIC.dao;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.AccountingSubHeadModel;

@RestController
@SuppressWarnings("unchecked") 
public class AccountingSubHeadDAO {
	@Autowired
	private EntityManager em;
	
	// Account Head
	public List<AccountingSubHeadModel> GetAllAccountingHead() {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAccountHead")
               .registerStoredProcedureParameter("oAH", Class.class, ParameterMode.REF_CURSOR);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<AccountingSubHeadModel> FList = list.stream().map(
             o -> new AccountingSubHeadModel((Number) o[0], (String) o[1]  ,(String) o[2])).collect(Collectors.toList());
	  	 
    	return FList;
	}
	
	
	// Accounting Group
	public List<AccountingSubHeadModel> GetAllSubAccountHeadbyAccountHead(int AccountHeadID) {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllSubAccountDropdown")
               .registerStoredProcedureParameter("vAccountHeadID", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("pResult", Class.class, ParameterMode.REF_CURSOR)
               .setParameter("vAccountHeadID", AccountHeadID);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<AccountingSubHeadModel> FList = list.stream().map(
             o -> new AccountingSubHeadModel((Number) o[0], (String) o[1]  ,(String) o[2],"")).collect(Collectors.toList());
	  	 
    	return FList;
	}
		
	//Create Sub Account Head
	public int CreateSubAccountHead(AccountingSubHeadModel SubAccmodel) {
    	 StoredProcedureQuery query = em
                .createStoredProcedureQuery("InsertorUpdateSubAccountHead")
                .registerStoredProcedureParameter("vSubAccountHeadID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("vAccountHeadID", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("vCode", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("vSubAccountName", String.class, ParameterMode.IN)
                .registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
                .registerStoredProcedureParameter("visactive", Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter("pResult", Integer.class, ParameterMode.OUT)
                .setParameter("vSubAccountHeadID", SubAccmodel.getSubAccountHeadId())
                .setParameter("vAccountHeadID", SubAccmodel.getAccountHeadId())
                .setParameter("vCode", SubAccmodel.getSubAccountHeadCode())
                .setParameter("vSubAccountName", SubAccmodel.getSubAccountHeadName())
                .setParameter("vCreatedBy", SubAccmodel.getCreatedBy())
                .setParameter("vCreatedOn", SubAccmodel.getCreatedOn())
                .setParameter("visactive", SubAccmodel.getIsactive());
    	query.execute();
    	 return (int)query.getOutputParameterValue("pResult");
    	
	}
	
	
	// Accounting Group
	public List<AccountingSubHeadModel> GetAllSubAccountHeads(int Id,int AccountHeadID,int Code,int Description) {
   	 StoredProcedureQuery query = em
               .createStoredProcedureQuery("spGetAllSubAccountName")
               .registerStoredProcedureParameter("vID", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vAccountHeadID", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vCode", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("vDescription", Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("pResult", Class.class, ParameterMode.REF_CURSOR)
               .setParameter("vID", Id)
		   	   .setParameter("vAccountHeadID", AccountHeadID)
		   	   .setParameter("vCode", Code)
		   	   .setParameter("vDescription", Description);
   	 query.execute();
   	 List<Object[]> list  =  (List<Object[]>)query.getResultList();
	 List<AccountingSubHeadModel> FList = list.stream().map(
             o -> new AccountingSubHeadModel((Number) o[0], (String) o[1]  ,(String) o[2],(Number) o[3],(Number) o[4],(String) o[5] )).collect(Collectors.toList());
	  	 
    	return FList;
	}
		
	
	
	
}

package com.LIC.dao;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.LIC.model.ClaimsSettlementModel;
import com.LIC.model.SaveClaimsSettlementModel;
import com.LIC.model.SearchClaimsSettlementModel;

@Repository
@SuppressWarnings("unchecked")
public class ClaimsSettlementDao {

	@Autowired
	private EntityManager em;

	public List<SearchClaimsSettlementModel> getAllClaimsForSettlement(String pClaimID, String pPolicyNumber,
			String pFirstName, String pLastName, String pAgentCode, String pServiceBranch) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllClaimsForSettlement")

				.registerStoredProcedureParameter("pClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPolicyNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pFirstName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pLastName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pAgentCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pServiceBranch", String.class, ParameterMode.IN)

				.registerStoredProcedureParameter("oCur1", Class.class, ParameterMode.REF_CURSOR)
		
		    .setParameter("pClaimID", pClaimID)
		    .setParameter("pPolicyNumber", pPolicyNumber)
		   .setParameter("pFirstName", pFirstName)
		   .setParameter("pLastName", pLastName)
		   .setParameter("pAgentCode", pAgentCode) 
		   .setParameter("pServiceBranch", pServiceBranch);
		 

		query.execute();

		
		
		
		
		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<SearchClaimsSettlementModel> getAllClaimsForSettlementList = list.stream()
				.map(o -> new SearchClaimsSettlementModel((Number) o[0], (Number) o[1], (Number) o[2], (String) o[3],
						(String) o[4], (Number) o[5],(Number) o[6], (Date) o[7],(Number) o[8], (String) o[9],(String) o[10], (String) o[11],(String) o[12], (String) o[13],(Number) o[14], (String) o[15],(Date) o[16], (String) o[17])) 
				.collect(Collectors.toList());

		return getAllClaimsForSettlementList;
		
	
	
	}
	
	public void insertClaimsSettlement(SaveClaimsSettlementModel saveClaimsSettlementModel) {
		StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spInsertClaimsSettlement")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pStatusID", Integer.class, ParameterMode.IN)

				.setParameter("pClaimID", saveClaimsSettlementModel.getpClaimID())
				.setParameter("pCreatedBy", saveClaimsSettlementModel.getpCreatedBy())
				.setParameter("pCreatedOn", saveClaimsSettlementModel.getpCreatedOn())
				.setParameter("pStatusID", saveClaimsSettlementModel.getpStatusID());

		storedProcedureQuery.execute();

	}

	public void deleteClaimsSettlementPaymentDetails(int pClaimID) {
		StoredProcedureQuery storedProcedureQuery = em
				.createStoredProcedureQuery("spDeleteClaimsSettlementPaymentDetails")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.setParameter("pClaimID", pClaimID);

		storedProcedureQuery.execute();
	}

	public int insertClaimsSettlementPayment(ClaimsSettlementModel claimsSettlementModel) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spInsertClaimsSettlementPaymentDetails")
				.registerStoredProcedureParameter("vClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vSerialNo", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPaymentModeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vPaymentDate", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vBankID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vBankBranchID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vChequeNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vChequeDate", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCardTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCardNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCardExpiryDate", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCardExpiryMonth", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCardExpiryYear", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vAmount", BigDecimal.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vBankBranchName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vBankName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vDescription", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vISFCCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vCreatedOn", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("vResult", Integer.class, ParameterMode.OUT)

				.setParameter("vClaimID", claimsSettlementModel.getvClaimID())
				.setParameter("vSerialNo", claimsSettlementModel.getvSerialNo())
				.setParameter("vPaymentModeID", claimsSettlementModel.getvPaymentModeID())
				.setParameter("vPaymentDate", claimsSettlementModel.getvPaymentDate())
				.setParameter("vBankID", claimsSettlementModel.getvBankID())
				.setParameter("vBankBranchID", claimsSettlementModel.getvBankBranchID())
				.setParameter("vChequeNo", claimsSettlementModel.getvChequeNo())
				.setParameter("vChequeDate", claimsSettlementModel.getvChequeDate())
				.setParameter("vCardTypeID", claimsSettlementModel.getvCardTypeID())
				.setParameter("vCardNo", claimsSettlementModel.getvCardNo())
				.setParameter("vCardExpiryDate", claimsSettlementModel.getvCardExpiryDate())
				.setParameter("vCardExpiryMonth", claimsSettlementModel.getvCardExpiryMonth())
				.setParameter("vCardExpiryYear", claimsSettlementModel.getvCardExpiryYear())
				.setParameter("vAmount", claimsSettlementModel.getvAmount())
				.setParameter("vBankBranchName", claimsSettlementModel.getvBankBranchName())
				.setParameter("vBankName", claimsSettlementModel.getvBankName())
				.setParameter("vDescription", claimsSettlementModel.getvDescription())
				.setParameter("vISFCCode", claimsSettlementModel.getvISFCCode())
				.setParameter("vCreatedBy", claimsSettlementModel.getvCreatedBy())
				.setParameter("vCreatedOn", claimsSettlementModel.getvCreatedOn());

		query.execute();
		return (int) query.getOutputParameterValue("vResult");
	}

	public List<SaveClaimsSettlementModel> getClaimNumberByClaimID(int pClaimID) {
		StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spGetClaimNumberByClaimID")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pClaimID", pClaimID);

		storedProcedureQuery.execute();
		List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();
		List<SaveClaimsSettlementModel> getClaimNumberList = list.stream()
				.map(o -> new SaveClaimsSettlementModel((int) o[0])).collect(Collectors.toList());

		return getClaimNumberList;
	}
	
	public List<ClaimsSettlementModel>getBeneficiary(int claimId) {
        StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spGetAllBeneficiaryByClaimID")
               .registerStoredProcedureParameter("vClaimID",Integer.class, ParameterMode.IN)
               .registerStoredProcedureParameter("oClaimsBeneficiary", Class.class, ParameterMode.REF_CURSOR)
                         .setParameter("vClaimID",claimId);
         //return query.execute() ? query.getResultList() : null;
        storedProcedureQuery.execute();
        List<Object[]> list  =  (List<Object[]>)storedProcedureQuery.getResultList();
        List<ClaimsSettlementModel> beneficiaryList = list.stream().map(
                       o -> new ClaimsSettlementModel((Number) o[0],(String) o[1])).collect(Collectors.toList());
       return beneficiaryList;         
       }


}
	
	
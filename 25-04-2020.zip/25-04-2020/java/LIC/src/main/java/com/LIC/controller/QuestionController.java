package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.QuestionDAO;
import com.LIC.model.GetProductModel;
import com.LIC.model.GetQuestionModel;
import com.LIC.model.QuestionMapModel;
import com.LIC.model.QuestionModel;

@RestController
public class QuestionController {
	@Autowired
	private QuestionDAO ques;
	
	
	
	@PostMapping("/createQuestion")
	public void postQuestion(@RequestBody QuestionModel model) {
		ques.createQuestionInfo(model);

	}
	
	/*@PostMapping("/createQuestionMap")
	public void postQuestionMap(@RequestBody QuestionMapModel model) {
		ques.createQuestionMapInfo(model);

	}*/
    @GetMapping( value="/getQuestions")
    public List<GetQuestionModel> GetAllQuestions() {
                        return	ques.GetAll();
}


	
	
	@GetMapping(path="/Questions/{questionId}/{description}")
	public List<GetQuestionModel> GetAllQuestionNames(@PathVariable Long questionId,@PathVariable String description) {
		return ques.GetAllQuestions(questionId,description);
	}
	
	
	
	@GetMapping(path="/QuestionExist/{questionId}/{description}/{lob}/{shortDescription}")
	public List<GetQuestionModel>QuestionIsExistOrNot(@PathVariable Long questionId,@PathVariable String description,@PathVariable Long lob,@PathVariable String shortDescription) {
		return ques.QuestionExistOrNot(questionId,description,lob,shortDescription);
	}
	

	
	
	
	
	
	@GetMapping(path="/Question/{questionId}/{lob}/{orderId}")
	public List<GetQuestionModel> GetAllQuestionNamesByOrderId(@PathVariable Long questionId,@PathVariable Long lob,@PathVariable Long orderId) {
		return ques.GetAllQuestionsByOrderId(questionId,lob,orderId);
	}
	
	
	

    @RequestMapping(method = RequestMethod.PUT, value = "/deleteQuestion")
    public void deleteAllQuestions(@RequestBody QuestionModel model) {

    	ques.deleteQuestions(model);
   }
    
    

   /* @RequestMapping(method = RequestMethod.DELETE, value = "/deleteQuestionMap")
    public void deleteAllQuestionsMap(@RequestBody QuestionMapModel model) {

    	ques.deleteQuestionsMap(model);
   }*/

}

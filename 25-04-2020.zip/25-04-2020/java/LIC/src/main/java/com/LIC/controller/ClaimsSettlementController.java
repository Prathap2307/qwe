package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsSettlementDao;
import com.LIC.model.ClaimsSettlementInsertModel;
import com.LIC.model.ClaimsSettlementModel;
import com.LIC.model.GetSettlementPaymentDetails;
import com.LIC.model.SaveClaimsSettlementModel;
import com.LIC.model.SearchClaimsSettlementModel;

@RestController
public class ClaimsSettlementController {

	@Autowired
	private ClaimsSettlementDao claimsSettlementDao;
	
	
	
	@GetMapping("/getAllClaimsSettlement")
	public List<SearchClaimsSettlementModel> getAllClaims() {
		return claimsSettlementDao.getAllClaimsSettlement();
	}


	
	@PostMapping("/getAllClaimsForSettlement")
	public List<SearchClaimsSettlementModel> getAllClaimsForSettlement(@RequestBody SearchClaimsSettlementModel  model) {
		return claimsSettlementDao.getAllClaimsForSettlement(model);
	}
	
	@RequestMapping(path = "/insertClaimsSettlement", method = RequestMethod.POST)
    public String insertClaimsSettlement(@RequestBody ClaimsSettlementInsertModel claimsSettlementModel) {
           return claimsSettlementDao.insertClaimsSettlement(claimsSettlementModel);
    }

	
	
	
	@RequestMapping(value = "/deleteClaimsSettlementPaymentDetails/{pClaimID}", method = RequestMethod.DELETE)
	public void deleteClaimsSettlementPaymentDetails(@PathVariable int pClaimID) {
		claimsSettlementDao.deleteClaimsSettlementPaymentDetails(pClaimID);
	}
	
	@RequestMapping(path = "/insertClaimsSettlementPayment", method = RequestMethod.POST)
	public void insertClaimsSettlementPayment(@RequestBody ClaimsSettlementInsertModel claimsSettlementModel) {
		 claimsSettlementDao.insertClaimsSettlementPayment(claimsSettlementModel);
	}
	
	
	@GetMapping("/getClaimsSettlementPayment")
	public List<GetSettlementPaymentDetails> ClaimsSettlementPayment() {
		return claimsSettlementDao.getAllClaimsSettlementPayment();
	}
	
	
	
	
	
	
	@RequestMapping(value = "/getClaimNumberByClaimID/{pClaimID}", method = RequestMethod.GET)
	public List<SaveClaimsSettlementModel> getClaimNumberByClaimID(@PathVariable int pClaimID) {
		return claimsSettlementDao.getClaimNumberByClaimID(pClaimID);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/beneficiary/{claimId}")
    public List<ClaimsSettlementModel> getAllBeneficiaryDetails(@PathVariable int claimId) {
                return     claimsSettlementDao.getBeneficiary(claimId);
	}
}
	
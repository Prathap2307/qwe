package com.LIC.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.LIC.PdfGenerator.DefectDataExcelFileExporter;
import com.LIC.dao.DefectDataDAO;
//import com.LIC.entity.DefectDataModel;
import com.LIC.model.GetGNBUploadHeader;
@RequestMapping("/lic")
@RestController
public class DefectDataController {
	
	@Autowired
		private DefectDataDAO dao;


	/*@GetMapping("/download/Excel")
	public ResponseEntity<InputStreamResource>AllApprovedApplicationsByApplicationID(@RequestBody DefectDataModel model  ) throws IOException {

	List<DefectDataModel> defectData = (List<DefectDataModel>) dao.GetGNBDataUpload(model);

	ByteArrayInputStream bis =DefectDataExcelFileExporter.exportDefectDataListToExcelFile(defectData);

	HttpHeaders headers = new HttpHeaders();
	headers.add("Content-Disposition", "attachment; filename=defectData.xlsx");

	return ResponseEntity
	   .ok()
	   .headers(headers)
	   .contentType(MediaType.APPLICATION_PDF)
	   .body(new InputStreamResource(bis));
	
	}*/

	
	@RequestMapping(value = "/GetallDefectData", method = RequestMethod.GET)
	public List<GetGNBUploadHeader> DefectDataGrid(@RequestBody GetGNBUploadHeader model) {

		return dao.getGNBuploadHeader(model);
	}
	
	
}

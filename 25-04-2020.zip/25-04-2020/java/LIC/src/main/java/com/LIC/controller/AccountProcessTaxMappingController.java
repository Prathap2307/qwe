package com.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.AccountProcessTaxMappingDAO;
import com.LIC.model.AccountingTaxProcessMapModel;
import com.LIC.model.GetAllAccountProcessTaxMapModeModel;
import com.LIC.model.GetAllAccountingTaxMapBasedOn;
import com.LIC.model.GetAllAccountingTaxProcessModel;
import com.LIC.model.GetProcessTaxMapRowNumberModel;



@RestController
public class AccountProcessTaxMappingController {
@Autowired
private AccountProcessTaxMappingDAO accClass;


//Get All Based on
@GetMapping ("/GetAllAccountingTaxMapBasedOn")
public List<GetAllAccountingTaxMapBasedOn> GetAllAccountingTaxMapBasedOn() {
	return accClass.GetAllAccountingTaxMapBasedOn();
}

//Get All Based on
	@GetMapping ("/GetAllAccountProcessTaxMapMode")
	public List<GetAllAccountProcessTaxMapModeModel> GetAllAccountProcessTaxMapMode() {
		return accClass.GetAllAccountProcessTaxMapMode();
	}
	
//Generate Row Numbers
@GetMapping ("/GetAllRowNumbers")
public List<GetProcessTaxMapRowNumberModel> GenerateRowNumber() {
	return accClass.GenerateRowNumber();
}

	//Get Tax Process
	@GetMapping ("/GetAllTaxProcess")
	public List<GetAllAccountingTaxProcessModel> GetAllTaxProcess()
	{
		return accClass.GetAllTaxProcess();
	}

	//Create tax Process map
	@PostMapping("/CreateProcessTaxMap")
	public int CreateTaxProcessMapping(@RequestBody  List<AccountingTaxProcessMapModel> TaxStructureInfo) {
		return accClass.CreateTaxProcessMapping( TaxStructureInfo);

	}
	
	//Get Tax Process
	@PostMapping ("/GetAllTaxStructureBasedonTaxName")
	public List<AccountingTaxProcessMapModel> GetAllTaxStructureBasedonTaxName(@RequestBody AccountingTaxProcessMapModel MDLTaxStructureName)
	{
		return accClass.GetAllTaxStructureBasedonTaxName(MDLTaxStructureName);
	}
	
	//Get Tax Process Details By ID
	@GetMapping ("/TaxProcessDetailsByID/{TaxStructureID}")
	public List<AccountingTaxProcessMapModel> TaxProcessDetailsByID(@PathVariable int TaxStructureID) 
	{
		return accClass.TaxProcessDetailsByID(TaxStructureID);
	}

}

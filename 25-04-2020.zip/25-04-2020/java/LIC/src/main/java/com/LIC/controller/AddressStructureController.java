package com.LIC.controller;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.AddressStructureDAO;
import com.LIC.model.AddressStructureModel;
import com.LIC.model.DistrictModal;
import com.LIC.model.GetAddressStructure;
import com.LIC.model.Response;
import com.LIC.model.StateModal;
import com.LIC.model.TalukaModal;
import com.LIC.model.TransactionContext;
import com.LIC.service.CountryService;
import com.LIC.service.DistrictService;
import com.LIC.service.RegionService;
import com.LIC.service.StateService;
import com.LIC.service.TalukService;
import com.LIC.utils.dataobject.ValueObject;

@RestController
public class AddressStructureController {
	
	@Autowired
	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(AddressStructureController.class);
	
	public AddressStructureController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	
	@Autowired 	CountryService		countryService;
	@Autowired 	StateService		stateService;
	@Autowired 	DistrictService		districtService;
	@Autowired 	TalukService		talukService;
	@Autowired 	RegionService		regionService;
	@Autowired
	private AddressStructureDAO address;
	

	@GetMapping("/address")
	public List<GetAddressStructure> getAddress() {
		return address.getAllAddressInfo();
	}

	@PostMapping("/createAddress")
	public void postAddress(@RequestBody AddressStructureModel model) {
		address.createAddressStructure(model);

}
	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteAddress")
	public void deleteAdd(@RequestBody AddressStructureModel model) {

		address.deleteAddress(model);
	}

	@RequestMapping(value = "/GetAllCountries", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	 public ResponseEntity<Response> getAllCountries(@RequestHeader HttpHeaders httpHeader) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, countryService.getAllCountries(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	///for REgion
	@RequestMapping(value = "/getAllRegion", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	 public ResponseEntity<Response> getAllRegion(@RequestHeader HttpHeaders httpHeader) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, regionService.getAllRegion(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	//end 
	@RequestMapping(value = "/getAllStateByCountryId", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> getAllStateByCountryId(@RequestHeader HttpHeaders httpHeader,
			@RequestParam HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject			object			= null;
		List<StateModal>	stateModalList	= null;	
		
		try {
			
			object			= new ValueObject(allRequestParams);
			stateModalList	= stateService.getAllStateByCountryId(object.getLong("CountryId"));
			
			return responseGenerator.successResponse(context, stateModalList , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/getAllDistrictsByStaeId", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> getAllDistrictsByStaeId(@RequestHeader HttpHeaders httpHeader,
			@RequestParam HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject			object				= null;
		List<DistrictModal>	districtModalList	= null;	
		
		try {
			
			object				= new ValueObject(allRequestParams);
			districtModalList	= districtService.getAllDistrictByStateId(object.getLong("StateId",0));
			
			return responseGenerator.successResponse(context, districtModalList , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/getAllTaluksByDistrictId", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> getAllTalukasByDistrictId(@RequestHeader HttpHeaders httpHeader,
			@RequestParam HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject			object				= null;
		List<TalukaModal>	talukaModalList		= null;	
		
		try {
			
			object				= new ValueObject(allRequestParams);
			talukaModalList		= talukService.getAllTalukasByDistrictId(object.getLong("DistrictId"));
			
			return responseGenerator.successResponse(context, talukaModalList , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/getAllStateCountry", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> GetAllStateCountry(@RequestHeader HttpHeaders httpHeader) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, stateService.GetAllStateCountry() , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/updateAddressStructure", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> updateAddressStructure(@RequestHeader HttpHeaders httpHeader,@RequestParam long structureId,@RequestParam String description) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, address.updateAddressStructure(structureId,description) , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	
}

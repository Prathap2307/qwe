package com.LIC.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LIC.model.ClaimsSettlementInsertModel;
import com.LIC.model.ClaimsSettlementModel;
import com.LIC.model.GetSettlementPaymentDetails;
import com.LIC.model.SaveClaimsSettlementModel;
import com.LIC.model.SearchClaimsSettlementModel;

@Repository
@SuppressWarnings("unchecked")
public class ClaimsSettlementDao {

	@Autowired
	private EntityManager em;

	public List<SearchClaimsSettlementModel> getAllClaimsSettlement() {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllClaimsForSettlement1")
				.registerStoredProcedureParameter("oCur1", Class.class, ParameterMode.REF_CURSOR);
		query.execute();
		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<SearchClaimsSettlementModel> getAllClaims = list.stream()
				.map(o -> new SearchClaimsSettlementModel((Number) o[0], (Number) o[1], (String) o[2], (String) o[3],
						(String) o[4], (Number) o[5], (Number) o[6], (Date) o[7], (Number) o[8], (String) o[9],
						(String) o[10], (String) o[11], (String) o[12], (String) o[13], (Number) o[14], (String) o[15],
						(Date) o[16], (String) o[17]))
				.collect(Collectors.toList());

		return getAllClaims;

	}

	public List<SearchClaimsSettlementModel> getAllClaimsForSettlement(SearchClaimsSettlementModel model) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetAllClaimsForSettlement")

				.registerStoredProcedureParameter("pClaimID", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPolicyNumber", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pFirstName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pLastName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pAgentCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pServiceBranch", String.class, ParameterMode.IN)

				.registerStoredProcedureParameter("oCur1", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pClaimID", model.getpClaimID()).setParameter("pPolicyNumber", model.getpPolicyNumber())
				.setParameter("pFirstName", model.getpFirstName()).setParameter("pLastName", model.getpLastName())
				.setParameter("pAgentCode", model.getpAgentCode())
				.setParameter("pServiceBranch", model.getpServiceBranch());

		query.execute();

		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<SearchClaimsSettlementModel> getAllClaimsForSettlementList = list.stream()
				.map(o -> new SearchClaimsSettlementModel((Number) o[0], (Number) o[1], (String) o[2], (String) o[3],
						(String) o[4], (Number) o[5], (Number) o[6], (Date) o[7], (Number) o[8], (String) o[9],
						(String) o[10], (String) o[11], (String) o[12], (String) o[13], (Number) o[14], (String) o[15],
						(Date) o[16], (String) o[17]))
				.collect(Collectors.toList());

		return getAllClaimsForSettlementList;

	}

//	public void insertClaimsSettlement(SaveClaimsSettlementModel saveClaimsSettlementModel) {
//		StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spInsertClaimsSettlement")
//				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
//				.registerStoredProcedureParameter("pCreatedBy", Integer.class, ParameterMode.IN)
//				.registerStoredProcedureParameter("pCreatedOn", Date.class, ParameterMode.IN)
//				.registerStoredProcedureParameter("pStatusID", Integer.class, ParameterMode.IN)
//
//				.setParameter("pClaimID", saveClaimsSettlementModel.getpClaimID())
//				.setParameter("pCreatedBy", saveClaimsSettlementModel.getpCreatedBy())
//				.setParameter("pCreatedOn", saveClaimsSettlementModel.getpCreatedOn())
//				.setParameter("pStatusID", saveClaimsSettlementModel.getpStatusID());
//
//		storedProcedureQuery.execute();
//
//	}
	
	
	
	
	
	public String insertClaimsSettlement(ClaimsSettlementInsertModel
	          claimsSettlementModel) { 
	                  StoredProcedureQuery storedProcedureQuery =
	          em.createStoredProcedureQuery("spInsertClaimsSettlement")
	          .registerStoredProcedureParameter("pClaimID", Integer.class,ParameterMode.IN) 
	          .registerStoredProcedureParameter("pCreatedBy",Integer.class, ParameterMode.IN)
	          .registerStoredProcedureParameter("pCreatedOn", Date.class, ParameterMode.IN)
	          .registerStoredProcedureParameter("pStatusID", Integer.class,ParameterMode.IN)
	          .setParameter("pClaimID", claimsSettlementModel.getClaimId())
	          .setParameter("pCreatedBy", claimsSettlementModel.getCreatedBy())
	          .setParameter("pCreatedOn", claimsSettlementModel.getCreatedOn())
	          .setParameter("pStatusID", claimsSettlementModel.getStatusId());
	          storedProcedureQuery.execute();
	          return "updated";
	          }
	
	
	
	
	
	
	
	
	

	public void deleteClaimsSettlementPaymentDetails(int pClaimID) {
		StoredProcedureQuery storedProcedureQuery = em
				.createStoredProcedureQuery("spDeleteClaimsSettlementPaymentDetails")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.setParameter("pClaimID", pClaimID);

		storedProcedureQuery.execute();
	}

	public void insertClaimsSettlementPayment(ClaimsSettlementInsertModel claimsSettlementModel) {
		StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spInsertClaimsSettlementPaymentDetails")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pSerialNo", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPaymentModeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pPaymentDate", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pBankID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pBankBranchID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pChequeNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pChequeDate", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCardTypeID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCardNo", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCardExpiryDate", Date.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCardExpiryMonth", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCardExpiryYear", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pAmount", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pBankBranchName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pBankName", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pDescription", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pISFCCode", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCreatedBy", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pCreatedOn", Date.class, ParameterMode.IN)
				

				.setParameter("pClaimID", claimsSettlementModel.getClaimId())
				.setParameter("pSerialNo", claimsSettlementModel.getSerialNo())
				.setParameter("pPaymentModeID", claimsSettlementModel.getPaymentModeId())
				.setParameter("pPaymentDate", claimsSettlementModel.getPaymentDate())
				.setParameter("pBankID", claimsSettlementModel.getBankId())
				.setParameter("pBankBranchID", claimsSettlementModel.getBankBranchId())
				.setParameter("pChequeNo", claimsSettlementModel.getChequeNo())
				.setParameter("pChequeDate", claimsSettlementModel.getChequeDate())
				.setParameter("pCardTypeID", claimsSettlementModel.getCardTypeId())
				.setParameter("pCardNo", claimsSettlementModel.getCardNo())
				.setParameter("pCardExpiryDate", claimsSettlementModel.getCardExpiryDate())
				.setParameter("pCardExpiryMonth", claimsSettlementModel.getCardExpiryMonth())
				.setParameter("pCardExpiryYear", claimsSettlementModel.getCardExpiryYear())
				.setParameter("pAmount", claimsSettlementModel.getAmount())
				.setParameter("pBankBranchName", claimsSettlementModel.getBankBranchName())
				.setParameter("pBankName", claimsSettlementModel.getBankName())
				.setParameter("pDescription", claimsSettlementModel.getDescription())
				.setParameter("pISFCCode", claimsSettlementModel.getIfscCode())
				.setParameter("pCreatedBy", claimsSettlementModel.getCreatedBy())
				.setParameter("pCreatedOn", claimsSettlementModel.getCreatedOn());
		
		storedProcedureQuery.execute();
		
	}

	
	public List<GetSettlementPaymentDetails> getAllClaimsSettlementPayment() {
		StoredProcedureQuery query = em.createStoredProcedureQuery("spGetClaimsSettlementPaymentDetails")
				.registerStoredProcedureParameter("oCur1", Class.class, ParameterMode.REF_CURSOR);
		query.execute();
		List<Object[]> list = (List<Object[]>) query.getResultList();
		List<GetSettlementPaymentDetails> getAllClaims = list.stream()
				.map(o -> new GetSettlementPaymentDetails((String) o[0], (Number) o[1], (Number) o[2], (Date) o[3],
						(Number) o[4], (Number) o[5],(String) o[6], (Date) o[7],(Number) o[8], (String) o[9],(Date) o[10], (String) o[11],(String) o[12], (Number) o[13],(String) o[14], (String) o[15],(String) o[16], (String) o[17],(Number) o[18],(Date) o[19])) 
				.collect(Collectors.toList());

		return getAllClaims;
		
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	public List<SaveClaimsSettlementModel> getClaimNumberByClaimID(int pClaimID) {
		StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spGetClaimNumberByClaimID")
				.registerStoredProcedureParameter("pClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("p_outCur", Class.class, ParameterMode.REF_CURSOR)

				.setParameter("pClaimID", pClaimID);

		storedProcedureQuery.execute();
		List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();
		List<SaveClaimsSettlementModel> getClaimNumberList = list.stream()
				.map(o -> new SaveClaimsSettlementModel((int) o[0])).collect(Collectors.toList());

		return getClaimNumberList;
	}

	public List<ClaimsSettlementModel> getBeneficiary(int claimId) {
		StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spGetAllBeneficiaryByClaimID")
				.registerStoredProcedureParameter("vClaimID", Integer.class, ParameterMode.IN)
				.registerStoredProcedureParameter("oClaimsBeneficiary", Class.class, ParameterMode.REF_CURSOR)
				.setParameter("vClaimID", claimId);
		// return query.execute() ? query.getResultList() : null;
		storedProcedureQuery.execute();
		List<Object[]> list = (List<Object[]>) storedProcedureQuery.getResultList();
		List<ClaimsSettlementModel> beneficiaryList = list.stream()
				.map(o -> new ClaimsSettlementModel((Number) o[0], (String) o[1])).collect(Collectors.toList());
		return beneficiaryList;
	}

}

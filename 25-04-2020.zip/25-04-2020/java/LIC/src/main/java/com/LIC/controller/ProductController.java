package com.LIC.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.model.BenefitRiders;
import com.LIC.model.Coefficient;
import com.LIC.model.ErrorDto;
import com.LIC.model.GetProductModel;
import com.LIC.model.Insurer;
import com.LIC.model.LineOfBusiness;
import com.LIC.model.ProductModel;
import com.LIC.model.Question;
import com.LIC.model.Response;
import com.LIC.model.Taxstructure;
import com.LIC.model.TransactionContext;
import com.LIC.model.Variant;
import com.LIC.model.VariantHistory;
import com.LIC.model.VariantRequest;
import com.LIC.service.IBenefitRidersService;
import com.LIC.service.ICoefficientService;
import com.LIC.service.IInsurerService;
import com.LIC.service.ILineOfBusinessService;
import com.LIC.service.IProductAgeProofDocumentService;
import com.LIC.service.IProductService;
import com.LIC.service.IProductTypeService;
import com.LIC.service.IQuestionService;
import com.LIC.service.ITaxstructureService;
import com.LIC.service.IVariantHistoryService;
import com.LIC.service.IVariantService;
import com.LIC.utils.TextUtil;

@RestController
@RequestMapping("/configuration")
public class ProductController {
	private ResponseGenerator responseGenerator;
	
	public ProductController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	
	@Autowired(required=true)
	IProductAgeProofDocumentService productAgeProofDocumentService;
	
	@Autowired(required=true)
	IInsurerService insurerService;
	
	@Autowired(required=true)
	IProductTypeService productTypeService;
	
	@Autowired(required=true)
	IVariantHistoryService variantHistoryService;
	
	@Autowired(required=true)
	IBenefitRidersService benefitRidersService;
	
	@Autowired(required=true)
	ITaxstructureService taxstructureService;
	
	@Autowired(required=true)
	IQuestionService questionService;
	
	@Autowired(required=true)
	ILineOfBusinessService lineOfBusinessService;
	
	@Autowired(required=true) ICoefficientService coefficientService;
	
	@Autowired(required=true) IVariantService variantService;
	
	@Autowired(required=true) IProductService productService;

	@RequestMapping(value = "/question/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllQuestion() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Question> questionList = questionService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("questionList", questionList); 
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/tax-structure/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllTaxStructure() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Taxstructure> taxstructureList = taxstructureService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("taxstructureList", taxstructureList); 
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/insurer/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllInsurer() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Insurer> insurerList = insurerService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("insurerList", insurerList); 
		return ResponseEntity.accepted().body(response);
	}

	@RequestMapping(value = "/line-of-business/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllLineOfBusiness() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<LineOfBusiness> lineOfBusinessList = lineOfBusinessService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("lineOfBusinessList", lineOfBusinessList); 
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/riders-factor/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllCoefficient() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Coefficient> coefficientList = coefficientService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("coefficientList", coefficientList); 
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/benefit-riders/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllBenefitRider() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<BenefitRiders> benefitRidersList = benefitRidersService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("benefitRidersList", benefitRidersList); 
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/product/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> saveOrUpdateProduct(@RequestBody VariantRequest request) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == request) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Request Payload.");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		System.out.println("saveOrUpdate >>>> "+request.toString());
		variantService.saveOrUpdate(request);
		response.put("status", 1);
		response.put("message","Product updated successfully.");
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/product/get/{productID}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getVariantRequest(@PathVariable Integer productID) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == productID) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Variant ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		VariantRequest variantRequestObj = variantService.get(productID);
		if(null == variantRequestObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Variant ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		List<VariantHistory> historyList = variantHistoryService.getAll(productID);
		response.put("status", 1);
		response.put("message","Success");
		response.put("historyList", historyList);
		response.put("variantRequestObj", variantRequestObj);
		return ResponseEntity.accepted().body(response);
	}
	@RequestMapping(value = "/product/get", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllVariantRequest() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Variant> variantRequestList = variantService.getAll(null);
		response.put("status", 1);
		response.put("message","Success");
		response.put("variantRequestList", variantRequestList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/product/delete/{productId}/{deletedBy}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity<?> deleteAccountType(@PathVariable Integer productId, @PathVariable Integer deletedBy) throws Exception {
		ErrorDto errorDto = null;
		Map<String, Object> response = new HashMap<String, Object>();
		if (null == productId) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Variant ID Required.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		VariantRequest variantObj = variantService.get(productId);
		System.out.println("VariantRequest >>> "+variantObj);
		if(null == variantObj) {
			errorDto = new ErrorDto();
			errorDto.setCode("400");
			errorDto.setMessage("Invalid Variant ID.!");
			response.put("status", 0);
			response.put("error", errorDto);
			return ResponseEntity.badRequest().body(response);
		}
		variantService.delete(productId, deletedBy);
		response.put("status", 1);
		response.put("message","Success");
		return ResponseEntity.accepted().body(response);
	}
	
	
	@RequestMapping(value = "/product/search", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> searchVariant(@RequestBody Variant filterObj) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Variant> variantList = variantService.getAll(filterObj);
		List<Variant> fliteredList = null;
		if(null != variantList && !variantList.isEmpty()) {
		fliteredList = variantList.stream()
	         .filter(p -> {
	        	 if(!TextUtil.isEmptyOrNull(filterObj.getDescription()) ) {
	        		 if(null != filterObj.getInsurerID()) {
	        			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription()) && 
	        					 p.getInsurerID().equals(filterObj.getInsurerID())) {
	                         return true;
	                     }
	        			 return false;
	        		 }else {
	        			 if (TextUtil.isContains(p.getDescription(), filterObj.getDescription())) {
	                         return true;
	                     }
	        			 return false;
	        		 }
	        	 }else if(null != filterObj.getInsurerID()){
	        		 if (p.getInsurerID().equals(filterObj.getInsurerID())) {
	                     return true;
	                 }
	        		 return false;
	        	 }
	             return true;
	         }).collect(Collectors.toList());
		}
		response.put("status", 1);
		response.put("message","Success");
		response.put("list", fliteredList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/benefit-riders/save", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> saveOrUpdateBenefitRider(@RequestBody BenefitRiders benefitRiders) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
	    BenefitRiders benefitRidersList = benefitRidersService.saveOrUpdateBenefitRider(benefitRiders);
		response.put("status", 1);
		response.put("message","Success");
		response.put("benefitRidersList", benefitRidersList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/product/getVarient", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllVariantRequestByLineOfBusinessId(@RequestParam Integer lineOfBusinessId) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<Variant> variantRequestList = variantService.getAllVariantByLineofBusinessId(lineOfBusinessId);
		response.put("status", 1);
		response.put("message","Success");
		response.put("variantList", variantRequestList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/product/getAllProduct", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getAllProduct() throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		List<GetProductModel> getProductModelList = productService.getAllProduct();
		response.put("status", 1);
		response.put("message","Success");
		response.put("getProductModelList", getProductModelList); 
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/product/insertOrUpdatePlanDetails", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> insertOrUpdatePlanDetails(@RequestBody ProductModel productModel) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		
		System.out.println("insertOrUpdatePlanDetails input "+productModel);
		
		long planId	= productService.saveOrUpdatePlanDetails(productModel);
		
		response.put("status", 1);
		response.put("message","Success");
		response.put("planId", planId); 
		
		return ResponseEntity.accepted().body(response);
	}
	
	@RequestMapping(value = "/product/deleteProduct", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> deleteProduct(@RequestHeader HttpHeaders httpHeaders, @RequestBody ProductModel productModel)  {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			System.out.println("deleteProduct input "+productModel);
			return responseGenerator.successResponse(context, productService.deleteProduct(productModel), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	@RequestMapping(value = "/product/getAllPlanDetailsByPlanName",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllPlanDetailsByPlanName(@RequestHeader HttpHeaders httpHeader,@RequestParam("planName") String planName){
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);

		try {
			System.out.println("getAllPlanDetailsByPlanName input "+planName);
			return responseGenerator.successResponse(context, productService.getAllPlanDetailsByPlanName(planName), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	@RequestMapping(value = "/product/getAllPlanCategory",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAllPlanCategory(@RequestHeader HttpHeaders httpHeader,@RequestParam("LobId") long LobId){
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			System.out.println("getAllPlanCategory input "+LobId);
			return responseGenerator.successResponse(context, productService.getAllPlanCategory(LobId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	@RequestMapping(value = "/product/getPlanDetailsByPlanId",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getPlanDetailsByPlanId(@RequestHeader HttpHeaders httpHeader,@RequestParam("planId") long planId){
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);

		try {
			System.out.println("getPlanDetailsByPlanId input "+planId);
			return responseGenerator.successResponse(context, productService.getPlanDetailsByPlanId(planId), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
}

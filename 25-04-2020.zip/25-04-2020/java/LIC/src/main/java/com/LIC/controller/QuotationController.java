package com.LIC.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.LIC.dao.QuotationDAO;
import com.LIC.model.ClaimsIntimationModel;
import com.LIC.model.DropDownModel;
import com.LIC.model.MasterPolicyPremiumModel;
import com.LIC.model.MemberAdditionModel;
import com.LIC.model.PremiumRateUploadModel;
import com.LIC.model.QuotationModel;
import com.LIC.model.QuotationSearchModel;
import com.LIC.utils.ExcelFileUpload;

@RestController
public class QuotationController {

	@Autowired
	private QuotationDAO quotationDAO;
	
	@Value("${uploadPath.location}")
	private String uploadPath;	

	@RequestMapping(path = "/salesHierarchy/{moCode}", method = RequestMethod.GET)
	public List getSalesHierarchyDetails(@PathVariable String moCode) {

		List sales = quotationDAO.getSalesHierarchyDetails(moCode);

		return sales;

	}

	@RequestMapping(path = "/salesHierarchy/getProduct", method = RequestMethod.GET)
	public List<DropDownModel> getAllPlans() {

		return quotationDAO.getAllPlans();

	}

	
	@RequestMapping(path = "/salesHierarchy/getPremium", method = RequestMethod.GET)
	public List<DropDownModel> getAllPremium() {

		return quotationDAO.getAllPremium();

	}

	@RequestMapping(path = "/salesHierarchy/getVariant/{lineOfBusinessID}", method = RequestMethod.GET)
	public List<DropDownModel> getVariant(@PathVariable int lineOfBusinessID) {

		return quotationDAO.getVariant(lineOfBusinessID);

	}

	@PostMapping("/saveQuotation")
	public List saveQuotationDetails(@RequestBody QuotationModel quotationObject) {
		return quotationDAO.saveQuotationDetails(quotationObject);	

	}
	
	@PostMapping("/insertPremiumValue")
	public void insertMasterPolicyPremium(@RequestBody MasterPolicyPremiumModel masterPolicyPremiumModel) {

		quotationDAO.insertMasterPolicyPremium(masterPolicyPremiumModel);

	}

	@RequestMapping(value = "/getPremiumDetailsByMasterPolicy/{productId}", method = RequestMethod.GET)
	public List<Object> getPremiumDetailsByMasterPolicy(@PathVariable int productId) {

		try {
			return quotationDAO.getPremiumDetailsByMasterPolicy(productId);
		} catch (Exception e) {
			List exception = new ArrayList();
			exception.add(e);
			return exception;
		}
	}
	
	@PostMapping("/migrationDataUpload")
	public List migrationDataUpload(@RequestBody QuotationModel quotationModel,String filePath) {

		return quotationDAO.migrationQuotationDataUpload(quotationModel,filePath);

	}
	
	@RequestMapping(path = "/getClientDetails/{clientId}/{typeId}", method = RequestMethod.GET)
	public List getClientDetails(@PathVariable int clientId,@PathVariable int typeId)
	{
		return quotationDAO.getClientDetails(clientId,typeId);
	}
	
	

	@PostMapping("/validateAnyExcelFile/PremiumRate")
	public String validatePremiumRateExcelFile(@RequestParam("file") MultipartFile mpfile) {

		try {
			ExcelFileUpload upload = new ExcelFileUpload();
			File file = upload.createFile(mpfile,uploadPath);

			String result = upload.validateExtension(file);
			List<String> colList = PremiumRateUploadModel.getColumnList();
			if (result == "") {
				Iterator workbookItr = upload.createWorkbook();
				result = upload.validateAnyExcelFile(workbookItr, colList);
				if (result == "") {
					ArrayList<ArrayList<String>> list = upload.formColumnList(colList, 0, workbookItr);
					upload.write(list, colList, "PREMIUMDETAILDATAUPLOAD");
				}

			}

			upload.closeStream();
			return result;
		} catch (Exception e) {
			return "";
		}
	}

	@PostMapping("/validateAnyExcelFile/MemberUpload/{quotationId}")
	public String validateMemberUploadExcelFile(@RequestParam("file") MultipartFile mpfile,@PathVariable String quotationId) {

		try {
			ExcelFileUpload upload = new ExcelFileUpload();
			File file = upload.createFile(mpfile,uploadPath);

			String result = upload.validateExtension(file);
			
			if(result!= "") {
				return result;
			}
			List<String> colList = QuotationModel.getMemberUploadColumnList();
			if (result == "") {
				Iterator workbookItr = upload.createWorkbook();
				result = upload.validateAnyExcelFile(workbookItr, colList);
				if (result == "") {
					// Write the number of rows to skip from top.Here it is 3
					ArrayList<ArrayList<String>> list = upload.formColumnList(colList, 3, workbookItr);

					// remove specified rows in list
					ArrayList<String> toRemove = new ArrayList<String>();
					toRemove.add("Type");
					toRemove.add("SchemeNo");
					colList = upload.removeColumnList(QuotationModel.getMemberUploadColumnList(), toRemove);

					// add new rows in array
					ArrayList<String> toAdd = new ArrayList<String>();
					toAdd.add("FileName");
					toAdd.add("DATAUPLOADID");
					colList = upload.addColumnList(colList, toAdd);

					// remove first two cols in list
					ArrayList<Integer> toRemoveValues = new ArrayList<Integer>();
					toRemoveValues.add(0);
					toRemoveValues.add(1);
					list = upload.removeParameter(list, toRemoveValues);

					ArrayList<String> toAddValues = new ArrayList<String>();
					toAddValues.add(file.getPath());
					toAddValues.add(quotationId);// generated quotation id
					list = upload.addParameter(list, toAddValues);

					result = upload.write(list, colList, "QUOTATIONDATAUPLOAD");
				}

			}

			upload.closeStream();
			return result;
		} catch (Exception e) {
			return e.toString();
		}
	}
	
	
	@PostMapping("/getSearchQuotation")
	public List getSearchQuotation(@RequestBody QuotationSearchModel model) {
		return quotationDAO.getSearchQuotation(model);
	}


	// Type SchemeNo EmployeeNo UniqueID Title FirstName MiddleName LastName
	// DateOfBirth DateOfJoining SchemeJoiningDate NBIntimationDate Age BasicSalary
	// Gender EmailID AddressType Address1 Address2 Address3 PinCode City State
	// Country PhoneNumber MobileNumber PanNo BenefitOption GPSSumAssured GPSRiderAD
	// GPSRiderADD GPSRiderTPD GPSRiderAT GPSRiderCI4 GPSRiderCIRC GPSRiderCIP
	// GPSRiderCIA GPSRiderTIP GPSRiderATIR SIngleJointLife BenefitTerm
	// TenureOfTheLoan PremiumTerm NomineeEffectiveDate NomineeName1
	// NomineeRelationship1 NomineePercentage1 NomineeName2 NomineeRelationship2
	// NomineePercentage2 NomineeName3 NomineeRelationship3 NomineePercentage3
	// NomineeName4 NomineeRelationship4 NomineePercentage4 BranchCodeOfBank
	// PremiumReceived DateOfDisbursementOfLoan UnderwritingDocumentType HDFDate
	// TypeOfLoan OccupationName Location IsWindowPeriodApplicable Grade TypeOfClaim
	// ClaimPayOutOption OccupationRisk PaymentFrequency
	
	
    @RequestMapping(path = "/insertQuotationPremiumMap", method = RequestMethod.POST)
    public String insertQuotationPremium(@RequestBody QuotationModel model) {
                    return quotationDAO.insertQuotationPremiumMap(model);
    }
    
    
    
    @RequestMapping(method = RequestMethod.GET, value = "/getQuotationPRemiumMap/{quotationID}")
    public List getQuotationPRemiumMap(@PathVariable int quotationID) {
                    return quotationDAO.getQuotationPRemiumMapByQuotationID(quotationID);
    }
    
    


}

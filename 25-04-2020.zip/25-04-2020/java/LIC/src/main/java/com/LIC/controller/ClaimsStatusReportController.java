/*package com.lic.claim.claimsstatusreport.controller;*/

package com.LIC.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.ClaimsStatusReportDAO;
import com.LIC.model.ClaimsStatusReportModel;

@RestController
public class ClaimsStatusReportController {

	@Autowired

	private ClaimsStatusReportDAO claimStatusReportDAO;

	@RequestMapping(value = "/getSearchClaimsView ", method = RequestMethod.GET)
	public int getSearchClaimsView(@RequestBody ClaimsStatusReportModel claimsStatusReportModel) {
		return claimStatusReportDAO.getSearchClaimsView(claimsStatusReportModel);
	}

	@RequestMapping(value = "/getClaimDocumentsByClaimID", method = RequestMethod.GET)
	public int getClaimDetailsByClaimID(@RequestBody ClaimsStatusReportModel claimsStatusReportModel) {
		return claimStatusReportDAO.getClaimDetailsByClaimID(claimsStatusReportModel);
	}

	@RequestMapping(value = "/getClaimProductTransactionDetails", method = RequestMethod.GET)
	public int getClaimProductTransactionDetails(@RequestBody ClaimsStatusReportModel claimsStatusReportModel) {
		return claimStatusReportDAO.getClaimProductTransactionDetails(claimsStatusReportModel);
	}

	@RequestMapping(value = "/getClaimsDocument", method = RequestMethod.GET)
	public int getClaimsDocument(@RequestBody ClaimsStatusReportModel claimsStatusReportModel) {
		return claimStatusReportDAO.getClaimsDocument(claimsStatusReportModel);
	}

	@RequestMapping(value = "/getAssessmentHistory", method = RequestMethod.GET)
	public int getAssessmentHistory(@RequestBody ClaimsStatusReportModel claimsStatusReportModel) {
		return claimStatusReportDAO.getAssessmentHistory(claimsStatusReportModel);
	}
}

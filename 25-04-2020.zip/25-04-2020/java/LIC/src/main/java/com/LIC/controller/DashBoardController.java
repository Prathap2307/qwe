package com.LIC.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.dao.DashBoardDAO;
import com.LIC.model.DashBoard;
@RestController
public class DashBoardController {
	
	@Autowired
	private DashBoardDAO dashBoard;
	
	@RequestMapping(value = "/dashBoard", method = RequestMethod.GET)
	public List<DashBoard> AlldashBoard() {

		return dashBoard.GetAllDashBoard();
	}
}

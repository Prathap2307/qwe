import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from "moment"
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { CommisionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/commision.service';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product1.service';
@Component({
  selector: 'app-commission',
  templateUrl: './commission.component.html',
  styleUrls: ['./commission.component.css'],
  providers: [

    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },


    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class CommissionComponent implements OnInit {
  @ViewChild('picker', { static: true }) picker;
  @ViewChild('picker1', { static: true }) picker1;
  @ViewChild('picker2', { static: true }) picker2;
  @ViewChild('picker3', { static: true }) picker3;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  variantArr: any;
  variantErrMsg: string;
  Sales: any;
  open() {
    this.picker.open();
    this.picker1.open();
    this.picker2.open();
    this.picker3.open();
  }

  Searchcommission: FormGroup;
  Addcommission: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  display: string;
  saveBtnMode: boolean = true;
  view: boolean = false;
  SubchannelHeading: string = "Add New - Commission";
  textSaveBtn: string = "Save";

  Varient = [
    { Id: 1, Name: 'first plan' },
  ]

  dummyObj =
    [
      { Id: 1, Name: 'Agent' },
    ]
  policyyear =
    [
      { Id: 1, Name: 'range' },
    ]
  invalidDate: boolean;
  invalidpolicy: boolean;
  validform: boolean;
  allchannel: any;
  allsubchannel: any;
  success: boolean;
  exist: boolean;
  transaction: string;
  invalidamount: boolean;
  error: boolean;
  msg: any;
  allcommision: any;
  commission: any;
  deleteid: any;
  deleted: boolean;


  constructor(private fb: FormBuilder,  private fchannelService: FchannelService,private _productService: ProductService, private FchannelService: FchannelService, private CommissionService: CommisionService) { }

  ngOnInit() {
    this.getvariant()
    // this. GetAllSalesHierarchyBySearch()
    this.getallchannel()
    // this.getallsubchannel()
    this.GetAllCommissionDetail()
    this.Searchcommission = this.fb.group({
      planID: [''],
      mainChannelID: [''],
      fromDate: [''],
      toDate: ['']
    })

    this.Addcommission = this.fb.group({
      commissionID: [''],
      // PlanID :[''],
      planID: ['', Validators.required],
      mainChannelID: ['', Validators.required],
      subChannelID: ['', Validators.required],
      salesHierarchyID: [''],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required],
      policyYearTypeID: ['', Validators.required],
      policyTermID: [''],
      rangeFrom: ['', Validators.required],
      rangeTo: ['', Validators.required],
      amount: ['', Validators.required],
      createdBy: [''],
      createdOn: [''],
      // isActive: ['']


      // ModifiedBy:['']
      // ModifiedOn :['']
      // DeletedBy:['']
      // DeletedOn:[''] 


    })



  }

  get d() { return this.Searchcommission.controls; }

  getallchannel() {
    this.CommissionService.GetAllMainChannel()
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        console.log(this.allchannel)
      });
  }
  // getallsubchannel() {
  //   let abc = {
  //     "ChannelName": "SubChannel1",
  //     "ChannelCode": "mh001"
  //   }

  //   this.FchannelService.GetAllSubChannel(abc)
  //     .subscribe(result => {
  //       console.log(result)
  //       this.allsubchannel = result.data
  //       console.log(this.allsubchannel)
  //     });
  // }
  onBtnSearchClick() {
    this.submitted = true;
    console.log(this.Searchcommission.value)
    this.CommissionService.searchcommision(this.Searchcommission.value)
      .subscribe(result => {
        console.log(result)
        this.allcommision = result['data']
        console.log(this.allcommision)

      });
    console.log(this.Searchcommission.value)
  }
  clearsearch() {
    this.submitted = false;
    this.Searchcommission.reset();
    this.GetAllCommissionDetail()
  }
  get a() { return this.Addcommission.controls; }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }

  IsCommisionExist(data: any) {
    this.Addcommission.value["fromDate"] = moment(new Date(this.Addcommission.value["fromDate"])).format('DD-MM-YYYY ')
    this.Addcommission.value["toDate"] = moment(new Date(this.Addcommission.value["toDate"])).format('DD-MM-YYYY ')
    this.CommissionService.IsCommissionDetailExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === "NOTEXIST") {
          this.CommissionService.InsertOrUpdatecommission(data)
            .subscribe(result => {
              console.log(result)
              this.success = true
              if (this.textSaveBtn === 'Save') {
                this.transaction = "Created"
              } else {
                this.transaction = "Updated"
              }
              this.openModalDialog()
              this.GetAllCommissionDetail()
              this.clear()
            });
        }
        else {
          this.exist = true
          //  this.present=result.data
          this.openModalDialog()
        }

      });
  }
  onBtnSave() {
    this.submitted1 = true;
    console.log(this.Addcommission.value)

    if (this.Addcommission.value["fromDate"] && this.Addcommission.value["toDate"]) {
      let today = moment(new Date()).format('YYYY/MM/DD')
      let fromvalue = moment(new Date(this.Addcommission.value["fromDate"])).format('YYYY/MM/DD')
      let tovalue = moment(new Date(this.Addcommission.value["toDate"])).format('YYYY/MM/DD')
      let fromDate = moment(fromvalue);
      let toDate = moment(tovalue);
      let result = fromDate.diff(toDate, 'days');
      console.log(result)
      if(fromDate < moment(today)){
        let msg = "From Date should not be less than to Current Date."
        this.openModalDialog1(msg)
        this.error = true
        this.invalidDate = true
        console.log(this.invalidDate)
        console.log("From Date should not be less than to Current Date.")
      }
      if (result >= 0) {
        let msg = "Commission Created To Date should be greater than Commission Created From Date"
        this.openModalDialog1(msg)
        this.error = true
        this.invalidDate = true
        console.log(this.invalidDate)
        console.log("To Date should be greater than From Date.")
      }
    }

    let from = this.Addcommission.value["rangeFrom"]
    let to = this.Addcommission.value["rangeTo"]
    console.log(from > to)
    if (from > to) {
      this.invalidpolicy = true
      this.error = true
      console.log(this.invalidpolicy)
      let msg = "Policy Year To should be greater than Policy Year From"
      this.openModalDialog1(msg)
      console.log("Policy Year To should be greater than Policy Year From")
    }
    // console.log(this.Addcommission.value["amount"].toFixed(2));
    if (this.Addcommission.value["amount"] > 100) {
      this.invalidamount = true
      console.log(this.invalidamount)
      this.error = true
      let msg = "Commission cannot be greater than 100%."
      this.openModalDialog1(msg)
      console.log("Commission cannot be greater than 100%.")
    }
    if (this.Addcommission.valid && !this.invalidamount && !this.invalidDate && !this.invalidpolicy) {
      this.IsCommisionExist(this.Addcommission.value)
    }
  }
  clear() {
    this.Addcommission.reset();
    this.SubchannelHeading = 'Add - Commission';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }

  btngEdit_Click(a) {

    this.SubchannelHeading = 'Edit - Commission';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.getcommissionById(a)
  }
  GetAllSalesHierarchyBySearch() {
    this.fchannelService.GetAllSalesHierarchyBySearch()
      .subscribe(result => {
        console.log(result)
        this.Sales = result.data
      
      });
  }
  getvariant() {
    this._productService.getVariant().subscribe(res => {
      console.log(res.variantRequestList)
      this.variantArr = res.variantRequestList;
    }, err => {
      console.log(err);
    })
  }

  getcommissionById(a) {
    console.log(a.commissionID)
    this.CommissionService.GetCommissionDetailByID(a.commissionID)
      .subscribe(result => {
        console.log(result)
        this.commission = result.data[0]
        if (this.commission) {
          if (this.commission.mainChannelID) {
            this.GetAllSubChannel(this.commission.mainChannelID);
          }

          console.log(this.Addcommission.value)
          this.Addcommission = this.fb.group({
            commissionID: [{ value: this.commission.commissionID, disabled: false }],
            planID: [{ value: this.commission.planID, disabled: false }, Validators.required],
            mainChannelID: [{ value: this.commission.mainChannelID, disabled: false }, Validators.required],
            subChannelID: [{ value: this.commission.subChannelID, disabled: false }, Validators.required],
            salesHierarchyID: [{ value: this.commission.salesHierarchyID, disabled: false }],
            fromDate: [{ value: new Date(this.commission.fromDate), disabled: false }, Validators.required],
            toDate: [{ value: new Date(this.commission.toDate), disabled: false }, Validators.required],
            policyYearTypeID: [{ value: this.commission.policyYearTypeID, disabled: false }, Validators.required],
            policyTermID: [{ value: this.commission.policyTermID, disabled: false }],
            rangeFrom: [{ value: this.commission.rangeFrom, disabled: false }, Validators.required],
            rangeTo: [{ value: this.commission.rangeTo, disabled: false }, Validators.required],
            amount: [{ value: this.commission.amount, disabled: false }, Validators.required],
          })
          console.log(this.Addcommission.value)

        }
      });

  }
  setdelete(data) {
    this.deleteid = data.commissionID
    console.log(data)
  }
  delete(a) {
    console.log(this.deleteid)
    this.CommissionService.DeleteCommision(this.deleteid)
      .subscribe(result => {
        console.log(result)

        if (result.data === "Success") {
          this.deleted = true
        }
        else {
          this.deleted = false
        }
        this.GetAllCommissionDetail()
      });
  }
  btngView_Click(a) {
    this.SubchannelHeading = 'View - Commission';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.getcommissionById(a)
  }
  Select_channel(event: any) {
    console.log(event.target.value)

    this.GetAllSubChannel(event.target.value);
  }
  GetAllCommissionDetail() {
    this.CommissionService.GetAllCommissionDetail()
      .subscribe(result => {
        console.log(result)
        this.allcommision = result.data
        console.log(this.allcommision)
        if (this.allcommision && this.allcommision.length > 0) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allcommision.length
          }
        }
      });
  }
  GetAllSubChannel(id) {
    this.CommissionService.GetSubChannelByChannelID(id)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        console.log(this.allsubchannel)
      });
  }
  dateValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (charCode === 32 || (charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)

        event.preventDefault();
      }
    }
  }
  policyYearValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 1) {
        console.log(l)
      }
      else {
        event.preventDefault();
      }
    }
  }

  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted1 = false

  }
  openModalDialog1(msg) {
    this.display = 'block'; //Set block css
    this.submitted1 = false
    this.msg = msg

  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.invalidpolicy = false
    this.invalidDate = false
    this.success = false
    this.invalidamount = false
    this.error = false
    this.msg=''
  }

}

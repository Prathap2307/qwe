import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';

import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';

import { TooltipPosition } from '@angular/material/tooltip';
import { Key } from 'protractor';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})

export class DepartmentComponent implements OnInit {

  saveBtnMode: boolean = true;

  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);




  departmentObj: DepartmentType[];
  departmentGridObj: DepartmentType[];
  departmentFilteredObj: DepartmentType[] = [];

  departmentColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];


  constructor(private departmentService: DepartmentService, private fb: FormBuilder, private changeDetectorRefs: ChangeDetectorRef) { }



  DepartmentForm: FormGroup;
  ActionGroupDepartment: FormGroup;



  departmentHeading: string = '';
  textSaveBtn: string = '';

  createBtn: boolean;

  dataSource = new MatTableDataSource<DepartmentType>(this.departmentGridObj);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  fieldDisable: Boolean;

  ngOnInit() {
    this.createBtn = true;

    this.dataSource = new MatTableDataSource<DepartmentType>(this.departmentGridObj);


    this.departmentHeading = 'Add New - Department';
    this.textSaveBtn = 'Save';
    //setTimeout(() => this.dataSource.paginator = this.paginator);
    this.getDepartmentDetails();
    this.DepartmentForm = this.fb.group({
      SearchDescription: [''],
      SearchDepartmentId: [''],
      ActionGroupDepartment: this.fb.group({
        departmentId: [''],
        description: ['', Validators.required],
        shortName: ['', Validators.required],
        createdBy: ['1'],
        createdOn: [new Date()],
        deletedBy: ['1'],
        deletedOn: [new Date()]

      })
    });

  }

  alreadyExist: number;
  alreadyEditExist: number;
  alreadyShortNameExist: number;
  alreadyShortNameEditExist: number;
  saveMethod() {
    this.DepartmentForm.get('ActionGroupDepartment').patchValue({
      createdBy: '1',
      createdOn: new Date()
    });

    this.DepartmentForm.controls.ActionGroupDepartment.markAllAsTouched();

    if (this.DepartmentForm.controls.ActionGroupDepartment.valid) {
      let a = this.DepartmentForm.controls.ActionGroupDepartment.value;

      this.departmentService.addDepartment(a)
        .subscribe(result => { this.getDepartmentDetails() });


      this.DepartmentForm.controls.ActionGroupDepartment.reset();
      this.departmentHeading = 'Add New - Department';
      this.textSaveBtn = 'Save';
      this.createBtn = true;


    }
  }


  onBtnSaveClick() {
    let des = this.DepartmentForm.get('ActionGroupDepartment.description').value;
    let sn = this.DepartmentForm.get('ActionGroupDepartment.shortName').value;
    if (this.createBtn) {

      this.DepartmentForm.get('ActionGroupDepartment.departmentId').patchValue('');
      this.alreadyExist = 0;
      this.alreadyShortNameExist = 0;
 
    
      this.departmentGridObj.forEach((fe) => {
       
        if (fe.description.toUpperCase().trim() == des.toUpperCase().trim()) {
          this.alreadyExist = 1;
        }

        if (fe.shortName.toUpperCase().trim() == sn.toUpperCase().trim()) {
          this.alreadyShortNameExist = 1;
        }

      });

      if (this.alreadyExist == 0 && this.alreadyShortNameExist == 0) {
        this.saveMethod();
      } else {
      
        if(this.alreadyExist == 1){
          window.alert('Department already exists');

          return false;
        }

        if(this.alreadyShortNameExist == 1){
          window.alert('Short Name already exists');
          
          return false;
        }
       
      }

    } else {

      let id = this.DepartmentForm.get('ActionGroupDepartment.departmentId').value;

      this.alreadyEditExist = 0;
      this.alreadyShortNameEditExist = 0;
      this.departmentGridObj.forEach((fe) => {


        if (fe.departmentId != id) {
          if (fe.description.toUpperCase().trim() == des.toUpperCase().trim()) {
            this.alreadyEditExist = 1;
          }

          if (fe.shortName.toUpperCase().trim() == sn.toUpperCase().trim()) {
            this.alreadyShortNameEditExist = 1;
          }
        }

      });

      if (this.alreadyEditExist == 0 && this.alreadyShortNameEditExist == 0) {
        this.saveMethod();
      } else {
        if(this.alreadyEditExist == 1){
          window.alert('Department already exists');

          return false;
        }

        if(this.alreadyShortNameEditExist == 1){
          window.alert('Short Name already exists');
          
          return false;
        }
      
      }



    }


  }


  onBtnResetClick() {
    // this.DepartmentForm.reset();
    this.fieldDisable = false;
    this.DepartmentForm.controls.ActionGroupDepartment.reset();
    this.departmentHeading = 'Add New - Department';
    this.textSaveBtn = 'Save';
    this.saveBtnMode = true;
    this.DepartmentForm = this.fb.group({
      SearchDescription: [''],
      SearchDepartmentId: [''],
      ActionGroupDepartment: this.fb.group({
        departmentId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        shortName: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false }

      })


    });



  }

  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(a => {
        this.departmentObj = a;
        this.departmentGridObj = a;
        this.dataSource = new MatTableDataSource<DepartmentType>(this.departmentGridObj);
        this.dataSource.data = this.departmentGridObj = a;
        this.dataSource.paginator = this.paginator;
      });

  }


  getDepartmentInfoByDescription(): void {


    //if (this.DepartmentForm.controls.SearchDescription.valid) {

    let a = this.DepartmentForm.get('SearchDepartmentId').value;
  
    if(a != ""){
      let r = this.departmentObj.filter((unit) => unit.departmentId == a);
      let b = r[0].description;
      this.departmentService.getDepartmentInfoByDescription(a, b)
      .subscribe(a => {
        this.departmentGridObj = a;

        this.dataSource = new MatTableDataSource<DepartmentType>(this.departmentGridObj);
        this.dataSource.data = this.departmentGridObj = a;
        this.dataSource.paginator = this.paginator;
      });
    }
   

   

    // }

  }

  clearDepartmentInfoByID() {
    this.DepartmentForm.get('SearchDepartmentId').patchValue('');
    this.getDepartmentDetails();
  }

  btngvView_Click(a) {
    this.fieldDisable = true;
    //this.departmentFilteredObj = new DepartmentType[];
    this.departmentFilteredObj = this.departmentGridObj.filter((unit) => unit.departmentId == a);

    this.DepartmentForm = this.fb.group({

      SearchDescription: [''],
      SearchDepartmentId: [''],
      ActionGroupDepartment: this.fb.group({
        departmentId: this.departmentFilteredObj[0].departmentId,
        description: this.departmentFilteredObj[0].description,
        shortName: this.departmentFilteredObj[0].shortName,
        createdBy: this.departmentFilteredObj[0].createdBy,
        createdOn: this.departmentFilteredObj[0].createdOn

      })


    });

    this.departmentHeading = 'View - Department';

    this.saveBtnMode = false;


  }


  btngvEdit_Click(a) {
    this.createBtn = false;
    this.fieldDisable = false;

    this.departmentFilteredObj = this.departmentGridObj.filter((unit) => unit.departmentId == a);
    console.log(this.departmentFilteredObj[0]);
    this.DepartmentForm = this.fb.group({

      SearchDescription: [''],
      SearchDepartmentId: [''],
      ActionGroupDepartment: this.fb.group({
        departmentId: this.departmentFilteredObj[0].departmentId,
        description: this.departmentFilteredObj[0].description,
        shortName: this.departmentFilteredObj[0].shortName,
        createdBy: this.departmentFilteredObj[0].createdBy,
        createdOn: this.departmentFilteredObj[0].createdOn

      })


    });

    this.departmentHeading = 'Edit - Department';
    this.textSaveBtn = 'Update';
    this.saveBtnMode = true;
  }

  btngvDelete_Click(a) {
    if (window.confirm('Are you sure you want to delete this item?')) {
      //  window.confirm('Are you sure you want to delete this item?');
      this.DepartmentForm = this.fb.group({
        SearchDescription: [''],
        SearchDepartmentId: [''],
        ActionGroupDepartment: this.fb.group({
          departmentId: { value: a, disabled: false },
          description: { value: '', disabled: false },
          shortName: { value: '', disabled: false },
          createdBy: { value: '', disabled: false },
          createdOn: { value: '', disabled: false },
          deletedBy: '2',
          deletedOn: '2020-01-30'
        })
      });
      let c = this.DepartmentForm.get('ActionGroupDepartment').value;
      console.log(c);
      this.departmentService
        .deleteDepartment(c)
        .subscribe(result => { this.getDepartmentDetails() });


      this.getDepartmentDetails();
    } else {

    }

  }

  consoleLogFn(val) {
    console.log(val);
  }


  omit_special_char(event)
{   
   var k;  
   k = event.charCode;  //         k = event.keyCode;  (Both can be used)
   return((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57)); 
}

}

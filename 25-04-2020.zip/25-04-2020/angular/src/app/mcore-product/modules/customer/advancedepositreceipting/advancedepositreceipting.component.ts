import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { TooltipPosition } from '@angular/material';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import { MatTableDataSource } from '@angular/material/table';
import { ClientOrgService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/client-org.service';
import { AdvanceDepositReceipt } from 'src/app/mcore-product/mcore-shared/mcore-entity/advancedepositreceipt';
import { AdvanceReceiptingService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/advance-receipting.service';
import * as moment from "moment"
@Component({
  selector: 'app-advancedepositreceipting',
  templateUrl: './advancedepositreceipting.component.html',
  styleUrls: ['./advancedepositreceipting.component.css']
})

export class AdvancedepositreceiptingComponent implements OnInit {
  @ViewChild('picker', { static: true }) picker;
  @ViewChild('picker1', { static: true }) picker1;
  dummyObj: string;
  displayedColumns: string[] = ['View', 'Edit', 'ClientName', 'ClientId', 'CoreBusiness', 'ContactPersonName'];
  dataSource = ELEMENT_DATA;
  searchform: any;
  clientformdetails: any;
  organisationID: string;
  dataObj;
  salutation: any;
  country: any;
  state: any;
  District: any;
  pinobj: any;
  address: any;
  Taluka: any;
  change: boolean;
  gradeform: FormGroup;
  addressform: FormGroup;
  IsgstType: boolean;
  submitted: boolean;
  show: boolean;
  gradelist: any[] = [];
  gradeIndex: any;
  saveBtnMode1: boolean;
  view1: boolean;
  gradeSaveBtn: string = 'Save';
  gradeobj: any;
  deletebtn: any;
  id: any;
  gradedelete: boolean;
  Addressdata: any[] = [];
  transaction: string;
  validaddress: boolean;
  msg: any;
  display: any = 'none';
  validform: boolean;
  addressid: any;
  adressSaveBtn: string = 'Save address';
  AddAdressBtnMode: boolean;
  addressdelete: boolean;
  allbranch: any;
  textSaveBtn: string = 'Save';
  allclient: any;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  clientHeading: string = 'Add Advance Deposit- Client Organization';
  saveBtnMode: boolean = true;
  view: boolean;
  clientobj: any;
  fieldDisable: boolean = true;
  saveBtnMode2: boolean = true;
  risk = [{ "ID": 1, "Name": "Preferred" }, { "ID": 2, "Name": "Medium" }, { "ID": 3, "Name": "High" }, { "ID": 4, "Name": "Negative" },]
  client = [{ ID: 1, Name: 'Regular Customer' },
  { ID: 2, Name: 'SEZ Customer' },]
  gst = [{ ID: 1, Name: 'GST' },
  { ID: 2, Name: 'NO GST' },]
  sezgst_ = [{ ID: 3, Name: 'GST Payable ' },
  { ID: 4, Name: 'NO GST Payable' },]
  paymenMode = [{ ID: '1', Name: 'Others' }, { ID: '2', Name: 'Cheque' }, { ID: '3', Name: 'Demand Draft' }, { ID: '4', Name: 'NEFT/RTGS' }, { ID: '5', Name: 'Credit/Debit Card' }, { ID: '6', Name: 'Online' }]
  showgst: any[];
  advancedreciptform: FormGroup;
  cheque: boolean;
  NEGS: boolean;
  card: boolean;
  online: boolean;
  masterpolicyarr: any;

  constructor(private user: UserService, private fb: FormBuilder, private BranchService: BranchService, private advanceReceiptingService: AdvanceReceiptingService, private clientOrgService: ClientOrgService) { }

  ngOnInit() {
    console.log(localStorage.getItem('organisationID'))
    this.organisationID = localStorage.getItem('organisationID')
    this.GetAllcountries()
    this.GetAllSalutation()
    this.getallbranches()
    this.getallclient()
    this.AdvanceDepositReceiptform()
  }
  AdvanceDepositReceiptform() {
    this.searchform = this.fb.group({
      groupName: ['',],
      customerGroupId: ['',],
      contactFirstName: ['',],
      contactLastName: ['',],
      branchId: ['',],
    })
    this.clientformdetails = this.fb.group({
      groupId: ['',],
      groupName: ['',],
      customerGroupId: ['',],
      coreBusiness: ['',],
      salutationId: ['', Validators.required],
      contactFirstName: ['', Validators.required],
      contactMiddleName: ['',],
      contactLastName: ['',],
      contact: ['',],
      masterPolicyAgeem: ['',],
      agreementStartDate: ['',],
      agreementEndDate: ['',],
      branchId: ['',],
      email: ['',],
      employeeURLKey: ['',],
      password: ['',],
      logo: ['',],
      createdBy: ['',],
      createdOn: ['',],
      isActive: ['',],
      isSms: ['',],
      isEmail: ['',],
      shortName: ['',],
      riskCategoryId: ['',],
      turnOver: ['',],
      salesHierarchyId: ['',],
      isParentGroup: ['',],
      parentGroupId: ['',],
      hierarchyId: ['',],
      panNo: ['', [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]],
      gstNo: ['',],
      clientTypeId: ['',],
      gstTypeId: ['',],
      sacCode: ['',],
    })
    this.advancedreciptform = this.fb.group({
      paymentModeID: ['',],
      insurermasteragreementno: ['',],
      paymentDate: ['',],
      bankID: ['',],
      bankBranchID: ['',],
      bankName: ['',],
      bankBranchName: ['',],
      description: ['',],
      cardTypeID: ['', Validators.required],
      cardNo: ['', Validators.required],
      cardExpiryMonth: ['', Validators.required],
      cardExpiryYear: ['', Validators.required],
      amount: ['', Validators.required],
      instrumentNumber: ['', Validators.required],
      masterPolicyID: ['', Validators.required],
      instrumentDate: ['', Validators.required],
    })
    this.paymentmode()
  }
  get co() { return this.clientformdetails.controls; }
  open() {
    this.picker.open();
    this.picker1.open();
  }
  paymentmode() {
    this.advancedreciptform.get('paymentModeID').valueChanges.subscribe((data: number) => {
      console.log(data)
      this.onchangepaymentmode(data)
    }
    )
  }
  onchangepaymentmode(selected: any) {

    console.log(selected);
    const bankID = this.advancedreciptform.get('bankID')
    const bankBranchID = this.advancedreciptform.get('bankBranchID')
    const instrumentNumber = this.advancedreciptform.get('instrumentNumber')
    const instrumentDate = this.advancedreciptform.get('instrumentDate')
    const cardTypeID = this.advancedreciptform.get('cardTypeID')
    const cardNo = this.advancedreciptform.get('cardNo')
    const cardExpiryMonth = this.advancedreciptform.get('cardExpiryMonth')
    const cardExpiryYear = this.advancedreciptform.get('cardExpiryYear')


    if (selected === "2" || selected === "3") {
      this.submitted = false
      bankID.setValidators(Validators.required);
      bankBranchID.setValidators(Validators.required);
      instrumentNumber.setValidators(Validators.required);
      instrumentDate.setValidators(Validators.required);
      this.cheque = true;
      this.NEGS = false
      this.card = false
      this.online = false
    }
    else if (selected === "4") {
      bankID.setValidators(Validators.required);
      bankBranchID.setValidators(Validators.required);
      this.NEGS = true;
      this.cheque = false
      this.card = false
      this.online = false
    }
    else if (selected === "5") {
      bankID.setValidators(Validators.required);
      bankBranchID.setValidators(Validators.required);
      cardTypeID.setValidators(Validators.required);
      cardNo.setValidators(Validators.required);
      cardExpiryMonth.setValidators(Validators.required);
      cardExpiryYear.setValidators(Validators.required);
      this.card = true
      this.cheque = false
      this.NEGS = false;
      this.online = false
    }
    else if (selected === "6") {
      bankID.setValidators(Validators.required);
      bankBranchID.setValidators(Validators.required);
      this.online = true
      this.card = false
      this.cheque = false
      this.NEGS = false;
    }
    else {
      bankID.clearValidators();
      bankBranchID.clearValidators();
      instrumentNumber.clearValidators();
      instrumentDate.clearValidators();
      cardTypeID.clearValidators();
      cardNo.clearValidators();
      cardExpiryMonth.clearValidators();
      cardExpiryYear.clearValidators();
      this.online = false
      this.cheque = false
      this.NEGS = false;
      this.card = false
    }
    bankID.updateValueAndValidity();
    bankBranchID.updateValueAndValidity();
    instrumentNumber.updateValueAndValidity();
    instrumentDate.updateValueAndValidity();
  }
  getallbranches() {
    let branch = {
      "OrganisationID": this.organisationID,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
      });
  }
  IsgstTypeId() {
    this.clientformdetails.get('gstTypeId').valueChanges.subscribe((data: number) => {
      console.log(data)
      this.onchangeIsgstTypeId(data)
    }
    )
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  getallclient() {
    this.clientOrgService.getALlClientOrg()
      .subscribe(result => {
        console.log(result)
        this.allclient = result.list
        if (this.allclient) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allclient.length
          }
        }
      }

      )
  }

  search() {
    console.log(this.searchform.value)
    this.clientOrgService.search(this.searchform.value)
      .subscribe(result => {
        console.log(result)

      })
  }
  clear() {
    this.searchform.reset()
  }
  btngEdit_Click(id: any) {
    this.clientHeading = 'Edit Advance Deposit- Client Organization';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.getbyid(id)
    this.fieldDisable = false;
  }
  btngView_Click(id: any) {
    this.clientHeading = 'View Advance Deposit- Client Organization';
    this.saveBtnMode = false;
    this.view = true;
    this.getbyid(id)
    this.fieldDisable = true;
  }
  getbyid(id) {
    this.clientOrgService.getClientById(id)
      .subscribe(result => {
        console.log(result)
        this.clientobj = result.masterGroupDetails
        this.clientformdetails = this.fb.group({
          groupId: { value: this.clientobj.groupId, disabled: false },
          groupName: [{ value: this.clientobj.groupName, disabled: false },],
          customerGroupId: [{ value: this.clientobj.customerGroupId, disabled: false },],
          coreBusiness: [{ value: this.clientobj.coreBusiness, disabled: false },],
          salutationId: [{ value: this.clientobj.salutationId, disabled: false }, Validators.required],
          contactFirstName: [{ value: this.clientobj.contactFirstName, disabled: false }, Validators.required],
          contactMiddleName: [{ value: this.clientobj.contactMiddleName, disabled: false },],
          contactLastName: [{ value: this.clientobj.contactLastName, disabled: false },],
          contact: [{ value: this.clientobj.contact, disabled: false },],
          masterPolicyAgeem: [{ value: this.clientobj.masterPolicyAgeem, disabled: false },],
          agreementStartDate: [{ value: this.clientobj.agreementStartDate, disabled: false },],
          agreementEndDate: [{ value: this.clientobj.agreementEndDate, disabled: false },],
          branchId: [{ value: this.clientobj.branchId, disabled: false },],
          email: [{ value: this.clientobj.email, disabled: false },],
          employeeURLKey: [{ value: this.clientobj.employeeURLKey, disabled: false },],
          password: [{ value: this.clientobj.password, disabled: false },],
          logo: [{ value: this.clientobj.logo, disabled: false },],
          createdBy: [{ value: this.clientobj.groupId, disabled: false },],
          createdOn: ['',],
          isActive: ['',],
          isSms: [{ value: this.clientobj.isSms, disabled: false }, ,],
          isEmail: [{ value: this.clientobj.isEmail, disabled: false },],
          shortName: [{ value: this.clientobj.shortName, disabled: false },],
          riskCategoryId: [{ value: this.clientobj.riskCategoryId, disabled: false },],
          turnOver: [{ value: this.clientobj.turnOver, disabled: false },],
          salesHierarchyId: [{ value: this.clientobj.salesHierarchyId, disabled: false },],
          isParentGroup: [{ value: this.clientobj.isParentGroup, disabled: false },],
          parentGroupId: [{ value: this.clientobj.parentGroupId, disabled: false },],
          hierarchyId: [{ value: this.clientobj.hierarchyId, disabled: false },],
          panNo: [{ value: this.clientobj.panNo, disabled: false },],
          gstNo: [{ value: this.clientobj.gstNo, disabled: false },],
          clientTypeId: [{ value: this.clientobj.clientTypeId, disabled: false },],
          gstTypeId: [{ value: this.clientobj.gstTypeId, disabled: false },],
          sacCode: [{ value: this.clientobj.sacCode, disabled: false },],
        })
        if (this.clientobj.clientTypeId === 1) {
          this.showgst = this.gst
          console.log(this.gst)
        }
        else if (this.clientobj.clientTypeId === 2) {
          this.showgst = this.sezgst_
          console.log(this.sezgst_)
        }
        this.onchangeIsgstTypeId(this.clientobj.gstTypeId)
        this.Addressdata = this.clientobj.clientAddressDetails
        this.gradelist = this.clientobj.MasterGrade
        if (this.clientobj.groupId) {
          this.advanceReceiptingService.mastPolicyNoGroupId(this.clientobj.groupId)
            .subscribe(result => {
              console.log(result)
              this.masterpolicyarr = result.response

            })
        }

      })
  }
  cancel() {
    this.textSaveBtn = 'Save'
    this.Addressdata = []
    this.gradelist = []
    this.clientformdetails.reset();
    this.clientHeading = 'Add Advance Deposit- Client Organization';
    this.saveBtnMode = true;
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  onchangeIsgstTypeId(selected: any) {
    this.IsgstType = false

    console.log(selected);
    const gstNo = this.clientformdetails.get('gstNo')


    if (selected === 1 || selected === 3) {
      this.submitted = false

      gstNo.setValidators(Validators.required);

      this.show = true;
    }
    else {
      gstNo.clearValidators();

      this.show = false
    }
    gstNo.updateValueAndValidity();
  }
  deleteclient() {
    this.clientOrgService.addClientOrganization(this.clientformdetails.value)
      .subscribe(result => {
        console.log(result)
      })
  }
  AddClient() {
    this.advancedreciptform.markAllAsTouched()
    this.advancedreciptform.value["paymentDate"] = moment(new Date(this.advancedreciptform.value["paymentDate"])).format('YYYY-MM-DD')
    console.log(this.advancedreciptform.value)
    // if (this.advancedreciptform.valid) {
      console.log(this.advancedreciptform.value)
      this.clientOrgService.addClientOrganization(this.advancedreciptform.value)
        .subscribe(result => {
          console.log(result)
          this.validform = true
          if (this.textSaveBtn === 'Update') {
            this.transaction = 'Client Organization updated Successufully'
            this.openModalDialog(this.transaction)
          }
          else {
            this.transaction = 'Client Organization Added Successufully'
            this.openModalDialog(this.transaction)
          }
          this.cancel()
        })
    // }

  }
  changepolicy(event: any) {
    console.log(event.value)
    this.advanceReceiptingService.getgridbypolicyid(event.value)
    .subscribe(result => {
      console.log(result)
 
    })
    let agreement = {
      insurermasteragreementno: event.value,
    }
    this.advancedreciptform.patchValue(agreement)
  }

  changeagreement(event: any) {
    let policy = {
      masterPolicyID: event.value
    }
    this.advancedreciptform.patchValue(policy)
  }
  GetAllSalutation() {
    this.user.GetAllSalutation()
      .subscribe(result => {
        console.log(result)
        this.salutation = result.salutationList
      })
  }

  Select_country(event: any) {
    console.log(event.target.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)
    this.change = true
    let zip = {
      ZipCode: '',
    }

    // this.BranchForm.patchValue(zip);
    this.GetTaluk(event.target.value);
  }
  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();

        }
        console.log(event.keyCode)
        // event.target.value = event.target.value.slice(0, 5).replace(/[^a-zA-Z]/g, "");
      }
      else if (l >= 5 && l <= 8) {

        console.log(l)
        console.log(charCode)
        // console.log(event.target.value.slice(5,9))
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l >= 8 && l <= 9) {
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  getdetailsbypin(a) {
    console.log(a)
    this.BranchService.GetAllDetailsByZipCode(a)
      .subscribe(result => {
        console.log(result)
        if (result.data.length > 0) {
          this.pinobj = result.data[0]
          this.GetAllStates(this.pinobj.countryID)
          this.GetAllDistricts(this.pinobj.stateID)

          let pin = {
            countryID: this.pinobj.countryID,
            stateID: this.pinobj.stateID,
            districtID: this.pinobj.districtID,

          }

          this.addressform.patchValue(pin);
        }
        else {
          let pin = {
            countryID: '',
            stateID: '',
            districtID: '',
          }

          this.addressform.patchValue(pin);
        }

      });
  }
  typeof(event: any) {
    this.showgst = []
    console.log(event.value)
    if (event.value === 1) {
      this.showgst = this.gst
      console.log(this.gst)
    }
    else if (event.value === 2) {
      this.showgst = this.sezgst_
      console.log(this.sezgst_)
    }
  }
  detectpin(event: any) {
    console.log(event.target.value.length);
    if (event.target.value.length === 6) {
      this.getdetailsbypin(this.addressform.value["zipCode"])
    }
  }
  pinValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if (charCode === 32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)

          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  get PanError() {
    // return this.email.hasError('required') ? 'You must enter a value' :
    //     this.email.hasError('email') ? 'Not a valid email' :
    //         '';
    if (this.clientformdetails.controls['panNo'].hasError('pattern')) {
      return 'Please enter valid PAN Number';
    } else if (this.clientformdetails.controls['panNo'].hasError('minlength')) {
      return 'Please Enter 10 digits of PAN Number.';
    }
  }
  openModalDialog(msg) {
    console.log(this.display)
    this.msg = msg
    this.display = 'block'; //Set block css
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.addressdelete = false
    this.gradedelete = false
    this.validform = false

  }
}


export interface PeriodicElement {
  ClientName: string;
  ClientId: number;
  CoreBusiness: string;
  ContactPersonName: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { ClientName: 'CitiFootballGroup', ClientId: 2012, CoreBusiness: 'Sports', ContactPersonName: 'Pep Joe' },
  { ClientName: 'ArsenalGunners', ClientId: 1996, CoreBusiness: 'Sports', ContactPersonName: 'Mikel Arteta' }
];
export class AffinityQuestionMap {
	clientName: string;
	masterPolicyNumber: string;	
}
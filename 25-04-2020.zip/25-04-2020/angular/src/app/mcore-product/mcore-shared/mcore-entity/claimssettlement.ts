import { DataRowOutlet } from '@angular/cdk/table';

export class Claimssettlement {

    paymentModeId: number;
    description: string;
    beneficiaryId: number;
    claimId: number;
    applicationId: number;
    claimNumber: number;
    policyNumber: string;
    insuredName: string;
    totalApprovedAmount:number;
    totalAmountPayable: number;
    approvedDate: Date;
    paymentmodeId: number;
    bankBankName: string;
    bankBranchName: string;
    accountName: string;
    accountNo: string;
    ifscCode: string;
    accountTypeId: number;
    chequeNo: string;
    chequeDate: Date;
    claimStatus: string;
}


export interface Beneficiary {
    beneficiaryId: number;
    description: string;
}

import { Injectable } from '@angular/core';
import { Subject, Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class McoreCommunicationService {
    public _bottomHeadSource = new BehaviorSubject({});


    sendData(data: any) {
        console.log(data)
        this._bottomHeadSource.next(data);
      }
    
}
import { TestBed } from '@angular/core/testing';

import { BankmasterService } from './bankmaster.service';

describe('BankmasterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BankmasterService = TestBed.get(BankmasterService);
    expect(service).toBeTruthy();
  });
});

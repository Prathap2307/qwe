import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Accountingsubhead } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingsubhead';

@Injectable({
  providedIn: 'root'
})
export class AccountingsubheadService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  // Get Select Account Head 
  accountHeadSelectUrl = this.baseUrl + `/GetAllAccountingHead`;
  getAccountHeadDetails(): Observable<Accountingsubhead[]> {
    return this.http.get<Accountingsubhead[]>(this.accountHeadSelectUrl).pipe();
  }

  // Get Search select Accounting Sub Head
  getAccountingSubHeadDetails(AccountHeadId: number): Observable<Accountingsubhead[]> {
    const AccountingSubheadUrl = this.baseUrl + `/GetAllSubAccountHeadbyAccountHead/${AccountHeadId}`;
    return this.http.get<Accountingsubhead[]>(AccountingSubheadUrl).pipe();
  }

  // Get Create & Update Accounting Sub Head
  createAccountingSubHeadUrl = this.baseUrl + `/CreateSubAccountHead`;
  addAccountingSubHeadDetails(accountsubhead: Accountingsubhead): Observable<Accountingsubhead[]> {
    return this.http.post<Accountingsubhead[]>(this.createAccountingSubHeadUrl, accountsubhead).pipe();
  }

  // Get Search & Grid Accounting Sub Head
  getAccountingSubHeadSearchDetails(Id: number, AccountHeadId: number, Code: number, Description: number): Observable<Accountingsubhead[]> {
    const accountSubHeadSearchUrl = this.baseUrl + `/GetAllSubAccountHeads/${Id}/${AccountHeadId}/${Code}/${Description}`;
    return this.http.get<Accountingsubhead[]>(accountSubHeadSearchUrl).pipe();
  }

}
